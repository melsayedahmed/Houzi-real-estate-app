
## Welcome to Houzi real estate app.

Houzi a real estate mobile application that connects with Houzez Wordpress theme.
A perfect compliment to your Houzez website, Houzi is a super flexible and powerful mobile app with top-notch features for real estate agents and companies.
Its build with Flutter so it can be deployed to Android and iOS.

Here are some useful links:

- Visit website here: https://houzi.booleanbites.com
- Visit documentation here: https://houzi-docs.booleanbites.com
- Download Android app: https://play.google.com/store/apps/details?id=com.booleanbites.houzez
- Download iOS app: https://apps.apple.com/us/app/id1598357211