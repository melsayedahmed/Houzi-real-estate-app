import 'package:houzi_package/houzi_main.dart' as houzi_package;
import 'Hooks.dart';
Future<void> main() async {

  Map<String,dynamic> hooksMap = {
    "headers" : IconHooks.getHeaderMap(),
    "propertyDetailPageIcons" : IconHooks.getPropertyDetailPageIconsMap(),
    "elegantHomeTermsIcons" : IconHooks.getElegantHomeTermsIconMap(),
    "drawerItems" : CustomDrawerHooks.getDrawerItems(),
    "widgetItems" : CustomWidgetHooks.getWidgetHook(),
    "fonts" : CustomFontsHooks.getFontHook(),
    "propertyItem" : CustomItemDesignHooks.getPropertyItemHook(),
    "termItem" : CustomItemDesignHooks.getTermItemHook(),
    "agentItem" : CustomItemDesignHooks.getAgentItemHook(),
    "agencyItem" : CustomItemDesignHooks.getAgencyItemHook(),
    "languageNameAndCode" : CustomLanguageHooks.getLanguageCodeAndName(),
    "defaultLanguageCode" : DefaultHook.getDefaultLanguageHook(),
    "defaultCountryCode" : DefaultHook.getDefaultCountryCodeHook(),
    "homeRightBarButtonWidget" : HomeRightBarButtonWidgetHookClass.getHomeRightBarButtonWidgetHookHook(),
    "profileItemHook" : ProfilePageHook.getProfileItemHook(),
    "settingsOption" : SettingsPageHook.getSettingsItemHook(),
  };

  return houzi_package.main(hooksMap,configurationsFilePath: "assets/configurations/configurations.json");
}



