import 'package:flutter/material.dart';
import 'package:houzi_package/dataProvider/locale_provider.dart';
import 'package:houzi_package/houzi_main.dart';
import 'package:houzi_package/l10n/l10n.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/models/drawer_menu_item.dart';
import 'package:houzi_package/models/realtor_model.dart';
import 'package:houzi_package/pages/home_page_screens/home_elegant_related/related_widgets/home_elegant_sliver_app_bar.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/all_agents.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/settings_page.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/phone_sign_in_widgets/user_get_phone_number.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_profile.dart';
import 'package:houzi_package/pages/property_details_related_pages/pd_widgets_listing.dart';
import 'package:houzi_package/widgets/article_box_widgets/article_box_design.dart';
import 'package:houzi_package/widgets/explore_by_type_design_widgets/explore_by_type_design.dart';
import 'package:houzi_package/widgets/generic_settings_row_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_drawer_widgets/home_screen_drawer_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_realtors_related_widgets/home_screen_realtors_list.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_sliver_app_bar_widgets/search_by_id_widget.dart';

class IconHooks {
  static getHeaderMap() {
    Map<String, dynamic> map = {
      // "secret_key": "!@#%^&*()_-+=",
      "secret_key": "",
    };
    return map;
  }

  static getPropertyDetailPageIconsMap() {
    Map<String, dynamic> _iconMap = {
      // "Air Conditioning": Icons.ac_unit_outlined,
    };

    return _iconMap;
  }

  static getElegantHomeTermsIconMap() {
    Map<String, dynamic> _iconMap = {
      // "for-rent": Icons.vpn_key_outlined,
    };

    return _iconMap;
  }
}

class CustomDrawerHooks {
  static getDrawerItems() {
    DrawerHook drawerHook = (BuildContext context) {
      DrawerItem drawerItem = DrawerItem(
        sectionType: "hook",
        title: "Agents",
        checkLogin: false,
        enable: true,
        icon: Icons.real_estate_agent_outlined,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AllAgents(),
            ),
          );
        },
        insertAt: 5,
      );

      List<dynamic> drawerItemList = [];

      return drawerItemList;
    };
    return drawerHook;
  }
}

class CustomFontsHooks {
  static getFontHook() {
    FontsHook fontsHook = (Locale locale) {
      // return "Ubuntu";
      // return "Qwitcher_Grypen";
      return "";
    };

    return fontsHook;
  }
}

class CustomItemDesignHooks {
  //provide your own design for property item
  static getPropertyItemHook() {
    PropertyItemHook propertyItemHook =
        (BuildContext context, Article article) {
      // return Container(
      //   child: Center(child: Text(article.title)),
      // );

      return null;
    };

    return propertyItemHook;
  }
  //provide your own design for term item design in the app
  static getTermItemHook() {
    TermItemHook termItemHook = (List metaDataList) {
      return null;
    };

    return termItemHook;
  }
  //provide your own designs for agent item design in the app.
  static getAgentItemHook() {
    AgentItemHook agentItemHook = (Agent item) {
      // return Container(
      //   height: 100,
      //   padding: EdgeInsets.only(
      //     bottom: 10,
      //   ),
      //   child: Card(
      //     // shape: AppThemePreferences.roundedCorners(AppThemePreferences.realtorPageRoundedCornersRadius),
      //     // elevation: AppThemePreferences.horizontalListForAgentsElevation,
      //     child: InkWell(
      //       borderRadius: const BorderRadius.all(Radius.circular(10)),
      //       onTap: () {
      //         // navigateToRealtorInformationDisplayPage(
      //         //   context: context,
      //         //   heroId: heroId,
      //         //   realtorType: tag == AGENTS_TAG ? AGENT_INFO : AGENCY_INFO,
      //         //   realtorInfo: tag == AGENTS_TAG ? {AGENT_DATA : item} : {AGENCY_DATA : item},
      //         // );
      //       },
      //       child: Container(
      //         // width: ,
      //         // height: 135,
      //         height: 100,
      //         padding: const EdgeInsets.symmetric(horizontal: 10),
      //         child: Text(
      //           item.title,
      //           textAlign: TextAlign.left,
      //           maxLines: 1,
      //           strutStyle: const StrutStyle(forceStrutHeight: true),
      //           overflow: TextOverflow.ellipsis,
      //           // style: AppThemePreferences().appTheme.homeScreenRealtorTitleTextStyle,
      //         ),
      //       ),
      //     ),
      //   ),
      // );
      return null;
    };
    return agentItemHook;
  }
  //provide your own design for agency item
  static getAgencyItemHook() {
    AgencyItemHook agencyItemHook = (Agency agency) {
      return null;
    };

    return agencyItemHook;
  }
}

class CustomWidgetHooks {
  //provide your own design for each section of the property page
  //you can use the provided details in Article (property)
  static getWidgetHook() {
    PropertyPageWidgetsHook detailsHook =
        (BuildContext context, Article article, String hook) {
      if (hook == 'article_images') {
        return null;
      } else if (hook == 'article_title') {
        return null;
      } else if (hook == 'article_address') {
        return null;
      } else if (hook == 'article_status_price') {
        return null;
      } else if (hook == 'valued_features') {
        return null;
      } else if (hook == 'article_features_details') {
        return null;
      } else if (hook == 'article_features') {
        return null;
      } else if (hook == 'article_description') {
        return null;
        // return descriptionWidget(article);
      } else if (hook == 'article_address_info') {
        return null;
      } else if (hook == 'article_map') {
        return null;
      } else if (hook == 'article_floor_plans') {
        return null;
      } else if (hook == 'article_multi_units') {
        return null;
      } else if (hook == 'article_contact_information') {
        return null;
      } else if (hook == 'enquire_info') {
        return null;
      } else if (hook == 'setup_tour') {
        return null;
      } else if (hook == 'watch_video') {
        return null;
      } else if (hook == 'virtual_tour') {
        return null;
      } else if (hook == 'article_related_posts') {
        return null;
      }
      return null;
    };

    return detailsHook;
  }
  //a sample widget for description in property details page.
  static Widget descriptionWidget(Article article) {
    if (article != null) {
      String content = article.content;
      return content != null && content.isNotEmpty
          ? Container(
              padding: const EdgeInsets.fromLTRB(20, 5, 20, 0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  content,
                  maxLines: 5,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.justify,
                ),
              ),
            )
          : Container();
    } else {
      return Container();
    }
  }

// static Widget descriptionWidget(Article article) {
//     return Text(
//       article.content,
//       maxLines: 5,
//       overflow: TextOverflow.ellipsis,
//       textAlign: TextAlign.justify,
//     );
// }
}

class CustomLanguageHooks {
  //add new language
  static getLanguageCodeAndName() {
    LanguageHook languageHook = () {
      ///  Make sure to add LANGUAGE-CODE_localization.json is added in asset and path
      ///  must be define in project level pubspec.yaml
      ///  assets/localization/LANGUAGE-CODE_localization.json

      Map<String,dynamic> russianLanguageMap = {
        "languageName": "Russian",
        "languageCode": "ru"
      };

      Map<String,dynamic> yourLanguageMap = {
        "languageName": "YOUR-LANGUAGE-NAME", // Specify your language name
        "languageCode": "YOUR-LANGUAGE-CODE"  // Specify your language code
      };

      Map<String,dynamic> amhericLanguageMap = {
        "languageName": "Amheric",
        "languageCode": "am"
      };

      Map<String,dynamic> turkishLanguageMap = {
        "languageName": "Turkish",
        "languageCode": "tr"
      };

      List<dynamic> languageList = [russianLanguageMap,amhericLanguageMap, turkishLanguageMap];
      return languageList;
    };

    return languageHook;
  }

}

class DefaultHook {

  static getDefaultLanguageHook() {
    DefaultLanguageCodeHook defaultLanguageCodeHook = () {
      /// Write here your default language code
      String defaultLanguage = "en";
      return defaultLanguage;
    };

    return defaultLanguageCodeHook;


  }

  static getDefaultCountryCodeHook() {
    DefaultCountryCodeHook defaultCountryCodeHook = () {
      /// return 2 Letter ISO Code to make it default country code for phone login
      return "PK";
    };

    return defaultCountryCodeHook;

  }
}

class HomeRightBarButtonWidgetHookClass {
  static getHomeRightBarButtonWidgetHookHook() {
    HomeRightBarButtonWidgetHook homeRightBarButtonWidgetHook = (context) {

      Widget rightBarButtonHook = null;
      // Widget rightBarButtonHook = SearchByIdWidget();
      
      return rightBarButtonHook;
    };

    return homeRightBarButtonWidgetHook;

  }
}

class SettingsPageHook{
  static getSettingsItemHook(){
    SettingsHook settingsHook = (BuildContext context){
      ///
      ///
      /// For info about adding Setting item visit below link:
      /// https://houzi-docs.booleanbites.com/hooks-widgets/add_item_settings/

      List<dynamic> settingsItemHookList = [
        // Add menu item map here
      ];
      return settingsItemHookList;
    };
    return settingsHook;
  }
}

class ProfilePageHook{
  static getProfileItemHook(){
    ProfileHook profileHook = (BuildContext context){
      ///
      ///
      /// For info about adding Profile item visit below link:
      /// https://houzi-docs.booleanbites.com/hooks-widgets/add_item_profile/

      List<Widget> profileItemHookList = [
        // Add menu item map here
      ];
      return profileItemHookList;
    };
    return profileHook;
  }
}
