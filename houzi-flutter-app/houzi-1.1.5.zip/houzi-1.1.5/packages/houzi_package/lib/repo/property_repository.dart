
import 'dart:core';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:houzi_package/dataProvider/property_api_provider.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/property_manager_files/property_manager.dart';
import 'package:houzi_package/models/custom_fields.dart';
import 'package:houzi_package/models/property_meta_data.dart';
import 'package:houzi_package/parsers/houzez_parser.dart';

import '../common/constants.dart';

class PropertyRepository{
  // PropertyApiProvider _propertyApiProvider = PropertyApiProvider(EPLApiProvider());
  PropertyApiProvider _propertyApiProvider = PropertyApiProvider(HOUZEZApiProvider());

  Future<List> fetchLatestArticlesList(int page) async {
    List<dynamic> latestArticles = [];
    final response = await _propertyApiProvider.fetchLatestArticlesResponse(page);

    if(response != null && response.data != null && response.statusCode == 200
        && response.data is Map && response.data.containsKey("result")){
      dynamic data = response.data["result"];
      List<dynamic> articles = data.map((m) =>
          _propertyApiProvider.getCurrentParser().parseArticle(m)).toList();
      latestArticles.addAll(articles);
    }else{
      if(response.statusCode == null){
        latestArticles = [response];
      }
    }

    return latestArticles;
  }

  Future<Map<String, dynamic>> fetchFilteredArticlesList(Map<String, dynamic> dataMap) async {
    Map<String, dynamic> articleMap = Map();
    final response = await _propertyApiProvider.fetchFilteredArticlesResponse(dataMap);

    if(response != null && response.data != null && response.statusCode == 200
        && response.data is Map && response.data.containsKey("result")){
      articleMap["count"] = response.data["count"];
      articleMap["result"] = response.data["result"].map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList();
    }else{
      if(response.statusCode == null){
        articleMap["response"] = response;
      }
    }

    return articleMap;
  }

  Future<List> fetchSimilarArticlesList(int propertyId) async {
    List<dynamic> similarArticles = [];
    final response = await _propertyApiProvider.fetchSimilarPropertiesResponse(propertyId);

    if(response != null && response.data != null && response.statusCode == 200
        && response.data is Map && response.data.containsKey("result")){
      similarArticles.addAll(response.data['result'].map((m) =>
          _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        similarArticles = [response];
      }
    }
    return similarArticles;
  }

  Future<List> fetchMultipleArticles(String propertiesId) async {
    List<dynamic> multipleArticles = [];
    final response = await _propertyApiProvider.fetchMultipleArticlesResponse(propertiesId);

    if(response != null && response.data != null && response.statusCode == 200){
      multipleArticles.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        multipleArticles = [response];
      }
    }
    return multipleArticles;
  }

  Future<List> fetchFeaturedArticlesList(int page) async {
    List<dynamic> featuredArticles = [];
    final response = await _propertyApiProvider.fetchFeaturedArticlesResponse(page);

    if(response != null && response.data != null && response.statusCode == 200){
      featuredArticles.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        featuredArticles = [response];
      }
    }

    return featuredArticles;
  }

  Future<List> fetchSingleArticleList(int id, {bool forEditing = false}) async {
    List<dynamic> singleArticle = [];
    final response = await _propertyApiProvider.fetchSingleArticleResponse(id, forEditing: forEditing);

    if(response != null && response.data != null && response.statusCode == 200){
      singleArticle.add(_propertyApiProvider.getCurrentParser().parseArticle(response.data));
    }else{
      if(response.statusCode == null) {
        singleArticle = [response];
      }
    }

    return singleArticle;
  }

  Future<Map<String, dynamic>> fetchPropertyMetaData() async {
    Map<String, dynamic> propertyMetaDataMap = {};
    final response = await _propertyApiProvider.fetchPropertyMetaDataApi();

    if(response != null && response.data != null && response.statusCode == 200){
      propertyMetaDataMap = response.data;
      if(propertyMetaDataMap != null){
        /// City Meta Data
        if(propertyMetaDataMap.containsKey('property_city')){
          var propertyCitiesData = propertyMetaDataMap["property_city"];
          if(propertyCitiesData != null && propertyCitiesData is List && propertyCitiesData.isNotEmpty){
            List<dynamic> _cityMetaDataList = propertyCitiesData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storeCitiesMetaData(_cityMetaDataList);
          }
        }
        /// Property Type Meta Data
        if(propertyMetaDataMap.containsKey('property_type')){
          var propertyTypesData = propertyMetaDataMap["property_type"];
          if(propertyTypesData != null && propertyTypesData is List && propertyTypesData.isNotEmpty){
            List<dynamic> _propertyTypeMetaDataList = propertyTypesData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyTypesMetaData(_propertyTypeMetaDataList);
            List<dynamic> parentCategoryList = [];
            List<dynamic> subCategoryList = [];
            Map<String, dynamic> _propertyTypesDataMap = {};
            /// Get Parent Categories List
            _propertyTypeMetaDataList.forEach((element) {
              if(element.parent == 0){
                parentCategoryList.add(element);
              }
            });
            /// Get sub Categories List if there is any...
            if(parentCategoryList.length != _propertyTypeMetaDataList.length){
              /// Get sub Categories List against each parent
              parentCategoryList.forEach((firstElement) {
                _propertyTypeMetaDataList.forEach((secondElement) {
                  if (firstElement.id == secondElement.parent) {
                    subCategoryList.add(secondElement);
                  }
                });
                _propertyTypesDataMap[firstElement.name] = subCategoryList;
                subCategoryList = [];
              });
              HiveStorageManager.storePropertyTypesMapData(_propertyTypesDataMap);
            }
          }
        }
        /// Property Country Meta Data
        if(propertyMetaDataMap.containsKey('property_country')){
          var countriesMetaData = propertyMetaDataMap['property_country'];
          if(countriesMetaData != null && countriesMetaData is List && countriesMetaData.isNotEmpty){
            List<dynamic> _propertyCountriesMetaDataList = countriesMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyCountriesMetaData(_propertyCountriesMetaDataList);
          }
        }
        /// Property State Meta Data
        if(propertyMetaDataMap.containsKey('property_state')){
          var propertyStateMetaData = propertyMetaDataMap['property_state'];
          if(propertyStateMetaData != null && propertyStateMetaData is List && propertyStateMetaData.isNotEmpty){
            List<dynamic> _propertyStateMetaDataList = propertyStateMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyStatesMetaData(_propertyStateMetaDataList);
          }
        }
        /// Property Area Meta Data
        if(propertyMetaDataMap.containsKey('property_area')){
          var propertyAreaMetaData = propertyMetaDataMap['property_area'];
          if(propertyAreaMetaData != null && propertyAreaMetaData is List && propertyAreaMetaData.isNotEmpty){
            List<dynamic> _propertyAreaMetaDataList = propertyAreaMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyAreaMetaData(_propertyAreaMetaDataList);
          }
        }
        /// Property Label Meta Data
        if(propertyMetaDataMap.containsKey('property_label')){
          var propertyLabelMetaData = propertyMetaDataMap['property_label'];
          if(propertyLabelMetaData != null && propertyLabelMetaData is List && propertyLabelMetaData.isNotEmpty){
            List<dynamic> _propertyLabelMetaDataList = propertyLabelMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyLabelsMetaData(_propertyLabelMetaDataList);
          }
        }
        /// Property Status Meta Data
        if(propertyMetaDataMap.containsKey('property_status')){
          var propertyStatusMetaData = propertyMetaDataMap['property_status'];
          if(propertyStatusMetaData != null && propertyStatusMetaData is List && propertyStatusMetaData.isNotEmpty){
            List<dynamic> _propertyStatusMetaDataList = propertyStatusMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            List tempList = _propertyStatusMetaDataList;
            // for(int i = 0; i<tempList.length ;i++){
            //   if(tempList[i].parent != 0){
            //     tempList.removeAt(i);
            //   }
            // }
            // print("tempList$tempList");
            // print("_propertyStatusMetaDataList$_propertyStatusMetaDataList");
            HiveStorageManager.storePropertyStatusMetaData(tempList);
            List<dynamic> parentCategoryList = [];
            List<dynamic> subCategoryList = [];
            Map<String, dynamic> _propertyStatusDataMap = {};
            /// Get Parent Categories List
            _propertyStatusMetaDataList.forEach((element) {
              if(element.parent == 0){
                parentCategoryList.add(element);
              }
            });
            /// Get sub Categories List if there is any...
            if(parentCategoryList.length != _propertyStatusMetaDataList.length){
              /// Get sub Categories List against each parent
              for (var firstElement in parentCategoryList) {
                for (var secondElement in _propertyStatusMetaDataList) {
                  if (firstElement.id == secondElement.parent) {
                    subCategoryList.add(secondElement);
                  }
                }
                _propertyStatusDataMap[firstElement.name] = subCategoryList;
                subCategoryList = [];
              }
              //print('_propertyStatusDataMap after adding child:$_propertyStatusDataMap');
              HiveStorageManager.storePropertyStatusMapData(_propertyStatusDataMap);
            }
          }
        }
        /// Property Features Meta Data
        if(propertyMetaDataMap.containsKey('property_feature')){
          var propertyFeaturesMetaData = propertyMetaDataMap['property_feature'];
          if(propertyFeaturesMetaData != null && propertyFeaturesMetaData is List && propertyFeaturesMetaData.isNotEmpty){
            List<dynamic> _propertyFeaturesMetaDataList = propertyFeaturesMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyFeaturesMetaData(_propertyFeaturesMetaDataList);
          }
        }
        ///  Schedule Time Slots Meta Data
        if(propertyMetaDataMap.containsKey('schedule_time_slots')){
          var scheduleTimeSlotsMetaData = propertyMetaDataMap["schedule_time_slots"];
          if(scheduleTimeSlotsMetaData != null && scheduleTimeSlotsMetaData is String && scheduleTimeSlotsMetaData.isNotEmpty){
            HiveStorageManager.storeScheduleTimeSlotsInfoData(scheduleTimeSlotsMetaData);
          }
        }
        ///  Default Currency Meta Data
        if(propertyMetaDataMap.containsKey('default_currency')){
          var defaultCurrencyMetaData = propertyMetaDataMap["default_currency"];
          if(defaultCurrencyMetaData != null && defaultCurrencyMetaData is String && defaultCurrencyMetaData.isNotEmpty){
            HiveStorageManager.storeDefaultCurrencyInfoData(defaultCurrencyMetaData);
          }
        }
        ///  Enquiry Type Meta Data
        if(propertyMetaDataMap.containsKey('enquiry_type')){
          var enquiryTypeMetaData = propertyMetaDataMap["enquiry_type"];
          if(enquiryTypeMetaData != null && enquiryTypeMetaData is String && enquiryTypeMetaData.isNotEmpty){
            HiveStorageManager.storeInquiryTypeInfoData(enquiryTypeMetaData);
          }
        }

        if(propertyMetaDataMap.containsKey('user_roles')){
          var userRoleList = propertyMetaDataMap["user_roles"];
          if(userRoleList != null && userRoleList.isNotEmpty){
            HiveStorageManager.storeUserRoleListData(userRoleList);
          }
        }

        if(propertyMetaDataMap.containsKey('all_user_roles')){
          var userRoleList = propertyMetaDataMap["all_user_roles"];
          if(userRoleList != null && userRoleList.isNotEmpty){
            HiveStorageManager.storeAdminUserRoleListData(userRoleList);
          }
        }

        if(propertyMetaDataMap.containsKey('property_reviews')){
          var propertyReviews = propertyMetaDataMap["property_reviews"];
          if(propertyReviews != null && propertyReviews.isNotEmpty){
            if(propertyReviews == "1"){
              SHOW_REVIEWS = true;
            }else{
              SHOW_REVIEWS = false;
            }
          }else{
            SHOW_REVIEWS = false;
          }
        }

        if (propertyMetaDataMap.containsKey("custom_fields")) {
          var data = propertyMetaDataMap["custom_fields"];
          if (data != null && data.isNotEmpty) {
            final custom = customFromJson(response.toString());
            HiveStorageManager.storeCustomFieldsDataMaps(customToJson(custom));
          }
        }

        if (propertyMetaDataMap.containsKey("currency_position")) {
          var data = propertyMetaDataMap["currency_position"];
          if (data != null && data.isNotEmpty) {
            CURRENCY_POSITION = data;
          }
        }

        if (propertyMetaDataMap.containsKey("thousands_separator")) {
          var data = propertyMetaDataMap["thousands_separator"];
          if (data != null && data.isNotEmpty) {
            THOUSAND_SEPARATOR = data;
          }
        }

        if (propertyMetaDataMap.containsKey("decimal_point_separator")) {
          var data = propertyMetaDataMap["decimal_point_separator"];
          if (data != null && data.isNotEmpty) {
            DECIMAL_POINT_SEPARATOR = data;
          }
        }

        if (propertyMetaDataMap.containsKey("add-prop-gdpr-enabled")) {
          var data = propertyMetaDataMap["add-prop-gdpr-enabled"];
          if (data != null && data.isNotEmpty) {
            ADD_PROP_GDPR_ENABLED = data;
          }
        }

        if (propertyMetaDataMap.containsKey("measurement_unit_global")) {
          var data = propertyMetaDataMap["measurement_unit_global"];
          if (data != null && data.isNotEmpty) {
            MEASUREMENT_UNIT_GLOBAL = data;
          }
        }

        if (propertyMetaDataMap.containsKey("measurement_unit_text")) {
          var data = propertyMetaDataMap["measurement_unit_text"];
          if (data != null && data.isNotEmpty) {
            MEASUREMENT_UNIT_TEXT = data;
          }
        }

        // if (propertyMetaDataMap.containsKey("mobile_app_config")) {
        //   var data = propertyMetaDataMap["mobile_app_config"];
        //   if (data != null && data.isNotEmpty) {
        //     // print(GenericMethods.cleanContent(data));
        //     HiveStorageManager.storeAppConfigurations(jsonEncode(GenericMethods.convertMap(data)));
        //     // print(jsonDecode(GenericMethods.cleanContent(data)));
        //   }
        // }
      }
    }else{
      if(response.statusCode == null){
        propertyMetaDataMap["response"] = response;
      }
    }

    return propertyMetaDataMap;
  }

  Future<List> fetchSingleAgencyInfoList(int id) async {
    List<dynamic> singleAgencyInfo = [];
    final response = await _propertyApiProvider.fetchSingleAgencyInfoApi(id);

    if(response != null && response.data != null && response.statusCode == 200){
      singleAgencyInfo.add(_propertyApiProvider.getCurrentParser().parseAgencyInfo(response.data));
    }else{
      if(response.statusCode == null) {
        singleAgencyInfo = [response];
      }
    }

    return singleAgencyInfo;
  }

  Future<List> fetchSingleAgentInfoList(int id) async {
    List<dynamic> singleAgentInfo = [];
    final response = await _propertyApiProvider.fetchSingleAgentInfoApi(id);

    if(response != null && response.data != null && response.statusCode == 200){
      singleAgentInfo.add(_propertyApiProvider.getCurrentParser().parseAgentInfo(response.data));
    }else{
      if(response.statusCode == null) {
        singleAgentInfo = [response];
      }
    }

    return singleAgentInfo;
  }

  Future<List> fetchAgencyAgentInfoList(int id) async {
    List<dynamic> agencyAgentInfo = [];
    final response = await _propertyApiProvider.fetchAgencyAgentInfoApi(id);

    if(response != null && response.data != null && response.statusCode == 200){
      agencyAgentInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgentInfo(m)).toList());
    }else{
      if(response.statusCode == null) {
        agencyAgentInfo = [response];
      }
    }

    return agencyAgentInfo;
  }

  Future<List> fetchAgencyAllAgentList(int id) async {
    List<dynamic> agencyAgentInfo = [];
    final response = await _propertyApiProvider.fetchAgencyAllAgentListApi(id);

    if(response != null && response.data != null && response.statusCode == 200){
      agencyAgentInfo.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgentInfo(m)).toList());
    }else{
      if(response.statusCode == null) {
        agencyAgentInfo = [response];
      }
    }

    return agencyAgentInfo;
  }

  Future<List> fetchPropertiesByAgencyList(int id, int page, int perPage) async {
    List<dynamic> propertiesByAgencyList = [];
    final response = await _propertyApiProvider.fetchPropertiesByAgencyApi(id, page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesByAgencyList.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesByAgencyList = [response];
      }
    }

    return propertiesByAgencyList;
  }

  Future<List> fetchPropertiesByAgentList(int id, int page, int perPage) async {
    List<dynamic> propertiesByAgentList = [];
    final response = await _propertyApiProvider.fetchPropertiesByAgentApi(id, page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesByAgentList.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesByAgentList = [response];
      }
    }

    return propertiesByAgentList;
  }

  Future<List> fetchAllAgentsInfoList(int page, int perPage) async {
    List<dynamic> allAgentsInfo = [];
    final response = await _propertyApiProvider.fetchAllAgentsApi(page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      allAgentsInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgentInfo(m)).toList());
    }else{
      if(response.statusCode == null) {
        allAgentsInfo = [response];
      }
    }

    return allAgentsInfo;
  }

  Future<List> fetchAllAgenciesInfoList(int page, int perPage) async {
    List<dynamic> allAgenciesInfo = [];
    final response = await _propertyApiProvider.fetchAllAgenciesApi(page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      allAgenciesInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgencyInfo(m)).toList());
    }else{
      if(response.statusCode == null) {
        allAgenciesInfo = [response];
      }
    }

    return allAgenciesInfo;
  }

  Future<List> fetchPropertiesInCityList(int id, int page, int perPage) async {
    List<dynamic> propertiesInCityArticles = [];
    final response = await _propertyApiProvider.fetchPropertiesInCityApi(id, page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesInCityArticles.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesInCityArticles = [response];
      }
    }

    return propertiesInCityArticles;
  }

  Future<List> fetchPropertiesByTypeList(int id, int page, int perPage) async {
    List<dynamic> propertiesByTypeArticles = [];
    final response = await _propertyApiProvider.fetchPropertiesByTypeApi(id, page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesByTypeArticles.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesByTypeArticles = [response];
      }
    }

    return propertiesByTypeArticles;
  }

  Future<List> fetchPropertiesInCityByTypeList(int cityId, int typeId, int page, int perPage) async {
    List<dynamic> propertiesInCityByTypeArticles = [];
    final response = await _propertyApiProvider.fetchPropertiesInCityByTypeApi(cityId, typeId, page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesInCityByTypeArticles.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesInCityByTypeArticles = [response];
      }
    }

    return propertiesInCityByTypeArticles;
  }

  Future<Response> fetchContactRealtorResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchContactRealtorResponse(dataMap);
    return response;
  }

  Future<Response> fetchContactDeveloperResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchContactDeveloperResponse(dataMap);
    return response;
  }

  Future<Response> fetchLoginResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchLoginResponse(dataMap);
    return response;
  }

  Future<Response> fetchScheduleATourResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchScheduleATourResponse(dataMap);
    return response;
  }

  Future<Response> fetchAddPropertyResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddPropertyResponse(dataMap);
    return response;
  }

  Future<List> fetchActivitiesFromBoard(int page,int perPage ,int userId) async {
    List<dynamic> activities = [];
    final response = await _propertyApiProvider.fetchActivitiesFromBoardResponse(page,perPage,userId);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data["results"];
      dynamic mapped = results.map((m) {
        return _propertyApiProvider.getCurrentParser().parseActivities(m);
      });
      activities.addAll(mapped.toList());
    }else{
      if(response.statusCode == null) {
        activities = [response];
      }
    }

    return activities;
  }

  Future<List> fetchInquiriesFromBoard(int page, int perPage, int userId) async {
    List<dynamic> inquiries = [];
    final response = await _propertyApiProvider.fetchInquiriesFromBoardResponse(page, perPage, userId);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data["results"];
      dynamic mapped = results.map((m) {
        return _propertyApiProvider.getCurrentParser().parseInquiries(m);
      });
      inquiries.addAll(mapped.toList());
    }else{
      if(response.statusCode == null) {
        inquiries = [response];
      }
    }

    return inquiries;
  }

  Future<List> fetchLeadsFromActivity(int page, int userId) async {
    List<dynamic> leads = [];
    final response = await _propertyApiProvider.fetchLeadsFromActivityResponse(page,userId);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data;
      leads.add(_propertyApiProvider.getCurrentParser().parseLeads(results));
    }else{
      if(response.statusCode == null) {
        leads = [response];
      }
    }

    return leads;
  }

  Future<Response> fetchSigupResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchSignUpResponse(dataMap);
    return response;
  }

  Future<List<dynamic>> fetchAllProperties(String status, int page, int perPage, int userId) async {
    List<dynamic> _propertiesList = [];
    final response = await _propertyApiProvider.fetchAllProperties(status,page,perPage, userId);

    if(response != null && response.data != null && response.statusCode == 200){
      _propertiesList.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        _propertiesList = [response];
      }
    }

    return _propertiesList;
  }

  Future<Response> statusOfProperty(Map<String, dynamic> dataMap,int id) async {
    final response = await _propertyApiProvider.statusOfProperty(dataMap,id);
    return response;
  }

  Future<Response> deleteProperty(int id) async {
    final response = await _propertyApiProvider.deleteProperty(id);
    return response;
  }

  Uri provideSavePropertyImagesApi() {
    var uri = _propertyApiProvider.provideSavePropertyImagesApi();
    return uri;
  }

  Future<List<dynamic>> fetchMyProperties(String status, int page, int perPage,int userId) async {
    List<dynamic> _propertiesList = [];
    final response = await _propertyApiProvider.fetchMyProperties(status, page, perPage, userId);

    if(response != null && response.data != null && response.statusCode == 200
        && response.data["success"]){
      _propertiesList.addAll(response.data["result"].map((m) =>
          _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        _propertiesList = [response];
      }
    }

    return _propertiesList;
  }

  Future<Response> fetchForgetPasswordResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchForgetPasswordResponse(dataMap);
    return response;
  }

  Future<List> fetchDealsFromActivity(int page, int userId) async {
    List<dynamic> deals = [];
    final response = await _propertyApiProvider.fetchDealsFromActivityResponse(page,userId);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data;
      deals.add(_propertyApiProvider.getCurrentParser().parseDeals(results));
    }else{
      if(response.statusCode == null) {
        deals = [response];
      }
    }

    return deals;
  }

  Future<List<dynamic>> fetchDealsFromBoard(int page,int perPage, String tab) async {
    List<dynamic> dealsList = [];
    final response = await _propertyApiProvider.fetchDealsFromBoardResponse(page,perPage,tab);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data["results"];
      dynamic mapped = results.map((m) {
        return _propertyApiProvider.getCurrentParser().parseDealsAndLeadsFromBoard(m);
      });
      dealsList.addAll(mapped.toList());
    }else{
      if(response.statusCode == null) {
        dealsList = [response];
      }
    }

    return dealsList;
  }

  Future<Response> fetchAddDealResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddDealResponse(dataMap);
    return response;
  }

  Future<List<dynamic>> fetchLeadsFromBoard(int page,int perPage) async {
    List<dynamic> dealsList = [];
    final response = await _propertyApiProvider.fetchLeadsFromBoard(page,perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data["results"];
      dynamic mapped = results.map((m) {
        return _propertyApiProvider.getCurrentParser().parseDealsAndLeadsFromBoard(m);
      });
      dealsList.addAll(mapped.toList());
    }else{
      if(response.statusCode == null) {
        dealsList = [response];
      }
    }

    return dealsList;
  }

  Future<Response> fetchDeleteDeal(int id) async {
    final response = await _propertyApiProvider.fetchDeleteDeal(id);
    return response;
  }

  Future<Response> fetchAddInquiryResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddInquiryResponse(dataMap);
    return response;
  }

  Future<Response> fetchDeleteInquiry(int id) async {
    final response = await _propertyApiProvider.fetchDeleteInquiry(id);
    return response;
  }

  Future<List> fetchTermData(String termData) async {
    Map<String, dynamic> metaDataMap = {};
    List<dynamic> metaDataList = [];
    final response = await _propertyApiProvider.fetchTermDataApi(termData);

    if(response != null && response.data != null && response.statusCode == 200){
      metaDataMap = response.data;
      if(metaDataMap != null){
        /// Property Area Meta Data
        if(metaDataMap.containsKey('property_area')){
          var propertyAreaMetaData = metaDataMap['property_area'];
          if(propertyAreaMetaData != null && propertyAreaMetaData is Map && propertyAreaMetaData.isNotEmpty){
            if(propertyAreaMetaData.containsKey("errors")){
              SHOW_NEIGHBOURHOOD_FIELD = false;
            }
          }else if(propertyAreaMetaData != null && propertyAreaMetaData is List && propertyAreaMetaData.isNotEmpty){
            metaDataList = propertyAreaMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyAreaMetaData(metaDataList);
          }
        }
        /// Property State Meta Data
        else if(metaDataMap.containsKey('property_state')){
          var propertyStateMetaData = metaDataMap['property_state'];
          if(propertyStateMetaData != null && propertyStateMetaData is Map && propertyStateMetaData.isNotEmpty){
            if(propertyStateMetaData.containsKey("errors")){
              SHOW_STATE_COUNTY_FIELD = false;
            }
          }else if(propertyStateMetaData != null && propertyStateMetaData is List && propertyStateMetaData.isNotEmpty){
            metaDataList = propertyStateMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyStatesMetaData(metaDataList);
          }
        }
        /// Property Country Meta Data
        else if(metaDataMap.containsKey('property_country')){
          var countriesMetaData = metaDataMap['property_country'];
          if(countriesMetaData != null && countriesMetaData is Map && countriesMetaData.isNotEmpty){
            if(countriesMetaData.containsKey("errors")){
              SHOW_COUNTRY_NAME_FIELD = false;
            }
          }else if(countriesMetaData != null && countriesMetaData is List && countriesMetaData.isNotEmpty){
            metaDataList = countriesMetaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storePropertyCountriesMetaData(metaDataList);
          }
        }
        /// City Meta Data
        else if(metaDataMap.containsKey('property_city')){
          var propertyCitiesData = metaDataMap["property_city"];
          if(propertyCitiesData != null && propertyCitiesData is Map && propertyCitiesData.isNotEmpty){
            if(propertyCitiesData.containsKey("errors")){
              SHOW_LOCALITY_FIELD = false;
            }
          }else if(propertyCitiesData != null && propertyCitiesData is List && propertyCitiesData.isNotEmpty){
            metaDataList = propertyCitiesData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            HiveStorageManager.storeCitiesMetaData(metaDataList);
          }
        }

        else if(termData=='agent_city' || termData=='agent_category'){
          if(metaDataMap.containsKey('agent_city')){
            var propertyAreaData = metaDataMap['agent_city'];
            if(propertyAreaData != null && propertyAreaData is List){
              if(propertyAreaData.isNotEmpty){
                metaDataList = propertyAreaData.map((m) => _propertyApiProvider.getCurrentParser().parseAgentMetaData(m)).toList();
              }
            }
          }
          else if(metaDataMap.containsKey('agent_category')){
            var propertyAreaData = metaDataMap['agent_category'];
            if(propertyAreaData != null && propertyAreaData is List){
              if(propertyAreaData.isNotEmpty){
                metaDataList = propertyAreaData.map((m) => _propertyApiProvider.getCurrentParser().parseAgentMetaData(m)).toList();
              }
            }
          }
        }

        else if(metaDataMap.containsKey(termData)){
          var propertyAreaData = metaDataMap[termData];
          if(propertyAreaData != null && propertyAreaData is List){
            if(propertyAreaData.isNotEmpty){
              metaDataList = propertyAreaData.map((m) => _propertyApiProvider.getCurrentParser().parseMetaDataMap(m)).toList();
            }
          }
        }
      }
    }else{
      if(response.statusCode == null) {
        metaDataList = [response];
      }
    }

    return metaDataList;
  }

  Future<Response> fetchAddOrRemoveFromFavResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddOrRemoveFromFavResponse(dataMap);
    return response;
  }

  Future<List<dynamic>> fetchFavProperties(int page, int perPage, String userIdStr) async {
    List<dynamic> _propertiesList = [];
    final response = await _propertyApiProvider.fetchFavProperties(page, perPage, userIdStr);

    if(response != null && response.data != null && response.statusCode == 200
        && response.data["success"]){
      _propertiesList.addAll(response.data['result'].map((m) {
        if (m is Map<dynamic, dynamic>) {
          m = GenericMethods.convertMap(m);
        }
        return _propertyApiProvider.getCurrentParser().parseArticle(m);
      }).toList());
    }else{
      if(response.statusCode == null) {
        _propertiesList = [response];
      }
    }

    return _propertiesList;
  }

  Future<Response> fetchDeleteLead(int id) async {
    final response = await _propertyApiProvider.fetchDeleteLead(id);
    return response;
  }

  Future<Response> fetchUpdatePropertyResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchUpdatePropertyResponse(dataMap);
    return response;
  }

  Future<List> fetchLatLongArticles(String lat,String long, String radius) async {
    List<dynamic> latestArticles = [];
    final response = await _propertyApiProvider.fetchLatLongArticlesResponse(lat,long,radius);

    if(response != null && response.data != null && response.statusCode == 200){
      latestArticles.addAll(response.data["result"].map((m) =>
          _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        latestArticles = [response];
      }
    }

    return latestArticles;
  }

  Future<Response> fetchDeleteImageFromEditProperty(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchDeleteImageFromEditProperty(dataMap);
    return response;
  }

  Future<Response> fetchAddSavedSearch(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddSavedSearch(dataMap);
    return response;
  }

  Future<List<dynamic>> fetchSavedSearches(int page, int perPage) async {
    List<dynamic> savedSearchList = [];
    final response = await _propertyApiProvider.fetchSavedSearches(page, perPage);

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data["results"];
      dynamic mapped = results.map((m) {
        return _propertyApiProvider.getCurrentParser().parseSavedSearch(m);
      });
      savedSearchList.addAll(mapped.toList());
    }else{
      if(response.statusCode == null) {
        savedSearchList = [response];
      }
    }

    return savedSearchList;
  }

  Future<Response> fetchDeleteSavedSearch(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchDeleteSavedSearch(dataMap);
    return response;
  }

  Future<List> fetchSavedSearchArticles(Map<String, dynamic> dataMap) async {
    List<dynamic> filteredArticles = [];
    final response = await _propertyApiProvider.fetchSavedSearchArticlesResponse(dataMap);

    if(response != null && response.data != null && response.statusCode == 200){
      filteredArticles.addAll(response.data["result"].map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        filteredArticles = [response];
      }
    }

    return filteredArticles;
  }

  Future<Response> fetchAddReviewResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddReviewResponse(dataMap);
    return response;
  }

  Future<List> fetchArticlesReviews(int id,String page, String perPage) async {
      List<dynamic> articlesReviews = [];
      final response = await _propertyApiProvider.fetchArticlesReviewsResponse(id,page,perPage);

      if(response != null && response.data != null && response.statusCode == 200){
        articlesReviews.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
      }else{
        if(response.statusCode == null) {
          articlesReviews = [response];
        }
      }

      return articlesReviews;
  }

  Future<List<dynamic>> fetchAgentAgencyAuthorReviews(int id,String page, String perPage, String type) async {
    List<dynamic> articlesReviews = [];
    final response = await _propertyApiProvider.fetchAgentAgencyAuthorReviewsResponse(id,page,perPage,type);

    if(response != null && response.data != null && response.statusCode == 200){
      articlesReviews.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        articlesReviews = [response];
      }
    }

    return articlesReviews;
  }

  Future<List> fetchUserInfo() async {
    List<dynamic> userInfo = [];
    final response = await _propertyApiProvider.fetchUserInfoResponse();

    if(response != null && response.data != null && response.statusCode == 200){
      var data;
      if(response.data is String){
        Map map = json.decode(response.data);
        data = _propertyApiProvider.getCurrentParser().parseUserInfo(map);
      }else{
        data = _propertyApiProvider.getCurrentParser().parseUserInfo(response.data);
      }
      userInfo.add(data);
    }else{
      if(response.statusCode == null) {
        userInfo = [response];
      }
    }

    return userInfo;
  }

  Future<Response> fetchUpdateUserProfileResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchUpdateUserProfileResponse(dataMap);
    return response;
  }

  Future<Response> fetchUpdateUserProfileImageResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchUpdateUserProfileImageResponse(dataMap);
    return response;
  }

  Future<List> fetchDealsAndLeadsFromActivity() async {
    List<dynamic> deals = [];
    final response = await _propertyApiProvider.fetchDealsAndLeadsFromActivityResponse();

    if(response != null && response.data != null && response.statusCode == 200){
      final results = response.data;
      deals.add(_propertyApiProvider.getCurrentParser().parseDealsAndLeadsFromActivity(results));
    }else{
      if(response.statusCode == null) {
        deals = [response];
      }
    }

    return deals;
  }

  Future<List> fetchSearchAgentsList(int page, int perPage,String search,String agentCity,String agentCategory) async {
    List<dynamic> allAgentsInfo = [];
    final response = await _propertyApiProvider.fetchSearchAgentsApi(page, perPage,search,agentCity,agentCategory);

    if(response != null && response.data != null && response.statusCode == 200){
      allAgentsInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgentInfo(m)).toList());
    }else{
      if(response.statusCode == null) {
        allAgentsInfo = [response];
      }
    }

    return allAgentsInfo;
  }

  Future<List> fetchSearchAgenciesList(int page, int perPage,String search) async {
    List<dynamic> allAgenciesInfo = [];
    final response = await _propertyApiProvider.fetchSearchAgenciesApi(page, perPage,search);

    if(response != null && response.data != null && response.statusCode == 200){
      allAgenciesInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgencyInfo(m)).toList());
    }else{
      if(response.statusCode == null) {
        allAgenciesInfo = [response];
      }
    }

    return allAgenciesInfo;
  }

  Future<Response> fetchFixProfileImageResponse() async {
    final response = await _propertyApiProvider.fetchFixProfileImageResponse();
    return response;
  }

  Future<Response> fetchIsFavProperty(String listingId) async {
    final response = await _propertyApiProvider.fetchIsFavPropertyApi(listingId);
    return response;
  }

  Future<Response> fetchSocialSignOnResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchSocialSignOnResponse(dataMap);
    return response;
  }

  Future<List> fetchPropertiesByType(int page,int id,String type) async {
    List<dynamic> propertiesByType = [];
    final response = await _propertyApiProvider.fetchPropertiesByTypeResponse(page, id, type);

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesByType.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesByType = [response];
      }
    }

    return propertiesByType;
  }

  Future<List> fetchRealtorInfoList(int page, String type) async {
    List<dynamic> realtorInfo = [];
    final response = await _propertyApiProvider.fetchRealtorInfoApi(page, type);

    if(response != null && response.data != null && response.statusCode == 200){
      if (type == REST_API_AGENT_ROUTE) {
        realtorInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgentInfo(m)).toList());
      } else {
        realtorInfo.add(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseAgencyInfo(m)).toList());
      }
    }else{
      if(response.statusCode == null) {
        realtorInfo = [response];
      }
    }

    return realtorInfo;
  }

  Future<Response> fetchDeleteUserAccountResponse() async {
    final response = await _propertyApiProvider.fetchDeleteUserAccountResponse();
    return response;
  }

  Future<Response> fetchUpdateUserPasswordResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchUpdateUserPasswordResponse(dataMap);
    return response;
  }

  Future<Response> fetchAddLeadResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddLeadResponse(dataMap);
    return response;
  }

  Future<List> fetchSingleArticleViaPermaLink(String permaLink) async {
    List<dynamic> singleArticle = [];
    final response = await _propertyApiProvider.fetchSingleArticleViaPermaLinkResponse(permaLink);




    if(response != null && response.data != null && response.statusCode == 200){
      singleArticle.add(_propertyApiProvider.getCurrentParser().parseArticle(response.data));
    }else{
      if(response.statusCode == null) {
        singleArticle = [response];
      }
    }

    return singleArticle;
  }



  Future<Response> fetchAddRequestPropertyResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddRequestPropertyResponse(dataMap);
    return response;
  }

  Future<List> fetchPropertiesAds() async {

    List<dynamic> propertiesByType = [];
    final response = await _propertyApiProvider.fetchPropertiesAdsResponse();

    if(response != null && response.data != null && response.statusCode == 200){
      propertiesByType.addAll(response.data.map((m) => _propertyApiProvider.getCurrentParser().parseArticle(m)).toList());
    }else{
      if(response.statusCode == null) {
        propertiesByType = [response];
      }
    }
    return propertiesByType;
  }

  Future<Response> fetchAddAgentResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchAddAgentResponse(dataMap);
    return response;
  }

  Future<Response> fetchEditAgentResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchEditAgentResponse(dataMap);
    return response;
  }

  Future<Response> fetchDeleteAgentResponse(Map<String, dynamic> dataMap) async {
    final response = await _propertyApiProvider.fetchDeleteAgentResponse(dataMap);
    return response;
  }

}