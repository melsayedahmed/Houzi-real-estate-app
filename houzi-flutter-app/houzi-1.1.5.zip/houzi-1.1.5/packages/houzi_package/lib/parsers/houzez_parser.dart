import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/dataProvider/locale_provider.dart';
import 'package:houzi_package/dataProvider/property_api_provider.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/activity.dart';
import 'package:houzi_package/models/realtor_model.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/models/deals_and_leads.dart';
import 'package:houzi_package/models/floor_plans.dart';
import 'package:houzi_package/models/inquiries.dart';
import 'package:houzi_package/models/property_meta_data.dart';
import 'package:houzi_package/models/saved_search.dart';
import 'package:houzi_package/models/user.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../models/custom_fields.dart';


// const String HOUZEZ_ALL_PROPERTIES_PATH = "/wp-json/wp/v2/$REST_API_PROPERTIES_ROUTE";
String HOUZEZ_ALL_PROPERTIES_PATH = "/wp-json/wp/v2/$REST_API_PROPERTIES_ROUTE";

const String HOUZEZ_SIMILAR_PROPERTIES_PATH = "/wp-json/houzez-mobile-api/v1/similar-properties";
const String HOUZEZ_MULTIPLE_PROPERTIES_PATH = "/wp-json/wp/v2/properties";

const String HOUZEZ_PROPERTY_TYPES_META_DATA_PATH = "/wp-json/wp/v2/property_type";

const String HOUZEZ_PROPERTY_CITIES_META_DATA_PATH = "/wp-json/wp/v2/property_city";

const String HOUZEZ_SEARCH_PROPERTIES_PATH = "/wp-json/houzez-mobile-api/v1/search-properties";

const String HOUZEZ_META_DATA_PATH = "/wp-json/houzez-mobile-api/v1/touch-base";

// const String HOUZEZ_SEARCH_AGENCIES_PATH = "/wp-json/wp/v2/$REST_API_AGENCY_ROUTE";
String HOUZEZ_SEARCH_AGENCIES_PATH = "/wp-json/wp/v2/$REST_API_AGENCY_ROUTE";

// const String HOUZEZ_SEARCH_AGENTS_PATH = "/wp-json/wp/v2/$REST_API_AGENT_ROUTE";
String HOUZEZ_SEARCH_AGENTS_PATH = "/wp-json/wp/v2/$REST_API_AGENT_ROUTE";

const String HOUZEZ_CONTACT_REALTOR_PATH = "/wp-json/houzez-mobile-api/v1/contact-property-agent";
// const String HOUZEZ_CONTACT_REALTOR_PATH = "/wp-json/houzez-mobile-api/v1/contact-realtor";

const String HOUZEZ_CONTACT_DEVELOPER_PATH = "/wp-json/contact-us/v1/send-message";

const String HOUZEZ_SCHEDULE_A_TOUR_PATH = "/wp-json/houzez-mobile-api/v1/schedule-tour";

const String HOUZEZ_SAVE_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/save-property";
// const String HOUZEZ_ADD_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/add-property";

const String HOUZEZ_SAVE_PROPERTY_IMAGES_PATH = "/wp-json/houzez-mobile-api/v1/save-property-image";

const String HOUZEZ_ACTIVITIES_FROM_BOARD_PATH = "/wp-json/houzez-mobile-api/v1/activities";

const String HOUZEZ_INQUIRIES_FROM_BOARD_PATH = "/wp-json/houzez-mobile-api/v1/enquiries";

const String JWT_Authentication_PATH = "/wp-json/houzez-mobile-api/v1/signin";
const String HOUZEZ_SOCIAL_LOGIN_PATH = "/wp-json/houzez-mobile-api/v1/social-sign-on";
// const String JWT_Authentication_PATH = "/wp-json/jwt-auth/v1/token";

const String SIGNUP_API_LINK_PATH = "/wp-json/houzez-mobile-api/v1/signup";
const String FORGET_PASSWORD_API_LINK_PATH = "/wp-json/houzez-mobile-api/v1/reset-password";

const String HOUZEZ_SINGLE_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/property";

const String HOUZEZ_MY_PROPERTIES_PATH = "/wp-json/houzez-mobile-api/v1/my-properties";

// const String HOUZEZ_USERS_PROPERTIES_PATH = "/wp-json/wp/v2/properties";

const String HOUZEZ_USERS_DELETE_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/delete-property";
const String HOUZEZ_DEALS_FROM_BOARD_PATH = "/wp-json/houzez-mobile-api/v1/deals";
const String HOUZEZ_LEADS_FROM_BOARD_PATH = "/wp-json/houzez-mobile-api/v1/leads";
const String HOUZEZ_ADD_DEALS_PATH = "/wp-json/houzez-mobile-api/v1/add-deal";
const String HOUZEZ_DELETE_DEALS_PATH = "/wp-json/houzez-mobile-api/v1/delete-deal";
const String HOUZEZ_ADD_INQUIRY_PATH = "/wp-json/houzez-mobile-api/v1/add-crm-enquiry";
const String HOUZEZ_DELETE_INQUIRY_PATH = "/wp-json/houzez-mobile-api/v1/delete-crm-enquiry";
const String HOUZEZ_TERM_DATA_PATH = "/wp-json/houzez-mobile-api/v1/get-terms";
const String HOUZEZ_ADD_REMOVE_FROM_FAV_PATH = "/wp-json/houzez-mobile-api/v1/like-property";
const String HOUZEZ_FAV_PROPERTIES_PATH = "/wp-json/houzez-mobile-api/v1/favorite-properties";
const String HOUZEZ_DELETE_LEADS_PATH = "/wp-json/houzez-mobile-api/v1/delete-lead";
const String HOUZEZ_UPDATE_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/update-property";
const String HOUZEZ_UPDATE_IMAGE_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/upload-property-image";
const String HOUZEZ_DELETE_PROPERTY_IMAGE_PATH = "/wp-json/houzez-mobile-api/v1/delete-property-image";
const String HOUZEZ_ADD_SAVED_SEARCH_PATH = "/wp-json/houzez-mobile-api/v1/save-search";
const String HOUZEZ_SAVED_SEARCHES_PATH = "/wp-json/houzez-mobile-api/v1/saved-searches";
const String HOUZEZ_DELETE_SAVED_SEARCH_PATH = "/wp-json/houzez-mobile-api/v1/delete-saved-search";
const String HOUZEZ_SAVED_SEARCH_ARTICLE_PATH = "/wp-json/houzez-mobile-api/v1/view-saved-search";
const String HOUZEZ_ADD_REVIEW_ARTICLE_PATH = "/wp-json/houzez-mobile-api/v1/add-review";
const String HOUZEZ_ARTICLE_REVIEWS_PATH = "/wp-json/wp/v2/houzez_reviews";
const String HOUZEZ_USER_INFO_PATH = "/wp-json/houzez-mobile-api/v1/profile";
const String HOUZEZ_UPDATE_USER_PROFILE_PATH = "/wp-json/houzez-mobile-api/v1/update-profile";
const String HOUZEZ_UPDATE_USER_PROFILE_IMAGE_PATH = "/wp-json/houzez-mobile-api/v1/update-profile-photo";
const String HOUZEZ_FIX_PROFILE_IMAGE_PATH = "/wp-json/houzez-mobile-api/v1/fix-profile-pic";
const String HOUZEZ_SEARCH_AGENTS_PROFILE_IMAGE_PATH = "/wp-json/houzez-mobile-api/v1/update-profile-photo";
const String HOUZEZ_IS_FAV_PROPERTY = "/wp-json/houzez-mobile-api/v1/is-fav-property";
const String HOUZEZ_UPDATE_USER_PASSWORD_PROPERTY = "/wp-json/houzez-mobile-api/v1/update-password";
const String HOUZEZ_DELETE_USER_ACCOUNT_PROPERTY = "/wp-json/houzez-mobile-api/v1/delete-user-account";
const String HOUZEZ_ADD_LEADS_PATH = "/wp-json/houzez-mobile-api/v1/add-lead";
const String HOUZEZ_SINGLE_ARTICLE_PERMA_LINK_PATH = "/wp-json/houzez-mobile-api/v1/property-by-permalink";
const String HOUZEZ_ADD_REQUEST_PROPERTY_PATH = "/wp-json/houzez-mobile-api/v1/add-property-request";
const String HOUZEZ_AGENCY_ALL_AGENTS_PATH = "/wp-json/houzez-mobile-api/v1/agency-all-agents";
const String HOUZEZ_AGENCY_ADD_AGENT_PATH = "/wp-json/houzez-mobile-api/v1/add-new-agent";
const String HOUZEZ_AGENCY_EDIT_AGENT_PATH = "/wp-json/houzez-mobile-api/v1/edit-an-agent";
const String HOUZEZ_AGENCY_DELETE_AGENT_PATH = "/wp-json/houzez-mobile-api/v1/delete-an-agent";
const String HOUZEZ_ADS_PATH = "/wp-json/wp/v2/ads";


class HOUZEZApiProvider implements ApiProviderInterface {


  Uri getUri({String unEncodedPath, Map<String, dynamic> params}){
    Uri uri;

    // String authority = WORDPRESS_URL_DOMAIN;
    // String communicationProtocol = WORDPRESS_URL_SCHEME;

    /// For Houzi Only (due to demo configurations)
    String authority = HiveStorageManager.readUrlAuthority() ?? WORDPRESS_URL_DOMAIN;
    String communicationProtocol = HiveStorageManager.readCommunicationProtocol() ?? WORDPRESS_URL_SCHEME;
    String urlScheme = WORDPRESS_URL_PATH;

    // String option = HiveStorageManager.readLocaleInUrl();
    DefaultLanguageCodeHook defaultLanguageCodeHook = GenericMethods.defaultLanguageCode;
    String defaultLanguage = defaultLanguageCodeHook();
    String tempSelectedLanguage = HiveStorageManager.readLanguageSelection() ?? defaultLanguage;
    if (currentSelectedLocaleUrlPosition == changeUrlPath) {
      urlScheme = urlScheme+"/$tempSelectedLanguage";
    } else if (currentSelectedLocaleUrlPosition == changeUrlQueryParameter) {
      params ??= {};
      params["lang"] = tempSelectedLanguage;
    }

    if(urlScheme != null && urlScheme.isNotEmpty){
      unEncodedPath = urlScheme + unEncodedPath;
    }

    if(communicationProtocol == HTTP){
      uri = Uri.http(authority, unEncodedPath, params);
    }else if(communicationProtocol == HTTPS){
      uri = Uri.https(authority, unEncodedPath, params);
    }

    return uri;
  }

  @override
  Uri provideFeaturedPropertiesApi(int page) {
    var queryParameters = {
      'fave_featured': "${1}",
      'page': '$page',
      'per_page': '${16}',
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideLatestPropertiesApi(int page) {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_PROPERTIES_PATH,
    );
    return uri;
  }

  @override
  Uri provideFilteredPropertiesApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_PROPERTIES_PATH,
    );
    return uri;
  }

  @override
  Uri provideSimilarPropertiesApi(int propertyId) {
    var queryParameters = {
      'property_id': '$propertyId'
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_SIMILAR_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideMultiplePropertiesApi(String propertiesId) {
    var uri = getUri(
      unEncodedPath: "$HOUZEZ_MULTIPLE_PROPERTIES_PATH/?include=$propertiesId",
    );
    return uri;
  }

  @override
  Uri provideSinglePropertyApi(int id, {bool forEditing = false}) {
    if (forEditing) {
      var queryParameters = {
        'editing': '$forEditing',
        'id': '$id',
      };
      var uri = getUri(
          unEncodedPath: HOUZEZ_SINGLE_PROPERTY_PATH,
          params: queryParameters);
      return uri;
    } else {
      var queryParameters = {
        'id': '$id',
      };
      var uri = getUri(
        unEncodedPath: HOUZEZ_SINGLE_PROPERTY_PATH,
          params: queryParameters);
      return uri;
    }
  }

  @override
  Uri providePropertyMetaDataApi() {
    var uri = getUri(unEncodedPath: HOUZEZ_META_DATA_PATH);
    return uri;
  }

  @override
  Uri provideSingleAgencyInfoApi(int id) {
    var uri = getUri(
      unEncodedPath: "$HOUZEZ_SEARCH_AGENCIES_PATH/$id",
    );
    return uri;
  }

  @override
  Uri provideSingleAgentInfoApi(int id) {
    var uri = getUri(
      unEncodedPath: "$HOUZEZ_SEARCH_AGENTS_PATH/$id",
    );
    return uri;
  }

  @override
  Uri providePropertiesByAgencyApi(int id, int page, int perPage) {
    var queryParameters = {
      "fave_property_agency": "$id",
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri providePropertiesByAgentApi(int id, int page, int perPage) {
    var queryParameters = {
      "fave_agents": "$id",
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAgencyAgentsInfoApi(int agencyId) {
    var queryParameters = {
      "fave_agent_agencies": "$agencyId",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_AGENTS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAllAgentsInfoApi(int page, int perPage) {
    var queryParameters = {
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_AGENTS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAllAgenciesInfoApi(int page, int perPage) {
    var queryParameters = {
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_AGENCIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri providePropertiesByTypesApi(int id, int page, int perPage) {
    var queryParameters = {
      "property_type": "$id",
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri providePropertiesInCityApi(int id, int page, int perPage) {
    var queryParameters = {
      "property_city": "$id",
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideContactRealtorApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_CONTACT_REALTOR_PATH,
    );
    return uri;
  }

  @override
  Uri provideLoginApi() {
    var uri = getUri(
      unEncodedPath: JWT_Authentication_PATH,
    );
    return uri;
  }

  @override
  Uri providePropertiesInCityByTypeApi(int cityId, int typeId, int page, int perPage) {
    var queryParameters = {
      "property_city": "$cityId",
      "property_type": "$typeId",
      'page': '$page',
      'per_page': '$perPage',
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideScheduleATourApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SCHEDULE_A_TOUR_PATH,
    );
    return uri;
  }

  @override
  Uri provideSavePropertyApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SAVE_PROPERTY_PATH,
    );
    return uri;
  }

  @override
  Uri provideSavePropertyImagesApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SAVE_PROPERTY_IMAGES_PATH,
    );
    return uri;
  }

  @override
  Uri provideActivitiesFromBoardApi(int page, int perPage,int userId) {
    var queryParameters = {
      'user_id': "$userId",
      'cpage': "$page",
      'per_page': "$perPage",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ACTIVITIES_FROM_BOARD_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideInquiriesFromBoardApi(int page,int perPage ,int userId) {
    var queryParameters = {
      'user_id': "$userId",
      'cpage': "$page",
      'per_page': "$perPage",
    };
    var uri;

      uri = getUri(
        unEncodedPath: HOUZEZ_INQUIRIES_FROM_BOARD_PATH,
        params: queryParameters,
      );

    return uri;
  }

  @override
  Uri provideLeadsFromActivityApi(int page, int userId) {
    var queryParameters = {
      'user_id': "$userId",
      'cpage': "${1}",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ACTIVITIES_FROM_BOARD_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideSignUpApi() {
    var uri = getUri(
      unEncodedPath: SIGNUP_API_LINK_PATH,
    );
    return uri;
  }

  @override
  Uri provideStatusOfPropertyApi(int id) {
    var uri = getUri(
      unEncodedPath: '$HOUZEZ_ALL_PROPERTIES_PATH/$id',
    );
    return uri;
  }

  @override
  Uri provideDeletePropertyApi(int id) {
    var queryParameters = {
      'prop_id': "$id",
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_USERS_DELETE_PROPERTY_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideMyPropertiesApi(String status, int page, int perPage, int userId) {
    var queryParameters = {
      'page': "$page",
      'per_page': "$perPage",
      'status': status,
      'author': "$userId",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_MY_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAllPropertiesApi(String status, int page, int perPage, int userId) {
    var queryParameters = {
      'page': "$page",
      'per_page': "$perPage",
      'status': status,
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideForgetPasswordApi() {
    var uri = getUri(
      unEncodedPath: FORGET_PASSWORD_API_LINK_PATH,
    );
    return uri;
  }

  @override
  Uri provideDealsFromActivityApi(int page, int userId) {
    var queryParameters = {
      'user_id': "$userId",
      'cpage': "${1}",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_ACTIVITIES_FROM_BOARD_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideDealsFromBoardApi(int page,int perPage, String tab) {
    var queryParameters = {
      'tab': tab,
      'cpage': "$page",
      'per_page': "$perPage",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_DEALS_FROM_BOARD_PATH,
      params: queryParameters,
    );
    return uri;
  }



  @override
  Uri provideContactDeveloperApi() {
    // var uri = getUri(
    //   unEncodedPath: HOUZEZ_CONTACT_DEVELOPER_PATH,
    // );
    var uri = getUri(
      unEncodedPath: HOUZEZ_CONTACT_DEVELOPER_PATH,
    );
    return uri;
  }

  @override
  Uri provideAddDealResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_DEALS_PATH,
    );
    return uri;
  }
  @override
  Uri provideLeadsFromBoardApi(int page,int perPage) {
    var queryParameters = {
      'cpage': "$page",
      'per_page': "$perPage",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_LEADS_FROM_BOARD_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideDeleteDealApi(int id) {
    var queryParameters = {
      'deal_id': "$id",
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_DELETE_DEALS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAddInquiryApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_INQUIRY_PATH,
    );
    return uri;
  }

  @override
  Uri provideDeleteInquiryApi(int id) {
    var queryParameters = {
      'ids': "$id",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_DELETE_INQUIRY_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideTermDataApi(String termData) {
    var queryParameters = {
      'term': termData,
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_TERM_DATA_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAddOrRemoveFromFavApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_REMOVE_FROM_FAV_PATH,
    );
    return uri;
  }

  @override
  Uri provideFavPropertiesApi(int page, int perPage,userIdStr) {
    var queryParameters = {
      'post_author': userIdStr,
      'cpage': "$page",
      'per_page': "$perPage",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_FAV_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideDeleteLeadApi(id) {
    var queryParameters = {
      'lead_id': "$id",
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_DELETE_LEADS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideUpdatePropertyApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_UPDATE_PROPERTY_PATH,
    );
    return uri;
  }

  @override
  Uri provideImagesForUpdateArticleApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_UPDATE_IMAGE_PROPERTY_PATH,
    );
    return uri;
  }

  @override
  Uri provideLatLongArticlesApi(String lat, String long) {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_PROPERTIES_PATH,
    );
    return uri;
  }

  @override
  Uri provideDeleteImageFromEditPropertyApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_DELETE_PROPERTY_IMAGE_PATH,
    );
    return uri;
  }

  @override
  Uri provideAddSavedSearchApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_SAVED_SEARCH_PATH,
    );
    return uri;
  }

  @override
  Uri provideSavedSearches(int page, int perPage) {
    var queryParameters = {
      'per_page': "$perPage",
      'cpage': "$page",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_SAVED_SEARCHES_PATH,
      params: queryParameters
    );
    return uri;
  }

  @override
  Uri provideDeleteSavedSearchApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_DELETE_SAVED_SEARCH_PATH,
    );
    return uri;
  }

  @override
  Uri provideSavedSearchArticlesApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SAVED_SEARCH_ARTICLE_PATH,
    );
    return uri;
  }

  @override
  Uri provideAddReviewApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_REVIEW_ARTICLE_PATH,
    );
    return uri;
  }

  @override
  Uri provideArticlesReviewsApi(int id, String page, String perPage) {
    var queryParameters = {
      'review_property_id': "$id",
      'per_page': perPage,
      'page': page,
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_ARTICLE_REVIEWS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAgentAgencyAuthorReviewsApi(
      int id, String page, String perPage, String type) {
    String realtorId = "";
    if (type == USER_ROLE_HOUZEZ_AGENT_VALUE) {
      realtorId = "review_agent_id";
    } else if (type == USER_ROLE_HOUZEZ_AGENCY_VALUE) {
      realtorId = "review_agency_id";
    } else {
      realtorId = "review_author_id";
    }
    var queryParameters = {
      realtorId: "$id",
      'per_page': perPage,
      'page': page,
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_ARTICLE_REVIEWS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideUserInfoApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_USER_INFO_PATH,
    );
    return uri;
  }

  @override
  Uri provideUpdateUserProfileApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_UPDATE_USER_PROFILE_PATH,
    );
    return uri;
  }

  @override
  Uri provideUpdateUserProfileImageApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_UPDATE_USER_PROFILE_IMAGE_PATH,
    );
    return uri;
  }

  @override
  Uri provideDealsAndLeadsFromActivityApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ACTIVITIES_FROM_BOARD_PATH,
    );
    return uri;
  }

  @override
  Uri provideSearchAgenciesApi(int page, int perPage, String search,) {
    var queryParameters = {
      'search': search,
      'per_page': "$perPage",
      'page': "$page",
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_AGENCIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideSearchAgentsApi(int page, int perPage, String search, String agentCity, String agentCategory) {
    var queryParameters = {
      'search': search,
      'per_page': "$perPage",
      'page': "$page",
    };
    if(agentCity !=null && agentCity.isNotEmpty){
      queryParameters["agent_city"] = agentCity;
    }
    if(agentCategory !=null && agentCategory.isNotEmpty){
      queryParameters["agent_category"] = agentCategory;
    }
    var uri = getUri(
      unEncodedPath: HOUZEZ_SEARCH_AGENTS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideFixProfileImageResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_FIX_PROFILE_IMAGE_PATH,
    );
    return uri;
  }

  @override
  Uri provideIsFavPropertyAp(String listingId) {
    var queryParameters = {
      'listing_id': listingId,
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_IS_FAV_PROPERTY,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideSocialLoginApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_SOCIAL_LOGIN_PATH,
    );
    return uri;
  }

  @override
  Uri providePropertiesByTypeApi(int page, int id, String type) {
    var queryParameters = {
      type: "$id",
      'page': '$page',
      'per_page': '${16}',
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_ALL_PROPERTIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideRealtorInfoApi(int page, String type) {
    var queryParameters = {
      'page': '$page',
      'per_page': '${16}',
    };
    var uri = getUri(
      unEncodedPath: type == REST_API_AGENT_ROUTE ? HOUZEZ_SEARCH_AGENTS_PATH : HOUZEZ_SEARCH_AGENCIES_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideDeleteUserAccountApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_DELETE_USER_ACCOUNT_PROPERTY,
    );
    return uri;
  }

  @override
  Uri provideUpdateUserPasswordApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_UPDATE_USER_PASSWORD_PROPERTY,
    );
    return uri;
  }

  @override
  Uri provideAddLeadResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_LEADS_PATH,
    );
    return uri;
  }@override
  Uri provideSingleArticleViaPermaLinkApi(String permaLink) {
    var queryParameters = {
      "perm": permaLink
    };

    var uri = getUri(
      unEncodedPath: HOUZEZ_SINGLE_ARTICLE_PERMA_LINK_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideAddRequestPropertyApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADD_REQUEST_PROPERTY_PATH,
    );
    return uri;
  }

  @override
  ApiParser getParser() {
    return HouzezParser();
  }

  @override
  Uri providePropertiesAdsResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_ADS_PATH,
    );
    return uri;
  }

  @override
  Uri provideAddAgentResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_AGENCY_ADD_AGENT_PATH,
    );
    return uri;
  }

  @override
  Uri provideAgencyAllAgentListApi(int agencyId) {
    var queryParameters = {
      "agency_id": "$agencyId",
    };
    var uri = getUri(
      unEncodedPath: HOUZEZ_AGENCY_ALL_AGENTS_PATH,
      params: queryParameters,
    );
    return uri;
  }

  @override
  Uri provideEditAgentResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_AGENCY_EDIT_AGENT_PATH,
    );
    return uri;
  }

  @override
  provideDeleteAgentResponseApi() {
    var uri = getUri(
      unEncodedPath: HOUZEZ_AGENCY_DELETE_AGENT_PATH,
    );
    return uri;
  }
}
class HouzezParser implements ApiParser {

  static Address parseAddressMap(Map<String, dynamic> json) {
    String tempAddress = "";
    String tempLat = "";
    String tempLng = "";
    String tempCoordinates = "";
    String tempPostalCode = "";
    String tempCity = "";
    String tempCountry = "";
    String tempState = "";
    String tempArea = "";

    if (json.containsKey("address")) {
      tempAddress = json['address'];
    }

    if (json.containsKey("lat")) {
      tempLat = json["lat"];
    }

    if (json.containsKey("lng")) {
      tempLng = json["lng"];
    }

    if (json.containsKey("property_meta")) {
      Map tempPropertyMeta = json["property_meta"];
      if (tempPropertyMeta.containsKey("fave_property_map_address")) {
        tempAddress = json["property_meta"]["fave_property_map_address"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_address")) {
        if(tempAddress == null || tempAddress.isEmpty) {
          tempAddress = json["property_meta"]["fave_property_address"][0];
        }
      }
      if (tempPropertyMeta.containsKey("houzez_geolocation_lat")) {
        tempLat = json["property_meta"]["houzez_geolocation_lat"][0];
      }
      if (tempPropertyMeta.containsKey("houzez_geolocation_long")) {
        tempLng = json["property_meta"]["houzez_geolocation_long"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_location")) {
        tempCoordinates = json["property_meta"]["fave_property_location"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_zip")) {
        tempPostalCode = json["property_meta"]["fave_property_zip"][0];
      }
    }

    if (json.containsKey("property_address")) {
      var tempData = json["property_address"];
      if (tempData is Map) {
        Map tempPropertyAddressMap = json["property_address"];
        if (tempPropertyAddressMap.containsKey("property_city")) {
          tempCity = json["property_address"]["property_city"];
        }
        if (tempPropertyAddressMap.containsKey("property_country")) {
          tempCountry = json["property_address"]["property_country"];
        }
        if (tempPropertyAddressMap.containsKey("property_state")) {
          tempState = json["property_address"]["property_state"];
        }
        if (tempPropertyAddressMap.containsKey("property_area")) {
          tempArea = json["property_address"]["property_area"];
        }
      }
    }

    return Address(
      city: tempCity,
      country: tempCountry,
      state: tempState,
      area: tempArea,
      address: tempAddress,
      coordinates: tempCoordinates,
      lat: tempLat,
      long: tempLng,
      postalCode: tempPostalCode,
    );
  }

  static Features parseFeaturesMap(Map<String, dynamic> json) {
    String tempLandArea = "";
    String tempLandAreaUnit = "";
    String tempBedrooms = "";
    String tempBathrooms = "";
    String tempGarage = "";
    String tempGarageSize = "";
    String tempYearBuilt = "";
    String tempMultiUnitsListingIDs = "";
    List<dynamic> tempFeatureList = [];
    List<String> listOfFeatures = [];
    List<dynamic> tempImagesIdList = [];
    List<String> listOfTempImagesId = [];
    List<Map<String, dynamic>> tempFloorPlan = [];
    List<dynamic> tempFloorPlansList = [];
    List<dynamic> tempAdditionalDetailsList = [];
    List<Map<String, dynamic>> tempMultiUnitsPlan = [];
    List<dynamic> tempMultiUnitsList = [];

    if (json.containsKey("property_features")) {
      tempFeatureList = json["property_features"];
      listOfFeatures = List<String>.from(tempFeatureList);
    }

    if (json.containsKey("property_meta")) {
      Map tempPropertyMeta = json["property_meta"];
      if (tempPropertyMeta.containsKey("fave_property_size")) {
        tempLandArea = json["property_meta"]["fave_property_size"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_size_prefix")) {
        tempLandAreaUnit =
            json["property_meta"]["fave_property_size_prefix"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_bedrooms")) {
        tempBedrooms = json["property_meta"]["fave_property_bedrooms"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_bathrooms")) {
        tempBathrooms = json["property_meta"]["fave_property_bathrooms"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_garage")) {
        tempGarage = json["property_meta"]["fave_property_garage"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_garage_size")) {
        tempGarageSize = json["property_meta"]["fave_property_garage_size"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_year")) {
        tempYearBuilt = json["property_meta"]["fave_property_year"][0];
      }
      if (tempPropertyMeta.containsKey("fave_property_images")) {
        tempImagesIdList = json["property_meta"]["fave_property_images"];
        tempImagesIdList.removeWhere((element) => element is !String || element == "null");
        listOfTempImagesId = List<String>.from(tempImagesIdList);
      }
      if (tempPropertyMeta.containsKey("floor_plans")) {
        var temp = json["property_meta"]["floor_plans"];
        if (temp is List) {
          List<dynamic> list = json["property_meta"]["floor_plans"];
          if (list[0] is Map) {
            tempFloorPlan = List<Map<String, dynamic>>.from(list);
          }
          if(tempFloorPlan != null && tempFloorPlan.isNotEmpty){
            tempFloorPlansList = getParsedDataInList(
              inputList: tempFloorPlan,
              function: parseFloorPlansMap,
            );
          }
        }
      }

      if (tempPropertyMeta.containsKey("fave_multi_units")) {
        var temp = json["property_meta"]["fave_multi_units"];
        if (temp is List) {
          List<dynamic> list = json["property_meta"]["fave_multi_units"];
          if (list[0] is Map) {
            tempMultiUnitsPlan = List<Map<String, dynamic>>.from(list);
          }
          if(tempMultiUnitsPlan != null && tempMultiUnitsPlan.isNotEmpty){
            tempMultiUnitsList = getParsedDataInList(
              inputList: tempMultiUnitsPlan,
              function: parseMultiUnitsMap,
            );
          }

        }
      }

      if (tempPropertyMeta.containsKey("additional_features")) {
        var temp = json["property_meta"]["additional_features"];
        if (temp != null && temp is List && temp.isNotEmpty) {
          for(var item in temp){
            if(item is Map){
              String title = item[faveAdditionalFeatureTitle].toString();
              String value = item[faveAdditionalFeatureValue].toString();
              tempAdditionalDetailsList.add(
                  AdditionalDetail(
                    title: title,
                    value: value,
                  )
              );
            }
          }
        }
      }
      if (tempPropertyMeta.containsKey("fave_multi_units_ids")) {
        tempMultiUnitsListingIDs = json["property_meta"]["fave_multi_units_ids"][0];
      }
    }
    return Features(
      featuresList: listOfFeatures,
      landArea: tempLandArea,
      landAreaUnit: tempLandAreaUnit,
      bedrooms: tempBedrooms,
      bathrooms: tempBathrooms,
      garage: tempGarage,
      garageSize: tempGarageSize,
      yearBuilt: tempYearBuilt,
      floorPlansList: tempFloorPlansList,
      imagesIdList: listOfTempImagesId,
      additionalDetailsList: tempAdditionalDetailsList,
      multiUnitsList: tempMultiUnitsList,
      multiUnitsListingIDs: tempMultiUnitsListingIDs,
    );
  }

  static PropertyInfo parsePropertyInfoMap(Map<String, dynamic> json) {
    String tempPropertyType = "";
    String tempPropertyStatus = "";
    String tempPropertyLabel = "";
    String tempPrice = "";
    String temporaryPrice = "";
    String tempFirstPrice = "";
    String tempSecondPrice = "";
    String tempPriceCurrency = "";
    String tempCurrency = "";
    String tempUniqueId = "";
    String tempPricePostfix = "";
    String tempPropertyVirtualTourLink = "";
    String tempAgentDisplayOption = "";
    String tempAddressHideMap = "";
    String tempFeatured = "";
    String tempTotalRating = "";
    Map<String, dynamic> tempAgentInfoMap = {};
    List<String> tempAgentList = [];
    List<String> tempAgencyList = [];
    bool tempIsFeatured = false;
    Map<String, String> customFieldsMap = {};
    Map<String, dynamic> customFieldsMapForEditing = {};

    if (json.containsKey("property_attr")) {
      var tempData = json["property_attr"];
      if (tempData is Map) {
        Map tempPropertyAttribute = json["property_attr"];
        if (tempPropertyAttribute.containsKey("property_type")) {
          tempPropertyType = json["property_attr"]["property_type"];
        }
        if (tempPropertyAttribute.containsKey("property_status")) {
          tempPropertyStatus = json["property_attr"]["property_status"];
        }
        if (tempPropertyAttribute.containsKey("property_label")) {
          tempPropertyLabel = json["property_attr"]["property_label"];
        }
      }
    } else {
      if (json.containsKey("property_type")) {
        var type =json["property_type"];
        if(type is List){
          tempPropertyType = type[0].toString();
        }else{
          tempPropertyType = json["property_type"];
        }
      }
    }

    // if (json.containsKey("price")) {
    //   temporaryPrice = json["price"];
    //   var tempVar = '\$'.allMatches(temporaryPrice).length;
    //   var list = temporaryPrice.split("\$");
    //   if(list != null && list.length > 1){
    //     tempFirstPrice = "\$" + list[1];
    //     if (tempVar == 2) {
    //       tempSecondPrice = "\$" + list[2];
    //     }
    //   }
    // }

    // if (json.containsKey("priceSimple")) {
    //   tempPrice = json["priceSimple"];
    // }

    if (json.containsKey("property_meta")) {
      Map tempPropertyMetaMap = json["property_meta"];
      if (tempPrice.isEmpty) {
        if (tempPropertyMetaMap.containsKey("fave_property_price")) {
          tempPrice = json["property_meta"]["fave_property_price"][0];
        }
      }
      if (tempSecondPrice.isEmpty) {
        if (tempPropertyMetaMap.containsKey("fave_property_sec_price")) {
          tempSecondPrice = json["property_meta"]["fave_property_sec_price"][0];
        }
      }
      if (tempPropertyMetaMap.containsKey("fave_currency_info")) {
        tempPriceCurrency = json["property_meta"]["fave_currency_info"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_currency")) {
        tempCurrency = json["property_meta"]["fave_currency"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_property_id")) {
        tempUniqueId = json["property_meta"]["fave_property_id"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_property_price_postfix")) {
        tempPricePostfix =
            json["property_meta"]["fave_property_price_postfix"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_virtual_tour")) {
        tempPropertyVirtualTourLink =
            json["property_meta"]["fave_virtual_tour"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_property_map")) {
        tempAddressHideMap = json["property_meta"]["fave_property_map"][0];
      }
      if (tempPropertyMetaMap.containsKey("agent_info")) {
        tempAgentInfoMap = json["property_meta"]["agent_info"];
      }
      if (tempPropertyMetaMap.containsKey("fave_agents")) {
        List<dynamic> list = json["property_meta"]["fave_agents"];
        List<String> tempList = List<String>.from(list);
        tempAgentList =
            tempList.toSet().toList(); /// To get the distinctive members only
      }
      if (tempPropertyMetaMap.containsKey("fave_property_agency")) {
        List<dynamic> list = json["property_meta"]["fave_property_agency"];
        List<String> tempList = List<String>.from(list);
        tempAgencyList = tempList.toSet().toList(); /// To get the distinctive members only
      }
      if (tempPropertyMetaMap.containsKey("fave_agent_display_option")) {
        tempAgentDisplayOption = json["property_meta"]["fave_agent_display_option"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_featured")) {
        tempFeatured = json["property_meta"]["fave_featured"][0];
        if(tempFeatured == '1'){
          tempIsFeatured = true;
        }
      }
      if (tempPropertyMetaMap.containsKey("houzez_total_rating")) {
        tempTotalRating = json["property_meta"]["houzez_total_rating"][0];
      }

      var data = HiveStorageManager.readCustomFieldsDataMaps();

      if (data != null && data.isNotEmpty) {
        final custom = customFromJson(data);
        var fieldList = [];
        var labelList = [];

        for (var data in custom.customFields) {
          fieldList.add(data.fieldId);
          labelList.add(data.label);
        }

        for (int i = 0; i < fieldList.length; i++) {
          if (tempPropertyMetaMap.containsKey("fave_${fieldList[i]}")) {
            String key = "fave_${fieldList[i]}";
            var field = json["property_meta"][key];
            Map<String, dynamic> mapForEdit = {fieldList[i]: field};
            if (field is List) {
              field = field.join("\n");
            }
            Map<String, String> map = {labelList[i]: field};

            customFieldsMap.addAll(map);
            customFieldsMapForEditing.addAll(mapForEdit);
          }
        }
      }
    }

    return PropertyInfo(
      propertyType: tempPropertyType,
      propertyStatus: tempPropertyStatus,
      propertyLabel: tempPropertyLabel,
      priceCurrency: tempPriceCurrency,
      uniqueId: tempUniqueId,
      price: tempPrice,
      firstPrice: tempFirstPrice,
      secondPrice: tempSecondPrice,
      pricePostfix: tempPricePostfix,
      propertyVirtualTourLink: tempPropertyVirtualTourLink,
      featured: tempFeatured,
      addressHideMap: tempAddressHideMap,
      agentInfo: tempAgentInfoMap,
      agencyList: tempAgencyList,
      agentList: tempAgentList,
      agentDisplayOption: tempAgentDisplayOption,
      isFeatured: tempIsFeatured,
      houzezTotalRating: tempTotalRating,
      currency: tempCurrency,
      customFieldsMap: customFieldsMap,
      customFieldsMapForEditing: customFieldsMapForEditing
    );
  }

  static Article parseArticleMap(Map<String, dynamic> json) {
    String content = "";
    // String image = "https://images.wallpaperscraft.com/image/surface_dark_background_texture_50754_1920x1080.jpg";
    String image = "";
    List<String> listOfImages = [];
    String tempVideoUrl = "";
    int author;
    String avatar = "";
    String category = "";
    int catId = 0;
    String date = "";
    String tempGMTDate = "";
    String modifiedGmt = "";
    int tempId;
    String tempLink = "";
    String tempGuid = "";
    int tempfeaturedImageId = -1;
    String tempType = "";
    String tempTitle = "";
    String tempVirtualTourLink = "";
    String propertyStatus = "";
    String userDisplayName = "";
    String userName = "";
    bool tempIsFav = false;
    String reviewPostType;
    String reviewStars;
    String reviewBy;
    String reviewTo;
    String reviewPropertyId;
    String reviewLikes;
    String reviewDislikes;
    String houzezTotalRating;

    if (json.containsKey("content")) {
      content = json['content']['rendered'];
      content = GenericMethods.cleanContent(content);
    }
    if (json.containsKey("author")) {
      author = json['author'];
    }
    if (json.containsKey("post_author")) {
      author = int.parse(json['post_author']);
    }
    if (json.containsKey("post_content")) {
      content = json['post_content'];
      content = GenericMethods.cleanContent(content);
    }
    if (json.containsKey("featured_media")) {
      tempfeaturedImageId = json['featured_media'];
    }

    if (json.containsKey("thumbnail")) {
      var temp = json["thumbnail"];
      if (temp is String) {
        image = json["thumbnail"];
      }
    }

    if (json.containsKey("property_images")) {
      List<dynamic> tempImageList = json["property_images"];
      if (tempImageList != null) {
        tempImageList.removeWhere((element) => element is !String);
        listOfImages = List<String>.from(tempImageList);
      }
    }
    if (listOfImages == null || listOfImages.isEmpty) {
      if (image.isNotEmpty) {
        listOfImages.add(image);
      } else {
        listOfImages.add(
            "https://images.wallpaperscraft.com/image/surface_dark_background_texture_50754_1920x1080.jpg");
      }
    }

    if (json.containsKey("property_meta")) {
      Map tempPropertyMetaMap = json["property_meta"];
      if (tempPropertyMetaMap.containsKey("fave_video_url")) {
        tempVideoUrl = json["property_meta"]["fave_video_url"][0];
      }
      if (tempPropertyMetaMap.containsKey("fave_virtual_tour")) {
        var temp = json["property_meta"]["fave_virtual_tour"][0];
        tempVirtualTourLink = temp.toString();
      }
      if (tempPropertyMetaMap.containsKey("_thumbnail_id")) {
        var tempMedia = tempPropertyMetaMap['_thumbnail_id'][0];

        try {
          tempfeaturedImageId = int.parse(tempMedia);
        } catch (e) {}
      }
    }

    if (json.containsKey("meta")) {
      Map tempMetaMap = json["meta"];
      if (tempMetaMap.containsKey("review_post_type")) {
        reviewPostType = tempMetaMap["review_post_type"][0];
      }
      if (tempMetaMap.containsKey("review_stars")) {
        reviewStars = tempMetaMap["review_stars"][0];
      }
      if (tempMetaMap.containsKey("review_by")) {
        reviewBy = tempMetaMap["review_by"][0];
      }
      if (tempMetaMap.containsKey("review_to")) {
        reviewTo = tempMetaMap["review_to"][0];
      }
      if (tempMetaMap.containsKey("review_property_id")) {
        reviewPropertyId = tempMetaMap["review_property_id"][0];
      }
      if (tempMetaMap.containsKey("review_likes")) {
        reviewLikes = tempMetaMap["review_likes"][0];
      }
      if (tempMetaMap.containsKey("review_dislikes")) {
        reviewDislikes = tempMetaMap["review_dislikes"][0];
      }
    }

    if (json.containsKey("date")) {
      tempGMTDate = json["date"];
      date = DateFormat('dd MMMM, yyyy', 'en_US')
          .format(DateTime.parse(tempGMTDate+"z"))
          .toString();
    }
    if (json.containsKey("date_gmt")) {
      tempGMTDate = json["date_gmt"];

      date = DateFormat('dd MMMM, yyyy', 'en_US')
          .format(DateTime.parse(tempGMTDate+"z"))
          .toString();
    }
    if (json.containsKey("modified_gmt")) {
      String tempModifiedGmt = json["modified_gmt"];
      var time = tempModifiedGmt;
      DateTime dt = DateTime.parse(time+"z");
      modifiedGmt = timeago.format(dt, locale: 'en_short');

    }
    if (json.containsKey("user_display_name")) {
       userDisplayName = json["user_display_name"];
    } if (json.containsKey("username")) {
       userName = json["username"];
    }


    if (json.containsKey("post_date")) {
      tempGMTDate = json["post_date"];
      date = DateFormat('dd MMMM, yyyy', 'en_US')
          .format(DateTime.parse(tempGMTDate))
          .toString();
    }

    if (json.containsKey("title")) {
      tempTitle = json['title']['rendered'] as String;
    }

    // var tempTitle = json['title'];
    // if(!(tempTitle is String)){
    //   tempTitle = json['title']['rendered'] as String;
    // }

    if (json.containsKey("post_title")) {
      tempTitle = json["post_title"];
    }

    if (json.containsKey("ID")) {
      tempId = json["ID"];
    }

    if (json.containsKey("type")) {
      tempType = json["type"];
    }
    if (json.containsKey("post_type")) {
      tempType = json["post_type"];
    }


    if (json.containsKey("id")) {
      tempId = json["id"];
    }

    if (json.containsKey("property_id")) {
      tempId = json['property_id'];
    }

    if (json.containsKey("link")) {
      tempLink = json["link"];
    }

    // var tempTitle = json['title'];
    // if(!(tempTitle is String)){
    //   tempTitle = json['title']['rendered'] as String;
    // }

    if (json.containsKey("guid")) {
      if(!(tempGuid is String)){
        tempGuid = json['guid']['rendered'] as String;
        }
      //
    }



    if (json.containsKey("status")) {
      propertyStatus = json["status"];
    }
    if (json.containsKey("post_status")) {
      propertyStatus = json["post_status"];
    }
    if (json.containsKey("is_fav")) {
      tempIsFav = json["is_fav"] is bool ? json["is_fav"] : false;
    }

    Article article;
    article = Article(
      id: tempId,
      title: tempTitle,
      content: content,
      image: image,
      imageList: listOfImages,
      video: tempVideoUrl,
      author: author,
      avatar: avatar,
      category: category,
      date: date,
      dateGMT: tempGMTDate,
      link: tempLink,
      guid: tempGuid,
      catId: catId,
      virtualTourLink: tempVirtualTourLink,
      status: propertyStatus,
      isFav: tempIsFav,
      type: tempType,
      reviewBy: reviewBy,
      featuredImageId: tempfeaturedImageId,
      // reviewDislikes: reviewDislikes,
      // reviewLikes: reviewLikes,
      reviewPostType: reviewPostType,
      reviewPropertyId: reviewPropertyId,
      reviewStars: reviewStars,
      reviewTo: reviewTo,
      modifiedGmt:modifiedGmt,
      userDisplayName: userDisplayName,
      userName: userName
    );

    Address address = parseAddressMap(json);
    PropertyInfo propertyInfo = parsePropertyInfoMap(json);
    Features features = parseFeaturesMap(json);
    Author authorInfo = parseAuthorInfoMap(json);

    article.propertyInfo = propertyInfo;
    article.address = address;
    article.features = features;
    article.otherFeatures.addAll(json);
    article.internalFeaturesList.addAll(features.featuresList);
    article.authorInfo = authorInfo;

    Map<String, String> propDetails = new Map<String, String>();
    if (article.id != null) {
      propDetails[PROPERTY_DETAILS_PROPERTY_ID] = article.id.toString();
    }
    if (propertyInfo.price != null && propertyInfo.price.isNotEmpty) {
      if (propertyInfo.secondPrice != null && propertyInfo.secondPrice.isNotEmpty) {
        propDetails[FIRST_PRICE] = propertyInfo.price;
        propDetails[SECOND_PRICE] = propertyInfo.secondPrice;
        if (propertyInfo.pricePostfix.isNotEmpty) {
          propDetails[SECOND_PRICE] = propertyInfo.secondPrice + "/" + propertyInfo.pricePostfix;
        }
      } else if (propertyInfo.secondPrice == null || propertyInfo.secondPrice.isEmpty) {
        propDetails[PRICE] = propertyInfo.price;
        if (propertyInfo.pricePostfix.isNotEmpty) {
          propDetails[PRICE] = propertyInfo.price + "/" + propertyInfo.pricePostfix;
        }
      }
    }

    if (propertyInfo.propertyType != null &&
        propertyInfo.propertyType.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_TYPE] = propertyInfo.propertyType;
    }

    if (propertyInfo.propertyStatus != null &&
        propertyInfo.propertyStatus.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_STATUS] = propertyInfo.propertyStatus;
    }

    if (propertyInfo.uniqueId != null && propertyInfo.uniqueId.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_UNIQUE_ID] = propertyInfo.uniqueId;
    }

    if (features.landArea != null && features.landArea.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_SIZE] = features.landArea;
      // propDetails['Property Size'] = features.landArea + " " + features.landAreaUnit;
    }

    if (features.bedrooms != null && features.bedrooms.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_BEDROOMS] = features.bedrooms;
    }

    if (features.bathrooms != null && features.bathrooms.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_BATHROOMS] = features.bathrooms;
    }

    if (features.garage != null && features.garage.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_GARAGE] = features.garage;
    }

    if (features.garageSize != null && features.garageSize.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_GARAGE_SIZE] = features.garageSize;
    }

    if (features.yearBuilt != null && features.yearBuilt.isNotEmpty) {
      propDetails[PROPERTY_DETAILS_PROPERTY_YEAR_BUILT] = features.yearBuilt;
    }

    article.propertyDetailsMap = propDetails;

    return article;
  }


  static PropertyMetaData parsePropertyMetaDataMap(Map<String, dynamic> json) {
    int tempId;
    int tempParent;
    int tempTotalCount;
    String tempName = "";
    String tempSlug = "";
    String tempThumbnail = "";
    String tempFullImage = "";
    String taxonomy = "";
    var unescape = HtmlUnescape();

    if (json.containsKey("term_id")) {
      tempId = json["term_id"];
    }

    if (json.containsKey("name")) {
      tempName = json["name"];
    }

    if (json.containsKey("slug")) {
      tempSlug = json["slug"];
    }

    if (json.containsKey("parent")) {
      tempParent = json["parent"];
    }

    if (json.containsKey("count")) {
      tempTotalCount = json["count"];
    }

    if (json.containsKey("thumbnail")) {
      tempThumbnail = json["thumbnail"];
    }

    if (json.containsKey("full")) {
      tempFullImage = json["full"];
    }

    if (json.containsKey("taxonomy")) {
      taxonomy = json["taxonomy"];
    }

    PropertyMetaData propertyMetaData = PropertyMetaData(
      id: tempId,
      name: unescape.convert(tempName).toString(),
      slug: unescape.convert(tempSlug).toString(),
      parent: tempParent,
      totalPropertiesCount: tempTotalCount,
      thumbnail: tempThumbnail,
      fullImage: tempFullImage,
      taxonomy: taxonomy
    );

    return propertyMetaData;
  }

  static Agency parseAgencyInformation(Map<String, dynamic> json) {
    int tempId;
    String tempSlug = "";
    String tempType = "";
    String tempTitle = "";
    String tempContent = "";
    String tempThumbnail = "";
    String tempAgencyFaxNumber = "";
    String tempAgencyLicenseNumber = "";
    String tempAgencyPhoneNumber = "";
    String tempAgencyMobileNumber = "";
    String tempAgencyEmail = "";
    String tempAgencyAddress = "";
    String tempAgencyMapAddress = "";
    String tempAgencyLocation = "";
    String tempAgencyTaxNumber = "";
    String tempAgencyLink = "";
    String agencyWhatsappNumber = "";
    String tempTotalRating = "";

    if (json.containsKey("id")) {
      tempId = json["id"];
    }

    if (json.containsKey("slug")) {
      tempSlug = json["slug"];
    }

    if (json.containsKey("type")) {
      tempType = json["type"];
    }

    if (json.containsKey("link")) {
      tempAgencyLink = json["link"];
    }


    if (json.containsKey("title")) {
      var temp = json["title"];
      if (temp != null) {
        tempTitle = json["title"]["rendered"];
      }
    }

    if (json.containsKey("content")) {
      var temp = json["content"];
      if (temp != null) {
        tempContent = json["content"]["rendered"];
      }
    }

    if (json.containsKey("thumbnail") && json["thumbnail"] is String) {
      tempThumbnail = json["thumbnail"];
    }

    if (json.containsKey("agency_meta")) {
      Map tempAgencyMap = json["agency_meta"];
      if (tempAgencyMap.containsKey("fave_agency_fax")) {
        tempAgencyFaxNumber = json["agency_meta"]["fave_agency_fax"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_licenses")) {
        tempAgencyLicenseNumber =
            json["agency_meta"]["fave_agency_licenses"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_phone")) {
        tempAgencyPhoneNumber = json["agency_meta"]["fave_agency_phone"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_mobile")) {
        tempAgencyMobileNumber = json["agency_meta"]["fave_agency_mobile"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_email")) {
        tempAgencyEmail = json["agency_meta"]["fave_agency_email"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_address")) {
        tempAgencyAddress = json["agency_meta"]["fave_agency_address"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_map_address")) {
        tempAgencyMapAddress =
            json["agency_meta"]["fave_agency_map_address"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_location")) {
        tempAgencyLocation = json["agency_meta"]["fave_agency_location"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_tax_no")) {
        tempAgencyTaxNumber = json["agency_meta"]["fave_agency_tax_no"][0];
      }

      if (tempAgencyMap.containsKey("fave_agency_whatsapp")) {
        agencyWhatsappNumber = json["agency_meta"]["fave_agency_whatsapp"][0];
      }
      if (tempAgencyMap.containsKey("houzez_total_rating")) {
        tempTotalRating = json["agency_meta"]["houzez_total_rating"][0];
      }
    }

    return Agency(
      id: tempId,
      slug: tempSlug,
      type: tempType,
      title: tempTitle,
      content: tempContent,
      thumbnail: tempThumbnail,
      agencyFaxNumber: tempAgencyFaxNumber,
      agencyLicenseNumber: tempAgencyLicenseNumber,
      agencyPhoneNumber: tempAgencyPhoneNumber,
      agencyMobileNumber: tempAgencyMobileNumber,
      email: tempAgencyEmail,
      agencyAddress: tempAgencyAddress,
      agencyMapAddress: tempAgencyMapAddress,
      agencyLocation: tempAgencyLocation,
      agencyTaxNumber: tempAgencyTaxNumber,
      agencyLink: tempAgencyLink,
      agencyWhatsappNumber: agencyWhatsappNumber,
      totalRating: tempTotalRating
    );
  }

  static Agent parseAgentInformation(Map<String, dynamic> json) {
    int tempId;
    String tempAgentId;
    String tempUserAgentId;
    String tempSlug = "";
    String tempType = "";
    String tempTitle = "";
    String tempContent = "";
    String tempThumbnail = "";
    String tempTotalRating = "";
    String tempAgentPosition = "";
    String tempAgentCompany = "";
    String tempAgentMobileNumber = "";
    String tempAgentOfficeNumber = "";
    String tempAgentPhoneNumber = "";
    String tempAgentFaxNumber = "";
    String tempAgentEmail = "";
    String tempAgentAddress = "";
    String tempAgentTaxNumber = "";
    String tempAgentLicenseNumber = "";
    String tempAgentServiceArea = "";
    String tempAgentSpecialties = "";
    String tempAgentLink = "";
    String agentWhatsappNumber = "";
    String agentUserName = "";
    List<String> tempAgentAgenciesList;
    String tempAgentFirstName;
    String tempAgentLastName;

    if (json.containsKey("id")) {
      tempId = json["id"];
    }
    if (json.containsKey("ID")) {
      tempUserAgentId = json["ID"];
    }

    if (json.containsKey("slug")) {
      tempSlug = json["slug"];
    }

    if (json.containsKey("user_login")) {
      agentUserName = json["user_login"];
    }

    if (json.containsKey("user_email")) {
      tempAgentEmail = json["user_email"];
    }

    if (json.containsKey("type")) {
      tempType = json["type"];
    }

    if (json.containsKey("link")) {
      tempAgentLink = json["link"];
    }

    if (json.containsKey("title")) {
      var temp = json["title"];
      if (temp != null) {
        tempTitle = json["title"]["rendered"];
      }
    }

    if (json.containsKey("display_name")) {
      var temp = json["display_name"];
      if (temp != null && tempTitle.isEmpty) {
        tempTitle = json["display_name"];
      }
    }

    if (json.containsKey("content")) {
      var temp = json["content"];
      if (temp != null) {
        tempContent = json["content"]["rendered"];
      }
    }

    if (json.containsKey("thumbnail")) {
      var tempThumbnailData = json["thumbnail"];
      if(tempThumbnailData is String){
        tempThumbnail = json["thumbnail"];
      }
    }

    if (json.containsKey("agent_meta")) {
      Map tempAgentMap = json["agent_meta"];
      if (tempAgentMap.containsKey("fave_agent_position")) {
        tempAgentPosition = json["agent_meta"]["fave_agent_position"][0];
      }

      if (tempAgentMap.containsKey("fave_author_custom_picture")) {
        if(tempThumbnail.isEmpty){
          tempThumbnail = tempAgentMap["fave_author_custom_picture"][0];
        }
      }

      if (tempAgentMap.containsKey("fave_agent_company")) {
        tempAgentCompany = json["agent_meta"]["fave_agent_company"][0];
      }

      if (tempAgentMap.containsKey("first_name")) {
        tempAgentFirstName = json["agent_meta"]["first_name"][0];
      }

      if (tempAgentMap.containsKey("last_name")) {
        tempAgentLastName = json["agent_meta"]["last_name"][0];
      }

      if (tempAgentMap.containsKey("fave_author_agent_id")) {
        tempAgentId = json["agent_meta"]["fave_author_agent_id"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_mobile")) {
        tempAgentMobileNumber = json["agent_meta"]["fave_agent_mobile"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_office_num")) {
        tempAgentOfficeNumber = json["agent_meta"]["fave_agent_office_num"][0];
      }

      if (tempAgentMap.containsKey("fave_author_mobile")) {
        if(tempAgentMobileNumber.isEmpty) {
          tempAgentMobileNumber = json["agent_meta"]["fave_author_mobile"][0];
        }
      }

      if (tempAgentMap.containsKey("fave_author_phone")) {
        tempAgentPhoneNumber = json["agent_meta"]["fave_author_phone"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_fax")) {
        tempAgentFaxNumber = json["agent_meta"]["fave_agent_fax"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_email")) {
        if(tempAgentEmail.isEmpty) {
          tempAgentEmail = json["agent_meta"]["fave_agent_email"][0];
        }
      }

      if (tempAgentMap.containsKey("fave_agent_agencies")) {
        List<dynamic> list = json["agent_meta"]["fave_agent_agencies"];
        tempAgentAgenciesList = List<String>.from(list);
      }

      if (tempAgentMap.containsKey("fave_author_agency_id")) {
        var tempAgentAgencies = json["agent_meta"]["fave_author_agency_id"][0];
        if (tempAgentAgenciesList == null || tempAgentAgenciesList.isEmpty) {
          tempAgentAgenciesList = [tempAgentAgencies];
        }
      }

      if (tempAgentMap.containsKey("fave_agent_address")) {
        tempAgentAddress = json["agent_meta"]["fave_agent_address"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_tax_no")) {
        tempAgentTaxNumber = json["agent_meta"]["fave_agent_tax_no"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_license")) {
        tempAgentLicenseNumber = json["agent_meta"]["fave_agent_license"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_service_area")) {
        tempAgentServiceArea = json["agent_meta"]["fave_agent_service_area"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_specialties")) {
        tempAgentSpecialties = json["agent_meta"]["fave_agent_specialties"][0];
      }

      if (tempAgentMap.containsKey("houzez_total_rating")) {
        tempTotalRating = json["agent_meta"]["houzez_total_rating"][0];
      }

      if (tempAgentMap.containsKey("fave_agent_whatsapp")) {
        agentWhatsappNumber = json["agent_meta"]["fave_agent_whatsapp"][0];
      }
    }

    return Agent(
      id: tempId,
      slug: tempSlug,
      type: tempType,
      title: tempTitle,
      content: tempContent,
      thumbnail: tempThumbnail,
      totalRating: tempTotalRating,
      agentFaxNumber: tempAgentFaxNumber,
      agentLicenseNumber: tempAgentLicenseNumber,
      agentOfficeNumber: tempAgentOfficeNumber,
      agentMobileNumber: tempAgentMobileNumber,
      email: tempAgentEmail,
      agentAddress: tempAgentAddress,
      agentServiceArea: tempAgentServiceArea,
      agentSpecialties: tempAgentSpecialties,
      agentTaxNumber: tempAgentTaxNumber,
      agentAgencies: tempAgentAgenciesList,
      agentCompany: tempAgentCompany,
      agentPosition: tempAgentPosition,
      agentLink: tempAgentLink,
      agentWhatsappNumber: agentWhatsappNumber,
      agentPhoneNumber: tempAgentPhoneNumber,
      agentId : tempAgentId,
      userAgentId : tempUserAgentId,
      agentUserName :agentUserName,
      agentFirstName:tempAgentFirstName,
      agentLastName:tempAgentLastName,
    );
  }

  static Activity parseActivitiesMap(Map<String, dynamic> json) {
    String activityId = "";
    String userId = "";
    String time = "";
    String type = "";
    String subtype = "";
    String name = "";
    String email = "";
    String phone = "";
    String message = "";
    String scheduleTourType = "";
    String scheduleDate = "";
    String scheduleTime = "";
    String title = "";
    var tempListingId;
    String reviewTitle = "";
    var reviewId;
    String reviewStar = "";
    String reviewPostType = "";
    String reviewContent = "";
    String reviewLink = "";
    String userName = "";

    if (json.containsKey("activity_id")) {
      activityId = json['activity_id'];
    }
    if (json.containsKey("user_id")) {
      userId = json['user_id'];
    }

    if (json.containsKey("meta")) {
      Map tempActivitiesMeta = json["meta"];
      if (tempActivitiesMeta.containsKey("type")) {
        type = json["meta"]["type"];
      }
      if (tempActivitiesMeta.containsKey("subtype")) {
        subtype = json["meta"]["subtype"];
      }
      if (tempActivitiesMeta.containsKey("name")) {
        name = json["meta"]["name"];
      }
      if (tempActivitiesMeta.containsKey("email")) {
        email = json["meta"]["email"];
      }
      if (tempActivitiesMeta.containsKey("phone")) {
        phone = json["meta"]["phone"];
      }
      if (tempActivitiesMeta.containsKey("message")) {
        message = json["meta"]["message"];
      }
      if (tempActivitiesMeta.containsKey("schedule_tour_type")) {
        scheduleTourType = json["meta"]["schedule_tour_type"];
      }
      if (tempActivitiesMeta.containsKey("schedule_date")) {
        scheduleDate = json["meta"]["schedule_date"];
      }
      if (tempActivitiesMeta.containsKey("schedule_time")) {
        scheduleTime = json["meta"]["schedule_time"];
      }
      if (tempActivitiesMeta.containsKey("title")) {
        title = json["meta"]["title"];
      }
      if (tempActivitiesMeta.containsKey("listing_id")) {
        tempListingId = json["meta"]["listing_id"];
      }
      if (tempActivitiesMeta.containsKey("review_title")) {
        reviewTitle = json["meta"]["review_title"];
      }
      if (tempActivitiesMeta.containsKey("review_id")) {
        reviewId = json["meta"]["review_id"];
      }
      if (tempActivitiesMeta.containsKey("review_stars")) {
        reviewStar = json["meta"]["review_stars"];
      }
      if (tempActivitiesMeta.containsKey("review_post_type")) {
        reviewPostType = json["meta"]["review_post_type"];
      }
      if (tempActivitiesMeta.containsKey("review_content")) {
        reviewContent = json["meta"]["review_content"];
      }
      if (tempActivitiesMeta.containsKey("review_link")) {
        reviewLink = json["meta"]["review_link"];
      }
      if (tempActivitiesMeta.containsKey("username")) {
        userName = json["meta"]["username"];
      }
    }
    if (json.containsKey("time")) {
      time = json['time'];
    }

    return Activity(
      activityId: activityId,
      userId: userId,
      time: time,
      type: type,
      subtype: subtype,
      name: name,
      email: email,
      phone: phone,
      message: message,
      scheduleTourType: scheduleTourType,
      scheduleDate: scheduleDate,
      scheduleTime: scheduleTime,
      title: title,
      listingId: tempListingId,
      reviewPostType: reviewPostType,
      userName: userName,
      reviewContent: reviewContent,
      reviewId: reviewId,
      reviewLink: reviewLink,
      reviewStar: reviewStar,
      reviewTitle: reviewTitle,
    );
  }

  static Inquiries parseInquiriesMap(Map<String, dynamic> json) {
    String enquiryId = "";
    String userId = "";
    String leadId = "";
    String listingId = "";
    String negotiator = "";
    String source = "";
    String status = "";
    String enquiryTo = "";
    String enquiryUserType = "";
    String message = "";
    String enquiryType = "";
    String privateNote = "";
    String time = "";
    String displayName = "";
    String minBeds = "";
    String maxBeds = "";
    String minBaths = "";
    String maxBaths = "";
    String minPrice = "";
    String maxPrice = "";
    String minArea = "";
    String maxArea = "";
    String zipcode = "";
    String propertyTypeName = "";
    String propertyTypeSlug = "";
    String countryTypeName = "";
    String countryTypeSlug = "";
    String stateTypeName = "";
    String stateTypeSlug = "";
    String cityTypeName = "";
    String cityTypeSlug = "";
    String areaTypeName = "";
    String areaTypeSlug = "";
    int matchedID;
    String postAuthor;
    String postDate;
    String postDateGmt;
    String postContent;
    String postTitle;
    String postExcerpt;
    String postStatus;
    String commentStatus;
    String pingStatus;
    String postPassword;
    String postName;
    String toPing;
    String pinged;
    String postModified;
    String postModifiedGmt;
    String postContentFiltered;
    int postParent;
    String guid;
    int menuOrder;
    String postType;
    String postMimeType;
    String commentCount;
    String filter;
    String location;

    if (json.containsKey("enquiry_id")) {
      enquiryId = json['enquiry_id'];
    }
    if (json.containsKey("user_id")) {
      userId = json['user_id'];
    }
    if (json.containsKey("lead_id")) {
      leadId = json['lead_id'];
    }
    if (json.containsKey("listing_id")) {
      listingId = json['listing_id'];
    }
    if (json.containsKey("negotiator")) {
      negotiator = json['negotiator'];
    }
    if (json.containsKey("source")) {
      source = json['source'];
    }
    if (json.containsKey("status")) {
      status = json['status'];
    }
    if (json.containsKey("enquiry_to")) {
      enquiryTo = json['enquiry_to'];
    }
    if (json.containsKey("enquiry_user_type")) {
      enquiryUserType = json['enquiry_user_type'];
    }
    if (json.containsKey("message")) {
      message = json['message'];
    }
    if (json.containsKey("enquiry_type")) {
      enquiryType = json['enquiry_type'];
    }
    if (json.containsKey("private_note")) {
      privateNote = json['private_note'];
    }
    if (json.containsKey("time")) {
      time = json['time'];
    }
    if (json.containsKey("display_name")) {
      displayName = json['display_name'];
    }

    if (json.containsKey("enquiry_meta")) {
      Map tempInquiresMeta = json["enquiry_meta"];
      if (tempInquiresMeta.containsKey("min_beds")) {
        minBeds = json["enquiry_meta"]["min_beds"];
      }
      if (tempInquiresMeta.containsKey("max_beds")) {
        maxBeds = json["enquiry_meta"]["max_beds"];
      }
      if (tempInquiresMeta.containsKey("min_baths")) {
        minBaths = json["enquiry_meta"]["min_baths"];
      }
      if (tempInquiresMeta.containsKey("max_baths")) {
        maxBaths = json["enquiry_meta"]["max_baths"];
      }
      if (tempInquiresMeta.containsKey("min_price")) {
        minPrice = json["enquiry_meta"]["min_price"];
      }
      if (tempInquiresMeta.containsKey("max_price")) {
        maxPrice = json["enquiry_meta"]["max_price"];
      }
      if (tempInquiresMeta.containsKey("min_area")) {
        minArea = json["enquiry_meta"]["min_area"];
      }
      if (tempInquiresMeta.containsKey("max_area")) {
        maxArea = json["enquiry_meta"]["max_area"];
      }
      if (tempInquiresMeta.containsKey("zipcode")) {
        zipcode = json["enquiry_meta"]["zipcode"];
      }

      var tempInquiresProperty = tempInquiresMeta["property_type"];
      if(tempInquiresProperty is Map){
        if (tempInquiresProperty != null && tempInquiresProperty.isNotEmpty) {
          if (tempInquiresProperty.containsKey("name")) {
            propertyTypeName = tempInquiresProperty["name"];
          }
          if (tempInquiresProperty.containsKey("slug")) {
            propertyTypeSlug = tempInquiresProperty["slug"];
          }
        }
      }

      var tempInquiresCountry = tempInquiresMeta["country"];
      if (tempInquiresCountry is Map) {
        if (tempInquiresCountry != null && tempInquiresCountry.isNotEmpty) {
          if (tempInquiresCountry.containsKey("name")) {
            countryTypeName = tempInquiresCountry["name"];
          }
          if (tempInquiresCountry.containsKey("slug")) {
            countryTypeSlug = tempInquiresCountry["slug"];
          }
        }
      }

      var tempInquiresState = tempInquiresMeta["state"];
      if (tempInquiresState is Map) {
        if (tempInquiresState != null && tempInquiresState.isNotEmpty) {
          if (tempInquiresState.containsKey("name")) {
            stateTypeName = tempInquiresState["name"];
          }
          if (tempInquiresState.containsKey("slug")) {
            stateTypeSlug = tempInquiresState["slug"];
          }
        }
      }

      var tempInquiresCity = tempInquiresMeta["city"];
      if (tempInquiresCity is Map) {
        if (tempInquiresCity != null && tempInquiresCity.isNotEmpty) {
          if (tempInquiresCity.containsKey("name")) {
            cityTypeName = tempInquiresCity["name"];
          }
          if (tempInquiresCity.containsKey("slug")) {
            cityTypeSlug = tempInquiresCity["slug"];
          }
        }
      }

      var tempInquiresArea = tempInquiresMeta["area"];
      if (tempInquiresArea is Map) {
        if (tempInquiresArea != null && tempInquiresArea.isNotEmpty) {
          if (tempInquiresArea.containsKey("name")) {
            areaTypeName = tempInquiresArea["name"];
          }
          if (tempInquiresArea.containsKey("slug")) {
            areaTypeSlug = tempInquiresArea["slug"];
          }
        }
      }

      location = "$countryTypeName " +
          "$stateTypeName " +
          "$cityTypeName " +
          "$areaTypeName " +
          "$zipcode";

    }
    if (json.containsKey("matched")) {
      List list = json["matched"];
      if (list != null && list.isNotEmpty) {
        Map tempMatches = list[0];
        if (tempMatches.containsKey("ID")) {
          matchedID = tempMatches["ID"];
        }
        if (tempMatches.containsKey("post_author")) {
          postAuthor = tempMatches["post_author"];
        }
        if (tempMatches.containsKey("post_date")) {
          postDate = tempMatches["post_date"];
        }
        if (tempMatches.containsKey("post_date_gmt")) {
          postDateGmt = tempMatches["post_date_gmt"];
        }
        if (tempMatches.containsKey("post_content")) {
          postContent = tempMatches["post_content"];
        }
        if (tempMatches.containsKey("post_title")) {
          postTitle = tempMatches["post_title"];
        }
        if (tempMatches.containsKey("post_excerpt")) {
          postExcerpt = tempMatches["post_excerpt"];
        }
        if (tempMatches.containsKey("post_status")) {
          postStatus = tempMatches["post_status"];
        }
        if (tempMatches.containsKey("comment_status")) {
          commentStatus = tempMatches["comment_status"];
        }
        if (tempMatches.containsKey("ping_status")) {
          pingStatus = tempMatches["ping_status"];
        }
        if (tempMatches.containsKey("post_password")) {
          postPassword = tempMatches["post_password"];
        }
        if (tempMatches.containsKey("post_name")) {
          postName = tempMatches["post_name"];
        }
        if (tempMatches.containsKey("to_ping")) {
          toPing = tempMatches["to_ping"];
        }
        if (tempMatches.containsKey("pinged")) {
          pinged = tempMatches["pinged"];
        }
        if (tempMatches.containsKey("post_modified")) {
          postModified = tempMatches["post_modified"];
        }
        if (tempMatches.containsKey("post_modified_gmt")) {
          postModifiedGmt = tempMatches["post_modified_gmt"];
        }
        if (tempMatches.containsKey("post_content_filtered")) {
          postContentFiltered = tempMatches["post_content_filtered"];
        }
        if (tempMatches.containsKey("post_parent")) {
          postParent = tempMatches["post_parent"];
        }
        if (tempMatches.containsKey("guid")) {
          guid = tempMatches["guid"];
        }
        if (tempMatches.containsKey("menu_order")) {
          menuOrder = tempMatches["menu_order"];
        }
        if (tempMatches.containsKey("post_type")) {
          postType = tempMatches["post_type"];
        }
        if (tempMatches.containsKey("post_mime_type")) {
          postMimeType = tempMatches["post_mime_type"];
        }
        if (tempMatches.containsKey("comment_count")) {
          commentCount = tempMatches["comment_count"];
        }
        if (tempMatches.containsKey("filter")) {
          filter = tempMatches["filter"];
        }
      }
    }

    return Inquiries(
      enquiryId: enquiryId,
      userId: userId,
      leadId: leadId,
      listingId: listingId,
      negotiator: negotiator,
      source: source,
      status: status,
      enquiryTo: enquiryTo,
      enquiryUserType: enquiryUserType,
      message: message,
      enquiryType: enquiryType,
      privateNote: privateNote,
      time: time,
      minBeds: minBeds,
      maxBeds: maxBeds,
      minBaths: minBaths,
      maxBaths: maxBaths,
      minPrice: minPrice,
      maxPrice: maxPrice,
      minArea: minArea,
      maxArea: maxArea,
      zipcode: zipcode,
      propertyTypeName: propertyTypeName,
      propertyTypeSlug: propertyTypeSlug,
      countryTypeName: countryTypeName,
      countryTypeSlug: countryTypeSlug,
      stateTypeName: stateTypeName,
      stateTypeSlug: stateTypeSlug,
      cityTypeName: cityTypeName,
      cityTypeSlug: cityTypeSlug,
      areaTypeName: areaTypeName,
      areaTypeSlug: areaTypeSlug,
      matchedID: matchedID,
      postAuthor: postAuthor,
      postDate: postDate,
      postDateGmt: postDateGmt,
      postContent: postContent,
      postTitle: postTitle,
      postExcerpt: postExcerpt,
      postStatus: postStatus,
      commentStatus: commentStatus,
      pingStatus: pingStatus,
      postPassword: postPassword,
      postName: postName,
      toPing: toPing,
      pinged: pinged,
      postModified: postModified,
      postModifiedGmt: postModifiedGmt,
      postContentFiltered: postContentFiltered,
      postParent: postParent,
      guid: guid,
      menuOrder: menuOrder,
      postType: postType,
      postMimeType: postMimeType,
      commentCount: commentCount,
      filter: filter,
      displayName: displayName,
      location: location
    );
  }

  static LeadsFromActivity parseLeadsMap(Map<String, dynamic> json) {
    String totalRecords = "";
    int itemsPerPage;
    int page;
    int lastDay;
    int lastTwo;
    int lastWeek;
    int last2Week;
    int lastMonth;
    int last2Month;

    if (json.containsKey("total_records")) {
      totalRecords = json['total_records'];
    }
    if (json.containsKey("items_per_page")) {
      itemsPerPage = json['items_per_page'];
    }
    if (json.containsKey("page")) {
      page = json['page'];
    }

    if (json.containsKey("stats")) {
      Map tempLeadsMeta = json["stats"];
      if (tempLeadsMeta.containsKey("lastday")) {
        lastDay = json["stats"]["lastday"];
      }
      if (tempLeadsMeta.containsKey("lasttwo")) {
        lastTwo = json["stats"]["lasttwo"];
      }
      if (tempLeadsMeta.containsKey("lastweek")) {
        lastWeek = json["stats"]["lastweek"];
      }
      if (tempLeadsMeta.containsKey("last2week")) {
        last2Week = json["stats"]["last2week"];
      }
      if (tempLeadsMeta.containsKey("lastmonth")) {
        lastMonth = json["stats"]["lastmonth"];
      }
      if (tempLeadsMeta.containsKey("last2month")) {
        last2Month = json["stats"]["last2month"];
      }
    }

    return LeadsFromActivity(
      totalRecords: totalRecords,
      itemsPerPage: itemsPerPage,
      page: page,
      lastDay: lastDay,
      lastTwo: lastTwo,
      lastWeek: lastWeek,
      last2Week: last2Week,
      lastMonth: lastMonth,
      last2Month: last2Month,
    );
  }

  static DealsFromActivity parseDealsFromActivityMap(Map<String, dynamic> json) {
    String activeCount = "";
    String wonCount = "";
    String lostCount = "";

    if (json.containsKey("deals")) {
      Map tempLeadsMeta = json["deals"];
      if (tempLeadsMeta.containsKey("active_count")) {
        activeCount = json["deals"]["active_count"];
      }
      if (tempLeadsMeta.containsKey("won_count")) {
        wonCount = json["deals"]["won_count"];
      }
      if (tempLeadsMeta.containsKey("lost_count")) {
        lostCount = json["deals"]["lost_count"];
      }

    }

    return DealsFromActivity(
      lostCount : lostCount,
      wonCount :wonCount,
      activeCount:activeCount,
    );
  }

  static DealsAndLeads parseDealsFromBoardMap(Map<String, dynamic> json) {
    String totalRecords;
    int itemsPerPage;
    int page;
    String status;
    String actions;
    String activeCount;
    String wonCount;
    String lostCount;
    String dealId;
    String userId;
    String title;
    String listingId;
    String resultLeadId;
    String agentId;
    String agentType;
    String leadStatus;
    String nextAction;
    String actionDueDate;
    String dealValue;
    String lastContactDate;
    String resultPrivateNote;
    String dealGroup;
    String resultTime;
    String agentName;
    String leadLeadId;
    String leadUserId;
    String prefix;
    String displayName;
    String firstName;
    String lastName;
    String email;
    String mobile;
    String homePhone;
    String workPhone;
    String address;
    String city;
    String state;
    String country;
    String zipcode;
    String type;
    String resultStatus;
    String source;
    String sourceLink;
    String enquiryTo;
    String enquiryUserType;
    String twitterUrl;
    String linkedinUrl;
    String facebookUrl;
    String leadPrivateNote;
    String message;
    String leadTime;

    // if (json.containsKey("total_records")) {
    //   totalRecords = json['total_records'];
    // }
    // if (json.containsKey("items_per_page")) {
    //   itemsPerPage = json['items_per_page'];
    // }
    // if (json.containsKey("page")) {
    //   page = json['page'];
    // }
    // if (json.containsKey("status")) {
    //   status = json['status'];
    // }
    // if (json.containsKey("actions")) {
    //   actions = json['actions'];
    // }
    // if (json.containsKey("active_count")) {
    //   activeCount = json['active_count'];
    // }
    // if (json.containsKey("won_count")) {
    //   wonCount = json['won_count'];
    // }
    // if (json.containsKey("lost_count")) {
    //   lostCount = json['lost_count'];
    // }

    if (json.containsKey("deal_id")) {
      dealId = json["deal_id"];
    }
    if (json.containsKey("user_id")) {
      userId = json["user_id"];
    }
    if (json.containsKey("title")) {
      title = json["title"];
    }
    if (json.containsKey("listing_id")) {
      listingId = json["listing_id"];
    }
    if (json.containsKey("lead_id")) {
      resultLeadId = json["lead_id"];
    }
    if (json.containsKey("agent_id")) {
      agentId = json["agent_id"];
    }
    if (json.containsKey("agent_type")) {
      agentType = json["agent_type"];
    }
    if (json.containsKey("status")) {
      resultStatus = json["status"];
    }
    if (json.containsKey("next_action")) {
      nextAction = json["next_action"];
    }
    if (json.containsKey("action_due_date")) {
      actionDueDate = json["action_due_date"];
    }
    if (json.containsKey("deal_value")) {
      dealValue = json["deal_value"];
    }
    if (json.containsKey("last_contact_date")) {
      lastContactDate = json["last_contact_date"];
    }
    if (json.containsKey("private_note")) {
      resultPrivateNote = json["private_note"];
    }
    if (json.containsKey("deal_group")) {
      dealGroup = json["deal_group"];
    }
    if (json.containsKey("time")) {
      resultTime = json["time"];
    }
    if (json.containsKey("agent_name")) {
      agentName = json["agent_name"];
    }
    if (json.containsKey("lead")) {
      Map tempResultLeadMeta = json["lead"];
      if (tempResultLeadMeta.containsKey("lead_id")) {
        leadLeadId = tempResultLeadMeta["lead_id"];
      }
      if (tempResultLeadMeta.containsKey("user_id")) {
        leadUserId = tempResultLeadMeta["user_id"];
      }
      if (tempResultLeadMeta.containsKey("prefix")) {
        prefix = tempResultLeadMeta["prefix"];
      }
      if (tempResultLeadMeta.containsKey("display_name")) {
        displayName = tempResultLeadMeta["display_name"];
      }
      if (tempResultLeadMeta.containsKey("first_name")) {
        firstName = tempResultLeadMeta["first_name"];
      }
      if (tempResultLeadMeta.containsKey("last_name")) {
        lastName = tempResultLeadMeta["last_name"];
      }
      if (tempResultLeadMeta.containsKey("email")) {
        email = tempResultLeadMeta["email"];
      }
      if (tempResultLeadMeta.containsKey("mobile")) {
        mobile = tempResultLeadMeta["mobile"];
      }
      if (tempResultLeadMeta.containsKey("home_phone")) {
        homePhone = tempResultLeadMeta["home_phone"];
      }
      if (tempResultLeadMeta.containsKey("work_phone")) {
        workPhone = tempResultLeadMeta["work_phone"];
      }
      if (tempResultLeadMeta.containsKey("address")) {
        address = tempResultLeadMeta["address"];
      }
      if (tempResultLeadMeta.containsKey("city")) {
        city = tempResultLeadMeta["city"];
      }
      if (tempResultLeadMeta.containsKey("state")) {
        state = tempResultLeadMeta["state"];
      }
      if (tempResultLeadMeta.containsKey("country")) {
        country = tempResultLeadMeta["country"];
      }
      if (tempResultLeadMeta.containsKey("zipcode")) {
        zipcode = tempResultLeadMeta["zipcode"];
      }
      if (tempResultLeadMeta.containsKey("type")) {
        type = tempResultLeadMeta["type"];
      }
      if (tempResultLeadMeta.containsKey("status")) {
        leadStatus = tempResultLeadMeta["status"];
      }
      if (tempResultLeadMeta.containsKey("source")) {
        source = tempResultLeadMeta["source"];
      }
      if (tempResultLeadMeta.containsKey("source_link")) {
        sourceLink = tempResultLeadMeta["source_link"];
      }
      if (tempResultLeadMeta.containsKey("enquiry_to")) {
        enquiryTo = tempResultLeadMeta["enquiry_to"];
      }
      if (tempResultLeadMeta.containsKey("enquiry_user_type")) {
        enquiryUserType = tempResultLeadMeta["enquiry_user_type"];
      }
      if (tempResultLeadMeta.containsKey("twitter_url")) {
        twitterUrl = tempResultLeadMeta["twitter_url"];
      }
      if (tempResultLeadMeta.containsKey("linkedin_url")) {
        linkedinUrl = tempResultLeadMeta["linkedin_url"];
      }
      if (tempResultLeadMeta.containsKey("facebook_url")) {
        facebookUrl = tempResultLeadMeta["facebook_url"];
      }
      if (tempResultLeadMeta.containsKey("private_note")) {
        leadPrivateNote = tempResultLeadMeta["private_note"];
      }
      if (tempResultLeadMeta.containsKey("message")) {
        message = tempResultLeadMeta["message"];
      }
      if (tempResultLeadMeta.containsKey("time")) {
        leadTime = tempResultLeadMeta["time"];
      }
    }

    if (json.containsKey("lead_id")) {
      leadLeadId = json["lead_id"];
    }
    if (json.containsKey("user_id")) {
      leadUserId = json["user_id"];
    }
    if (json.containsKey("prefix")) {
      prefix = json["prefix"];
    }
    if (json.containsKey("display_name")) {
      displayName = json["display_name"];
    }
    if (json.containsKey("first_name")) {
      firstName = json["first_name"];
    }
    if (json.containsKey("last_name")) {
      lastName = json["last_name"];
    }
    if (json.containsKey("email")) {
      email = json["email"];
    }
    if (json.containsKey("mobile")) {
      mobile = json["mobile"];
    }
    if (json.containsKey("home_phone")) {
      homePhone = json["home_phone"];
    }
    if (json.containsKey("work_phone")) {
      workPhone = json["work_phone"];
    }
    if (json.containsKey("address")) {
      address = json["address"];
    }
    if (json.containsKey("city")) {
      city = json["city"];
    }
    if (json.containsKey("state")) {
      state = json["state"];
    }
    if (json.containsKey("country")) {
      country = json["country"];
    }
    if (json.containsKey("zipcode")) {
      zipcode = json["zipcode"];
    }
    if (json.containsKey("type")) {
      type = json["type"];
    }
    if (json.containsKey("status")) {
      leadStatus = json["status"];
    }
    if (json.containsKey("source")) {
      source = json["source"];
    }
    if (json.containsKey("source_link")) {
      sourceLink = json["source_link"];
    }
    if (json.containsKey("enquiry_to")) {
      enquiryTo = json["enquiry_to"];
    }
    if (json.containsKey("enquiry_user_type")) {
      enquiryUserType = json["enquiry_user_type"];
    }
    if (json.containsKey("twitter_url")) {
      twitterUrl = json["twitter_url"];
    }
    if (json.containsKey("linkedin_url")) {
      linkedinUrl = json["linkedin_url"];
    }
    if (json.containsKey("facebook_url")) {
      facebookUrl = json["facebook_url"];
    }
    if (json.containsKey("private_note")) {
      leadPrivateNote = json["private_note"];
    }
    if (json.containsKey("message")) {
      message = json["message"];
    }
    if (json.containsKey("time")) {
      leadTime = json["time"];
    }

    return DealsAndLeads(
        // totalRecords: totalRecords,
        // itemsPerPage: itemsPerPage,
        // page: page,
        // status: status,
        // actions: actions,
        // activeCount: activeCount,
        // wonCount: wonCount,
        // lostCount: lostCount,
        dealId: dealId,
        userId: userId,
        title: title,
        listingId: listingId,
        resultLeadId: resultLeadId,
        agentId: agentId,
        agentType: agentType,
        leadStatus: leadStatus,
        nextAction: nextAction,
        actionDueDate: actionDueDate,
        dealValue: dealValue,
        lastContactDate: lastContactDate,
        resultPrivateNote: resultPrivateNote,
        dealGroup: dealGroup,
        resultTime: resultTime,
        agentName: agentName,
        leadLeadId: leadLeadId,
        leadUserId: leadUserId,
        prefix: prefix,
        displayName: displayName,
        firstName: firstName,
        lastName: lastName,
        email: email,
        mobile: mobile,
        homePhone: homePhone,
        workPhone: workPhone,
        address: address,
        city: city,
        state: state,
        country: country,
        zipcode: zipcode,
        type: type,
        resultStatus: resultStatus,
        source: source,
        sourceLink: sourceLink,
        enquiryTo: enquiryTo,
        enquiryUserType: enquiryUserType,
        twitterUrl: twitterUrl,
        linkedinUrl: linkedinUrl,
        facebookUrl: facebookUrl,
        leadPrivateNote: leadPrivateNote,
        message: message,
        leadTime: leadTime
    );
  }

  static Author parseAuthorInfoMap(Map<String, dynamic> json) {
    int tempId;
    bool tempIsSingle;
    String tempData;
    String tempEmail;
    String tempName;
    String tempPhone;
    String tempPhoneCall;
    String tempMobile;
    String tempMobileCall;
    String tempWhatsApp;
    String tempWhatsAppCall;
    String tempPicture;
    String tempLink;
    String tempType;

    if(json.containsKey('property_meta')){
      Map tempMetaMap = json['property_meta'];
      if(tempMetaMap.containsKey('agent_info')){
        Map tempAgentInfo = tempMetaMap['agent_info'];
        if(tempAgentInfo.containsKey('agent_data')){
          tempData = tempAgentInfo['agent_data'] is String ? tempAgentInfo['agent_data'] : null;
        }
        if(tempAgentInfo.containsKey('is_single_agent')){
          tempIsSingle = tempAgentInfo['is_single_agent'] is bool ? tempAgentInfo['is_single_agent'] : null;
        }
        if(tempAgentInfo.containsKey('agent_email')){
          tempEmail = tempAgentInfo['agent_email'] is String ? tempAgentInfo['agent_email'] : null;
        }
        if(tempAgentInfo.containsKey('agent_name')){
          tempName = tempAgentInfo['agent_name'] is String ? tempAgentInfo['agent_name'] : null;
        }
        if(tempAgentInfo.containsKey('agent_phone')){
          tempPhone = tempAgentInfo['agent_phone'] is String ? tempAgentInfo['agent_phone'] : null;
        }
        if(tempAgentInfo.containsKey('agent_phone_call')){
          tempPhoneCall = tempAgentInfo['agent_phone_call'] is String ? tempAgentInfo['agent_phone_call'] : null;
        }
        if(tempAgentInfo.containsKey('agent_mobile')){
          tempMobile = tempAgentInfo['agent_mobile'] is String ? tempAgentInfo['agent_mobile'] : null;
        }
        if(tempAgentInfo.containsKey('agent_mobile_call')){
          tempMobileCall = tempAgentInfo['agent_mobile_call'] is String ? tempAgentInfo['agent_mobile_call'] : null;
        }
        if(tempAgentInfo.containsKey('agent_whatsapp')){
          tempWhatsApp = tempAgentInfo['agent_whatsapp'] is String ? tempAgentInfo['agent_whatsapp'] : null;
        }
        if(tempAgentInfo.containsKey('agent_whatsapp_call')){
          tempWhatsAppCall = tempAgentInfo['agent_whatsapp_call'] is String ? tempAgentInfo['agent_whatsapp_call'] : null;
        }
        if(tempAgentInfo.containsKey('picture')){
          tempPicture = tempAgentInfo['picture'] is String ? tempAgentInfo['picture'] : null;
        }
        if(tempAgentInfo.containsKey('link')){
          tempLink = tempAgentInfo['link'] is String ? tempAgentInfo['link'] : null;
        }
        if(tempAgentInfo.containsKey('agent_type')){
          tempType = tempAgentInfo['agent_type'] is String ? tempAgentInfo['agent_type'] : null;
        }
        if(tempAgentInfo.containsKey('agent_id')){
          tempId = tempAgentInfo['agent_id'] is int ? tempAgentInfo['agent_id'] : null;
        }
      }
    }

    Author authorInfo = Author(
      id: tempId,
      isSingle: tempIsSingle,
      data: tempData,
      email: tempEmail,
      name: tempName,
      phone: tempPhone,
      phoneCall: tempPhoneCall,
      mobile: tempMobile,
      mobileCall: tempMobileCall,
      whatsApp: tempWhatsApp,
      whatsAppCall: tempWhatsAppCall,
      picture: tempPicture,
      link: tempLink,
      type: tempType,
    );
    return authorInfo;
  }

  static FloorPlans parseFloorPlansMap(Map<String, dynamic> json) {
    String tempTitle;
    String tempRooms;
    String tempBathrooms;
    String tempPrice;
    String tempPricePostFix;
    String tempSize;
    String tempImage;
    String tempDescription;

    Map tempFloorPlanInfo = json;
    if(tempFloorPlanInfo.containsKey('fave_plan_title')){
      tempTitle = tempFloorPlanInfo['fave_plan_title'] is String ? tempFloorPlanInfo['fave_plan_title'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_rooms')){
      tempRooms = tempFloorPlanInfo['fave_plan_rooms'] is String ? tempFloorPlanInfo['fave_plan_rooms'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_bathrooms')){
      tempBathrooms = tempFloorPlanInfo['fave_plan_bathrooms'] is String ? tempFloorPlanInfo['fave_plan_bathrooms'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_price')){
      tempPrice = tempFloorPlanInfo['fave_plan_price'] is String ? tempFloorPlanInfo['fave_plan_price'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_price_postfix')){
      tempPricePostFix = tempFloorPlanInfo['fave_plan_price_postfix'] is String ? tempFloorPlanInfo['fave_plan_price_postfix'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_size')){
      tempSize = tempFloorPlanInfo['fave_plan_size'] is String ? tempFloorPlanInfo['fave_plan_size'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_image')){
      tempImage = tempFloorPlanInfo['fave_plan_image'] is String ? tempFloorPlanInfo['fave_plan_image'] : null;
    }
    if(tempFloorPlanInfo.containsKey('fave_plan_description')){
      tempDescription = tempFloorPlanInfo['fave_plan_description'] is String ? tempFloorPlanInfo['fave_plan_description'] : null;
    }


    FloorPlans floorPlans = FloorPlans(
      title: tempTitle,
      rooms: tempRooms,
      bathrooms: tempBathrooms,
      price: tempPrice,
      pricePostFix: tempPricePostFix,
      size: tempSize,
      image: tempImage,
      description: tempDescription,
    );

    return floorPlans;
  }

  static MultiUnit parseMultiUnitsMap(Map<String, dynamic> json) {
    String faveMuTitle;
    String faveMuPrice;
    String faveMuPricePostfix;
    String faveMuBeds;
    String faveMuBaths;
    String faveMuSize;
    String faveMuSizePostfix;
    String faveMuType;
    String faveMuAvailabilityDate;

    Map tempMultiUnitInfo = json;
    if(tempMultiUnitInfo.containsKey('fave_mu_title')){
      faveMuTitle = tempMultiUnitInfo['fave_mu_title'] is String ? tempMultiUnitInfo['fave_mu_title'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_price')){
      faveMuPrice = tempMultiUnitInfo['fave_mu_price'] is String ? tempMultiUnitInfo['fave_mu_price'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_price_postfix')){
      faveMuPricePostfix = tempMultiUnitInfo['fave_mu_price_postfix'] is String ? tempMultiUnitInfo['fave_mu_price_postfix'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_beds')){
      faveMuBeds = tempMultiUnitInfo['fave_mu_beds'] is String ? tempMultiUnitInfo['fave_mu_beds'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_baths')){
      faveMuBaths = tempMultiUnitInfo['fave_mu_baths'] is String ? tempMultiUnitInfo['fave_mu_baths'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_size')){
      faveMuSize = tempMultiUnitInfo['fave_mu_size'] is String ? tempMultiUnitInfo['fave_mu_size'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_size_postfix')){
      faveMuSizePostfix = tempMultiUnitInfo['fave_mu_size_postfix'] is String ? tempMultiUnitInfo['fave_mu_size_postfix'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_type')){
      faveMuType = tempMultiUnitInfo['fave_mu_type'] is String ? tempMultiUnitInfo['fave_mu_type'] : null;
    }
    if(tempMultiUnitInfo.containsKey('fave_mu_availability_date')){
      faveMuAvailabilityDate = tempMultiUnitInfo['fave_mu_availability_date'] is String ? tempMultiUnitInfo['fave_mu_availability_date'] : null;
    }


    MultiUnit multiUnit = MultiUnit(
      availabilityDate: faveMuAvailabilityDate,
      bathrooms: faveMuBaths,
      bedrooms: faveMuBeds,
      price: faveMuPrice,
      pricePostfix: faveMuPricePostfix,
      size: faveMuSize,
      sizePostfix: faveMuSizePostfix,
      title: faveMuTitle,
      type: faveMuType,
    );

    return multiUnit;
  }

  static SavedSearch parseSavedSearchMap(Map<String, dynamic> json) {
    String id;
    String autherId;
    String query;
    String email;
    String url;
    String time;

    if(json.containsKey("id")){
      id = json["id"];
    }

    if(json.containsKey("auther_id")){
      autherId = json["auther_id"];
    }

    if(json.containsKey("query")){
      query = json["query"];
    }

    if(json.containsKey("email")){
      email = json["email"];
    }

    if(json.containsKey("url")){
      url = json["url"];
    }

    if(json.containsKey("time")){
      time = json["time"];
    }


    return SavedSearch(
      id: id,
      autherId: autherId,
      email: email,
      query: query,
      time: time,
      url: url,
    );
  }

  static User parseUserInfoMap(Map<String, dynamic> json) {
    String id= "";
    String userLogin= "";
    String userNicename= "";
    String userEmail= "";
    String userUrl= "";
    String userStatus= "";
    String displayName= "";
    String profile= "";
    String username= "";
    String userTitle= "";
    String firstName= "";
    String lastName= "";
    String userMobile= "";
    String userWhatsapp= "";
    String userPhone= "";
    String description= "";
    String userlangs= "";
    String userCompany= "";
    String taxNumber= "";
    String faxNumber= "";
    String userAddress= "";
    String serviceAreas= "";
    String specialties= "";
    String license= "";
    String gdprAgreement= "";
    String roles= "";
    String facebook = "";
    String twitter = "";
    String instagram = "";
    String linkedin = "";
    String youtube = "";
    String pinterest = "";
    String vimeo = "";
    String skype = "";
    String website = "";
    List displayNameOptions = [];

    if(json.containsKey("roles")){
      roles = json["roles"][0];
    }

    if(json.containsKey("user")){
      Map userData = json["user"];

      if(userData.containsKey('data')){
        Map tempDataMap = userData['data'];
        if(tempDataMap.containsKey('ID')) {
          id = tempDataMap['ID'];
        }
        if(tempDataMap.containsKey('user_login')) {
          id = tempDataMap['user_login'];
        }
        if(tempDataMap.containsKey('user_nicename')) {
          userNicename = tempDataMap['user_nicename'];
        }
        if(tempDataMap.containsKey('user_email')) {
          userEmail = tempDataMap['user_email'];
        }
        if(tempDataMap.containsKey('user_url')) {
          userUrl = tempDataMap['user_url'];
        }
        if(tempDataMap.containsKey('user_status')) {
          userStatus = tempDataMap['user_status'];
        }
        if(tempDataMap.containsKey('display_name')) {
          displayName = tempDataMap['display_name'];
        }
        if(tempDataMap.containsKey('profile') && tempDataMap['profile'] is String) {
          profile = tempDataMap['profile'];
        }
        if(tempDataMap.containsKey('username')) {
          username = tempDataMap['username'];
        }
        if(tempDataMap.containsKey('user_title')) {
          userTitle = tempDataMap['user_title'];
        }
        if(tempDataMap.containsKey('first_name')) {
          firstName = tempDataMap['first_name'];
        }
        if(tempDataMap.containsKey('last_name')) {
          lastName = tempDataMap['last_name'];
        }
        if(tempDataMap.containsKey('user_mobile')) {
          userMobile = tempDataMap['user_mobile'];
        }
        if(tempDataMap.containsKey('user_whatsapp')) {
          userWhatsapp = tempDataMap['user_whatsapp'];
        }
        if(tempDataMap.containsKey('user_phone')) {
          userPhone = tempDataMap['user_phone'];
        }
        if(tempDataMap.containsKey('description')) {
          // description = tempDataMap['description'];
          description = GenericMethods.cleanContent(tempDataMap['description']);
        }
        if(tempDataMap.containsKey('userlangs')) {
          userlangs = tempDataMap['userlangs'];
        }
        if(tempDataMap.containsKey('user_company')) {
          userCompany = tempDataMap['user_company'];
        }
        if(tempDataMap.containsKey('tax_number')) {
          taxNumber = tempDataMap['tax_number'];
        }
        if(tempDataMap.containsKey('fax_number')) {
          faxNumber = tempDataMap['fax_number'];
        }
        if(tempDataMap.containsKey('user_address')) {
          userAddress = tempDataMap['user_address'];
        }
        if(tempDataMap.containsKey('service_areas')) {
          serviceAreas = tempDataMap['service_areas'];
        }
        if(tempDataMap.containsKey('specialties')) {
          specialties = tempDataMap['specialties'];
        }
        if(tempDataMap.containsKey('license')) {
          license = tempDataMap['license'];
        }
        if(tempDataMap.containsKey('gdpr_agreement')) {
          gdprAgreement = tempDataMap['gdpr_agreement'];
        }
        if(tempDataMap.containsKey('facebook')) {
          facebook = tempDataMap['facebook'];
        }
        if(tempDataMap.containsKey('twitter')) {
          twitter = tempDataMap['twitter'];
        }
        if(tempDataMap.containsKey('instagram')) {
          instagram = tempDataMap['instagram'];
        }
        if(tempDataMap.containsKey('linkedin')) {
          linkedin = tempDataMap['linkedin'];
        }
        if(tempDataMap.containsKey('userskype')) {
          skype = tempDataMap['userskype'];
        }
        if(tempDataMap.containsKey('pinterest')) {
          pinterest = tempDataMap['pinterest'];
        }
        if(tempDataMap.containsKey('youtube')) {
          youtube = tempDataMap['youtube'];
        }
        if(tempDataMap.containsKey('vimeo')) {
          vimeo = tempDataMap['vimeo'];
        }
        if(tempDataMap.containsKey('website')) {
          website = tempDataMap['website'];
        }

        if (tempDataMap.containsKey("display_name_options")) {
          var tempData = tempDataMap["display_name_options"];
          if(tempData is List){
            List<dynamic> list = tempDataMap["display_name_options"];
            displayNameOptions = List<String>.from(list);
          }
        }
      }

    }

    return User(
      id: id,
      lastName: lastName,
      firstName: firstName,
      displayName: displayName,
      description: description,
      faxNumber: faxNumber,
      gdprAgreement: gdprAgreement,
      license: license,
      profile: profile,
      roles: roles,
      serviceAreas: serviceAreas,
      specialties: specialties,
      taxNumber: taxNumber,
      userAddress: userAddress,
      userCompany: userCompany,
      userEmail: userEmail,
      userlangs: userlangs,
      userLogin: userLogin,
      userMobile: userMobile,
      username: username,
      userNicename: userNicename,
      userPhone: userPhone,
      userStatus: userStatus,
      userTitle: userTitle,
      userUrl: userUrl,
      userWhatsapp: userWhatsapp,
      displayNameOptions: displayNameOptions,
      facebook: facebook,
      instagram: instagram,
      linkedin: linkedin,
      twitter: twitter,
      pinterest: pinterest,
      skype: skype,
      vimeo: vimeo,
      website: website,
      youtube: youtube,
    );
  }

  static DealsAndLeadsFromActivity parseDealsAndLeadsFromActivityMap(Map<String, dynamic> json) {

    String activeCount = "";
    String wonCount = "";
    String lostCount = "";

    if (json.containsKey("deals")) {
      Map tempLeadsMeta = json["deals"];
      if (tempLeadsMeta.containsKey("active_count")) {
        activeCount = json["deals"]["active_count"];
      }
      if (tempLeadsMeta.containsKey("won_count")) {
        wonCount = json["deals"]["won_count"];
      }
      if (tempLeadsMeta.containsKey("lost_count")) {
        lostCount = json["deals"]["lost_count"];
      }

    }

    int lastDay;
    int lastTwo;
    int lastWeek;
    int last2Week;
    int lastMonth;
    int last2Month;

    if (json.containsKey("stats")) {
      Map tempLeadsMeta = json["stats"];
      if (tempLeadsMeta.containsKey("lastday")) {
        lastDay = json["stats"]["lastday"];
      }
      if (tempLeadsMeta.containsKey("lasttwo")) {
        lastTwo = json["stats"]["lasttwo"];
      }
      if (tempLeadsMeta.containsKey("lastweek")) {
        lastWeek = json["stats"]["lastweek"];
      }
      if (tempLeadsMeta.containsKey("last2week")) {
        last2Week = json["stats"]["last2week"];
      }
      if (tempLeadsMeta.containsKey("lastmonth")) {
        lastMonth = json["stats"]["lastmonth"];
      }
      if (tempLeadsMeta.containsKey("last2month")) {
        last2Month = json["stats"]["last2month"];
      }
    }

    return DealsAndLeadsFromActivity(
      activeCount: activeCount,
      wonCount: wonCount,
      lostCount: lostCount,
      lastDay: lastDay,
      lastTwo: lastTwo,
      lastWeek: lastWeek,
      last2Week: last2Week,
      lastMonth: lastMonth,
      last2Month: last2Month,
    );
  }

  static AgentMetaData parseAgentMetaDataMap(Map<String, dynamic> json) {
    int termId;
    String name = "";
    String slug = "";
    int termGroup;
    int termTaxonomyId;
    String taxonomy = "";
    String description = "";
    int parent;
    int count;
    String filter = "";

    if (json.containsKey("term_id")) {
      termId = json["term_id"];
    }
    if (json.containsKey("name")) {
      name = json["name"];
    }
    if (json.containsKey("slug")) {
      slug = json["slug"];
    }
    if (json.containsKey("term_group")) {
      termGroup = json["term_group"];
    }
    if (json.containsKey("term_taxonomy_id")) {
      termTaxonomyId = json["term_taxonomy_id"];
    }
    if (json.containsKey("taxonomy")) {
      taxonomy = json["taxonomy"];
    }
    if (json.containsKey("description")) {
      description = json["description"];
    }
    if (json.containsKey("parent")) {
      parent = json["parent"];
    }
    if (json.containsKey("count")) {
      count = json["count"];
    }
    if (json.containsKey("filter")) {
      filter = json["filter"];
    }

    return AgentMetaData(
        count: count,
        description: description,
        filter: filter,
        name: name,
        parent: parent,
        slug: slug,
        taxonomy: taxonomy,
        termGroup: termGroup,
        termId: termId,
        termTaxonomyId: termTaxonomyId
    );
  }

  static List<dynamic> getParsedDataInList({List<dynamic> inputList, Function(Map<String, dynamic>) function}){
    List<dynamic> outputList = inputList.map((item) => function(item)).toList();
    return outputList;
  }

  @override
  Article parseArticle(Map<String, dynamic> json) {
    return HouzezParser.parseArticleMap(json);
  }

  @override
  PropertyMetaData parseMetaDataMap(Map<String, dynamic> json) {
    return HouzezParser.parsePropertyMetaDataMap(json);
  }

  @override
  Agency parseAgencyInfo(Map<String, dynamic> json) {
    return HouzezParser.parseAgencyInformation(json);
  }

  @override
  Agent parseAgentInfo(Map<String, dynamic> json) {
    return HouzezParser.parseAgentInformation(json);
  }

  @override
  Activity parseActivities(Map<String, dynamic> json) {
    return HouzezParser.parseActivitiesMap(json);
  }

  @override
  Inquiries parseInquiries(Map<String, dynamic> json) {
    return HouzezParser.parseInquiriesMap(json);
  }

  @override
  LeadsFromActivity parseLeads(Map<String, dynamic> json) {
    return HouzezParser.parseLeadsMap(json);
  }

  @override
  DealsFromActivity parseDeals(Map<String, dynamic> json) {
    return HouzezParser.parseDealsFromActivityMap(json);
  }

  @override
  DealsAndLeads parseDealsAndLeadsFromBoard(Map<String, dynamic> json) {
    return HouzezParser.parseDealsFromBoardMap(json);
  }

  @override
  SavedSearch parseSavedSearch(Map<String, dynamic> json) {
    return HouzezParser.parseSavedSearchMap(json);
  }

  @override
  User parseUserInfo(Map<String, dynamic> json) {
    return HouzezParser.parseUserInfoMap(json);
  }

  @override
  DealsAndLeadsFromActivity parseDealsAndLeadsFromActivity(Map<String, dynamic> json) {
    return HouzezParser.parseDealsAndLeadsFromActivityMap(json);
  }

  @override
  AgentMetaData parseAgentMetaData(Map<String, dynamic> json) {
    return HouzezParser.parseAgentMetaDataMap(json);
  }
}
