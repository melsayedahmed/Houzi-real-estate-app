import 'dart:convert';

import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/user_log_provider.dart';
import 'package:houzi_package/l10n/string_extension.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/models/drawer.dart';
import 'package:houzi_package/models/home_config.dart';
import 'package:houzi_package/models/property_detail_page_config.dart';
import 'package:houzi_package/models/property_meta_data.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:html/parser.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

typedef NavigateToSearchResultScreenListener = void Function({
  Map<String, dynamic> filterDataMap,
  List<dynamic> recentSearchesDataMapList,
  bool loadProperties,
});
typedef AppTrackingPermissionCallback = void Function({String status});

class GenericMethods{
  // Platform messages are asynchronous, so we initialize in an async method.
  static Future<void> initTrackingPermissionAndInitializeMobileAds(AppTrackingPermissionCallback trackingCallback) async {
    final TrackingStatus status = await AppTrackingTransparency.trackingAuthorizationStatus;
    if (trackingCallback != null) {
      trackingCallback(status:'$status');
    }
    // If the system can show an authorization request dialog
    if (status == TrackingStatus.notDetermined) {
      // Show a custom explainer dialog before the system dialog
      //await showCustomTrackingDialog(context);
      // Wait for dialog popping animation
      //await Future.delayed(const Duration(milliseconds: 200));
      // Request system's tracking authorization dialog
      final TrackingStatus status =
      await AppTrackingTransparency.requestTrackingAuthorization();
      if (trackingCallback != null) {
        trackingCallback(status:'$status');
      }
    }

    final uuid = await AppTrackingTransparency.getAdvertisingIdentifier();
    print("AppTrackingTransparency status: $status and UUID: $uuid");
    await MobileAds.instance.initialize();
  }

  static bool validateURL(String url){
    if(url == null || url.isEmpty){
      return false;
    }
    bool isURLValid = Uri.parse(url).isAbsolute;
    return isURLValid;
  }

  static String getLocalizedString(String key,{List inputWords}){
    return key.localisedString(inputWords);
  }

  static bool isRTL(BuildContext context) {
    return Bidi.isRtlLanguage(Localizations.localeOf(context).languageCode);
  }

  static String toTitleCase(String inputString){
    return inputString.replaceAll(RegExp(' +'), ' ').split(" ").map((str) => toCapitalized(str)).join(" ");
  }

  static String toCapitalized(String inputString) {
    return inputString.isNotEmpty ?'${inputString[0].toUpperCase()}${inputString.substring(1)}':'';
  }

  static String stripHtmlIfNeeded(String text) {
    return text.replaceAll(RegExp(r'<[^>]*>|&[^;]+;'), ' ');
  }

  static String makePriceCompact(String inputPrice){
    String compactPrice = '';
    String postfix = '';
    String additionalCharacter = '';
    String defaultCurrency = HiveStorageManager.readDefaultCurrencyInfoData() ?? '\$';

    // print('1. Input Price: $inputPrice');
    /// Return Input Price If already in Compact State
    if(inputPrice.contains('K') || inputPrice.contains('M')){
      return inputPrice;
    }

    // print("Input Price: $inputPrice");
    /// Remove Currency from Input Price
    if(inputPrice.contains(defaultCurrency)) {
      inputPrice = inputPrice.replaceAll(defaultCurrency, '');
      // inputPrice = inputPrice.split(defaultCurrency)[1];
    }
    /// Remove ',' from Input Price
    if(inputPrice.contains(',')) {
      inputPrice = inputPrice.replaceAll(',', '');
    }
    /// Separate Postfix from Input Price
    if(inputPrice.contains('/')){
      postfix = inputPrice.split('/')[1];
      inputPrice = inputPrice.split('/')[0];
    }
    /// Round of Input Price to One Digit
    if (inputPrice.contains('.')) {
      double tempPrice = double.parse(inputPrice);
      inputPrice = tempPrice.toStringAsFixed(0);
    }

    if(inputPrice.contains('+')){
      inputPrice = inputPrice.split('+')[0];
      additionalCharacter = "+";
    }


    // print('2. Input Price: $inputPrice');
    /// Make the Input Price Compact
    compactPrice = NumberFormat.compact().format(double.parse(inputPrice));

    ///  Add Currency Symbol to Input Price
    if(defaultCurrency != null && defaultCurrency.isNotEmpty){
      compactPrice = setCurrencyPosition(compactPrice);
    }
    ///  Add PostFix to Input Price
    if(postfix != null && postfix.isNotEmpty){
      compactPrice = '$compactPrice/$postfix';
    }
    if(additionalCharacter != null && additionalCharacter.isNotEmpty){
      compactPrice = '$compactPrice$additionalCharacter';
    }

    return compactPrice;
  }
  static String formatPrice(String inputPrice){
    String compactPrice = '';
    String postfix = '';
    String additionalCharacter = '';
    String defaultCurrency = HiveStorageManager.readDefaultCurrencyInfoData() ?? '\$';

    // print('1. Input Price: $inputPrice');
    /// Return Input Price If already in Compact State
    if(inputPrice.contains('K') || inputPrice.contains('M')){
      return inputPrice;
    }

    // print("Input Price: $inputPrice");
    /// Remove Currency from Input Price
    if(inputPrice.contains(defaultCurrency)) {
      inputPrice = inputPrice.replaceAll(defaultCurrency, '');
      // inputPrice = inputPrice.split(defaultCurrency)[1];
    }
    /// Remove ',' from Input Price
    if(inputPrice.contains(',')) {
      inputPrice = inputPrice.replaceAll(',', '');
    }
    /// Separate Postfix from Input Price
    if(inputPrice.contains('/')){
      postfix = inputPrice.split('/')[1];
      inputPrice = inputPrice.split('/')[0];
    }
    /// Round of Input Price to One Digit
    if (inputPrice.contains('.')) {
      double tempPrice = double.parse(inputPrice);
      inputPrice = tempPrice.toStringAsFixed(0);
    }

    if(inputPrice.contains('+')){
      inputPrice = inputPrice.split('+')[0];
      additionalCharacter = "+";
    }


    // print('2. Input Price: $inputPrice');
    /// Make the Input Price Compact
    compactPrice = inputPrice;

    ///  Add Currency Symbol to Input Price
    if(defaultCurrency != null && defaultCurrency.isNotEmpty){
      compactPrice = setCurrencyPosition(compactPrice);
    }
    ///  Add PostFix to Input Price
    if(postfix != null && postfix.isNotEmpty){
      compactPrice = '$compactPrice/$postfix';
    }
    if(additionalCharacter != null && additionalCharacter.isNotEmpty){
      compactPrice = '$compactPrice$additionalCharacter';
    }

    return compactPrice;
  }

  static String priceFormatter(String propertyPrice, String firstPrice){
    String _propertyPrice = "";
    String _firstPrice = "";
    String _finalPrice = "";


    if (_propertyPrice != null &&propertyPrice.isNotEmpty) {
      _propertyPrice = propertyPrice ?? "";
      if (!_propertyPrice.contains("/")) {
        _propertyPrice = formatPrice(propertyPrice);
      }
    }
    if (firstPrice != null && firstPrice.isNotEmpty) {
      _firstPrice = firstPrice ?? "";
      if (!_firstPrice.contains("/")) {
        _firstPrice = formatPrice(propertyPrice);
      }
    }

    _finalPrice = _firstPrice != null && _firstPrice.isNotEmpty
        ? _firstPrice
        : _propertyPrice;

    return _finalPrice;
  }

  static String setCurrencyPosition(String price){
    String defaultCurrency = HiveStorageManager.readDefaultCurrencyInfoData() ?? '\$';
    if (CURRENCY_POSITION == "after") {
      return price = "$price $defaultCurrency";
    } else {
      return price = "$defaultCurrency$price";
    }
  }

  static NumberFormat getNumberFormat(){
    NumberFormat numberFormat;
    if(THOUSAND_SEPARATOR == ",") {
      numberFormat =  NumberFormat("#$THOUSAND_SEPARATOR###$DECIMAL_POINT_SEPARATOR##");
    } else if(THOUSAND_SEPARATOR == ".") {
      numberFormat = NumberFormat.currency(locale: 'eu',customPattern: '#$DECIMAL_POINT_SEPARATOR###', decimalDigits: 0);

    } else if(THOUSAND_SEPARATOR == " ") {
      numberFormat = NumberFormat.currency(locale: 'fr',customPattern: '#,###', decimalDigits: 0);
    }
    return numberFormat;
  }


  static void navigateToRoute({
    @required context,
    @required WidgetBuilder builder
  }){
    if(builder!=null){
      Route pageRoute = MaterialPageRoute(builder: builder);
      Navigator.push(context, pageRoute);
    }

  }

  static void navigateToRouteByReplacement({
    @required context,
    @required WidgetBuilder builder
  }){
    Route pageRoute = MaterialPageRoute(builder: builder);
    Navigator.pushReplacement(context, pageRoute);
  }

  static void navigateToRouteByPushAndRemoveUntil({
    @required context,
    @required WidgetBuilder builder
  }){
    Route pageRoute = MaterialPageRoute(builder: builder);
    Navigator.pushAndRemoveUntil(context, pageRoute, (route) => false);
    // Navigator.of(context).pushAndRemoveUntil(pageRoute, (Route<dynamic> route) => false);
  }



  static void navigateToSearchResultScreen({
    @required BuildContext context,
    Map<String, dynamic> dataInitializationMap,
    Map<String, dynamic> searchRelatedData,
    final NavigateToSearchResultScreenListener navigateToSearchResultScreenListener,
  }){
    WidgetBuilder builder = (context) => SearchResult(
      dataInitializationMap: dataInitializationMap,
      searchRelatedData: searchRelatedData,
      searchPageListener: (Map<String, dynamic> map, String closeOption){
        if(closeOption == CLOSE){
          Navigator.of(context).pop();
          navigateToSearchResultScreenListener(
            filterDataMap: HiveStorageManager.readFilterDataInfo(),
            recentSearchesDataMapList: HiveStorageManager.readRecentSearchesInfo(),
            loadProperties: true,
          );
        }
      },
    );
    GenericMethods.navigateToRoute(context: context, builder: builder);
  }

  static Future<Map<String, dynamic>> convertArticleToMap(int propertyId,int userId, PropertyBloc propertyBloc) async {
    List<dynamic> propertyTypesList = [];
    List<dynamic> propertyLabelList = [];
    List<dynamic> propertyStatusList = [];
    List<dynamic> propertyFeaturesList = [];

    propertyTypesList = HiveStorageManager.readPropertyTypesMetaData();
    propertyLabelList = HiveStorageManager.readPropertyLabelsMetaData();
    propertyStatusList = HiveStorageManager.readPropertyStatusMetaData();
    propertyFeaturesList = HiveStorageManager.readPropertyFeaturesMetaData();


    final response = await propertyBloc.fetchSingleArticle(propertyId, forEditing: true);
    Map<String, dynamic> dataMapForUpdateProperty;
    if (response == null || response.isEmpty) {
      print("list of single article is null or empty");
    } else {
      Article article = response[0];
      List<dynamic> propertyImagesList = article.imageList;
      String propertyTitle = article.title;
      String propertyVideo = article.video;
      String featuredImageId = "${article.featuredImageId}";
      String content = GenericMethods.stripHtmlIfNeeded(article.content);
      String propertyType = article.propertyInfo.propertyType;
      int intPropertyType;
      String propertyStatus = article.propertyInfo.propertyStatus;
      int intPropertyStatus;
      String propertyLabel = article.propertyInfo.propertyLabel;
      int intPropertyLabel;
      String propertyFirstPrice = article.propertyInfo.firstPrice;
      String propertyPrice = article.propertyInfo.price;
      List<dynamic> agencyList = article.propertyInfo.agencyList;
      List<dynamic> agentList = article.propertyInfo.agentList;
      // print("agentList: $agentList");
      String agentDisplayOption = article.propertyInfo.agentDisplayOption;
      String propertyPricePostfix = article.propertyInfo.pricePostfix;
      String propertySecondPrice = article.propertyInfo.secondPrice;
      Map<String, dynamic> propertyCustomFieldsMap = article.propertyInfo.customFieldsMapForEditing;
      String propertyBedrooms = article.features.bedrooms;
      String propertyBathrooms = article.features.bathrooms;
      String propertyLandArea = article.features.landArea;
      String propertyGarage = article.features.garage;
      String propertyGarageSize = article.features.garageSize;
      String propertyYearBuilt = article.features.yearBuilt;
      String propertyBuildingAreaUnit = article.features.buildingAreaUnit;
      String propertyLandAreaUnit = article.features.landAreaUnit;
      List<dynamic> propertyFeaturesListFromArticle = article.features.featuresList;
      List<dynamic> propertyImagesIdList = article.features.imagesIdList;
      String propertyAddress = article.address.address;
      String propertyCountry = article.address.country;
      String propertyState = article.address.state;
      String propertyCity = article.address.city;
      String propertyArea = article.address.area;
      String propertyPostalCode = article.address.postalCode;
      String propertyLat = article.address.lat;
      String propertyLong = article.address.long;
      String multiUnitsListingIDs = article.features.multiUnitsListingIDs;
      String propertyVirtualTourLink = article.propertyInfo.propertyVirtualTourLink;
      List<dynamic> floorPlansList = article.features.floorPlansList;
      List<dynamic> additionalDetailsList = article.features.additionalDetailsList;
      List<dynamic> multiUnitsList = article.features.multiUnitsList;

      int comparedValueForType = getIDS(propertyTypesList, propertyType);
      int comparedValueForLabel = getIDS(propertyLabelList, propertyLabel);
      int comparedValueForStatus = getIDS(propertyStatusList, propertyStatus);
      var listOfFeatures = getIdsForFeatures(propertyFeaturesList, propertyFeaturesListFromArticle);
      intPropertyType = comparedValueForType;
      intPropertyLabel = comparedValueForLabel;
      intPropertyStatus = comparedValueForStatus;

      if (propertyPrice == "") {
        propertyPrice = propertyFirstPrice;
      }
      String featuredImageIndex = "0";
      for (int i = 0; i < propertyImagesIdList.length; i++) {

        if(featuredImageId == propertyImagesIdList[i]) {
          featuredImageIndex = "$i";
        }
      }

      dataMapForUpdateProperty = {
        UPDATE_PROPERTY_ID: '$propertyId',
        ADD_PROPERTY_ACTION: ADD_PROPERTY_ACTION_UPDATE,
        ADD_PROPERTY_USER_ID: '$userId',
        ADD_PROPERTY_USER_HAS_NO_MEMBERSHIP: 'no',
        //ADD_PROPERTY_CURRENCY : '\$',
        //ADD_PROPERTY_MULTI_UNITS : '${0}',
        ADD_PROPERTY_FLOOR_PLANS_ENABLE: '0',
        ADD_PROPERTY_TITLE: propertyTitle,
        ADD_PROPERTY_DESCRIPTION: content,
        ADD_PROPERTY_TYPE: [intPropertyType],
        ADD_PROPERTY_STATUS: [intPropertyStatus],
        ADD_PROPERTY_LABELS: [intPropertyLabel],
        ADD_PROPERTY_TYPE_NAMES_LIST: [propertyType],
        ADD_PROPERTY_LABEL_NAMES_LIST: [propertyLabel],
        ADD_PROPERTY_STATUS_NAMES_LIST: [propertyStatus],
        ADD_PROPERTY_PRICE: propertyPrice,
        ADD_PROPERTY_PRICE_POSTFIX: propertyPricePostfix,
        ADD_PROPERTY_PRICE_PREFIX: '',
        //ADD_PROPERTY_PRICE_PREFIX : 'prop_price_prefix',
        ADD_PROPERTY_SECOND_PRICE: propertySecondPrice,
        ADD_PROPERTY_VIDEO_URL: propertyVideo,
        ADD_PROPERTY_BEDROOMS: propertyBedrooms,
        ADD_PROPERTY_BATHROOMS: propertyBathrooms,
        ADD_PROPERTY_SIZE: propertyLandArea,
        ADD_PROPERTY_SIZE_PREFIX: propertyLandAreaUnit,
        ADD_PROPERTY_LAND_AREA: '',
        //ADD_PROPERTY_LAND_AREA : 'prop_land_area',
        ADD_PROPERTY_LAND_AREA_PREFIX: '',
        //ADD_PROPERTY_LAND_AREA_PREFIX : 'prop_land_area_prefix',
        ADD_PROPERTY_GARAGE: propertyGarage,
        ADD_PROPERTY_GARAGE_SIZE: propertyGarageSize,
        ADD_PROPERTY_YEAR_BUILT: propertyYearBuilt,
        ADD_PROPERTY_FEATURES_LIST: listOfFeatures,
        ADD_PROPERTY_VIRTUAL_TOUR: propertyVirtualTourLink,
        ADD_PROPERTY_FAVE_PROPERTY_MAP: '',
        ADD_PROPERTY_FLOOR_PLANS: getFloorPlansList(floorPlansList),
        ADD_PROPERTY_ADDITIONAL_FEATURES: getAdditionalDetailsList(additionalDetailsList),
        ADD_PROPERTY_FAVE_MULTI_UNITS: getMultiUnitsList(multiUnitsList),
        // ADD_PROPERTY_FAVE_PROPERTY_MAP: 'fave_property_map',
        UPDATE_PROPERTY_IMAGES: propertyImagesList,
        // ADD_PROPERTY_PROPERTY_ID: 'property_id',
        ADD_PROPERTY_IMAGE_IDS: propertyImagesIdList,
        ADD_PROPERTY_FEATURED_IMAGE_ID: featuredImageId,
        ADD_PROPERTY_FEATURED_IMAGE_LOCAL_INDEX: featuredImageIndex,
        ADD_PROPERTY_FAVE_AGENT_DISPLAY_OPTION: agentDisplayOption,
        ADD_PROPERTY_FAVE_AGENT: agentList,
        ADD_PROPERTY_FAVE_AGENCY: agencyList,
      };

      if(propertyAddress != null && propertyAddress.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_MAP_ADDRESS] = propertyAddress;
      }
      if(SHOW_COUNTRY_NAME_FIELD && propertyCountry != null && propertyCountry.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_COUNTRY] = propertyCountry;
      }
      if(SHOW_STATE_COUNTY_FIELD && propertyState != null && propertyState.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_STATE_OR_COUNTY] = propertyState;
      }
      if(SHOW_LOCALITY_FIELD && propertyCity != null && propertyCity.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_CITY] = propertyCity;
      }
      if(SHOW_NEIGHBOURHOOD_FIELD && propertyArea != null && propertyArea.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_AREA] = propertyArea;
      }
      if(propertyPostalCode != null && propertyPostalCode.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_POSTAL_CODE] = propertyPostalCode;
      }
      if(propertyLat != null && propertyLat.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_LATITUDE] = propertyLat;
      }
      if(propertyLong != null && propertyLong.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_LONGITUDE] = propertyLong;
      }
      if(multiUnitsListingIDs != null && multiUnitsListingIDs.isNotEmpty){
        dataMapForUpdateProperty[ADD_PROPERTY_FAVE_MULTI_UNITS_IDS] = multiUnitsListingIDs;
      }

      if(propertyCustomFieldsMap!=null && propertyCustomFieldsMap.isNotEmpty){
        propertyCustomFieldsMap.forEach((key, value) {
          Map<String,dynamic> map = {key:value};
          dataMapForUpdateProperty.addAll(map);
        });
      }

    }

    return dataMapForUpdateProperty;

  }

  static int getIDS(List<dynamic> inputList, String inputString) {
    int itemId;
    if (inputList == null || inputList.isEmpty || inputString == null) {
      return null;
    } else {
      for (int i = 0; i < inputList.length; i++) {
        if (inputString == inputList[i].name) {
          itemId = inputList[i].id;
        }
      }
    }

    return itemId;
  }

  static List<int> getIdsForFeatures(List<dynamic> propertyFeaturesList,
      List<dynamic> propertyFeaturesListFromArticle) {
    List<int> featuresList = [];
    if ((propertyFeaturesList == null || propertyFeaturesList.isEmpty) &&
        (propertyFeaturesListFromArticle == null ||
            propertyFeaturesListFromArticle.isEmpty)) {
      return featuresList;
    } else {
      for (int i = 0; i < propertyFeaturesList.length; i++) {
        String tempName = propertyFeaturesList[i].name;
        int tempId = propertyFeaturesList[i].id;
        for (int i = 0; i < propertyFeaturesListFromArticle.length; i++) {
          if (propertyFeaturesListFromArticle[i] == tempName) {
            featuresList.add(tempId);
          }
        }
      }
    }
    return featuresList;
  }

  static List<Map<String, dynamic>> getFloorPlansList(List<dynamic> list){
    if(list != null && list.isNotEmpty){
      List<Map<String, dynamic>> floorPlanList = [];
      for(var floorPlanElement in list){
        floorPlanList.add({
          favePlanTitle : floorPlanElement.title,
          favePlanRooms : floorPlanElement.rooms,
          favePlanBathrooms : floorPlanElement.bathrooms,
          favePlanPrice : floorPlanElement.price,
          favePlanPricePostFix : floorPlanElement.pricePostFix,
          favePlanSize : floorPlanElement.size,
          favePlanImage : floorPlanElement.image,
          favePlanDescription : floorPlanElement.description,
        });
      }
      return floorPlanList;
    }

    return null;
  }

  static List<Map<String, dynamic>> getAdditionalDetailsList(List<dynamic> list){
    if(list != null && list.isNotEmpty){
      List<Map<String, dynamic>> additionalDetailsList = [];
      for(var additionalDetailElement in list){
        additionalDetailsList.add({
          faveAdditionalFeatureTitle : additionalDetailElement.title,
          faveAdditionalFeatureValue : additionalDetailElement.value,
        });
      }
      return additionalDetailsList;
    }

    return null;
  }

  static List<Map<String, dynamic>> getMultiUnitsList(List<dynamic> list){
    if(list != null && list.isNotEmpty){
      List<Map<String, dynamic>> multiUnitsList = [];
      for(var multiUnitsElement in list){
        multiUnitsList.add({
          faveMUTitle : multiUnitsElement.title,
          faveMUBeds : multiUnitsElement.bedrooms,
          faveMUBaths : multiUnitsElement.bathrooms,
          faveMUPrice : multiUnitsElement.price,
          faveMUPricePostfix : multiUnitsElement.pricePostfix,
          faveMUSizePostfix : multiUnitsElement.sizePostfix,
          faveMUSize : multiUnitsElement.size,
          faveMUType : multiUnitsElement.type,
          faveMUAvailabilityDate : multiUnitsElement.availabilityDate,
        });
      }
      return multiUnitsList;
    }

    return null;
  }



  static Map<String,dynamic> iconMap = {};
  static getIconsMap() {
    iconMap["Bedrooms"] = Icons.king_bed_outlined;
    iconMap["Bathrooms"] = Icons.bathtub_outlined;
    iconMap["Garage"] = Icons.garage_outlined;
    iconMap["Gym"] = Icons.fitness_center_outlined;
    iconMap["Property Size"] = Icons.square_foot_outlined;
    iconMap["Year Built"] = Icons.calendar_today;
    iconMap["Air Conditioning"]= Icons.ac_unit_outlined;
    iconMap["Broadband"] = Icons.router_outlined;
    iconMap["WiFi"] = Icons.router_outlined;
    iconMap["Intercom"] = Icons.phone_in_talk_outlined;
    iconMap["Pay Tv"] = Icons.tv_outlined;
    iconMap["TV Cable"] = Icons.tv_outlined;
    iconMap["Pool"] = Icons.pool_outlined;
    iconMap["Swimming Pool"] = Icons.pool_outlined;
    iconMap["Security System"] = Icons.security_outlined;
    iconMap["Microwave"] = Icons.microwave;
    iconMap["Refrigerator"] = Icons.kitchen;
    iconMap["Washer"] = Icons.local_laundry_service;
    iconMap["Elevator"] = Icons.elevator;
    iconMap["Sliding Doors"] = Icons.door_sliding;
    iconMap["Security"] = Icons.security_outlined;
    iconMap["Fitted Kitchen"] = Icons.kitchen;
    iconMap["Guest Washroom"] = Icons.bathroom;
    iconMap["Laundry"] = Icons.local_laundry_service;
    iconMap["Washing Machine"] = Icons.local_laundry_service;
    iconMap["Bar"] = Icons.local_bar;
    iconMap["Fence"] = Icons.fence;
    iconMap["Heat Extractor"] = Icons.heat_pump;
    iconMap["Stove"] = Icons.date_range;
    iconMap["Lawn"] = Icons.grass;
    iconMap["Automated Gate"] = Icons.door_sliding;
    iconMap["Balcony"] = Icons.balcony;
    iconMap["Parking"] = Icons.garage_rounded;
    iconMap["for-rent"] = Icons.vpn_key_outlined;
    iconMap["for-sale"]= Icons.real_estate_agent_outlined;
    iconMap["commercial"]= Icons.storefront_outlined;
    iconMap["residential"]= Icons.apartment_outlined;
    return iconMap;
  }

  static String cleanContent(String content, {bool decodeComponent = false}) {
    if (content.contains("<p>")) {
      content = content.replaceAll("<p>", "").trim();
    }
    if (content.contains("</p>")) {
      content = content.replaceAll("</p>", "").trim();
    }
    var unescape = HtmlUnescape();
    content = unescape.convert(content).toString();
    if (content.contains("\\<.*?\\>")) {
      content = content.replaceAll("\\<.*?\\>", "").trim();
    }
    content = parseHtmlString(content,decodeComponent: decodeComponent);
    return content;
  }

  static String parseHtmlString(String htmlString,{bool decodeComponent = false}) {
    final document = parse(htmlString);
    String parsedString = parse(document.body.text).documentElement.text;
    if(parsedString.contains("%3A")){
      parsedString = parsedString.replaceAll("%3A", ":");
    }
    if(parsedString.contains("%2F")){
      parsedString = parsedString.replaceAll("%2F", "/");
    }
    if(decodeComponent){
      parsedString = Uri.decodeComponent(parsedString);
    }

    return parsedString;
  }

  static String chkRoleValueAndConvertToOption(String roleValue) {
    if (roleValue == ROLE_ADMINISTRATOR) {
      return ROLE_ADMINISTRATOR_CAPITAL;
    } else if (roleValue == USER_ROLE_HOUZEZ_AGENT_VALUE) {
      return USER_ROLE_HOUZEZ_AGENT_OPTION;
    } else if (roleValue == USER_ROLE_HOUZEZ_AGENCY_VALUE) {
      return USER_ROLE_HOUZEZ_AGENCY_OPTION;
    } else if (roleValue == USER_ROLE_HOUZEZ_OWNER_VALUE) {
      return USER_ROLE_HOUZEZ_OWNER_OPTION;
    } else if (roleValue == USER_ROLE_HOUZEZ_BUYER_VALUE) {
      return USER_ROLE_HOUZEZ_BUYER_OPTION;
    } else if (roleValue == USER_ROLE_HOUZEZ_SELLER_VALUE) {
      return USER_ROLE_HOUZEZ_SELLER_OPTION;
    } else if (roleValue == USER_ROLE_HOUZEZ_MANAGER_VALUE) {
      return USER_ROLE_HOUZEZ_MANAGER_OPTION;
    } else {
      return "";
    }
  }

  static String getSearchKey(subType) {
    if (subType == propertyTypeDataType) {
      return SEARCH_RESULTS_TYPE;
    } else if (subType == propertyStatusDataType) {
      return SEARCH_RESULTS_STATUS;
    } else if (subType == propertyFeatureDataType) {
      return SEARCH_RESULTS_FEATURES;
    } else if (subType == propertyLabelDataType) {
      return SEARCH_RESULTS_LABEL;
    } else if (subType == propertyStateDataType) {
      return SEARCH_RESULTS_STATE;
    } else if (subType == propertyAreaDataType) {
      return SEARCH_RESULTS_AREA;
    } else if (subType == propertyCityDataType) {
      return SEARCH_RESULTS_LOCATION;
    } else {
      return subType;
    }
  }

  static Map<String, dynamic> convertMap(Map<dynamic, dynamic> inputMap){
    Map<dynamic, dynamic> data = inputMap;
    Map<String, dynamic> convertedMap =  <String, dynamic>{};
    if(data != null){
      for (dynamic type in data.keys) {
        convertedMap[type.toString()] = data[type];
      }
    }
    return convertedMap;
  }

  static MaterialColor getMaterialColor(String hexValue){
    int colorValue;

    if(hexValue.contains("#")){
      colorValue = int.parse(hexValue.substring(1), radix: 16);
    }

    Map<int, Color> colorCodes = {
      50: Color(colorValue).withAlpha((255.0 * 0.1).round()),
      100: Color(colorValue).withAlpha((255.0 * 0.2).round()),
      200: Color(colorValue).withAlpha((255.0 * 0.3).round()),
      300: Color(colorValue).withAlpha((255.0 * 0.4).round()),
      400: Color(colorValue).withAlpha((255.0 * 0.5).round()),
      500: Color(colorValue).withAlpha((255.0 * 0.6).round()),
      600: Color(colorValue).withAlpha((255.0 * 0.7).round()),
      700: Color(colorValue).withAlpha((255.0 * 0.8).round()),
      800: Color(colorValue).withAlpha((255.0 * 0.9).round()),
      900: Color(colorValue).withAlpha((255.0 * 1.0).round()),
    };

    MaterialColor materialColor = MaterialColor(colorValue, colorCodes);
    return materialColor;
  }

  static Color getColorFromString(String hexValue){
    int colorValue;
    if(hexValue.contains("#")){
      colorValue = int.parse(hexValue.substring(1), radix: 16);
    }
    return Color(colorValue);
  }

  static IconData fromJsonToIconData(String jsonString) {
    Map<String, dynamic> map = jsonDecode(jsonString);
    return IconData(
      map['codePoint'],
      fontFamily: map['fontFamily'],
      fontPackage: map['fontPackage'],
      matchTextDirection: map['matchTextDirection'],
    );
  }

  static String getPlacesApiLockedCountriesFormattedString(String countriesString){
    String formattedString = '';
    if(countriesString != null && countriesString.isNotEmpty){
      if(countriesString.contains(",")){
        List tempList = countriesString.split(",");
        if(tempList.length > 1){
          for(int i = 0; i < (tempList.length); i++){
            if(tempList[i].isNotEmpty){
              formattedString = formattedString + "country:" + tempList[i];
              if((tempList.length) != (i+1)){
                formattedString = formattedString + "|";
              }
            }
          }
        }else{
          if(tempList[0].isNotEmpty){
            formattedString = formattedString + "country:" + tempList[0];
          }
        }
      }else{
        formattedString = formattedString + "country:" + countriesString;
      }
    }

    formattedString = formattedString.replaceAll(" ", "");

    return formattedString;
  }

  static userLogOut({
    @required context,
    @required WidgetBuilder builder
}){
    Provider.of<UserLoggedProvider>(context,listen: false).loggedOut();
    HiveStorageManager.deleteUserLoginInfoData();
    GeneralNotifier().publishChange(GeneralNotifier.USER_LOGGED_OUT);
    GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: builder);
  }

  static bool checkRTLDirectionality(Locale locale) {
    return Bidi.isRtlLanguage(locale.languageCode);
  }

  static saveHomeConfigFile(Map appConfigurationsData) {
    final homeConfig = homeConfigFromJson(json.encode(appConfigurationsData));
    List<dynamic> homeConfigList = homeConfig.homeLayout;
    HiveStorageManager.storeHomeConfigListData(json.encode(homeConfigList));
  }

  static saveDrawerConfigFile(Map appConfigurationsData) {
    final drawerConfig = drawerLayoutConfigFromJson(json.encode(appConfigurationsData));
    List<dynamic> drawerConfigList = drawerConfig.drawerLayout;
    HiveStorageManager.storeDrawerConfigListData(json.encode(drawerConfigList));
  }

  static saveFilterPageConfigFile(Map appConfigurationsData) {
    // List<dynamic> filterPageConfigElementsList = FilterPageElement.decode(appConfigurationsData[searchPageLayoutConfiguration]);
    List<dynamic> filterPageConfigElementsList = appConfigurationsData[searchPageLayoutConfiguration];
    HiveStorageManager.storeFilterConfigListData(json.encode(filterPageConfigElementsList));
  }

  static savePropertyDetailPageConfigFile(Map appConfigurationsData) {
    final propertyDetailPageConfig = propertyDetailPageLayoutFromJson(json.encode(appConfigurationsData));
    List<dynamic> propertyDetailPageConfigList = propertyDetailPageConfig.propertyDetailPageLayout;
    HiveStorageManager.storePropertyDetailConfigListData(json.encode(propertyDetailPageConfigList));
  }

  static storeOrUpdateRecentSearches(Map dataMap){
    List recentSearchesList = [];
    recentSearchesList = HiveStorageManager.readRecentSearchesInfo() ?? [];

    /// Save only 10 recent searches
    if(recentSearchesList != null && recentSearchesList.length > 10){
      recentSearchesList.removeLast();
    }

    if (recentSearchesList == null || recentSearchesList.isEmpty) {
      if(dataMap != null){
        recentSearchesList.add(dataMap);
      }
    } else {
      recentSearchesList.insert(0, dataMap);
    }

    HiveStorageManager.storeRecentSearchesInfo(infoList: recentSearchesList);
    GeneralNotifier().publishChange(GeneralNotifier.RECENT_DATA_UPDATE);
  }

  static var drawerItemsList;
  static var widgetItem;
  static var propertyItem;
  static var termItem;
  static var agentItem;
  static var agencyItem;
  static var languageNameAndCode;
  static var defaultLanguageCode;
  static var defaultHomePage;
  static var defaultCountryCode;
  static var homeRightBarButtonWidget;
  static var profileItemHook;
  static var settingsOption;

  static void setHooks(Map<String, dynamic> hooksMap) {
    if(hooksMap!=null && hooksMap.isNotEmpty) {
      if (hooksMap.containsKey("propertyDetailPageIcons") &&
          hooksMap["propertyDetailPageIcons"] != null &&
          hooksMap["propertyDetailPageIcons"].isNotEmpty) {
        iconMap.addAll(hooksMap["propertyDetailPageIcons"]);
      }

      if (hooksMap.containsKey("elegantHomeTermsIcons") &&
          hooksMap["elegantHomeTermsIcons"] != null &&
          hooksMap["elegantHomeTermsIcons"].isNotEmpty) {
        iconMap.addAll(hooksMap["elegantHomeTermsIcons"]);
      }

      if (hooksMap.containsKey("headers") &&
          hooksMap["headers"] != null &&
          hooksMap["headers"].isNotEmpty) {
        HiveStorageManager.storeSecurityKeyMapData(hooksMap["headers"]);
      }

      if (hooksMap.containsKey("drawerItems") && hooksMap["drawerItems"] != null) {
        drawerItemsList = hooksMap["drawerItems"];
      }

      if (hooksMap.containsKey("widgetItems") && hooksMap["widgetItems"] != null) {
        widgetItem = hooksMap["widgetItems"];
      }

      if (hooksMap.containsKey("propertyItem") && hooksMap["propertyItem"] != null) {
        propertyItem = hooksMap["propertyItem"];
      }

      if (hooksMap.containsKey("termItem") && hooksMap["termItem"] != null) {
        termItem = hooksMap["termItem"];
      }

      if (hooksMap.containsKey("agentItem") && hooksMap["agentItem"] != null) {
        agentItem = hooksMap["agentItem"];
      }

      if (hooksMap.containsKey("agencyItem") && hooksMap["agencyItem"] != null) {
        agencyItem = hooksMap["agencyItem"];
      }

      if (hooksMap.containsKey("languageNameAndCode") && hooksMap["languageNameAndCode"] != null) {
        languageNameAndCode = hooksMap["languageNameAndCode"];
      }

      if (hooksMap.containsKey("defaultLanguageCode") && hooksMap["defaultLanguageCode"] != null) {
        defaultLanguageCode = hooksMap["defaultLanguageCode"];
      }

      if (hooksMap.containsKey("defaultHomePage") && hooksMap["defaultHomePage"] != null) {
        defaultHomePage = hooksMap["defaultHomePage"];
      }

      if (hooksMap.containsKey("defaultCountryCode") && hooksMap["defaultCountryCode"] != null) {
        defaultCountryCode = hooksMap["defaultCountryCode"];
      }

      if (hooksMap.containsKey("homeRightBarButtonWidget") && hooksMap["homeRightBarButtonWidget"] != null) {
        homeRightBarButtonWidget = hooksMap["homeRightBarButtonWidget"];
      }

      if (hooksMap.containsKey("profileItemHook") && hooksMap["profileItemHook"] != null) {
        profileItemHook = hooksMap["profileItemHook"];
      }

      if (hooksMap.containsKey("settingsOption") && hooksMap["settingsOption"] != null) {
        settingsOption = hooksMap["settingsOption"];
      }
    }
  }

  static updateTouchBaseDataAndConfigurations(Map touchBaseDataMap){
    /// Store TouchBase Data Map in Hive
    HiveStorageManager.storePropertyMetaData(touchBaseDataMap);
    GeneralNotifier().publishChange(GeneralNotifier.FILTER_DATA_LOADING_COMPLETE);

    /// Enable/Disable Register PhoneNumber on SignUp
    if(touchBaseDataMap.containsKey(SIGNUP_REGISTER_MOBILE_KEY) &&
        touchBaseDataMap[SIGNUP_REGISTER_MOBILE_KEY] != null){
      if(touchBaseDataMap[SIGNUP_REGISTER_MOBILE_KEY] == "1"){
        SHOW_SIGNUP_ENTER_PHONE_FIELD = true;
      }else{
        SHOW_SIGNUP_ENTER_PHONE_FIELD = false;
      }
    }

    /// Enable/Disable Register First Name on SignUp
    if(touchBaseDataMap.containsKey(SIGNUP_REGISTER_FIRST_NAME_KEY) &&
        touchBaseDataMap[SIGNUP_REGISTER_FIRST_NAME_KEY] != null){
      if(touchBaseDataMap[SIGNUP_REGISTER_FIRST_NAME_KEY] == "1"){
        SHOW_SIGNUP_ENTER_FIRST_NAME_FIELD = true;
      }else{
        SHOW_SIGNUP_ENTER_FIRST_NAME_FIELD = false;
      }
    }

    /// Enable/Disable Register Last Name on SignUp
    if(touchBaseDataMap.containsKey(SIGNUP_REGISTER_LAST_NAME_KEY) &&
        touchBaseDataMap[SIGNUP_REGISTER_LAST_NAME_KEY] != null){
      if(touchBaseDataMap[SIGNUP_REGISTER_LAST_NAME_KEY] == "1"){
        SHOW_SIGNUP_ENTER_LAST_NAME_FIELD = true;
      }else{
        SHOW_SIGNUP_ENTER_LAST_NAME_FIELD = false;
      }
    }

    /// Enable/Disable Password Field on SignUp
    if(touchBaseDataMap.containsKey(SIGNUP_ENABLE_PASSWORD_KEY) &&
        touchBaseDataMap[SIGNUP_ENABLE_PASSWORD_KEY] != null){
      if(touchBaseDataMap[SIGNUP_ENABLE_PASSWORD_KEY] == "yes"){
        SHOW_SIGNUP_PASSWORD_FIELD = true;
      }else{
        SHOW_SIGNUP_PASSWORD_FIELD = false;
      }
    }

    /// Store Houzez Version in Hive
    if(touchBaseDataMap.containsKey(HOUZEZ_VERSION_KEY) &&
        touchBaseDataMap[HOUZEZ_VERSION_KEY] != null){
      String houzezVersion = touchBaseDataMap[HOUZEZ_VERSION_KEY];
      HiveStorageManager.storeHouzezVersion(houzezVersion);
    }

    /// Update Config in Hive
    if(ENABLE_API_CONFIG) {
      if (FETCH_DEV_API_CONFIG &&
          touchBaseDataMap.containsKey(DEV_MOBILE_APP_CONFIG_KEY) &&
          touchBaseDataMap[DEV_MOBILE_APP_CONFIG_KEY] != null) {
        // print("FETCH_DEV_API_CONFIG: ${FETCH_DEV_API_CONFIG}");
        // print("DEV_MOBILE_APP_CONFIG_KEY: ${touchBaseDataMap[DEV_MOBILE_APP_CONFIG_KEY]}");
        Map newConfigMap = touchBaseDataMap[DEV_MOBILE_APP_CONFIG_KEY];
        updateAppConfigurationsInStorage(newConfigMap);
      } else {
        // print("FETCH_DEV_API_CONFIG: ${FETCH_DEV_API_CONFIG}");
        if (touchBaseDataMap.containsKey(MOBILE_APP_CONFIG_KEY) &&
            touchBaseDataMap[MOBILE_APP_CONFIG_KEY] != null) {
          Map newConfigMap = touchBaseDataMap[MOBILE_APP_CONFIG_KEY];
          updateAppConfigurationsInStorage(newConfigMap);
        }
      }
    }
  }

  static updateAppConfigurationsInStorage(Map newConfigMap){
    int newConfigVersion = newConfigMap[versionApiConfiguration];
    
    String oldConfigJsonString = HiveStorageManager.readAppConfigurations();
    if(oldConfigJsonString != null && oldConfigJsonString.isNotEmpty){
      Map oldConfigMap = jsonDecode(oldConfigJsonString) as Map<String, dynamic>;

      if(newConfigVersion != oldConfigMap[versionApiConfiguration]){
        HiveStorageManager.storeAppConfigurations(jsonEncode(convertMap(newConfigMap)));
        // Save current Houzi version to Hive
        HiveStorageManager.storeHouziVersion(newConfigVersion);
        saveHomeConfigFile(newConfigMap);
        saveDrawerConfigFile(newConfigMap);
        saveFilterPageConfigFile(newConfigMap);
        savePropertyDetailPageConfigFile(newConfigMap);

        if(newConfigMap.containsKey(totalSearchTypeOptionsApiConfiguration) &&
            newConfigMap[totalSearchTypeOptionsApiConfiguration] != null){
          defaultSearchTypeSwitchOptions = newConfigMap[totalSearchTypeOptionsApiConfiguration];
        }

        /// Read Default Home Config
        if(newConfigMap.containsKey(defaultHomeApiConfiguration) &&
            newConfigMap[defaultHomeApiConfiguration] != null){
          String newHome = newConfigMap[defaultHomeApiConfiguration];
          if(newHome != null && newHome.isNotEmpty){
            String oldHome = HiveStorageManager.readSelectedHomeOption();
            if(oldHome == null || oldHome.isEmpty || oldHome != newHome){
              HiveStorageManager.storeSelectedHomeOption(newHome);
              // print("New home from config: $newHome...................................................");
              GeneralNotifier().publishChange(GeneralNotifier.HOME_DESIGN_MODIFIED);
            }
            // else{
            //   print("Same Home, No need to replace it...................................................");
            // }
          }
        }

        GeneralNotifier().publishChange(GeneralNotifier.APP_CONFIGURATIONS_UPDATED);
        if (SHOW_ADS) {
          GenericMethods.initTrackingPermissionAndInitializeMobileAds(({status}) { });
        }

      }
    }
  }

  static List getPropertyMetaDataList({@required String dataType}){
    List dataTypeList = [];
    if(dataType == propertyTypeDataType){
      dataTypeList = HiveStorageManager.readPropertyTypesMetaData() ?? [];
    }else if(dataType == propertyCityDataType){
      dataTypeList = HiveStorageManager.readCitiesMetaData() ?? [];
    }else if(dataType == propertyLabelDataType){
      dataTypeList = HiveStorageManager.readPropertyLabelsMetaData() ?? [];
    }else if(dataType == propertyStatusDataType){
      dataTypeList = HiveStorageManager.readPropertyStatusMetaData() ?? [];
    }else if(dataType == propertyAreaDataType){
      dataTypeList = HiveStorageManager.readPropertyAreaMetaData() ?? [];
    }else if(dataType == propertyFeatureDataType){
      dataTypeList = HiveStorageManager.readPropertyFeaturesMetaData() ?? [];
    }else if(dataType == propertyStateDataType){
      dataTypeList = HiveStorageManager.readPropertyStatesMetaData() ?? [];
    }else if(dataType == propertyCountryDataType){
      dataTypeList = HiveStorageManager.readPropertyCountriesMetaData() ?? [];
    }

    return dataTypeList;
  }

  static String getPropertyMetaDataItemNameWithSlug({
    @required String dataType,
    @required String slug,
  }){
    List dataList = getPropertyMetaDataList(dataType: dataType) ?? [];
    if(dataList != null && dataList.isNotEmpty) {
      PropertyMetaData item = dataList.firstWhere((element) => ((element is PropertyMetaData) && (element.slug == slug)), orElse: null);
      if (item != null) {
        return item.name;
      }
    }
    return null;
  }

  static PropertyMetaData getPropertyMetaDataObjectWithSlug({
    @required String dataType,
    @required String slug,
  }){
    List dataList = getPropertyMetaDataList(dataType: dataType) ?? [];
    if(dataList != null && dataList.isNotEmpty) {
      PropertyMetaData item = dataList.firstWhere((element) {
        return ((element is PropertyMetaData) && (element.slug == slug));
      }, orElse: () => null);
      if (item != null) {
        return item;
      }
    }
    return null;
  }

  static PropertyMetaData getPropertyMetaDataObjectWithId({
    @required String dataType,
    @required int id,
  }){
    List dataList = getPropertyMetaDataList(dataType: dataType) ?? [];
    if(dataList != null && dataList.isNotEmpty) {
      PropertyMetaData item = dataList.firstWhere((element) => ((element is PropertyMetaData) && (element.id == id)), orElse: null);
      if (item != null) {
        return item;
      }
    }
    return null;
  }

  static PropertyMetaData getPropertyMetaDataObjectWithItemName({
    @required String dataType,
    @required String name,
  }){
    List dataList = getPropertyMetaDataList(dataType: dataType) ?? [];
    if(dataList != null && dataList.isNotEmpty) {
      PropertyMetaData item = dataList.firstWhere((element) => ((element is PropertyMetaData) && (element.name == name)), orElse: null);
      if (item != null) {
        return item;
      }
    }
    return null;
  }

  static Map<String, dynamic> getParentAndChildCategorizedMap({@required List<dynamic> metaDataList}) {
    List<dynamic> parentCategoryList = [];
    List<dynamic> subCategoryList = [];
    Map<String, dynamic> categorizedDataMap = {};

    /// Get Parent Categories List
    for(var item in metaDataList){
      if (item.parent == 0) {
        parentCategoryList.add(item);
      }
    }

    /// Get sub Categories List if there is any...
    if (parentCategoryList.length != metaDataList.length) {
      /// Get sub Categories List against each parent
      for(var parentElement in parentCategoryList){
        for(var dataElement in metaDataList){
          if (parentElement.id == dataElement.parent) {
            subCategoryList.add(dataElement);
          }
        }
        categorizedDataMap[parentElement.name] = subCategoryList;
        subCategoryList = [];
      }
    }

    return categorizedDataMap;
  }

  static String getStaticMapUrl({
    @required String lat,
    @required String lng,
    double zoomValue = 16,
    double width = 400,
    double height = 100,
    String markerColor = "red",
  }){
    return 'https://maps.googleapis.com/maps/api/staticmap'
        '?center=$lat,$lng&'
        'zoom=${zoomValue.toInt()}&'
        'size=${width.toInt()}x${height.toInt()}&'
        'markers=color:$markerColor%7C$lat,$lng&'
        'key=$GOOGLE_MAP_API_KEY';
  }

  /// check if the string contains only numbers
  static bool isNumeric(String str) {
    RegExp _numeric = RegExp(r'^-?[0-9]+$');
    return _numeric.hasMatch(str);
  }

  /// check if the string contains only characters
  static bool isText(String str) {
    RegExp text = RegExp(r'^-?[A-Za-z]+$');
    return text.hasMatch(str);
  }
}