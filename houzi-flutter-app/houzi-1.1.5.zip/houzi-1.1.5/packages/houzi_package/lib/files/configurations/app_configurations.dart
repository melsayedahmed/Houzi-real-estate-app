import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';

import '../../common/constants.dart';
import '../app_preferences/app_preferences.dart';
import '../generic_methods/generic_methods.dart';

typedef AppConfigurationsListener = void Function(bool areConfigsIntegrated);

class AppConfigurations{
  final String filePath;
  final AppConfigurationsListener appConfigurationsListener;

  AppConfigurations({
    this.filePath,
    this.appConfigurationsListener,
  });

  getConfigFile()  async {
    String jsonString = "";
    Map configurationsFile = {};

    // if ENABLE_API_CONFIG is true then read the last Saved Config file.
    // else read Local Config File
    if(ENABLE_API_CONFIG){
      jsonString = HiveStorageManager.readAppConfigurations();
    }

    if(jsonString == null || jsonString.isEmpty){
      jsonString = await rootBundle.loadString(filePath); // Load Local Config File
    }

    configurationsFile = jsonDecode(jsonString) as Map<String, dynamic>;

    return configurationsFile ;
  }

  void integrateConfigurations(){
    getConfigFile().then((value) {
      Map<String, dynamic> configurationsFile = value;

      String tempStringValue = "";
      bool tempBoolValue = false;

      tempStringValue = configurationsFile[appNameConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        APP_NAME = tempStringValue;
      }
      tempStringValue = configurationsFile[wordpressUrlSchemeConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        WORDPRESS_URL_SCHEME = tempStringValue;
      }
      tempStringValue = configurationsFile[wordpressUrlDomainConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        WORDPRESS_URL_DOMAIN = tempStringValue;
      }
      tempStringValue = configurationsFile[wordpressUrlPathConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        WORDPRESS_URL_PATH = tempStringValue;
      }
      tempStringValue = configurationsFile[appTermsUrlConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        APP_TERMS_URL = tempStringValue;
      }
      tempStringValue = configurationsFile[appPrivacyUrlConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        APP_PRIVACY_URL = tempStringValue;
      }
      tempStringValue = configurationsFile[appTermsOfUseUrlConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        APP_TERMS_OF_USE_URL = tempStringValue;
      }
      tempStringValue = configurationsFile[wordpressUrlGDPRAgreementConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        WORDPRESS_URL_GDPR_AGREEMENT = tempStringValue;
      }
      tempStringValue = configurationsFile[companyUrlConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        COMPANY_URL = tempStringValue;
      }
      tempStringValue = configurationsFile[localeInUrl] ?? doNotChangeUrl;
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        currentSelectedLocaleUrlPosition = tempStringValue;
      }
      tempStringValue = configurationsFile[restAPIPropertiesRouteConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        REST_API_PROPERTIES_ROUTE = tempStringValue;
      }
      tempStringValue = configurationsFile[restAPIAgentRouteConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        REST_API_AGENT_ROUTE = tempStringValue;
      }
      tempStringValue = configurationsFile[restAPIAgencyRouteConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        REST_API_AGENCY_ROUTE = tempStringValue;
      }
      tempStringValue = configurationsFile[googleMapAPIKeyConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        GOOGLE_MAP_API_KEY = tempStringValue;
      }
      tempStringValue = configurationsFile[androidNativeAdIdConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        ANDROID_NATIVE_AD_ID = tempStringValue;
      }
      tempStringValue = configurationsFile[iosNativeAdIdConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        IOS_NATIVE_AD_ID = tempStringValue;
      }
      tempStringValue = configurationsFile[primaryColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        MaterialColor tempColor = GenericMethods.getMaterialColor(tempStringValue);
        AppThemePreferences.appPrimaryColor = GenericMethods.getColorFromString(tempStringValue);
        AppThemePreferences.appPrimaryColorSwatch = tempColor;
        AppThemePreferences.formFieldBorderColor = tempColor;
      }
      tempStringValue = configurationsFile[secondaryColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        MaterialColor tempSecondaryColor = GenericMethods.getMaterialColor(tempStringValue);
        AppThemePreferences.appSecondaryColor = tempSecondaryColor;
        AppThemePreferences.switchSelectedBackgroundLight = tempSecondaryColor[200];
        AppThemePreferences.linkColor = tempSecondaryColor;
        AppThemePreferences.switchSelectedTextLight = tempSecondaryColor;
        AppThemePreferences.label02TextColor = tempSecondaryColor;
        AppThemePreferences.readMoreTextColorLight = tempSecondaryColor;
        AppThemePreferences.homeScreenTopBarRightArrowBackgroundColorLight = tempSecondaryColor;

        AppThemePreferences.homeScreenRecentSearchTitleColorLight = tempSecondaryColor;
        AppThemePreferences.articleBoxPropertyStatusColorLight = tempSecondaryColor;
        AppThemePreferences.explorePropertyColorLight = tempSecondaryColor;
        AppThemePreferences.propertyDetailsPagePropertyStatusColorLight = tempSecondaryColor;


        AppThemePreferences.readMoreTextColorDark = tempSecondaryColor;
        AppThemePreferences.homeScreenRecentSearchTitleColorDark = tempSecondaryColor;
        AppThemePreferences.explorePropertyColorDark = tempSecondaryColor;
        AppThemePreferences.propertyDetailsPagePropertyStatusColorDark = tempSecondaryColor;

        AppThemePreferences.locationWidgetTextColorLight = tempSecondaryColor[500];
        AppThemePreferences.locationWidgetTextColorDark = tempSecondaryColor;
      }

      tempStringValue = configurationsFile[iconTintColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        Color tempIconTintColor = GenericMethods.getColorFromString(tempStringValue);
        AppThemePreferences.appIconsMasterColorLight = tempIconTintColor;
        AppThemePreferences.articleBoxIconsColorLight = tempIconTintColor;
        AppThemePreferences.filterPageIconsColorLight = tempIconTintColor;
        AppThemePreferences.drawerMenuIconColorLight = tempIconTintColor;
        AppThemePreferences.homeScreenTopBarLocationIconColorLight = tempIconTintColor;
        AppThemePreferences.homeScreenTopBarSearchIconColorLight = tempIconTintColor;
        AppThemePreferences.searchByIdTextColorLight = tempIconTintColor;
      }

      tempStringValue = configurationsFile[bottomTabBarTintColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.bottomTabBarTintColor = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[sliderTintColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.sliderTintColor = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[selectedItemBackgroundColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.selectedItemBackgroundColorLight = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[selectedItemTextColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.selectedItemTextColorLight = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[unSelectedItemTextColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.unSelectedItemTextColorLight = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[unSelectedItemBackgroundColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.unSelectedItemBackgroundColorLight = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[actionButtonBackgroundColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.actionButtonBackgroundColor = GenericMethods.getColorFromString(tempStringValue);
      }

      tempStringValue = configurationsFile[featuredLabelBackgroundColorConfiguration];
      if(tempStringValue != null && tempStringValue.isNotEmpty){
        AppThemePreferences.featuredTagBackgroundColorLight = GenericMethods.getColorFromString(tempStringValue);
      }

      tempBoolValue = configurationsFile[showAdsConfiguration] ?? false;
      if(tempBoolValue){
        if(Platform.isAndroid && (configurationsFile.containsKey(showAndroidAdsConfiguration))){
          if(configurationsFile[showAndroidAdsConfiguration] == true){
            SHOW_ADS = true;
          }else{
            SHOW_ADS = false;
          }
        }else if(Platform.isIOS && (configurationsFile.containsKey(showIOSAdsConfiguration))){
          if(configurationsFile[showIOSAdsConfiguration] == true){
            SHOW_ADS = true;
          }else{
            SHOW_ADS = false;
          }
        }else{
          SHOW_ADS = true;
        }
      }else{
        SHOW_ADS = false;
      }

      tempBoolValue = configurationsFile[showAddPropertyInProfileConfiguration];
      SHOW_ADD_PROPERTY_IN_PROFILE = tempBoolValue ?? false;


      tempBoolValue = configurationsFile[showLoginWithPhoneConfiguration];
      SHOW_LOGIN_WITH_PHONE = tempBoolValue ?? false;

      tempBoolValue = configurationsFile[showLoginWithFacebookConfiguration];
      SHOW_LOGIN_WITH_FACEBOOK = tempBoolValue ?? false;

      tempBoolValue = configurationsFile[showLoginWithGoogleConfiguration];
      SHOW_LOGIN_WITH_GOOGLE = tempBoolValue ?? false;

      tempBoolValue = configurationsFile[showLoginWithAppleConfiguration];
      SHOW_LOGIN_WITH_APPLE = tempBoolValue ?? false;

      tempBoolValue = configurationsFile[lockPlacesApiConfiguration];
      LOCK_PLACES_API = tempBoolValue ?? false;

      tempStringValue = configurationsFile[lockPlacesCountriesApiConfiguration];
      if(LOCK_PLACES_API && tempStringValue != null && tempStringValue.isNotEmpty){
        PLACES_API_COUNTRIES = GenericMethods.getPlacesApiLockedCountriesFormattedString(tempStringValue);
      }

      if(configurationsFile.containsKey(totalSearchTypeOptionsApiConfiguration) &&
      configurationsFile[totalSearchTypeOptionsApiConfiguration] != null){
        defaultSearchTypeSwitchOptions = configurationsFile[totalSearchTypeOptionsApiConfiguration];
      }

      if(configurationsFile.containsKey(quoteApiConfiguration) &&
      configurationsFile[quoteApiConfiguration] != null){
        TABBED_HOME_QUOTE = configurationsFile[quoteApiConfiguration];
      }

      /// Read Default Home Config
      if(configurationsFile.containsKey(defaultHomeApiConfiguration) &&
      configurationsFile[defaultHomeApiConfiguration] != null){
        String tempHome = configurationsFile[defaultHomeApiConfiguration];
        if(tempHome != null && tempHome.isNotEmpty){
          HiveStorageManager.storeSelectedHomeOption(tempHome);
          GeneralNotifier().publishChange(GeneralNotifier.HOME_DESIGN_MODIFIED);
        }
      }
      // else{
      //   HiveStorageManager.storeSelectedHomeOption(home0SectionType);
      //   GeneralNotifier().publishChange(GeneralNotifier.HOME_DESIGN_MODIFIED);
      // }

      // Save current Houzi version to Hive
      if(configurationsFile.containsKey(versionApiConfiguration) &&
          configurationsFile[versionApiConfiguration] != null){
        HiveStorageManager.storeHouziVersion(configurationsFile[versionApiConfiguration]);
      }

      HiveStorageManager.storeAppConfigurations(jsonEncode(GenericMethods.convertMap(configurationsFile)));
      GenericMethods.saveHomeConfigFile(configurationsFile);
      GenericMethods.saveDrawerConfigFile(configurationsFile);
      GenericMethods.saveFilterPageConfigFile(configurationsFile);
      GenericMethods.savePropertyDetailPageConfigFile(configurationsFile);

      appConfigurationsListener(true);

      return null;
    });
  }
}