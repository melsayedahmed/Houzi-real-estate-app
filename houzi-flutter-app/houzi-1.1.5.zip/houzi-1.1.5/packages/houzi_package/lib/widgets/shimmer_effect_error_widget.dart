import 'package:flutter/cupertino.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';

Widget shimmerEffectErrorWidget({
  double iconSize = 80.0,
  Color iconColor,
  IconData iconData,
  Color backgroundColor,
}){
  return Container(
    color: backgroundColor ?? AppThemePreferences().appTheme.shimmerEffectErrorWidgetBackgroundColor,
    child: Center(
      child: Icon(
        iconData ?? AppThemePreferences.imageIcon,
        size: iconSize,
        color: iconColor ?? AppThemePreferences().appTheme.shimmerEffectErrorIconColor,
      ),
    ),
  );
}