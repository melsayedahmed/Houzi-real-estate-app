import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';

import '../generic_text_widget.dart';

Widget genericDropDownWidget({
  @required String labelText,
  @required String hintText,
  @required String value,
  String Function(String) validator,
  void Function(String) onChanged,
  void Function(String) onSaved,
  List<DropdownMenuItem<String>> items,
  bool isExpanded = true,
  EdgeInsetsGeometry padding = const EdgeInsets.fromLTRB(20, 20, 20, 0),
}){
  return Container(
    padding: padding,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        genericTextWidget(
          labelText,
          style: AppThemePreferences().appTheme.labelTextStyle,
        ),
        Padding(
          padding: EdgeInsets.only(top: 10.0),
          child: DropdownButtonFormField(
            value: value,
            isExpanded: isExpanded,
            decoration: AppThemePreferences.formFieldDecoration(hintText: hintText),
            validator: validator,
            items: items,
            onChanged: onChanged,
            onSaved: onSaved,
          ),
        ),
      ],
    ),
  );
}