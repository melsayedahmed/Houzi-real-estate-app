import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';

import '../generic_text_widget.dart';

Widget textFieldWidget({
  String labelText,
  String additionalHintText,
  bool ignorePadding = false,
  String initialValue,
  int maxLines = 1,
  String hintText,
  bool readOnly = false,
  bool obscureText = false,
  Widget suffixIcon,
  TextEditingController controller,
  TextInputType keyboardType = TextInputType.text,
  List<TextInputFormatter> inputFormatters,
  String Function(String) validator,
  void Function(String) onSaved,
  void Function(String) onChanged,
  void Function(String) onFieldSubmitted,
  void Function() onTap,
  EdgeInsetsGeometry padding = const EdgeInsets.symmetric(horizontal: 20.0),
  EdgeInsetsGeometry textFieldPadding = const EdgeInsets.only(top: 10),
  bool enabled = true,
}){
  return Container(
    padding: ignorePadding ? EdgeInsets.all(0.0) : padding,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        labelText == null || labelText.isEmpty ? Container() :
        labelWidget(labelText),
        Padding(
          padding: textFieldPadding,
          child: TextFormField(
            enabled: enabled,
            initialValue: initialValue,
            controller: controller,
            keyboardType: keyboardType,
            validator: validator,
            decoration: AppThemePreferences.formFieldDecoration(hintText: hintText, suffixIcon: suffixIcon),
            onSaved: onSaved,
            onChanged: onChanged,
            onFieldSubmitted: onFieldSubmitted,
            maxLines: maxLines,
            readOnly: readOnly,
            inputFormatters: inputFormatters,
            obscureText: obscureText,
            onTap: onTap,
          ),
        ),
        additionalHintText == null || additionalHintText.isEmpty ? Container() :
        Padding(
          padding: EdgeInsets.only(top: 5),
          child: additionalHintWidget(additionalHintText),
        ),
      ],
    ),
  );
}

Widget labelWidget(String text){
  return  genericTextWidget(
    text,
    style: AppThemePreferences().appTheme.labelTextStyle,
  );
}

Widget additionalHintWidget(String text){
  return genericTextWidget(
    text,
    style: AppThemePreferences().appTheme.hintTextStyle,
  );
}
