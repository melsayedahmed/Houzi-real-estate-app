import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

import 'generic_text_widget.dart';

void toastWidget({
  BuildContext buildContext,
  String text,
  bool showButton = false,
  String buttonText = 'Button',
  Function() onButtonPressed,
  int toastDuration = 2, // in seconds
}){
  FToast _fToast = FToast();
  Widget toast = Container(
    padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 10.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(5.0),//25
      color: AppThemePreferences.toastBackgroundColor,
    ),
    child: showButton ? Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Expanded(
          flex: 2,
          child: genericTextWidget(
            text,
            style: AppThemePreferences().appTheme.toastTextTextStyle,
            textAlign: TextAlign.start,
          ),
        ),
        Expanded(
          flex: 1,
          child: SizedBox(
            height: 40,
            child: ElevatedButton(
              child: genericTextWidget(buttonText, style: AppThemePreferences().appTheme.toastTextTextStyle),
              onPressed: onButtonPressed,
              style: ElevatedButton.styleFrom(
                elevation: 0.0,
                primary: AppThemePreferences.toastButtonBackgroundColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24.0),
                    side: BorderSide(width: 2, color: Colors.white.withOpacity(0.4)),
                ),
              ),
            ),
          ),
        ),
      ],
    ) : Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: genericTextWidget(
            text,
            style: AppThemePreferences().appTheme.toastTextTextStyle,
            textAlign: TextAlign.center,
          ),
        ),
      ],
    ),
  );
  _fToast.init(buildContext);
  _fToast.showToast(

    child: toast,
    gravity: ToastGravity.BOTTOM,
    toastDuration: Duration(seconds: toastDuration),
  );
}