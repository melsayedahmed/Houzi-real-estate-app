import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:material_segmented_control/material_segmented_control.dart';

Widget tabBarTitleWidget(
    List<String> itemList,
    int initialSelection,
    Function(int) onSegmentChosen,
    ) {

  return SingleChildScrollView(
    child: Container(
      padding: EdgeInsets.all(5),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          // mainAxisAlignment: MainAxisAlignment.start,
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            MaterialSegmentedControl(
              // horizontalPadding: EdgeInsets.only(left: 5,right: 5),
              children: itemList.map((item) {
                var index = itemList.indexOf(item);
                return Container(
                  // padding:  EdgeInsets.all(10),
                  padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
                  child: genericTextWidget(
                    item,
                    style: TextStyle(
                      fontSize: AppThemePreferences.tabBarTitleFontSize,
                      // fontWeight: AppThemePreferences.tabBarTitleFontWeight,
                      color: initialSelection == index ? AppThemePreferences().appTheme.selectedItemTextColor :
                      AppThemePreferences.unSelectedItemTextColorLight,
                    ),),
                );
              },).toList().asMap(),

              selectionIndex: initialSelection,
              unselectedColor: AppThemePreferences().appTheme.unSelectedItemBackgroundColor,
              selectedColor: AppThemePreferences().appTheme.selectedItemBackgroundColor,
              borderColor: Colors.transparent,
              borderRadius: 8.0, //5.0
              verticalOffset: 8.0, // 8.0
              onSegmentChosen: onSegmentChosen
            ),
          ],
        ),
      ),
    ),
  );
}