import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/widgets/filter_page_widgets/term_picker_multi_select_dialog.dart';
import 'package:material_segmented_control/material_segmented_control.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../models/property_meta_data.dart';
import '../generic_text_widget.dart';

typedef TermPickerPickerListener = void Function(List<dynamic> _listOfTermSlugs, List<dynamic> _listOfTerms);

class TermPicker extends StatefulWidget {
  final String pickerTitle;
  final Icon pickerIcon;
  final String pickerType;
  final List<dynamic> selectedTermsSlugsList;
  final List<dynamic> selectedTermsList;
  final Map<String, dynamic> termsDataMap;
  final List<dynamic> termsDataList;
  final bool singleChoice;
  final TermPickerPickerListener termPickerListener;

  const TermPicker({
    Key key,
    this.pickerTitle,
    this.pickerIcon,
    this.pickerType,
    this.termsDataMap,
    this.termsDataList,
    this.selectedTermsSlugsList,
    this.selectedTermsList,
    this.termPickerListener,
    this.singleChoice = false,
  }) : super(key: key);

  @override
  State<TermPicker> createState() => _TermPickerState();
}

class _TermPickerState extends State<TermPicker> {

  int _selectedTermTitle = 0;

  bool tabBarOptionsAvailable = false;
  bool hasNoTerms = true;

  List<dynamic> _tempTitleList = [];
  final List<dynamic> _termsMetaData = [];
  final Map<String, dynamic> _termsMap = {};
  List<dynamic> _listOfTermSlugs= [];
  List<dynamic> _listOfTerms = [];

  final dropDownTextController = TextEditingController();

  @override
  void initState() {
    super.initState();
    initializeData();
  }

  initializeData(){
    if(widget.termsDataMap != null) {
      _termsMap.addAll(widget.termsDataMap);
    }
    if(widget.termsDataList != null) {
      _termsMetaData.addAll(widget.termsDataList);
    }
    if (widget.selectedTermsSlugsList != null) {
      _listOfTermSlugs.addAll(widget.selectedTermsSlugsList);
    }
    if (widget.selectedTermsList != null) {
      _listOfTerms.addAll(widget.selectedTermsList);
    }
    if((_termsMap != null && _termsMap.isNotEmpty) ||
        (_termsMetaData != null && _termsMetaData.isNotEmpty)){
      hasNoTerms = false;
    }

    if(_termsMap != null && _termsMap.isNotEmpty){
      tabBarOptionsAvailable = true;
      _tempTitleList = _termsMap.keys.toList();
      if (_listOfTerms.isNotEmpty) {
        var index = _tempTitleList.indexOf(_listOfTerms.first);
        if (index != null && index != -1) {
          _selectedTermTitle = index;
          //addTitleSlugToList();
        }
      } else if (_listOfTermSlugs.isNotEmpty) {

        //make map based on slugs, so we can get the selected index.

        //first get the slugs of parent categories
        List<dynamic> termSlugKeyList = [];
        for (var element in _termsMetaData) {
          if(element.parent == 0){
            termSlugKeyList.add(element.slug);
          }
        }

        var index = termSlugKeyList.indexOf(_listOfTermSlugs.first);
        if (index != null && index != -1) {
          _selectedTermTitle = index;
          //addTitleSlugToList();
        }
      }
    }

    if(!tabBarOptionsAvailable){
      if(_listOfTerms != null && _listOfTerms.isNotEmpty){
        String title = _listOfTerms[0];
        int index = _termsMetaData.indexWhere((element) => element.name == title);
        if(index != null && index != -1){
          String slug = _termsMetaData[index].slug;
          if(slug != null && slug.isNotEmpty){
            setState(() {
              _selectedTermTitle = index;
              _listOfTermSlugs.add(slug);
              _listOfTerms.add(title);
            });
          }
        }
      }
    }
  }

  void addTitleSlugToList(){
    if(_tempTitleList != null && _tempTitleList.isNotEmpty){
      String title = _tempTitleList[_selectedTermTitle];
      int index = _termsMetaData.indexWhere((element) => element.name == title);
      if(index != null && index != -1){
        String slug = _termsMetaData[index].slug;
        if(slug != null && slug.isNotEmpty){
          setState(() {
            _listOfTermSlugs.add(slug);
            _listOfTerms.add(title);
          });
        }
      }
    }
  }


  @override
  void dispose() {
    super.dispose();
    dropDownTextController.dispose();
  }

  @override
  Widget build(BuildContext context) {

    _listOfTerms = widget.selectedTermsList;
    _listOfTermSlugs = widget.selectedTermsSlugsList;

    if(widget.pickerType == dropDownTermPicker){
      if(_listOfTerms.isNotEmpty && _listOfTerms.toSet().toList().length == 1){
        dropDownTextController.text = "${_listOfTerms.toSet().toList().first}";
      }
      else if(_listOfTerms.isNotEmpty && _listOfTerms.toSet().toList().length > 1){
        dropDownTextController.text = GenericMethods.getLocalizedString(
            "multi_select_drop_down_item_selected",
            inputWords: [(_listOfTerms.toSet().toList().length.toString())]
        );
      }
    }

    if(_listOfTerms.isEmpty && _listOfTermSlugs.isEmpty){
      _selectedTermTitle = 0;
    }

    return hasNoTerms ? Container() : Container(
      padding: const EdgeInsets.symmetric(vertical: 20.0),
      decoration: BoxDecoration(
        border: Border(
          top: AppThemePreferences().appTheme.filterPageBorderSide,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          termPickerHeaderWidget(),
          widget.pickerType == dropDownTermPicker ? dropDownViewWidget()
              : tabBarViewWidget(),
        ],
      ),
    );
  }

  Widget termPickerHeaderWidget(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child: widget.pickerIcon,
        ),
        Expanded(
          flex: 8,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              genericTextWidget(
                widget.pickerTitle ?? "",
                style: AppThemePreferences().appTheme.filterPageHeadingTitleTextStyle,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget tabBarViewWidget(){
    return tabBarOptionsAvailable ? Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        tabBarWidget(_tempTitleList),
        tabBarOptionsWidget(),
      ],
    ) : tabBarWithoutOptionsViewWidget();
  }

  Widget tabBarWidget(List<dynamic> dataList){
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 20, 10, 0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            MaterialSegmentedControl(

              children: dataList.map((item) {
                var index = dataList.indexOf(item);

                return Container(
                  padding:  const EdgeInsets.only(left: 10, right: 10),
                  child: genericTextWidget(
                    item.runtimeType == PropertyMetaData ?
                    GenericMethods.getLocalizedString(item.name) : GenericMethods.getLocalizedString(item),
                    style: TextStyle(
                      fontSize: AppThemePreferences.tabBarTitleFontSize,
                      fontWeight: AppThemePreferences.tabBarTitleFontWeight,
                      color: _selectedTermTitle == index ? AppThemePreferences().appTheme.selectedItemTextColor :
                      AppThemePreferences.unSelectedItemTextColorLight,
                    ),),
                );
              },).toList().asMap(),

              selectionIndex: _selectedTermTitle,
              unselectedColor: AppThemePreferences().appTheme.unSelectedItemBackgroundColor,
              selectedColor: AppThemePreferences().appTheme.selectedItemBackgroundColor,
              borderRadius: 5.0,
              verticalOffset: 8.0,
              onSegmentChosen: (index){
                setState(() {
                  _selectedTermTitle = index;
                });

                _listOfTerms.clear();
                _listOfTermSlugs.clear();

                String slug;
                String title;

                if(dataList[_selectedTermTitle].runtimeType == PropertyMetaData){
                  title = dataList[_selectedTermTitle].name;
                  slug = dataList[_selectedTermTitle].slug;
                }else{
                  title = dataList[_selectedTermTitle];
                  int itemIndex = _termsMetaData.indexWhere((element) => element.name == title);
                  if(itemIndex != null && itemIndex != -1){
                    slug = _termsMetaData[itemIndex].slug;
                  }
                }



                setState(() {
                  if(title != null && title.isNotEmpty){
                    _listOfTerms.add(title);
                  }

                  if(slug != null && slug.isNotEmpty){
                    _listOfTermSlugs.add(slug);
                  }
                });
                widget.termPickerListener(_listOfTermSlugs, _listOfTerms);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget tabBarOptionsWidget(){
    String key = _tempTitleList[_selectedTermTitle];
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
      child: Wrap(
        children: (_termsMap[key]).map<Widget>((item) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5.0),
          child: ChoiceChip(
            label: Padding(
              padding: const EdgeInsets.all(5.0),
              child: genericTextWidget(
                GenericMethods.getLocalizedString(item.name),
                style: AppThemePreferences().appTheme.filterPageChoiceChipTextStyle,
              ),
            ),
            selected: _listOfTermSlugs.contains(item.slug),
            selectedColor: AppThemePreferences().appTheme.selectedItemBackgroundColor,
            onSelected: (bool selected) {

              if(selected == true) {

                setState(() {
                  _listOfTerms.add(item.name);
                  _listOfTermSlugs.add(item.slug);
                });
              }if(selected == false){
                setState(() {
                  _listOfTerms.remove(item.name);
                  _listOfTermSlugs.remove(item.slug);
                });
              }
              widget.termPickerListener(_listOfTermSlugs, _listOfTerms);
            },
            labelStyle: TextStyle(
              color: _listOfTermSlugs.contains(item.slug) ? AppThemePreferences().appTheme.selectedItemTextColor : Colors.black,
            ),
            backgroundColor: AppThemePreferences().appTheme.unSelectedItemBackgroundColor,
            // backgroundColor: AppThemePreferences().appTheme.searchPageChoiceChipsBackgroundColor,
            shape: AppThemePreferences.roundedCorners(AppThemePreferences.searchPageChoiceChipsRoundedCornersRadius),
          ),
        )).toList(),
      ),
    );
  }

  Widget tabBarWithoutOptionsViewWidget(){
    return tabBarWidget(_termsMetaData);
    // return Container(
    //   width: MediaQuery.of(context).size.width,
    //   padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
    //   child: Row(
    //     children: [
    //       Expanded(
    //         child: SingleChildScrollView(
    //           scrollDirection: Axis.horizontal,
    //           child: Row(
    //             children: _termsMetaData.map<Widget>((item) => Padding(
    //               padding: const EdgeInsets.symmetric(horizontal: 5.0),
    //               child: ChoiceChip(
    //                 label: Padding(
    //                   padding: const EdgeInsets.all(5.0),
    //                   child: genericTextWidget(
    //                     GenericMethods.getLocalizedString(item.name),
    //                     style: AppThemePreferences().appTheme.filterPageChoiceChipTextStyle,
    //                   ),
    //                 ),
    //                 selected: _listOfTermSlugs.contains(item.slug),
    //                 selectedColor: AppThemePreferences().appTheme.selectedItemBackgroundColor,
    //                 onSelected: (bool selected) {
    //                   if (widget.singleChoice) {
    //                     _listOfTermSlugs.clear();
    //                     _listOfTerms.clear();
    //                   }
    //                   if(selected == true){
    //                     setState(() {
    //                       _listOfTermSlugs.add(item.slug);
    //                       _listOfTerms.add(item.name);
    //                     });
    //                   }if(selected == false){
    //                     setState(() {
    //                       _listOfTermSlugs.remove(item.slug);
    //                       _listOfTerms.remove(item.name);
    //                     });
    //                   }
    //                   widget.termPickerListener(_listOfTermSlugs, _listOfTerms);
    //                   // widget.termPickerListener("", _listOfTermSlugs, _listOfTerms);
    //                 },
    //                 backgroundColor: AppThemePreferences().appTheme.unSelectedItemBackgroundColor,
    //                 labelStyle: TextStyle(
    //                   color: _listOfTermSlugs.contains(item.slug) ?
    //                   AppThemePreferences().appTheme.selectedItemTextColor : AppThemePreferences().appTheme.unSelectedItemTextColor,
    //                   // color: _listOfTermSlugs.contains(item.slug) ?
    //                   // AppThemePreferences().appTheme.selectedItemTextColor : Colors.black,
    //                 ),
    //               ),
    //             )).toList(),
    //           ),
    //         ),
    //       ),
    //     ],
    //   ),
    // );
  }

  Widget dropDownViewWidget(){
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0, vertical: 20.0),
          child: TextFormField(
            controller: dropDownTextController,
            decoration: AppThemePreferences.formFieldDecoration(
              hintText: GenericMethods.getLocalizedString("select"),
              suffixIcon: Icon(AppThemePreferences.arrowDropDownIcon),
            ),
            readOnly: true,
            onTap: (){
              FocusScope.of(context).requestFocus(FocusNode());
              _showMultiSelect(context);
            },
          ),
        ),
      ],
    );
  }

  void _showMultiSelect(BuildContext context) async {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return MultiSelectDialogWidget(
          title: GenericMethods.getLocalizedString("select"),
          dataItemsList: _termsMetaData,
          selectedItemsList: _listOfTerms,
          selectedItemsSlugsList: _listOfTermSlugs,
          multiSelectDialogWidgetListener: (List<dynamic> selectedItemsList, List<dynamic> listOfSelectedItemsSlugs){
            setState(() {
              _listOfTerms = selectedItemsList;
              _listOfTermSlugs = listOfSelectedItemsSlugs;
            });
            widget.termPickerListener(_listOfTermSlugs, _listOfTerms);
          },
        );
      },
    );
  }

}
