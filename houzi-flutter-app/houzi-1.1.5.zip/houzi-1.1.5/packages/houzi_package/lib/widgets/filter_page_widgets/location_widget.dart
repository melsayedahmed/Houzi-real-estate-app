import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/dataProvider/place_api_provider.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/address_search.dart';
import 'package:houzi_package/models/filter_page_config.dart';
import 'package:houzi_package/pages/city_picker.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:material_segmented_control/material_segmented_control.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:uuid/uuid.dart';
// import 'package:google_maps_webservice/places.dart';

import '../../models/address.dart';

typedef LocationWidgetListener = void Function(Map<String,dynamic> locationWidgetListener, String closeOption);

class LocationWidget extends StatefulWidget{

  final FilterPageElement filterPageConfigData;
  final Map<String, dynamic> filterDataMap;
  final LocationWidgetListener locationWidgetListener;

  const LocationWidget({
    Key key,
    @required this.filterPageConfigData,
    @required this.filterDataMap,
    this.locationWidgetListener,
  }) : super(key: key);

  
  @override
  State<StatefulWidget> createState() => LocationWidgetState();
  
}

class LocationWidgetState extends State<LocationWidget> {

  // IconData locationIconData;
  bool showSearchByCity = true;
  bool showSearchByLocation = true;
  FilterPageElement _filterPageElement;

  int _currentSelection = 0;
  int _selectedCityId;
  
  String _selectedRadiusKm = "50.0";
  String _selectedCitySlug = '';
  String _selectedCity = '';
  String _selectedLocation = '';
  String _latitude = "";
  String _longitude = "";

  List<dynamic> _locationWidgetTabBarList = [];
  List<dynamic> citiesMetaDataList = [];

  Map<String, dynamic> _filterDataMap = {};

  // final GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: GOOGLE_MAP_API_KEY);
  

  @override
  void initState() {
    super.initState();

    _selectedCity = GenericMethods.getLocalizedString("please_select");
    _selectedLocation =GenericMethods.getLocalizedString("please_select");

    _filterPageElement = widget.filterPageConfigData;
    // locationIconData = GenericMethods.fromJsonToIconData(_filterPageElement.iconData);
    showSearchByCity = _filterPageElement.showSearchByCity;
    showSearchByLocation = _filterPageElement.showSearchByLocation;

    setState(() {
      SHOW_SEARCH_BY_CITY = showSearchByCity;
      SHOW_SEARCH_BY_LOCATION = showSearchByLocation;
    });
  }

  @override
  Widget build(BuildContext context) {
    if(!mapEquals(widget.filterDataMap, _filterDataMap)){
      loadData();
    }
    _locationWidgetTabBarList = [GenericMethods.getLocalizedString("city"),GenericMethods.getLocalizedString("location")];
    citiesMetaDataList = HiveStorageManager.readCitiesMetaData();

    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: AppThemePreferences().appTheme.filterPageBorderSide,
        ),
      ),
      child: SHOW_SEARCH_BY_CITY && SHOW_SEARCH_BY_LOCATION ? showTabBar() :
      SHOW_SEARCH_BY_CITY && !SHOW_SEARCH_BY_LOCATION ? citySelectionWidget() :
      !SHOW_SEARCH_BY_CITY && SHOW_SEARCH_BY_LOCATION ? genericLocationSelectionWidget() :
      Container(),
    );
  }

  loadData(){
    _filterDataMap = widget.filterDataMap;
    if (_filterDataMap != null) {
      if (_filterDataMap.containsKey(SELECTED_INDEX_FOR_TAB) && _filterDataMap[SELECTED_INDEX_FOR_TAB] != null) {
        _currentSelection = _filterDataMap[SELECTED_INDEX_FOR_TAB];
      }

      if (_filterDataMap.containsKey(CITY_SLUG) && _filterDataMap[CITY_SLUG] != null && _filterDataMap[CITY_SLUG].isNotEmpty) {
        _selectedCitySlug = _filterDataMap[CITY_SLUG] is List ? _filterDataMap[CITY_SLUG][0] : _filterDataMap[CITY_SLUG];
      }

      if (_filterDataMap.containsKey(CITY) && _filterDataMap[CITY] != null && _filterDataMap[CITY].isNotEmpty) {
        _selectedCity = _filterDataMap[CITY] is List ? _filterDataMap[CITY][0] : _filterDataMap[CITY];
      } else {
        _selectedCity = GenericMethods.getLocalizedString("please_select");
      }

      if (_filterDataMap.containsKey(CITY_ID) && _filterDataMap[CITY_ID] != null) {
        _selectedCityId = _filterDataMap[CITY_ID];
      }

      if (_filterDataMap.containsKey(SELECTED_LOCATION) && _filterDataMap[SELECTED_LOCATION] != null && _filterDataMap[SELECTED_LOCATION].isNotEmpty) {
        _selectedLocation = _filterDataMap[SELECTED_LOCATION];

      } else {
        _selectedLocation =GenericMethods.getLocalizedString("please_select");
      }
      if (_filterDataMap.containsKey(LATITUDE) && _filterDataMap[LATITUDE] != null && _filterDataMap[LATITUDE].isNotEmpty) {
        _latitude = _filterDataMap[LATITUDE];
        _currentSelection = 1;

      } else {
        _latitude = "";
      }
      if (_filterDataMap.containsKey(LONGITUDE) && _filterDataMap[LONGITUDE] != null && _filterDataMap[LONGITUDE].isNotEmpty) {
        _longitude = _filterDataMap[LONGITUDE];
        _currentSelection = 1;
      } else {
        _longitude = "";
      }
      if (_filterDataMap.containsKey(RADIUS) && _filterDataMap[RADIUS] != null && _filterDataMap[RADIUS].isNotEmpty) {
        _selectedRadiusKm = _filterDataMap[RADIUS];
      } else {
        _selectedRadiusKm = "50.0";
      }
    }else {
      _selectedCity = GenericMethods.getLocalizedString("please_select");
      _selectedLocation =GenericMethods.getLocalizedString("please_select");
      _currentSelection = 0;
    }
  }

  Widget showTabBar(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        tabBarViewWidget(),
        _currentSelection == 0 ? citySelectionWidget() : genericLocationSelectionWidget(),
      ],
    );
  }

  Widget tabBarViewWidget(){
    return _locationWidgetTabBarList != null && _locationWidgetTabBarList.isNotEmpty ? Container(
      padding: const EdgeInsets.fromLTRB(10, 30, 10, 10),
      child: MaterialSegmentedControl(
        children: _locationWidgetTabBarList.map((item) {
          var index = _locationWidgetTabBarList.indexOf(item);
          return Container(
            padding:  const EdgeInsets.only(left: 35 ,right: 35),
            child: genericTextWidget(
              GenericMethods.getLocalizedString(item),
              style: TextStyle(
                fontSize: AppThemePreferences.tabBarTitleFontSize,
                fontWeight: AppThemePreferences.tabBarTitleFontWeight,
                color: _currentSelection == index ? AppThemePreferences().appTheme.selectedItemTextColor :
                AppThemePreferences.unSelectedItemTextColorLight,
              ),),
          );
        },).toList().asMap(),

        selectionIndex: _currentSelection,
        unselectedColor: AppThemePreferences().appTheme.unSelectedItemBackgroundColor,
        selectedColor: AppThemePreferences().appTheme.selectedItemBackgroundColor,
        borderRadius: 5.0,
        verticalOffset: 8.0,
        onSegmentChosen: (index){
          setState(() {
            _currentSelection = index;
          });
          _filterDataMap[SELECTED_INDEX_FOR_TAB] = _currentSelection;
          widget.locationWidgetListener(_filterDataMap, UPDATE_DATA);
        },
      ),
    ) : Container();
  }

  Widget citySelectionWidget(){
    return citiesMetaDataList == null ||  citiesMetaDataList.isEmpty ? Container() : GestureDetector(
      onTap: (){
        if(citiesMetaDataList != null && citiesMetaDataList.isNotEmpty){
          Navigator.push(context, MaterialPageRoute(
            builder: (context) => CityPicker(
              citiesMetaDataList: citiesMetaDataList,
              cityPickerListener: (String pickedCity, int pickedCityId, String pickedCitySlug){
                setState(() {
                  _selectedCity = pickedCity;
                  _selectedCityId = pickedCityId;
                  _selectedCitySlug = pickedCitySlug;
                  _filterDataMap[CITY] = _selectedCity;
                  _filterDataMap[CITY_ID] = _selectedCityId;
                  _filterDataMap[CITY_SLUG] = pickedCitySlug;
                });
                saveSelectedCityInfo(pickedCityId, pickedCity, pickedCitySlug);
                widget.locationWidgetListener(_filterDataMap, UPDATE_DATA);
              },
            ),
          ),
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              flex: 2,
              child: AppThemePreferences().appTheme.filterPageLocationIcon,
            ),
            Expanded(
              flex: 8,
              child: Container(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        genericTextWidget(
                          GenericMethods.getLocalizedString("city"),
                          style: AppThemePreferences().appTheme.filterPageHeadingTitleTextStyle,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top:10.0),
                          child: genericTextWidget(
                            _selectedCity ==  PLEASE_SELECT ? GenericMethods.getLocalizedString("please_select") :
                            GenericMethods.getLocalizedString(_selectedCity),
                            style: AppThemePreferences().appTheme.locationWidgetTextStyle,
                          ),
                        ),
                      ],
                    ),
                    IconButton(padding: const EdgeInsets.only(right: 27),
                      icon: AppThemePreferences().appTheme.filterPageArrowForwardIcon,
                      onPressed: (){
                        if(citiesMetaDataList != null && citiesMetaDataList.isNotEmpty){
                          Navigator.push(context, MaterialPageRoute(
                            builder: (context) => CityPicker(
                              citiesMetaDataList: citiesMetaDataList,
                              cityPickerListener: (String pickedCity, int pickedCityId, String pickedCitySlug){
                                setState(() {
                                  _selectedCity = pickedCity;
                                  _selectedCityId = pickedCityId;
                                  _selectedCitySlug = pickedCitySlug;
                                  _filterDataMap[CITY] = _selectedCity;
                                  _filterDataMap[CITY_ID] = _selectedCityId;
                                  _filterDataMap[CITY_SLUG] = pickedCitySlug;

                                });

                                saveSelectedCityInfo(pickedCityId, pickedCity, pickedCitySlug);
                                widget.locationWidgetListener(_filterDataMap,UPDATE_DATA);
                              },
                            ),
                          ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }

  Widget genericLocationSelectionWidget(){
    return Column(
      children: [
        locationSelectionWidget(),
        kmSlidingWidget()
      ],
    );
  }

  Widget locationSelectionWidget(){
    return GestureDetector(
      onTap: () async {
        final sessionToken = const Uuid().v4();
        final Suggestion result = await showSearch(
          context: context,
          delegate: AddressSearch(sessionToken),
        );
        if (result != null) {
          var response = await PlaceApiProvider.getPlaceDetailFromPlaceId(result.placeId);
          Map addressMap = response.data;
          try {
            if(addressMap != null && addressMap.isNotEmpty){
              setState(() {
                _selectedLocation = addressMap["result"]["formatted_address"];
                _latitude = addressMap["result"]["geometry"]["location"]["lat"].toString();
                _longitude = addressMap["result"]["geometry"]["location"]["lng"].toString();
              });

              _filterDataMap[SELECTED_LOCATION] = _selectedLocation;
              _filterDataMap[LATITUDE] = _latitude;
              _filterDataMap[LONGITUDE] = _longitude;
              widget.locationWidgetListener(_filterDataMap, UPDATE_DATA);
            }
          } catch (e) {
            e.toString();
          }

        }
      },
      child: Container(
        decoration: const BoxDecoration(color: Colors.transparent),
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 2,
              child: AppThemePreferences().appTheme.filterPageGpsLocationIcon,
            ),
            Expanded(
              flex: 6,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  genericTextWidget(
                    GenericMethods.getLocalizedString("location"),
                    style: AppThemePreferences().appTheme.filterPageHeadingTitleTextStyle,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top:10.0),
                    child: genericTextWidget(
                      _selectedLocation == PLEASE_SELECT ? GenericMethods.getLocalizedString("please_select") : _selectedLocation,
                      style: AppThemePreferences().appTheme.locationWidgetTextStyle,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: AppThemePreferences().appTheme.filterPageArrowForwardIcon,
            ),
          ],
        ),
      ),
    );
  }

  Widget kmSlidingWidget(){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 2,
            child:
            AppThemePreferences().appTheme.filterPageRadiusLocationIcon,
          ),
          Expanded(
            flex: 8,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                genericTextWidget(
                  "Radius ${double.parse(_selectedRadiusKm).round()} km",
                  style: AppThemePreferences().appTheme.filterPageHeadingTitleTextStyle,
                ),
                SliderTheme(
                  data: SliderThemeData(
                      trackHeight: 5.0,
                      activeTrackColor: AppThemePreferences.sliderTintColor,
                      inactiveTrackColor: AppThemePreferences.sliderTintColor.withOpacity(0.3),
                      activeTickMarkColor: Colors.transparent,
                      inactiveTickMarkColor: Colors.transparent,
                      thumbColor: AppThemePreferences.sliderTintColor,
                      overlayColor: AppThemePreferences.sliderTintColor.withOpacity(0.3),
                      overlayShape: const RoundSliderOverlayShape(overlayRadius: 28.0),
                      valueIndicatorColor: AppThemePreferences.sliderTintColor.withOpacity(0.3),
                      valueIndicatorShape: const PaddleSliderValueIndicatorShape(),
                      valueIndicatorTextStyle: TextStyle(
                        color: AppThemePreferences.sliderTintColor,
                      )
                  ),
                  child: Slider(
                    value: double.parse(_selectedRadiusKm),
                    max: 100,
                    min: 1,
                    label: null,
                    //_kmSliderValue.round().toString(),
                    onChanged: (double value) {
                      setState(() {
                        _selectedRadiusKm = value.toString();
                      });
                      _filterDataMap[RADIUS] = _selectedRadiusKm;
                      widget.locationWidgetListener(_filterDataMap,"");
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  void saveSelectedCityInfo(int cityId, String cityName, String citySlug){
    HiveStorageManager.storeSelectedCityInfo(data:
    {
      CITY : cityName,
      CITY_ID : cityId,
      CITY_SLUG : citySlug,
    }
    );
    GeneralNotifier().publishChange(GeneralNotifier.CITY_DATA_UPDATE);
  }
}