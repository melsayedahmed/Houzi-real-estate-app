import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';

import 'package:houzi_package/widgets/text_span_widgets/text_span_widgets.dart';

Widget genericLinkWidget({
  @required BuildContext context,
  String preLinkText,
  @required String linkText,
  @required Function() onLinkPressed,
  StrutStyle strutStyle = const StrutStyle(forceStrutHeight: true, height: 1.5),
}){
  return RichText(
    strutStyle: strutStyle,
    text: TextSpan(
      style: TextStyle(
        fontFamily: Theme.of(context).textTheme.bodyText1.fontFamily,
      ),

      children: [
        genericNormalTextSpanWidget(text: preLinkText),
        genericLinkTextSpanWidget(
          text: " " + linkText,
          onTap: onLinkPressed,
        ),
      ],
    ),
  );
}
Widget genericInlineLinkWidget({
  @required BuildContext context,
  String text,
  @required String linkText,
  @required Function() onLinkPressed,
  StrutStyle strutStyle = const StrutStyle(forceStrutHeight: true, height: 1.5),
}){
  List<String> pieces = text.split(linkText);

  return RichText(
    strutStyle: strutStyle,
    text: TextSpan(
      style: TextStyle(
        fontFamily: Theme.of(context).textTheme.bodyText1.fontFamily,
      ),
      children: [
        genericNormalTextSpanWidget(text: pieces.first),
        genericLinkTextSpanWidget(
          text: linkText,
          onTap: onLinkPressed,
        ),
        genericNormalTextSpanWidget(text: pieces.last),
      ],
    ),
  );
}