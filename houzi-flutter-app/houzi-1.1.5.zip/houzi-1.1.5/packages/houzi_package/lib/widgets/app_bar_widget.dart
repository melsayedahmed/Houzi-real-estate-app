import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

Widget appBarWidget(
  BuildContext context, {
  String appBarTitle,
  Function() onBackPressed,
  double elevation = 1.0,
  List<Widget> actions,
  PreferredSizeWidget bottom,
  double toolbarHeight = kToolbarHeight,
  bool automaticallyImplyLeading = true,
  double leadingWidth = 56.0,
}) {
  return AppBar(
    automaticallyImplyLeading: automaticallyImplyLeading,
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor: AppThemePreferences().appTheme.genericStatusBarColor,
      statusBarIconBrightness: AppThemePreferences().appTheme.genericStatusBarIconBrightness,
      statusBarBrightness:AppThemePreferences().appTheme.statusBarBrightness
    ),
    backgroundColor: AppThemePreferences().appTheme.primaryColor,
    leading: automaticallyImplyLeading ? IconButton(
      icon: Icon(AppThemePreferences.arrowBackIcon),
      color: AppThemePreferences().appTheme.genericAppBarIconsColor,
      onPressed: onBackPressed != null
          ? onBackPressed
          : () {
        onBackPressedFunc(context);
      },
    ) : Container(),
    leadingWidth: automaticallyImplyLeading ? leadingWidth : 0.0,
    title: genericTextWidget(
      appBarTitle,strutStyle: const StrutStyle(height: 1),
      style: AppThemePreferences().appTheme.genericAppBarTextStyle,
    ),
    actions: actions,
    bottom: bottom,
    toolbarHeight: toolbarHeight,
    elevation: elevation != AppThemePreferences.appBarWidgetElevation ?
                elevation : AppThemePreferences.appBarWidgetElevation,
  );
}

void onBackPressedFunc(BuildContext context) {
  Navigator.of(context).pop();
}
