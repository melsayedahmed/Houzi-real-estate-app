import 'dart:math';

import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/realtor_model.dart';
import 'package:houzi_package/pages/realtor_information_page.dart';

import '../../generic_text_widget.dart';
import '../../header_widget.dart';
import '../../shimmer_effect_error_widget.dart';

Widget realtorInfoListWidget({
  @required BuildContext context,
  @required String realtorTitle,
  @required List<dynamic> realtorInfoList,
  @required String tag,
}) {
  return realtorInfoList == null || realtorInfoList.isEmpty ? Container() : Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      headerWidget(
        text: realtorTitle,
        padding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 5.0),
      ),
      realtorListingWidget(
        context: context,
        tag: tag,
        realtorInfoList: realtorInfoList,
      ),
      // _horizontalListForAgents(context, realtorInfoList),
    ],
  );
}

typedef AgentItemHook = Widget Function(Agent agent);
typedef AgencyItemHook = Widget Function(Agency agency);

Widget realtorListingWidget({
  BuildContext context,
  @required List<dynamic> realtorInfoList,
  @required String tag,
  String listingView = homeScreenWidgetsListingCarouselView,
}){
  // if (tag == AGENTS_TAG) {
  //   AgentItemHook agentItemHook = GenericMethods.agentItem;
  //   if (agentItemHook(realtorInfoList) != null) {
  //     return agentItemHook(realtorInfoList);
  //   }
  // } else {
  //   AgencyItemHook agencyItemHook = GenericMethods.agencyItem;
  //   if (agencyItemHook(realtorInfoList) != null) {
  //     return agencyItemHook(realtorInfoList);
  //   }
  // }

  double height = tag == AGENTS_TAG ? AppThemePreferences.agentsListContainerHeight : AppThemePreferences.agenciesListContainerHeight;
  double width = tag == AGENTS_TAG ? AppThemePreferences.agentsListContainerWidth : AppThemePreferences.agenciesListContainerWidth;

  return Container(
    // padding: listingView == homeScreenWidgetsListingListView ? null :  EdgeInsets.only(top: 5, left: 20),
    padding: listingView == homeScreenWidgetsListingListView ? EdgeInsets.symmetric(horizontal: 15) :
    EdgeInsets.only(
      left: GenericMethods.isRTL(context) ? 0 : 10,
      right: GenericMethods.isRTL(context) ? 10 : 0),
    // height: height,
    height: listingView == homeScreenWidgetsListingListView ? null : height,
    child: ListView.builder(
      scrollDirection: listingView == homeScreenWidgetsListingListView ? Axis.vertical : Axis.horizontal,
      physics: listingView == homeScreenWidgetsListingListView ? NeverScrollableScrollPhysics() : null,
      shrinkWrap: true,
      itemCount: min(10, realtorInfoList.length),
      itemBuilder: (context, index) {
        var item = realtorInfoList[index];
        if (tag == AGENTS_TAG) {
          if(item is Agent) {
            AgentItemHook agentItemHook = GenericMethods.agentItem;
            if (agentItemHook(item) != null) {
              return agentItemHook(item);
            }
          }
        } else {
          if(item is Agency) {
            AgencyItemHook agencyItemHook = GenericMethods.agencyItem;
            if (agencyItemHook(item) != null) {
              return agencyItemHook(item);
            }
          }

        }
        String stringContent = GenericMethods.stripHtmlIfNeeded(item.content);
        String heroId = HERO + item.id.toString();

        return Container(
          height: height,
          padding: EdgeInsets.only(bottom: 10, right: listingView == homeScreenWidgetsListingListView ? 0 : 5),
          child: Card(
            shape: AppThemePreferences.roundedCorners(AppThemePreferences.realtorPageRoundedCornersRadius),
            elevation: AppThemePreferences.horizontalListForAgentsElevation,
            child: InkWell(
              borderRadius: const BorderRadius.all(Radius.circular(10)),
              onTap: () {
                navigateToRealtorInformationDisplayPage(
                  context: context,
                  heroId: heroId,
                  realtorType: tag == AGENTS_TAG ? AGENT_INFO : AGENCY_INFO,
                  realtorInfo: tag == AGENTS_TAG ? {AGENT_DATA : item} : {AGENCY_DATA : item},
                );
              },
              child: Container(
                width: width,
                // height: 135,
                height: height,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        realtorImageWidget(
                            tag: tag,
                            heroId: heroId,
                            imageUrl: item.thumbnail,
                        ),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                realtorHeadingTextWidget(title: item.title, tag: tag),
                                if (tag == AGENTS_TAG && item is Agent) realtorPosition(position: "${item.agentPosition}"),
                                if (tag == AGENTS_TAG && item is Agent) realtorHeadingTextWidget(title: "${item.agentCompany}",tag: tag),
                                realtorDescription(description: stringContent.replaceFirst("\n", ""), tag: tag),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    ),
  );
}

Widget realtorHeadingTextWidget({@required String title, @required String tag}){
  return Container(
    padding: tag == AGENTS_TAG ? const EdgeInsets.only(top: 10) : const EdgeInsets.only(top: 15),
    child: genericTextWidget(
      title,
      textAlign: TextAlign.left,
      maxLines: 1,
      strutStyle: const StrutStyle(forceStrutHeight: true),
      overflow: TextOverflow.ellipsis,
      style: AppThemePreferences().appTheme.homeScreenRealtorTitleTextStyle,
    ),
  );
}

Widget realtorPosition({@required String position}){
  return Container(
    padding: const EdgeInsets.only(top: 10),
    child: genericTextWidget(
      position,
      textAlign: TextAlign.left,
      style: AppThemePreferences().appTheme.homeScreenRealtorInfoTextStyle,
    ),
  );
}

Widget realtorDescription({@required String description, @required String tag}){
  return Container(
    padding: const EdgeInsets.only(top: 5, bottom: 10),
    child: genericTextWidget(
      description,
      maxLines: tag == AGENTS_TAG ? 2 : 2,
      overflow:
      TextOverflow.ellipsis,

      style: AppThemePreferences().appTheme.subBodyTextStyle,
      textAlign: TextAlign.justify,
    ),
  );
}

Widget realtorImageWidget({
  @required String heroId,
  @required String imageUrl,
  @required String tag,
}){
  return  Container(
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: Hero(
      tag: heroId,
      child: ClipRRect(
        borderRadius:
        BorderRadius.circular(10),
        child: FancyShimmerImage(
          imageUrl: imageUrl,
          boxFit: BoxFit.cover,
          shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
          shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
          width: tag == AGENTS_TAG ? AppThemePreferences.agentsListImageWidth : AppThemePreferences.agenciesListImageWidth,
          height: tag == AGENTS_TAG ? AppThemePreferences.agentsListImageHeight : AppThemePreferences.agenciesListImageHeight,
          errorWidget: shimmerEffectErrorWidget(iconSize: 50),
        ),
      ),
    ),
  );
}

void navigateToRealtorInformationDisplayPage({
  @required BuildContext context,
  @required String heroId,
  @required Map<String, dynamic> realtorInfo,
  @required String realtorType,
}){
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => RealtorInformationDisplayPage(
        heroId: heroId,
        realtorInformation: realtorInfo,
        agentType: realtorType,
      ),
    ),
  );
}


