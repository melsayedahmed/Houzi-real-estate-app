import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';

import 'home_screen_search_bar_widget.dart';
import 'home_screen_search_type_widget.dart';
import 'home_screen_top_bar_widgets.dart';

typedef HomeScreenSliverAppBarListener = void Function({Map<String, dynamic> filterDataMap});

Widget homeScreenSliverAppBarWidget({
  @required BuildContext context,
  @required String city,
  @required int selectedStatusIndex,
  @required Function() onLeadingIconPressed,
  @required Map<String, dynamic> propertyMetaDataMap,
  @required List<dynamic> cityMetaDataList,
  final HomeScreenSliverAppBarListener homeScreenSliverAppBarListener,
  
  bool isCollapsed = false,
  bool isStretched = true,
  bool increasePadding = true,
  bool reducePadding = false,
  double extendedHeight = 185.0,
  double padding = 10.0,
  double currentHeight = 0.0,
  double previousHeight = 0.0,
}){
  return SliverAppBar(
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor: AppThemePreferences().appTheme.homeScreenStatusBarColor,
      statusBarIconBrightness: AppThemePreferences().appTheme.statusBarIconBrightness,
      statusBarBrightness:AppThemePreferences().appTheme.statusBarBrightness
    ),
    backgroundColor: AppThemePreferences().appTheme.sliverAppBarBackgroundColor,
    pinned: true,
    expandedHeight: extendedHeight,
    leading: IconButton(
      padding: const EdgeInsets.all(0),
      onPressed: onLeadingIconPressed,
      icon:  AppThemePreferences().appTheme.drawerMenuIcon,
      tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
    ),

    flexibleSpace: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          isCollapsed = constraints.biggest.height ==  MediaQuery.of(context).padding.top + kToolbarHeight ? true : false;
          isStretched = constraints.biggest.height ==  MediaQuery.of(context).padding.top + extendedHeight ? true : false;
          currentHeight = constraints.maxHeight;
          if(previousHeight < currentHeight){
            increasePadding = false;
            reducePadding = true;
            previousHeight = currentHeight;
          }
          if(previousHeight > currentHeight){
            increasePadding = true;
            reducePadding = false;
            previousHeight = currentHeight;
          }
          if(isCollapsed){
            padding = 60;
            increasePadding = false;
            reducePadding = true;
          }
          if(isStretched){
            padding = 10;
            increasePadding = true;
            reducePadding = false;
          }

          if(increasePadding){
            double temp = padding + (constraints.maxHeight) / 100;
            if(temp <= 60){
              padding = temp;
            }else{
              temp = temp - (temp - 60);
              padding = temp;
            }
          }
          if(reducePadding){
            double temp = padding - (constraints.maxHeight) / 100;
            if(temp >= 10){
              padding = temp;
            }else{
              temp = temp + (10 - temp);
              padding = temp;
            }
          }

          return FlexibleSpaceBar(
            centerTitle: false,
            titlePadding: EdgeInsets.only(left: GenericMethods.isRTL(context) ? 10 : padding, bottom: 10, right: GenericMethods.isRTL(context) ? padding : 10),
            title: homeScreenSearchBarWidget(
                context: context,
                propertyMetaDataMap: propertyMetaDataMap,
                homeScreenSearchBarWidgetListener: ({filterDataMap, recentSearchesDataMapList, loadProperties}){
                  homeScreenSliverAppBarListener(filterDataMap: filterDataMap);
                }
            ),
            background: Column(
              children: [
                HomeScreenTopBarWidget(
                  city: city,
                  cityMetaDataList: cityMetaDataList,
                  propertyMetaDataMap: propertyMetaDataMap,
                  homeScreenTopBarWidgetListener:  ({filterDataMap, loadProperties}){
                    homeScreenSliverAppBarListener(filterDataMap: filterDataMap);
                  },
                ),
                HomeScreenSearchTypeWidget(
                  homeScreenSearchTypeWidgetListener: (String selectedItem, String selectedItemSlug){
                    // Do something here
                  }
                ),
              ],
            ),
          );
        }),
    elevation: 5,
  );
}