import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import '../../generic_text_widget.dart';
import '../../header_widget.dart';

typedef HomeScreenRecentSearchesWidgetListener = void Function({
  Map<String, dynamic> filterDataMap,
  List<dynamic> recentSearchesDataMapList,
  bool loadProperties,
});

Widget homeScreenRecentSearchesWidget({
  @required BuildContext context,
  @required List<dynamic> recentSearchesInfoList,
  String listingView = homeScreenWidgetsListingCarouselView,
}){

  return recentSearchesInfoList == null || recentSearchesInfoList.isEmpty ?  Container() : Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      recentSearchesListViewWidget(
        context: context,
        recentSearchesList: recentSearchesInfoList,
        listingView: listingView,
      ),
    ],
  );
}

Widget textRecentSearchesWidget(BuildContext context) {
  return headerWidget(
    text: GenericMethods.getLocalizedString("recent_searches"),
    padding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 5.0),
  );
}

Widget recentSearchesListViewWidget({
  @required BuildContext context,
  @required List<dynamic> recentSearchesList,
  String listingView = homeScreenWidgetsListingCarouselView,
}){
  return recentSearchesList == null || recentSearchesList.isEmpty ? Container() : Container(
    padding: EdgeInsets.only(
        top: listingView == homeScreenWidgetsListingCarouselView ? 20 : 0,
        left: 20, right: 10
    ),
    height: listingView == homeScreenWidgetsListingCarouselView ? 110 : null,
    child: ListView.builder(
      scrollDirection: listingView == homeScreenWidgetsListingCarouselView ?
      Axis.horizontal : Axis.vertical,
      physics: listingView == homeScreenWidgetsListingListView ?
      NeverScrollableScrollPhysics() : null,
      itemCount: recentSearchesList.length,
      shrinkWrap: listingView == homeScreenWidgetsListingListView ? true : false,
      itemBuilder: (context, index) {
        var result = recentSearchesList[index];
        if(result is Map) {
          Map<String, dynamic> item = {};
          for (dynamic type in result.keys) {
            item[type.toString()] = result[type];
          }
          String propertyTitle = '';
          String propertyType = '';
          String propertyCity = '';
          String propertyStatus = '';

          if (item.containsKey(PROPERTY_TYPE) && item[PROPERTY_TYPE] != null &&
              item[PROPERTY_TYPE].isNotEmpty) {
            List<String> tempPropertyTypeList = List<String>.from(
                item[PROPERTY_TYPE]);
            List<String> tempList = [];
            for (var element in tempPropertyTypeList) {
              tempList.add(GenericMethods.getLocalizedString(element));
            }
            propertyType = tempList.join(", ");
            // propertyType = '$tempList';
            // propertyType = propertyType.replaceAll("[", '');
            // propertyType = propertyType.replaceAll("]", '');
            // if(propertyType.length > 18){
            //   var temp = '${propertyType.substring(0, 18)}...';
            //   propertyType = temp;
            // }
          }
          if (item.containsKey(CITY_SLUG) && item[CITY_SLUG] != null &&
              item[CITY_SLUG].isNotEmpty) {
            propertyCity = '${item[CITY]} ';
          }
          if (item.containsKey(PROPERTY_STATUS) &&
              item[PROPERTY_STATUS] != null &&
              item[PROPERTY_STATUS].isNotEmpty) {
            List<String> tempPropertyStatusList = List<String>.from(
                item[PROPERTY_STATUS]);
            List<String> tempList = [];
            for (var element in tempPropertyStatusList) {
              tempList.add(GenericMethods.getLocalizedString(element));
            }
            propertyStatus = tempList.join(", ");
            // propertyStatus = '${GenericMethods.getLocalizedString(item[PROPERTY_STATUS].toString())} ';
            // if(propertyStatus.contains("[")){
            //   propertyStatus = propertyStatus.replaceAll("[", '');
            // }
            // if(propertyStatus.contains("]")){
            //   propertyStatus = propertyStatus.replaceAll("]", '');
            // }
          }

          propertyTitle = propertyType.isNotEmpty ?
          propertyType : GenericMethods.getLocalizedString("latest_properties");
          // propertyType : GenericMethods.getLocalizedString("error_occurred")latest_properties}${propertyStatus.isNotEmpty ? " $propertyStatus" : ""}';

          return Container(
            height: 90,
            width: 225,
            padding: const EdgeInsets.only(bottom: 10, right: 10),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                    color: AppThemePreferences().appTheme.dividerColor),
                borderRadius: const BorderRadius.all(Radius.circular(10)),
              ),
              child: InkWell(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                onTap: () {
                  GenericMethods.navigateToSearchResultScreen(
                    context: context,
                    dataInitializationMap: item,
                    navigateToSearchResultScreenListener: (
                        {filterDataMap, recentSearchesDataMapList, loadProperties}) {
                      // recentSearchesListViewWidgetListener(
                      //   filterDataMap: filterDataMap,
                      //   recentSearchesDataMapList: recentSearchesDataMapList,
                      //   loadProperties: loadProperties,
                      // );
                    },
                  );
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      padding: const EdgeInsets.fromLTRB(10, 5, 10, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(
                            AppThemePreferences.searchIcon,
                            size: AppThemePreferences
                                .homeScreenRecentSearchIconSize,
                          ),
                          Container(
                            width: 170,
                            padding: const EdgeInsets.only(left: 5, right: 5),
                            child: genericTextWidget(
                              propertyTitle,
                              overflow: TextOverflow.ellipsis,
                              style: AppThemePreferences().appTheme
                                  .homeScreenRecentSearchTitleTextStyle,
                            ),
                          ),
                        ],
                      ),
                    ),

                    propertyStatus.isEmpty ? Container() : Container(
                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(
                            AppThemePreferences.checkCircleIcon,
                            size: AppThemePreferences
                                .homeScreenRecentCheckCircleIconSize,
                          ),
                          Container(
                            width: 170,
                            padding: const EdgeInsets.only(left: 5, right: 5),
                            child: genericTextWidget(
                              propertyStatus,
                              overflow: TextOverflow.ellipsis,
                              style: AppThemePreferences().appTheme
                                  .homeScreenRecentSearchCityTextStyle,
                            ),
                          ),
                        ],
                      ),
                    ),

                    propertyCity.isEmpty ? Container() : Container(
                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            size: AppThemePreferences
                                .homeScreenRecentSearchLocationIconSize,
                          ),
                          Container(
                            padding: const EdgeInsets.only(left: 5, right: 5),
                            child: genericTextWidget(
                              propertyCity,
                              style: AppThemePreferences().appTheme
                                  .homeScreenRecentSearchCityTextStyle,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        return Container();
      },
    ),
  );
}

