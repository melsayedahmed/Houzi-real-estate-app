import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/pages/filter_page.dart';

import '../../toast_widget.dart';

typedef HomeScreenSearchBarWidgetListener = void Function({
  Map<String, dynamic> filterDataMap,
  List<dynamic> recentSearchesDataMapList,
  bool loadProperties,
});

Widget homeScreenSearchBarWidget({
  @required BuildContext context,
  @required Map<String, dynamic> propertyMetaDataMap,
  final HomeScreenSearchBarWidgetListener homeScreenSearchBarWidgetListener,
}){
  return GestureDetector(
    onTap: () {
      if (propertyMetaDataMap == null) {
        _showToast(context, GenericMethods.getLocalizedString("data_loading"));
      } else {
        navigateToFilterScreen(
          context: context,
          navigateToFilterScreenListener: (
              {filterDataMap, recentSearchesDataMapList, loadProperties}) {
            homeScreenSearchBarWidgetListener(
              filterDataMap: filterDataMap,
              recentSearchesDataMapList: recentSearchesDataMapList,
              loadProperties: loadProperties,
            );
          },
        );
      }
    },
    child: SizedBox(
      height: 36.0,
      width: double.infinity,
      child: TextFormField(
        readOnly: true,
        strutStyle: const StrutStyle(forceStrutHeight: true),
        decoration: InputDecoration(
          border: InputBorder.none,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          enabled: false,
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(24.0),
            borderSide: BorderSide(color: AppThemePreferences().appTheme.searchBarBackgroundColor),
          ),
          // enabledBorder: OutlineInputBorder(
          //   borderRadius: BorderRadius.circular(24.0),
          //   borderSide: BorderSide(
          //       color: AppThemePreferences().appTheme.searchBarBackgroundColor,
          //       width: 0.0,
          //   ),
          // ),
          // border: OutlineInputBorder(
          //   borderRadius: BorderRadius.circular(24.0),
          //   borderSide: BorderSide(
          //       color: AppThemePreferences().appTheme.searchBarBackgroundColor,
          //       width: 0.0,
          //   ),
          // ),
          contentPadding: const EdgeInsets.only(top: 5, left: 15, right: 15),
          fillColor: AppThemePreferences().appTheme.searchBarBackgroundColor,
          filled: true,
          hintText: GenericMethods.getLocalizedString("search"),
          hintStyle: AppThemePreferences().appTheme.searchBarTextStyle,
          suffixIcon: Padding(
            padding: const EdgeInsets.only(right: 10, left: 10),
            child: AppThemePreferences().appTheme.homeScreenSearchBarIcon,
          ),
        ),
      ),
    ),
  );
}

_showToast(BuildContext context, String text) {
  toastWidget(
    buildContext: context,
    text: text,
  );
}

void navigateToFilterScreen({
  @required BuildContext context,
  final HomeScreenSearchBarWidgetListener navigateToFilterScreenListener,
}){
  WidgetBuilder builder = (context) => FilterPage(
    mapInitializeData: HiveStorageManager.readFilterDataInfo(),
    filterPageListener: (Map<String, dynamic> dataMap, String closeOption) {
      if (closeOption == DONE) {
        navigateToFilterScreenListener(
          filterDataMap: HiveStorageManager.readFilterDataInfo(),
          recentSearchesDataMapList: HiveStorageManager.readRecentSearchesInfo(),
          loadProperties: true,
        );
        Navigator.pop(context);

        GenericMethods.navigateToSearchResultScreen(
            context: context,
            dataInitializationMap: HiveStorageManager.readFilterDataInfo(),
            navigateToSearchResultScreenListener: ({filterDataMap, recentSearchesDataMapList, loadProperties}){
              navigateToFilterScreenListener(
                filterDataMap: filterDataMap,
                recentSearchesDataMapList: recentSearchesDataMapList,
                loadProperties: loadProperties,
              );
            }
        );
      } else if(closeOption == CLOSE){
        Navigator.pop(context);
      }else if(closeOption == UPDATE_DATA || closeOption == RESET){
        navigateToFilterScreenListener(
          filterDataMap: dataMap,
          loadProperties: true,
        );
      }else{
        navigateToFilterScreenListener(
          filterDataMap: dataMap,
          loadProperties: false,
        );
      }
    },
  );
  GenericMethods.navigateToRoute(context: context, builder: builder);
}