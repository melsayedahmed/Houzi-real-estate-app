import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/pages/filter_page.dart';
import 'package:houzi_package/widgets/toast_widget.dart';


typedef SearchBarWidgetListener = void Function(Map<String, dynamic> filterInfo);

class SearchBarWidget extends StatefulWidget{

  final Map<String, dynamic> propertyMetaDataMap;
  final SearchBarWidgetListener searchBarWidgetListener;
  BorderRadius borderRadius = BorderRadius.circular(24.0);

  SearchBarWidget({
    Key key,
    this.borderRadius,
    @required this.propertyMetaDataMap,
    this.searchBarWidgetListener,
  }) : super(key: key);
  
  
  @override
  State<StatefulWidget> createState() => SearchBarWidgetState();
}

class SearchBarWidgetState extends State<SearchBarWidget> {



  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (widget.propertyMetaDataMap == null) {
          toastWidget(
              buildContext: context,
              text: GenericMethods.getLocalizedString("data_loading"),
          );
        } else {
          navigateToFilterScreen(
            context: context,
            navigateToFilterScreenListener: (filterDataMap) {
              widget.searchBarWidgetListener(filterDataMap);
            },
          );
        }
      },
      child: SizedBox(
        height: 36.0,
        width: double.infinity,
        child: TextFormField(
          readOnly: true,
          strutStyle: const StrutStyle(forceStrutHeight: true),
          decoration: InputDecoration(
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
            errorBorder: InputBorder.none,
            enabled: false,
            disabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: AppThemePreferences().appTheme.searchBarBackgroundColor),
            ),
            contentPadding: const EdgeInsets.only(top: 5, left: 15, right: 15),
            fillColor: AppThemePreferences().appTheme.searchBarBackgroundColor,
            filled: true,
            hintText: GenericMethods.getLocalizedString("search"),
            hintStyle: AppThemePreferences().appTheme.searchBarTextStyle,
            suffixIcon: Padding(
              padding: const EdgeInsets.only(right: 10, left: 10),
              child: AppThemePreferences().appTheme.homeScreenSearchBarIcon,
            ),
            // enabledBorder: OutlineInputBorder(
            //   borderRadius: widget.borderRadius,
            //   borderSide: BorderSide(
            //     color: AppThemePreferences().appTheme.searchBarBackgroundColor,
            //     width: 1.0,
            //   ),
            // ),
            // border: OutlineInputBorder(
            //   borderRadius: widget.borderRadius,
            //   borderSide: BorderSide(
            //     color: AppThemePreferences().appTheme.searchBarBackgroundColor,
            //     width: 1.0,
            //   ),
            // ),
          ),
        ),
      ),
    );
  }

  void navigateToFilterScreen({
    @required BuildContext context,
    final SearchBarWidgetListener navigateToFilterScreenListener,
  }){
    WidgetBuilder builder = (context) => FilterPage(
      mapInitializeData: HiveStorageManager.readFilterDataInfo(),
      filterPageListener: (Map<String, dynamic> dataMap, String closeOption) {
        if (closeOption == DONE) {
          navigateToFilterScreenListener(HiveStorageManager.readFilterDataInfo());
          Navigator.pop(context);

          GenericMethods.navigateToSearchResultScreen(
              context: context,
              dataInitializationMap: HiveStorageManager.readFilterDataInfo(),
              navigateToSearchResultScreenListener: ({filterDataMap, recentSearchesDataMapList, loadProperties}){
                navigateToFilterScreenListener(filterDataMap);
              }
          );
        } else if(closeOption == CLOSE){
          Navigator.pop(context);
        }else if(closeOption == UPDATE_DATA || closeOption == RESET){
          navigateToFilterScreenListener(dataMap);
        }else{
          navigateToFilterScreenListener(dataMap);
        }
      },
    );
    GenericMethods.navigateToRoute(context: context, builder: builder);
  }
}