import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/drawer_menu_item.dart';
import 'package:houzi_package/pages/board_pages/activities_from_board.dart';
import 'package:houzi_package/pages/board_pages/deals_from_board.dart';
import 'package:houzi_package/pages/board_pages/inquiries_from_board.dart';
import 'package:houzi_package/pages/board_pages/leads_from_board.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/add_property.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/all_agency.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/all_agents.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/favorites.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/properties.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/quick_add_property.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/request_demo.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/saved_searches.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/settings_page.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_profile.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_signin.dart';
import 'package:houzi_package/pages/main_screen_pages/my_home_page.dart';

import '../../../pages/board_pages/add_property_request.dart';
import '../../../pages/home_screen_drawer_menu_pages/my_agency_agents.dart';
import '../../dialog_box_widget.dart';
import '../../generic_text_widget.dart';
import '../../shimmer_effect_error_widget.dart';

typedef HomeScreenDrawerWidgetListener = void Function(bool loginInfo);

class HomeScreenDrawerWidget extends StatefulWidget{
  
  final HomeScreenDrawerWidgetListener homeScreenDrawerWidgetListener;
  final Map<String, dynamic> drawerInfoData;
  final List<dynamic> drawerConfigDataList;

  const HomeScreenDrawerWidget({
    Key key,
    this.drawerConfigDataList,
    this.drawerInfoData,
    this.homeScreenDrawerWidgetListener,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => HomeScreenDrawerWidgetState();

}
typedef DrawerHook = List Function(BuildContext context);
class HomeScreenDrawerWidgetState extends State<HomeScreenDrawerWidget> {

  String _selectedHome = home0SectionType;
  DrawerHook drawerHook = GenericMethods.drawerItemsList;

  List<dynamic> drawerConfigDataList = [];

  @override
  void initState() {
    super.initState();
    _selectedHome = HiveStorageManager.readSelectedHomeOption() ?? home0SectionType;

    drawerConfigDataList = widget.drawerConfigDataList;

    List<dynamic> menuItemList = drawerHook(context) ?? [];
    int totalLength = drawerConfigDataList.length;
    for (var item in menuItemList) {
      int insertAt = item.insertAt;
      if(insertAt != null) {
        if(insertAt > totalLength) {
          drawerConfigDataList.add(item);
        } else {
          drawerConfigDataList.insert(insertAt, item);
        }
      } else {
        drawerConfigDataList.add(item);
      }
    }

    drawerConfigDataList = drawerConfigDataList.toSet().toList();

  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppThemePreferences().appTheme.backgroundColor,
      child: ListView(
        children: <Widget>[
          DrawerHeader(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    AppThemePreferences().appTheme.drawerImage,
                    Container(
                      margin: const EdgeInsets.only(top: 8.0),
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: genericTextWidget(
                        APP_NAME,
                        style: AppThemePreferences().appTheme.homeScreenDrawerTextStyle,
                      ),
                    ),
                  ],
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(5, 40, 5, 0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      widget.drawerInfoData[USER_PROFILE_NAME] == null || widget.drawerInfoData[USER_PROFILE_NAME].isEmpty
                      // _userName == null || _userName.isEmpty
                          ? Container()
                          : GestureDetector(
                        child: ClipRRect(
                          borderRadius: const BorderRadius.all(Radius.circular(10)),
                          child: FancyShimmerImage(
                            imageUrl: widget.drawerInfoData[USER_PROFILE_IMAGE],
                            boxFit: BoxFit.cover,
                            shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
                            shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
                            width: 40,
                            height: 40,
                            errorWidget: shimmerEffectErrorWidget(iconSize: 15),
                          ),
                        ),
                        onTap: () => onUserProfileTap(context),
                      ),
                      widget.drawerInfoData[USER_PROFILE_NAME] == null || widget.drawerInfoData[USER_PROFILE_NAME].isEmpty
                      // _userName == null || _userName.isEmpty
                          ? Container()
                          : Container(
                        margin: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: GestureDetector(
                          onTap: () => onUserProfileTap(context),
                          child: Padding(
                            padding: const EdgeInsets.only(top: 13.0),
                            child: genericTextWidget(
                              widget.drawerInfoData[USER_PROFILE_NAME],
                              style: AppThemePreferences().appTheme.homeScreenDrawerUserNameTextStyle,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            decoration: BoxDecoration(
              color: AppThemePreferences().appTheme.primaryColor,
            ),
          ),
          Column(
            children: drawerConfigDataList.map((map) {
              return drawerWidget(
                  context: context,
                  drawerInfoData: widget.drawerInfoData,
                  drawerConfigMapData: map,
                  homeScreenDrawerWidgetListener: widget.homeScreenDrawerWidgetListener,
              );
            }).toList(),
          )
        ],
      ),
    );
  }

  Widget drawerWidget({BuildContext context,drawerInfoData, drawerConfigMapData,homeScreenDrawerWidgetListener}){
    Map drawerConfigMap = {};
    bool isMenuDrawerHelper = false;
    DrawerItem menuDrawerHelper;
    if(drawerConfigMapData is DrawerItem){
      menuDrawerHelper = drawerConfigMapData;
      isMenuDrawerHelper = true;
    } else
      if(drawerConfigMapData is! Map) {
      drawerConfigMap = drawerConfigMapData.toJson();
    }else {
      drawerConfigMap = drawerConfigMapData;
    }

    List expansionTileChildren = [];

    if (drawerConfigMap[sectionTypeKey] == expansionTileSectionType) {
      expansionTileChildren = drawerConfigMap[expansionTileChildrenSectionType];
    }

    if(isMenuDrawerHelper) {
      return listTile(
        context: context,
        title: GenericMethods.getLocalizedString(menuDrawerHelper.title ?? ""),
        iconData: menuDrawerHelper.icon ?? AppThemePreferences.infoIcon,
        sectionType: menuDrawerHelper.sectionType ?? "",
        onTap: menuDrawerHelper.onTap,
        isUserLoggedIn: drawerInfoData[USER_LOGGED_IN],
        checkLogin: menuDrawerHelper.checkLogin ?? false,
      );
    }

    return drawerConfigMap[enableKey] ? Column(
      children: [
        if(drawerConfigMap[sectionTypeKey] != expansionTileSectionType)
          getListTile(context,drawerConfigMap,drawerInfoData,homeScreenDrawerWidgetListener)
        else if (drawerConfigMap[sectionTypeKey] == expansionTileSectionType && drawerInfoData[USER_ROLE] != USER_ROLE_HOUZEZ_BUYER_VALUE )
          ExpansionTile(
            maintainState: true,
            title: genericTextWidget(
              GenericMethods.getLocalizedString(drawerConfigMap[titleKey]),
              style: TextStyle(
                fontWeight: AppThemePreferences.drawerMenuTextFontWeight,
                fontSize: AppThemePreferences.drawerMenuTextFontSize,
                color: AppThemePreferences().appTheme.normalTextColor.withOpacity(0.8),
              ),
            ),
            leading: Padding(
              padding: const EdgeInsets.only(right: 10),
              child: Icon(
                AppThemePreferences.dashboardIcon,
                color: AppThemePreferences().appTheme.normalTextColor.withOpacity(0.8),
              ),
            ),
            children: expansionTileChildren.map((map) {
              return getListTile(context,map,drawerInfoData,homeScreenDrawerWidgetListener);
            }).toList(),
          )
        else
          Container(),
      ],
    ) : Container();

  }

  Widget getListTile(
      BuildContext context, map, drawerInfoData,
      HomeScreenDrawerWidgetListener homeScreenDrawerWidgetListener,
      ) {
    if (map[sectionTypeKey] == logoutSectionType && drawerInfoData[USER_LOGGED_IN]) {
      return listTile(
        context: context,
        title: GenericMethods.getLocalizedString(map[titleKey]),
        iconData: getSectionIcon(context, map[sectionTypeKey]),
        sectionType: map[sectionTypeKey],
        logOutConfirm: () {
          logOutConfirmation(
            context: context,
            onPositiveButtonPressed: () {
              Navigator.pop(context);
              homeScreenDrawerWidgetListener(false);
              GenericMethods.userLogOut(
                context: context,
                builder: (context) => const MyHomePage(),
              );
            },
          );
        },
      );
    } else if(checkConditionForHomeSections(map[sectionTypeKey])){
      return listTile(
        context: context,
        title: GenericMethods.getLocalizedString(map[titleKey]),
        iconData: getSectionIcon(context, map[sectionTypeKey]),
        sectionType: map[sectionTypeKey],
        builder: map["on_tap"] ?? getWidgetBuilder(context, map[sectionTypeKey]),
        isUserLoggedIn: drawerInfoData[USER_LOGGED_IN],
        checkLogin: map[checkLoginKey],
        onTap: ()=> onHomeSectionsTap(map[sectionTypeKey])
      );
    } else {
      if (map[sectionTypeKey] == loginSectionType && drawerInfoData[USER_LOGGED_IN]) {
        return Container();
      } else if (map[sectionTypeKey] != logoutSectionType) {
        if (drawerInfoData[USER_ROLE] == USER_ROLE_HOUZEZ_BUYER_VALUE) {
          if (checkConditionsForRoleBuyer(map[sectionTypeKey])) {
            return Container();
          }
        }
        if (map[sectionTypeKey] == addPropertySectionType || map[sectionTypeKey] == quickAddPropertySectionType) {
          if (!checkConditionsForAddProperties(map[sectionTypeKey])) {
            return Container();
          }
        }
        if (map[sectionTypeKey] == myAgentsSectionType && !drawerInfoData[USER_LOGGED_IN]) {
          return Container();
        }
        else if(map[sectionTypeKey] == myAgentsSectionType && drawerInfoData[USER_ROLE] != USER_ROLE_HOUZEZ_AGENCY_VALUE){
          return Container();
        }

        return listTile(
          context: context,
          title: GenericMethods.getLocalizedString(map[titleKey]),
          iconData: getSectionIcon(context, map[sectionTypeKey]),
          sectionType: map[sectionTypeKey],
          builder: map["on_tap"] ?? getWidgetBuilder(context, map[sectionTypeKey]),
          isUserLoggedIn: drawerInfoData[USER_LOGGED_IN],
          checkLogin: map[checkLoginKey],
        );
      }
    }
    return Container();
  }

  bool checkConditionsForRoleBuyer(String section) {
    if (section == addPropertySectionType ||
        section == quickAddPropertySectionType ||
        section == propertiesSectionType) {
      return true;
    } else {
      return false;
    }
  }

  bool checkConditionsForAddProperties(String section) {
    if (section == addPropertySectionType) {
      return true;
    } else if (section == quickAddPropertySectionType) {
      return true;
    }
    return false;
  }

  bool checkConditionForHomeSections(String sectionType){
    if(sectionType == homeSectionType || sectionType == home0SectionType ||
        sectionType == home01SectionType || sectionType == home02SectionType ||
        sectionType == home03SectionType){
      return true;
    }
    return false;
  }

  void onUserProfileTap(BuildContext context){
    GenericMethods.navigateToRoute(
      context: context,
      builder: (context) => (UserProfile(userProfilePageListener: (String closeOption)
      {if (closeOption == CLOSE) {Navigator.pop(context);}})),
    );
  }

  onHomeSectionsTap(String sectionType){
    setState(() {
      _selectedHome = sectionType;
      if(sectionType == homeSectionType || sectionType == home0SectionType){
        HOME_SCREEN_DESIGN = DESIGN_01;
      }else if(sectionType == home01SectionType){
        HOME_SCREEN_DESIGN = DESIGN_02;
      }else if(sectionType == home02SectionType){
        HOME_SCREEN_DESIGN = DESIGN_03;
      }else if(sectionType == home03SectionType){
        HOME_SCREEN_DESIGN = DESIGN_04;
      }else{
        // Default Home Screen Design
        HOME_SCREEN_DESIGN = DESIGN_01;
      }

      HiveStorageManager.storeSelectedHomeOption(_selectedHome);
      GeneralNotifier().publishChange(GeneralNotifier.HOME_DESIGN_MODIFIED);
    });
  }

  WidgetBuilder getWidgetBuilder(BuildContext context, String sectionType){
  if(sectionType == addPropertySectionType) return (context) => AddProperty();
  if(sectionType == quickAddPropertySectionType) return (context) => QuickAddProperty();
  if(sectionType == propertiesSectionType) return (context) => Properties();
  if(sectionType == agentsSectionType) return (context) => AllAgents();
  if(sectionType == agenciesSectionType) return (context) => AllAgency();
  if(sectionType == myAgentsSectionType) return (context) => const MyAgencyAgents();
  if(sectionType == requestPropertySectionType) return (context) => AddPropertyRequest();
  if(sectionType == favoritesSectionType) {
    return (context) => Favorites(
    showAppBar: true,
    favoritesPageListener: (String closeOption) {
      if (closeOption == CLOSE) {
        Navigator.pop(context);
      }
    },
  );
  }
  if(sectionType == savedSearchesSectionType) return (context) =>  SavedSearches(showAppBar: true);
  if(sectionType == activitiesSectionType) return (context) =>  ActivitiesFromBoard();
  if(sectionType == inquiriesSectionType) return (context) =>  InquiriesFromBoard();
  if(sectionType == dealsSectionType) return (context) =>  DealsFromBoard();
  if(sectionType == leadsSectionType) return (context) =>  LeadsFromBoard();
  if(sectionType == settingsSectionType) return (context) =>  HomePageSettings();
  if(sectionType == requestDemoSectionType) return (context) =>  ContactDeveloper();
  if (sectionType == loginSectionType) {
    return (context) =>   UserSignIn(
          (String closeOption) {
        if (closeOption == CLOSE) {
          Navigator.pop(context);
        }
      },
    );
  }


  return null;
}

  getSectionIcon(BuildContext context, sectionData){
    if(sectionData == homeSectionType) return AppThemePreferences.homeIcon;
    if(sectionData == home0SectionType) return AppThemePreferences.homeIcon;
    if(sectionData == home01SectionType) return AppThemePreferences.homeIcon;
    if(sectionData == home02SectionType) return AppThemePreferences.homeIcon;
    if(sectionData == home03SectionType) return AppThemePreferences.homeIcon;
    if(sectionData == addPropertySectionType) return AppThemePreferences.addPropertyIcon;
    if(sectionData == quickAddPropertySectionType) return AppThemePreferences.quickAddPropertyIcon;
    if(sectionData == propertiesSectionType) return AppThemePreferences.propertiesIcon;
    if(sectionData == agentsSectionType) return AppThemePreferences.agentsIcon;
    if(sectionData == agenciesSectionType) return AppThemePreferences.agencyIcon;
    if(sectionData == myAgentsSectionType) return AppThemePreferences.realEstateAgent;
    if(sectionData == requestPropertySectionType) return AppThemePreferences.requestPropertyIcon;
    if(sectionData == favoritesSectionType) return AppThemePreferences.favouriteBorderIcon;
    if(sectionData == savedSearchesSectionType) return AppThemePreferences.savedSearchesIcon;
    if(sectionData == activitiesSectionType) return AppThemePreferences.activitiesIcon;
    if(sectionData == inquiriesSectionType) return AppThemePreferences.inquiriesIcon;
    if(sectionData == dealsSectionType) return AppThemePreferences.dealsIcon;
    if(sectionData == leadsSectionType) return AppThemePreferences.leadsIcon;
    if(sectionData == settingsSectionType) return AppThemePreferences.settingsIcon;
    if(sectionData == requestDemoSectionType) return AppThemePreferences.requestDemoIcon;
    if(sectionData == loginSectionType) return AppThemePreferences.loginIcon;
    if(sectionData == logoutSectionType) return AppThemePreferences.logOutIcon;

    return AppThemePreferences.infoIcon;
  }

  Widget listTile({
    @required BuildContext context,
    String title,
    String sectionType,
    IconData iconData,
    WidgetBuilder builder,
    bool checkLogin = false,
    bool isUserLoggedIn = false,
    GestureTapCallback logOutConfirm,
    GestureTapCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 10.0),
      child: ListTile(
        // selected: sectionType == homeSectionType ? true : false,
        // selectedTileColor: sectionType == homeSectionType
        //     ? AppThemePreferences().appTheme.primaryColor.withOpacity(0.1)
        //     : null,

        // selected: title == _selectedDrawerOption ? true : false,
        // selectedTileColor: title == _selectedDrawerOption
        //     ? AppThemePreferences().appTheme.primaryColor.withOpacity(0.1)
        //     : null,
        selected: sectionType == _selectedHome || sectionType == homeSectionType ? true : false,
        selectedTileColor: sectionType == _selectedHome || sectionType == homeSectionType
            ? AppThemePreferences().appTheme.primaryColor.withOpacity(0.1)
            : null,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(30),
            bottomRight: Radius.circular(30),
          ),
        ),
        title: genericTextWidget(
          title,
          style: TextStyle(
              fontWeight: AppThemePreferences.drawerMenuTextFontWeight,
              fontSize: AppThemePreferences.drawerMenuTextFontSize,
              // color: title == _selectedDrawerOption
              //     ? AppThemePreferences().appTheme.primaryColor
              //     : AppThemePreferences().appTheme.normalTextColor),
              // color: sectionType == homeSectionType
              //     ? AppThemePreferences().appTheme.primaryColor
              //     : AppThemePreferences().appTheme.normalTextColor),
              color: sectionType == _selectedHome || sectionType == homeSectionType
                  ? AppThemePreferences().appTheme.primaryColor
                  : AppThemePreferences().appTheme.normalTextColor),
        ),
        leading: Icon(iconData,
            // color: title == _selectedDrawerOption
            //     ? AppThemePreferences().appTheme.primaryColor
            //     : AppThemePreferences().appTheme.normalTextColor),
            // color: sectionType == homeSectionType
            //     ? AppThemePreferences().appTheme.primaryColor
            //     : AppThemePreferences().appTheme.normalTextColor),
            color: sectionType == _selectedHome || sectionType == homeSectionType
                ? AppThemePreferences().appTheme.primaryColor
                : AppThemePreferences().appTheme.normalTextColor),

        onTap: logOutConfirm ?? onTap ?? () {
          // setState(() {
          //   _selectedDrawerOption = title;
          // });
          //Navigator.pop(context);
          if(builder != null){
            // if(sectionType != homeSectionType && builder != null){
            if (checkLogin) {
              if (isUserLoggedIn) {
                navigateToRoute(context, builder);
              } else {
                navigateToRoute(context, (context) => UserSignIn(
                      (String closeOption) {
                    if (closeOption == CLOSE) {
                      Navigator.pop(context);
                    }
                  },
                ));
              }
            }else{
              navigateToRoute(context, builder);
            }
          }
        },
      ),
    );
  }

  void navigateToRoute(BuildContext context, WidgetBuilder builder){
    GenericMethods.navigateToRoute(context: context, builder: builder);
  }

  Future logOutConfirmation({
    @required BuildContext context,
    @required Function() onPositiveButtonPressed,
  }) {
    return dialogBoxWidget(
      context,
      title: GenericMethods.getLocalizedString("log_out"),
      content: genericTextWidget(GenericMethods.getLocalizedString("are_you_sure_you_want_to_log_out")),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
        ),
        TextButton(
          onPressed: onPositiveButtonPressed,
          child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
        ),
      ],
    );
  }
}