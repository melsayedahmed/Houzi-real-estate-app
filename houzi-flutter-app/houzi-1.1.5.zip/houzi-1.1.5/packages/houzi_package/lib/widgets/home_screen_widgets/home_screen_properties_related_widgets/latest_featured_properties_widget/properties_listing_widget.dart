import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/item_design_files/item_design_notifier.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_page.dart';
import 'package:houzi_package/widgets/article_box_widgets/article_box_design.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';


class PropertiesListingGenericWidget extends StatefulWidget {

  final List<dynamic> propertiesList;
  final String design;
  final String listingView;

  PropertiesListingGenericWidget({
    Key key,
    @required this.propertiesList,
    this.design = DESIGN_01,
    this.listingView = homeScreenWidgetsListingCarouselView,
  }) : super(key: key);

  @override
  State<PropertiesListingGenericWidget> createState() => _PropertiesListingGenericWidgetState();
}

class _PropertiesListingGenericWidgetState extends State<PropertiesListingGenericWidget> {

  @override
  Widget build(BuildContext context) {
    return Consumer<ItemDesignNotifier>(
        builder: (context, itemDesignNotifier, child) {
      return widget.listingView == homeScreenWidgetsListingListView
          ? propertiesListViewWidget(
              context: context,
              propertiesList: widget.propertiesList,
              design: widget.design,
            )
          : propertiesCarouselViewWidget(
              context: context,
              propertiesList: widget.propertiesList,
              design: widget.design,
            );
    });
  }
}



// Widget propertiesCarouselListGenericWidget({
//   @required BuildContext context,
//   @required List<dynamic> propertiesList,
//   String design = DESIGN_01,
//   String listingView = homeScreenWidgetsListingCarouselView,
// }){
//   return Consumer<ItemDesignNotifier>(
//       builder: (context, itemDesignNotifier, child) {
//         return listingView == homeScreenWidgetsListingListView ?
//         propertiesListViewWidget(
//           context: context,
//           propertiesList: propertiesList,
//           design: design,
//         ) : propertiesCarouselViewWidget(
//           context: context,
//           propertiesList: propertiesList,
//           design: design,
//         );
//       });
// }

Widget propertiesCarouselViewWidget({
  @required BuildContext context,
  @required List<dynamic> propertiesList,
  String design = DESIGN_01,
}){
  ArticleBoxDesign _articleBoxDesign = ArticleBoxDesign();
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: <Widget>[
      SizedBox(
        height: _articleBoxDesign.getArticleBoxDesignHeight(design: design),
        child: PageView.builder(
          controller: PageController(viewportFraction: 0.9),
          itemCount: propertiesList.length,
          itemBuilder: (BuildContext context, int itemIndex) {
            var item = propertiesList[itemIndex];
            if(item is! Article){
              return null;
            }
            var heroId = item.id.toString() + CAROUSEL;
            return _articleBoxDesign.getArticleBoxDesign(
              article: item,
              heroId: heroId,
              buildContext: context,
              design: design,//itemDesignNotifier.homeScreenItemDesign,
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PropertyDetailsPage(
                      article: item,
                      propertyID: item.id,
                      heroId: heroId,
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    ],
  );
}

Widget propertiesListViewWidget({
  @required BuildContext context,
  @required List<dynamic> propertiesList,
  String design = DESIGN_01,
}){
  ArticleBoxDesign _articleBoxDesign = ArticleBoxDesign();
  return ListView.builder(
      scrollDirection: Axis.vertical,
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: propertiesList.length,
      itemBuilder: (context, index) {
        var item = propertiesList[index];
        if(item is Article) {
          var heroId = item.id.toString() + CAROUSEL;
          return Padding(
            padding: const EdgeInsets.only(left: 15.0, right: 15.0),
            child: _articleBoxDesign.getArticleBoxDesign(
              article: item,
              heroId: heroId,
              buildContext: context,
              design: design,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        PropertyDetailsPage(
                          article: item,
                          propertyID: item.id,
                          heroId: heroId,
                        ),
                  ),
                );
              },
            ),
          );
        }
        return Container();
      },
  );

  // return Padding(
  //   padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
  //   child: Column(
  //     // mainAxisSize: MainAxisSize.min,
  //     children: propertiesList.map((item) {
  //       var heroId = item.id.toString() + CAROUSEL;
  //       return _articleBoxDesign.getArticleBoxDesign(
  //         article: item,
  //         heroId: heroId,
  //         buildContext: context,
  //         design: design,//itemDesignNotifier.homeScreenItemDesign,
  //         onTap: (){
  //           Navigator.push(
  //             context,
  //             MaterialPageRoute(
  //               builder: (context) => PropertyDetailsPage(
  //                 article: item,
  //                 propertyID: item.id,
  //                 heroId: heroId,
  //               ),
  //             ),
  //           );
  //         },
  //       );
  //     }).toList(),
  //   ),
  // );
}

Widget propertiesSlidingCarouselListGenericWidget({
  @required BuildContext context,
  @required List<dynamic> propertiesList,
}){
  return Consumer<ItemDesignNotifier>(
      builder: (context, itemDesignNotifier, child) {
        ArticleBoxDesign _articleBoxDesign = ArticleBoxDesign();
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              //height: _articleBoxDesign.getArticleBoxDesignHeight(design: itemDesignNotifier.homeScreenItemDesign),
              child: CarouselSlider.builder(
                itemCount: propertiesList.length,
                options: CarouselOptions(
                  autoPlay: true,
                  height: _articleBoxDesign.getArticleBoxDesignHeight(design: itemDesignNotifier.homeScreenItemDesign),
                  viewportFraction: 0.9,
                  //aspectRatio: 16/7,
                  //enlargeCenterPage: true,
                  //enlargeStrategy: CenterPageEnlargeStrategy.height,
                ),
                itemBuilder: (BuildContext context, int itemIndex,int realIndex) {
                  var item = propertiesList[itemIndex];
                  var heroId = item.id.toString() + CAROUSEL;
                  return _articleBoxDesign.getArticleBoxDesign(
                    article: item,
                    heroId: heroId,
                    buildContext: context,
                    design: itemDesignNotifier.homeScreenItemDesign,
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PropertyDetailsPage(
                            article: item,
                            propertyID: item.id,
                            heroId: heroId,
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        );
      });
}

Widget genericLoadingWidgetForCarousalWithShimmerEffect(BuildContext context){
  return Container(
    padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
    child: SizedBox(
        height: 170,
        child: Shimmer.fromColors(
          baseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
          highlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
          child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (_, __) => Padding(
              padding: const EdgeInsets.only(bottom: 5.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  loadingWidgetGenericContainerWidget(width: 120.0, height: 135.0,
                    decoration: BoxDecoration(color: AppThemePreferences.shimmerLoadingWidgetContainerColor, borderRadius: BorderRadius.circular(10)),
                    // decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                  ),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 8.0)),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        loadingWidgetGenericContainerWidget(),
                        loadingWidgetGenericPaddingWidget(),
                        loadingWidgetGenericContainerWidget(),
                        loadingWidgetGenericPaddingWidget(),
                        loadingWidgetGenericContainerWidget(),
                        loadingWidgetGenericPaddingWidget(),
                        loadingWidgetGenericContainerWidget(),
                      ],
                    ),
                  )
                ],
              ),
            ),
            itemCount: 1,
          ),
        )),
  );
}

Widget loadingWidgetGenericPaddingWidget(){
  return const Padding(padding: EdgeInsets.symmetric(vertical: 10.0));
}

Widget loadingWidgetGenericContainerWidget({
  double width = double.infinity,
  double height = 18.0,
  Decoration decoration = const BoxDecoration(color: Colors.white),
  // Decoration decoration = const BoxDecoration(color: AppThemePreferences.shimmerLoadingWidgetContainerColor),
}){
  return Container(width: width, height: height, decoration: decoration);
}