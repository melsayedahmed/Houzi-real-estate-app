import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../files/generic_methods/generic_methods.dart';
import 'button_widget.dart';
import 'generic_text_widget.dart';

Widget noInternetConnectionErrorWidget(BuildContext context, Function() onPressed, {double topPadding = 50.0}){
  return SafeArea(
    child: SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: Container(
        padding: const EdgeInsets.only(top: 50),
        color: AppThemePreferences().appTheme.backgroundColor,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(
                AppThemePreferences.noInternetIcon,
                size: AppThemePreferences.genericErrorWidgetIconSize,
                color: AppThemePreferences().appTheme.primaryColor,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: genericTextWidget(
                  GenericMethods.getLocalizedString("no_internet_connection_error_message_01"),
                  style: AppThemePreferences().appTheme.label02TextStyle,
                  textAlign: TextAlign.center,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0, left: 50.0, right: 50.0),
                child: genericTextWidget(
                  GenericMethods.getLocalizedString("no_internet_connection_body_error_message"),
                  style: AppThemePreferences().appTheme.bodyTextStyle,
                  textAlign: TextAlign.center,
                ),
              ),
              Padding(
                padding:
                const EdgeInsets.only(top: 20.0, left: 20.0, right: 20.0),
                child: buttonWidget(
                    text: GenericMethods.getLocalizedString("retry"),
                    onPressed: onPressed,
                    ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}