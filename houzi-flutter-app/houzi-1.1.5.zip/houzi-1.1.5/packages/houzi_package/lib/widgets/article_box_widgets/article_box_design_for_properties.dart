import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';

import '../button_widget.dart';
import '../generic_text_widget.dart';

typedef PropertiesArticleBoxDesignWidgetListener = void Function(Map<String, dynamic> actionButtonMap);

Widget propertiesArticleBoxDesign({
  @required BuildContext context,
  @required Article item,
  @required Map<String, dynamic> actionButtonMap,
  @required Function() onTap,
  final PropertiesArticleBoxDesignWidgetListener propertiesArticleBoxDesignWidgetListener}) {

  String _imageUrl = item.imageList[0];
  String _status = item.status;
  String _title = GenericMethods.stripHtmlIfNeeded(item.title);
  String heroId = item.id.toString() + RELATED;

  return InkWell(
    borderRadius: const BorderRadius.all(Radius.circular(10)),
    onTap: onTap,
    child: Container(
      height: 270,
      padding: const EdgeInsets.only(bottom: 7,left: 5,right: 5,top: 3),
      child: Card(
        shape: AppThemePreferences.roundedCorners(AppThemePreferences.articleDesignRoundedCornersRadius),
        elevation: AppThemePreferences.articleDeignsElevation,
        child: Stack(
          children: <Widget>[
            imageWidget(context: context, heroId: heroId, imageUrl: _imageUrl),
            propertyStatusWidget(_status),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  titleAndActionButtonWidget(context: context, title: _title, actionButtonMap: actionButtonMap, articleBox09WidgetListener: propertiesArticleBoxDesignWidgetListener),
                  Container(
                    padding: const EdgeInsets.fromLTRB(10, 10, 10, 15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        propertyFeaturesWidget(item: item, padding: const EdgeInsets.fromLTRB(0, 0, 0, 0)),
                        priceWidget(item: item),
                      ],
                    ),
                  ),

                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget imageWidget({
  @required BuildContext context,
  @required String heroId,
  @required String imageUrl,
}) {
  bool _validURL = GenericMethods.validateURL(imageUrl);

  return SizedBox(
    height: 165,
    width: MediaQuery.of(context).size.width,
    child: Hero(
      tag: heroId,
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(10),
          topRight: Radius.circular(10),
        ),
        child: !_validURL ? errorWidget() : FancyShimmerImage(
          imageUrl: imageUrl,
          boxFit: BoxFit.cover,
          shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
          shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
          errorWidget: errorWidget(),
        ),
      ),
    ),
  );
}

Widget titleWidget({
  @required String title
}){
  return genericTextWidget(
    title,
    maxLines: 2,
    overflow: TextOverflow.ellipsis,
    style: AppThemePreferences().appTheme.titleTextStyle,
  );
}

Widget priceWidget({
  @required Article item,
}){
  String _propertyPrice = "";
  String _firstPrice = "";
  if(item.propertyDetailsMap.containsKey(PRICE)){
    String tempPrice = item.propertyDetailsMap[PRICE];
    if(tempPrice != null && tempPrice.isNotEmpty){
      _propertyPrice = GenericMethods.makePriceCompact(tempPrice);
    }
  }
  if(item.propertyDetailsMap.containsKey(FIRST_PRICE)){
    String tempPrice = item.propertyDetailsMap[FIRST_PRICE];
    if(tempPrice != null && tempPrice.isNotEmpty){
      _firstPrice = GenericMethods.makePriceCompact(tempPrice);
    }
  }

  return genericTextWidget(
    _firstPrice != null && _firstPrice.isNotEmpty ? _firstPrice : _propertyPrice,
    style: AppThemePreferences().appTheme.articleBoxPropertyPriceTextStyle,
  );
}


Widget titleAndActionButtonWidget({
  @required BuildContext context,
  @required String title,
  @required Map<String, dynamic> actionButtonMap,
  PropertiesArticleBoxDesignWidgetListener articleBox09WidgetListener,
}) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          flex: 3,
          child: titleWidget(title: title),
        ),
        Expanded(
          flex: 2,
          child: buttonWidget(
              buttonHeight: 40,
              centeredContent: true,
              iconOnRightSide: true,
              icon: Icon(
                AppThemePreferences.arrowDropDownIcon,
                color: AppThemePreferences.filledButtonIconColor,
              ),
              text: GenericMethods.getLocalizedString("action"),
              onPressed: () => articleBox09WidgetListener(actionButtonMap)),
        ),
      ],
    ),
  );
}

Widget propertyStatusWidget(String status) {
  return Positioned(
    top: 10,
    right: 15,
    child: status == null || status.isEmpty ? Container() : Container(
      padding: const EdgeInsets.all(5),
      alignment: Alignment.topRight,
      child: genericTextWidget(
        GenericMethods.getLocalizedString(status).toUpperCase(),
        style: AppThemePreferences().appTheme.tagTextStyle,
      ),
      decoration: BoxDecoration(
        color: AppThemePreferences.propertyStatusTagBackgroundColorDark,
        borderRadius: const BorderRadius.all(Radius.circular(4)),
      ),
    ),
  );
}

Widget propertyFeaturesWidget({
  @required Article item,
  EdgeInsetsGeometry padding = const EdgeInsets.fromLTRB(5, 5, 5, 0),
}){

  String _area = item.features.landArea;
  String _areaPostFix = item.features.landAreaUnit;
  String _bedRooms = item.features.bedrooms;
  String _bathRooms = item.features.bathrooms;

  return Container(
    padding: padding,
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _bedRooms == null || _bedRooms.isEmpty ? Container() :  Row(
          children: <Widget>[
            AppThemePreferences().appTheme.articleBoxBedIcon,
            Padding(
              padding: const EdgeInsets.only(left: 5, right: 5),
              child: genericTextWidget(
                _bedRooms,
                style: AppThemePreferences().appTheme.subBodyTextStyle,
              ),
            ),
          ],
        ),
        _bathRooms == null || _bathRooms.isEmpty ? Container() : Padding(
          padding: const EdgeInsets.only(left: 15),
          child: Row(
            children: <Widget>[
              AppThemePreferences().appTheme.articleBoxBathtubIcon,
              Padding(
                padding: const EdgeInsets.only(left: 4, right: 8),
                child: genericTextWidget(
                  _bathRooms,
                  style: AppThemePreferences().appTheme.subBodyTextStyle,
                ),
              ),
            ],
          ),
        ),
        _area == null || _area.isEmpty ? Container() : Row(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 5.0),
              child: AppThemePreferences().appTheme.articleBoxAreaSizeIcon,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 4, right: 5),
              child: genericTextWidget(
                "$_area $_areaPostFix",
                style: AppThemePreferences().appTheme.subBodyTextStyle,
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

Widget errorWidget(){
  return Container(
    color: AppThemePreferences().appTheme.shimmerEffectErrorWidgetBackgroundColor,
    child: Center(child: AppThemePreferences().appTheme.shimmerEffectImageErrorIcon),
  );
}