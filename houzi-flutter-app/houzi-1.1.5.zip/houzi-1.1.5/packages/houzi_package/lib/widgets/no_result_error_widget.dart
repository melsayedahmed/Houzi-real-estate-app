import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';

import '../files/generic_methods/generic_methods.dart';
import 'button_widget.dart';
import 'generic_text_widget.dart';

Widget noResultErrorWidget(
    BuildContext context, {
      String headerErrorText,
      String bodyErrorText,
      String buttonText,
      bool showBackNavigationIcon = false,
      bool hideGoBackButton = false,
      Function() onPressed,
      Function() onButtonPressed,
      Color backgroundColor,
    }) {
  return SafeArea(
    child: Stack(
      children: [
        Container(
          color: backgroundColor ?? AppThemePreferences().appTheme.backgroundColor,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  AppThemePreferences.errorIcon,
                  size: AppThemePreferences.genericErrorWidgetIconSize,
                  color: AppThemePreferences().appTheme.selectedItemBackgroundColor,
                  // color: AppThemePreferences().appTheme.primaryColor,
                ),
                headerErrorText != null && headerErrorText.isNotEmpty
                    ? Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: genericTextWidget(
                    headerErrorText,
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.label02TextStyle,
                    textAlign: TextAlign.center,
                  ),
                )
                    : Container(),
                bodyErrorText != null && bodyErrorText.isNotEmpty
                    ? Padding(
                  padding: const EdgeInsets.only(top: 20.0, left: 20.0, right: 20.0),
                  child: genericTextWidget(
                    bodyErrorText,
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.bodyTextStyle,
                    textAlign: TextAlign.center,
                  ),
                )
                    : Container(),
                !hideGoBackButton
                    ? Padding(
                  padding: const EdgeInsets.only(top: 30.0, left: 20.0, right: 20.0),
                  child: buttonWidget(
                    text: buttonText != null && buttonText.isNotEmpty ? buttonText : GenericMethods.getLocalizedString("go_back"),
                    // onPressed: (){
                    //   print("Func Called...");
                    // }
                    onPressed: onButtonPressed != null ? ()=> onButtonPressed() : onPressed != null ? ()=> onPressed() : () => onBackPressed(context),
                    // onPressed == null && onButtonPressed == null ? ()=> onBackPressed(context) :
                    //     onButtonPressed != null ? onButtonPressed : onPressed,
                    // onPressed: onPressed != null
                    //     ? onPressed
                    //     : () {
                    //         onBackPressed(context);
                    //       },
                  ),
                ) : Container(),
              ],
            ),
          ),
        ),
        showBackNavigationIcon
            ? Positioned(
          top: MediaQuery.of(context).padding.top,
          child: Padding(
            padding: const EdgeInsets.only(left: 20),
            child: CircleAvatar(
              backgroundColor: AppThemePreferences()
                  .appTheme
                  .propertyDetailsPageTopBarIconsBackgroundColor,
              child: IconButton(
                icon: Icon(AppThemePreferences.arrowBackIcon),
                color: AppThemePreferences()
                    .appTheme
                    .propertyDetailsPageTopBarIconsColor,
                onPressed: onPressed ?? () {
                  onBackPressed(context);
                },
              ),
            ),
          ),
        )
            : Container(),
      ],
    ),
  );
}

void onBackPressed(BuildContext context) {
  Navigator.of(context).pop();
}
