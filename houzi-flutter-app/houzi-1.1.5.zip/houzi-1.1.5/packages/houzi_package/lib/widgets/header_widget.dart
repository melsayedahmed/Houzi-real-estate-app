import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';

import 'generic_text_widget.dart';

Widget headerWidget({
  String text,
  EdgeInsetsGeometry padding = const EdgeInsets.all(0.0),
  AlignmentGeometry alignment,
  Decoration decoration,
}){
  return Container(
    padding: padding,
    alignment: alignment,
    decoration: decoration,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Expanded(
          child: genericTextWidget(
            text,
            strutStyle: StrutStyle(height: 1.5),
            style: AppThemePreferences().appTheme.headingTextStyle,
          ),
        ),
      ],
    ),
  );
}

Widget propertyDetailPageHeaderWidget({
  String text,
  EdgeInsetsGeometry padding = const EdgeInsets.all(0.0),
  AlignmentGeometry alignment,
  Decoration decoration,
  TextStyle textStyle,
}){
  return Container(
    padding: padding,
    alignment: alignment,
    decoration: decoration,
    child: genericTextWidget(
      text,
      strutStyle: StrutStyle(height: 1.5),
      style: textStyle ?? AppThemePreferences().appTheme.headingTextStyle,
    ),
  );
}

Widget home02HeaderWidget({
  String text,
  EdgeInsetsGeometry padding = const EdgeInsets.all(0.0),
  AlignmentGeometry alignment,
  Decoration decoration,
  TextStyle textStyle,
}){
  return Container(
    padding: padding,
    alignment: alignment,
    decoration: decoration,
    child: genericTextWidget(
      text,
      strutStyle: const StrutStyle(height: 1.5),
      style: textStyle ?? AppThemePreferences().appTheme.titleTextStyle,
    ),
  );
}