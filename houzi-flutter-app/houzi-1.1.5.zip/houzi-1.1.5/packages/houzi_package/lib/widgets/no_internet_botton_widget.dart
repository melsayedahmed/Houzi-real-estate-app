import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../files/generic_methods/generic_methods.dart';
import 'generic_text_widget.dart';

Widget noInternetBottomActionBar(BuildContext context, Function() onPressed, {bool showRetryButton = true}){
  return showRetryButton ? Container(
    height: 55.0,
    width: MediaQuery.of(context).size.width,
    color: AppThemePreferences.noInternetBottomActionBarBackgroundColor,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            flex: 7,
            child: genericTextWidget(
              GenericMethods.getLocalizedString("no_internet_connection_error_message_02"),
              style: AppThemePreferences().appTheme.toastTextTextStyle,
            ),
          ),
          Expanded(
            flex: 3,
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                child: genericTextWidget(
                    GenericMethods.getLocalizedString("retry"),
                    textAlign: TextAlign.center,
                    style: AppThemePreferences().appTheme.toastTextTextStyle,
                ),
                onPressed: onPressed,
                style: ElevatedButton.styleFrom(
                  elevation: 0.0,
                  primary: AppThemePreferences.noInternetBottomActionBarBackgroundColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24.0),
                    side: BorderSide(width: 2, color: Colors.white.withOpacity(0.4)),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  ) :
  Container(
    height: 55.0,
    width: MediaQuery.of(context).size.width,
    color: AppThemePreferences.noInternetBottomActionBarBackgroundColor,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            child: genericTextWidget(
              GenericMethods.getLocalizedString("no_internet_connection_error_message_02"),
              style: AppThemePreferences().appTheme.toastTextTextStyle,
            ),
          ),
        ],
      ),
    ),
  );
}