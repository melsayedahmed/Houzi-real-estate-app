import 'package:flutter/material.dart';

Widget genericTextWidget(
  String text,
{
  StrutStyle strutStyle = const StrutStyle(height: 1.2, forceStrutHeight: true),
  TextStyle style,
  TextAlign textAlign,
  TextDirection textDirection,
  Locale locale,
  bool softWrap,
  TextOverflow overflow,
  double textScaleFactor,
  int maxLines,
  String semanticsLabel,
  TextWidthBasis textWidthBasis,
  TextHeightBehavior textHeightBehavior,
}){
  return Text(
    text,
    strutStyle: strutStyle,
    style: style,
    textAlign: textAlign,
    textDirection: textDirection,
    locale: locale,
    softWrap: softWrap,
    overflow: overflow,
    textScaleFactor: textScaleFactor,
    maxLines: maxLines,
    semanticsLabel: semanticsLabel,
    textWidthBasis: textWidthBasis,
    textHeightBehavior: textHeightBehavior,
  );
}