import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';

import 'generic_text_widget.dart';

Widget genericWidgetRow({
  @required IconData iconData,
  @required String text,
  @required void Function() onTap,
  EdgeInsetsGeometry padding = const EdgeInsets.only(top: 20.0, bottom: 10.0),
  bool removeDecoration = false,
}){
  return Container(
    padding: padding,
    child: InkWell(
      child: Row(
        children: [
          Icon(
            iconData,
            color: AppThemePreferences().appTheme.iconsColor,
            size: AppThemePreferences.settingsIconSize,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20),
            child: genericTextWidget(
              text,
              style: AppThemePreferences().appTheme.settingOptionsTextStyle,
            ),
          ),
        ],
      ),
      onTap: onTap,
    ),
    decoration: removeDecoration ? null : AppThemePreferences.dividerDecoration(),
  );
}

Widget genericSettingsWidget({
  @required String headingText,
  String headingSubTitleText,
  @required Widget body,
  bool removeDecoration = false,
  bool enableTopDecoration = false,
  bool enableBottomDecoration = true,
}){
  return Container(
    decoration: removeDecoration ? null : AppThemePreferences.dividerDecoration(
      bottom: enableBottomDecoration,
      top: enableTopDecoration,
    ),
    // decoration: removeDecoration ? null : AppThemePreferences.dividerDecoration(),
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        headingWidget(text: headingText),
        headingSubTitleText == null || headingSubTitleText.isEmpty ?  Container(): headingSubTitleWidget(text: headingSubTitleText),
        body,
      ],
    ),
  );
}

Widget headingWidget({String text}){
  return genericTextWidget(
    text,
    style: AppThemePreferences().appTheme.settingHeadingTextStyle,
    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  );
}

Widget headingSubTitleWidget({String text}){
  return Container(
    padding: const EdgeInsets.only(top: 3),
    child: genericTextWidget(
      text,
      style: AppThemePreferences().appTheme.settingHeadingSubTitleTextStyle,
      strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
    ),
  );
}