import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/review_related_widgets/add_review_page.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/review_related_widgets/single_review_row.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../files/generic_methods/generic_methods.dart';
import '../app_bar_widget.dart';
import '../no_internet_error_widget.dart';
import '../no_result_error_widget.dart';

class AllReviews extends StatefulWidget {
  final id;
  final fromProperty;
  final reviewPostType;
  final permaLink;
  final listingTitle;

  AllReviews({
    this.id,
    this.fromProperty,
    this.reviewPostType,
    this.permaLink = "",
    this.listingTitle,
  });

  @override
  _AllReviewsState createState() => _AllReviewsState();
}

class _AllReviewsState extends State<AllReviews> {
  final PropertyBloc _propertyBloc = PropertyBloc();
  final RefreshController _refreshController = RefreshController(initialRefresh: false);

  Future<List<dynamic>> _futureFetchReviews;
  List<dynamic> articleReviewsList = [];

  int page = 1;
  int perPage = 10;
  bool isInternetConnected = true;
  bool isRefreshing = false;
  bool shouldLoadMore = true;
  bool isLoading = false;
  @override
  void initState() {
    super.initState();
    loadDataFromApi();
  }

  loadDataFromApi({bool forPullToRefresh = true}) {
    // if (forPullToRefresh) {
    //   if (isLoading) {
    //     return;
    //   }
    // } else {
    //   if (!shouldLoadMore || isLoading) {
    //     _refreshController.loadComplete();
    //     return;
    //   }
    // }
    //
    // setState(() {
    //   if (forPullToRefresh) {
    //     //isRefreshing = true;
    //     page = 1;
    //   } else {
    //     //isRefreshing = false;
    //     page++;
    //   }
    //   isLoading = true;
    // });
    //
    // _futureInquiriesFromBoard = fetchInquiriesFromBoard(page, userId);
    // if (forPullToRefresh) {
    //   _refreshController.refreshCompleted();
    // } else {
    //   _refreshController.loadComplete();
    // }

    if (forPullToRefresh) {
      if (isLoading) {
        return;
      }
      setState(() {
        isRefreshing = true;
        isLoading = true;
      });

      page = 1;
      if (widget.fromProperty) {
        _futureFetchReviews = fetchPropertyReviews(widget.id, page, perPage);
      } else {
        _futureFetchReviews = fetchReviews(widget.id, page, perPage, widget.reviewPostType);
      }
      _refreshController.refreshCompleted();
    } else {
      if (!shouldLoadMore || isLoading) {
        _refreshController.loadComplete();
        return;
      }
      setState(() {
        isRefreshing = false;
        isLoading = true;
      });
      page++;
      if (widget.fromProperty) {
        _futureFetchReviews = fetchPropertyReviews(widget.id, page, perPage);
      } else {
        _futureFetchReviews = fetchReviews(widget.id, page, perPage, widget.reviewPostType);
      }
      _refreshController.loadComplete();

    }
  }

  Future<List<dynamic>> fetchPropertyReviews(int propertyId, int page, int perPage) async {
    if (page == 1) {
      setState(() {
        shouldLoadMore = true;
      });
    }
    List<dynamic> tempList = await _propertyBloc.fetchArticlesReviews(propertyId, page.toString(), perPage.toString());

    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          shouldLoadMore = false;
        });
      }
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }

      if (page == 1) {
        articleReviewsList.clear();
      }
      if (tempList != null && tempList.isNotEmpty) {
        articleReviewsList.addAll(tempList);
      }
      if(tempList.isEmpty || tempList.length < perPage){
      // if(tempList == null || tempList.isEmpty || tempList.length < perPage){
        if (mounted) {
          setState(() {
            shouldLoadMore = false;
          });
        }
      }
    }
    return articleReviewsList;
  }

  Future<List<dynamic>> fetchReviews(int propertyId, int page, int perPage, String type) async {
    if (page == 1) {
      setState(() {
        shouldLoadMore = true;
      });
    }
    List<dynamic> tempList = await _propertyBloc.fetchAgentAgencyAuthorReviews(propertyId, page.toString(), perPage.toString(), type);

    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          shouldLoadMore = false;
        });
      }
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }

      if (page == 1) {
        articleReviewsList.clear();
      }
      if (tempList != null && tempList.isNotEmpty) {
        articleReviewsList.addAll(tempList);
      }
      if(tempList.isEmpty || tempList.length < perPage){
        setState(() {
          shouldLoadMore = false;
        });
      }
    }
    return articleReviewsList;
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: isInternetConnected == false ? appBarWidget(
        context,
        appBarTitle: GenericMethods.getLocalizedString("reviews"),
      ) : widgetAppBar(),
      body: isInternetConnected == false ? Align(
        alignment: Alignment.topCenter,
        child: noInternetConnectionErrorWidget(context, (){
          loadDataFromApi();
        }),
      ) : articleReviews(context,_futureFetchReviews),
    );
  }

  Widget widgetAppBar(){
    return appBarWidget(
      context,
      appBarTitle: GenericMethods.getLocalizedString("reviews"),
      actions: <Widget>[
        Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
            icon: Icon(
              AppThemePreferences.addIcon,
              color: AppThemePreferences.backgroundColorLight,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddReview(
                    reviewPostType: widget.reviewPostType,
                    permaLink: widget.permaLink,
                    listingTitle: widget.listingTitle,
                    listingId: widget.id,
                  ),
                ),
              );
            },
          ),
        )
      ],
    );
  }

  Widget articleReviews(BuildContext context, Future<List<dynamic>> futureFetchReviews) {
    return FutureBuilder<List<dynamic>>(
      future: futureFetchReviews,
      builder: (context, articleSnapshot) {
        isLoading = false;
        if (articleSnapshot.hasData) {
          if (articleSnapshot.data.isEmpty) {
            return noResultFoundPage();
          }

          List<dynamic> list = articleSnapshot.data;

          return SmartRefresher(
            enablePullDown: true,
            enablePullUp: true,
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus mode) {
                Widget body;
                if (mode == LoadStatus.loading) {
                  if (shouldLoadMore) {
                    body = paginationLoadingWidget();
                  } else {
                    body = Container();
                  }
                }
                return SizedBox(
                  height: 55.0,
                  child: Center(child: body),
                );
              },
            ),
            header: const MaterialClassicHeader(),
            controller: _refreshController,
            onRefresh: loadDataFromApi,
            onLoading: () => loadDataFromApi(forPullToRefresh: false),
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                var review = list[index];
                return SingleReviewRow(review,true);
              },
            ),
          );
        } else if (articleSnapshot.hasError) {
          return noResultFoundPage();
        }
        return loadingIndicatorWidget();
      },
    );
  }
  

  Widget loadingIndicatorWidget() {
    return Container(
      height: (MediaQuery.of(context).size.height) / 2,
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  Widget starsWidget(String totalRating) {
    return totalRating == null || totalRating.isEmpty || totalRating == 'null'? Container() : Padding(
      padding: const EdgeInsets.only(left: 5, right: 5),
      child: RatingBar.builder(
        initialRating: double.parse(totalRating),
        minRating: 1,
        itemSize: 20,
        direction: Axis.horizontal,
        allowHalfRating: true,
        ignoreGestures: true,
        itemCount: 5,
        itemPadding: const EdgeInsets.symmetric(horizontal: 1.0),
        itemBuilder: (context, _) => Icon(
          Icons.star,
          color: AppThemePreferences.ratingWidgetStarsColor,
        ),
        onRatingUpdate: (rating) {},
      ),
    );
  }

  Widget paginationLoadingWidget() {
    return Container(
      color: Theme.of(context).backgroundColor,
      alignment: Alignment.center,
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 50,
            child: loadingBallRotatingWidget(),
          ),
        ],
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
      bodyErrorText: GenericMethods.getLocalizedString("oops_inquiries_not_exist"),
    );
  }

}
