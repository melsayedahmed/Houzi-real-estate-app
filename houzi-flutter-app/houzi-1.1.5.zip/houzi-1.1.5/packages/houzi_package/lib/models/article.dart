import 'realtor_model.dart';

class Address {
  String suburb;
  String subNumber;
  String street;
  String streetNumber;
  String state;
  String postalCode;
  String display;
  String country;
  String coordinates;
  // Newly Added Item/Items for Houzez
  String area;
  String city;
  String address;
  String lat;
  String long;

  Address({
      this.suburb,
      this.subNumber,
      this.street,
      this.streetNumber,
      this.state,
      this.postalCode,
      this.country,
      this.display,
      this.coordinates,
    // Newly Added Item/Items for Houzez
      this.city,
      this.area,
      this.address,
      this.lat,
      this.long,

  });

}

class Features {
  String airConditioning;
  String bathrooms;
  String bedrooms;
  String buildingArea;
  String buildingAreaUnit;
  String carport;
  String energyRating;
  String ensuite;
  String garage;
  String landArea;
  String landAreaUnit;
  String landFullyFenced;
  String newConstruction;
  String openSpaces;
  String pool;
  String rooms;
  String securitySystem;
  String toilet;
  String yearBuilt;
  // Newly Added Item/Items for Houzez
  List<String> featuresList = [];
  List<String> imagesIdList = [];
  String garageSize;
  List<dynamic> floorPlansList;
  List<dynamic> additionalDetailsList = [];
  List<dynamic> multiUnitsList;
  String multiUnitsListingIDs;

  Features({
      this.bedrooms,
      this.bathrooms,
      this.toilet,
      this.ensuite,
      this.garage,
      this.carport,
      this.openSpaces,
      this.rooms,
      this.landArea,
      this.landAreaUnit,
      this.buildingArea,
      this.buildingAreaUnit,
      this.landFullyFenced,
      this.energyRating,
      this.yearBuilt,
      this.newConstruction,
      this.pool,
      this.airConditioning,
      this.securitySystem,

    // Newly Added Item/Items for Houzez
      this.featuresList,
      this.garageSize,
      this.floorPlansList,
      this.imagesIdList,
      this.additionalDetailsList,
      this.multiUnitsList,
      this.multiUnitsListingIDs,
  });

}

class PropertyInfo {
  // static const String LISTING_SALE = "SALE";
  // static const String LISTING_RENT = "RENT";
  // static const String LISTING_LEASE = "LEASE";
  // String listingType = LISTING_SALE;


  String heading;
  String category;
  String uniqueId;
  String modDate;
  String listDate;
  String imagesModDate;
  String floorplanModDate;
  String owner;
  String officeId;
  String agentHideAuthorBox;
  String addressHideMap;
  String price;
  String priceView;
  String priceGlobal;
  String priceDisplay;
  String priceCurrency;
  String currency;
  String status;
  String inspectionTimes;
  String auction;
  String authority;
  String soldPrice;
  String soldDate;
  String soldPriceDisplay;
  String underOffer;
  String isHomeLandPackage;
  String featured;
  String agent;
  String secondAgent;

  // Newly Added Item/Items for Rent Property
  String rent;
  String rentDisplay;


  // Newly Added Item/Items for Houzez
  String propertyType;
  String propertyStatus;
  String propertyLabel;
  String pricePostfix;
  String firstPrice;
  String secondPrice;
  String propertyVirtualTourLink;
  String agentDisplayOption;
  Map<String, dynamic> agentInfo;
  List<String> agentList;
  List<String> agencyList;
  bool isFeatured;
  String houzezTotalRating = "";

  String availability;
  String subCity;
  String placeName;
  String cartaTitleDeed;
  String woreda = "";
  List<dynamic> securityFeatureList;
  Map<String, String>  customFieldsMap = {};
  Map<String, dynamic>  customFieldsMapForEditing = {};


  PropertyInfo({
    this.heading,
    this.category,
    this.uniqueId,
    this.modDate,
    this.listDate,
    this.imagesModDate,
    this.floorplanModDate,
    this.owner,
    this.officeId,
    this.agentHideAuthorBox,
    this.addressHideMap,
    this.price,
    this.priceView,
    this.priceGlobal,
    this.priceDisplay,
    this.priceCurrency,
    this.status,
    this.inspectionTimes,
    this.auction,
    this.authority,
    this.soldPrice,
    this.soldDate,
    this.soldPriceDisplay,
    this.underOffer,
    this.isHomeLandPackage,
    this.featured,
    this.agent,
    this.secondAgent,

    // Newly Added Item/Items for Rent Property
    this.rent,
    this.rentDisplay,

    // Newly Added Item/Items for Houzez
    this.propertyType,
    this.propertyStatus,
    this.propertyLabel,
    this.pricePostfix,
    this.firstPrice,
    this.secondPrice,
    this.propertyVirtualTourLink,
    this.agentInfo,
    this.agencyList,
    this.agentDisplayOption,
    this.agentList,
    this.isFeatured,
    this.houzezTotalRating,
    this.currency,

    this.availability,
    this.subCity,
    this.placeName,
    this.cartaTitleDeed,
    this.woreda,
    this.securityFeatureList,
    this.customFieldsMap,
    this.customFieldsMapForEditing
  });


  // Map<String, dynamic> toJson(){
  //   final Map<String, dynamic> data = new Map<String, dynamic>();
  //   data['heading'] = this.heading;
  //   data['category'] = this.category;
  //   data['unique_id'] = this.uniqueId;
  //   data['mod_date'] = this.modDate;
  //   data['list_date'] = this.listDate;
  //   data['images_mod_date'] = this.imagesModDate;
  //   data['floorplan_mod_date'] = this.floorplanModDate;
  //   data['owner'] = this.owner;
  //   data['office_id'] = this.officeId;
  //   data['agent_hide_author_box'] = this.agentHideAuthorBox;
  //   data['address_hide_map'] = this.addressHideMap;
  //   data['property_price'] = this.price;
  //   data['price_view'] = this.priceView;
  //   data['price_global'] = this.priceGlobal;
  //   data['property_price_display'] = this.priceDisplay;
  //   data['price_currency'] = this.priceCurrency;
  //   data['status'] = this.status;
  //   data['inspection_times'] = this.inspectionTimes;
  //   data['auction'] = this.auction;
  //   data['authority'] = this.authority;
  //   data['sold_price'] = this.soldPrice;
  //   data['sold_date'] = this.soldDate;
  //   data['sold_price_display'] = this.soldPriceDisplay;
  //   data['under_offer'] = this.underOffer;
  //   data['is_home_land_package'] = this.isHomeLandPackage;
  //   data['featured'] = this.featured;
  //   data['agent'] = this.agent;
  //   data['second_agent'] = this.secondAgent;
  //   return data;
  // }
}

class Article {
  final int id;
  final String title;
  final String content;
  final String type;
  String image;
  final String video;
  final int author;
  final String avatar;
  final String category;
  final String date;
  final String dateGMT;
  final String link;
  final String guid;
  final int featuredImageId;
  final String status;
  final int catId;
  final bool isFav;
  final String reviewPostType;
  final String reviewStars;
  final String reviewBy;
  final String reviewTo;
  final String reviewPropertyId;
  final String modifiedGmt;

  // final String reviewLikes;
  // final String reviewDislikes;

  // Newly Added Item/Items for Houzez
  List<String> imageList = [];
  String virtualTourLink;

  PropertyInfo propertyInfo;
  Address propertyAddress;
  Features propertyFeatures;

  Map<String, dynamic> otherFeatures = new Map();

  PropertyInfo info;
  Address address;
  Features features;
  List<String> internalFeaturesList = [];
  List<String> externalFeaturesList = [];
  List<String> heatingAndCoolingFeaturesList = [];
  Map<String, String> propertyDetailsMap = new Map<String, String>();
  Author authorInfo;

  String userDisplayName = "";
  String userName = "";


  Article({
    this.reviewPostType,
    this.reviewStars,
    this.reviewBy,
    this.reviewTo,
    this.reviewPropertyId,
    // this.reviewLikes,
    // this.reviewDislikes,
    this.id,
    this.title,
    this.type,
    this.content,
    this.image,
    this.video,
    this.author,
    this.avatar,
    this.category,
    this.date,
    this.dateGMT,
    this.link,
    this.catId,
    // Newly Added Item/Items for Houzez
    this.imageList,
    this.virtualTourLink,
    this.status,
    this.isFav,
    this.guid,
    this.featuredImageId,
    this.modifiedGmt,
    this.userDisplayName,
    this.userName
  });

  factory Article.fromDatabaseJson(Map<String, dynamic> data) {
    return Article(
      id: data['id'],
      title: data['title'],
      content: data['content'],
      image: data['image'],
      video: data['video'],
      author: data['author'],
      avatar: data['avatar'],
      category: data['category'],
      date: data['date'],
      link: data['link'],
      catId: data["catId"]);
  }

  Map<String, dynamic> toDatabaseJson() => {
        'id': this.id,
        'title': this.title,
        'content': this.content,
        'image': this.image,
        'video': this.video,
        'author': this.author,
        'avatar': this.avatar,
        'category': this.category,
        'date': this.date,
        'link': this.link,
        'catId': this.catId
      };

  String getFormattedAddress(){
    String propAddress = '';
    if(address.display == "yes"){
      if(address.subNumber.isNotEmpty){
        propAddress = propAddress + address.subNumber;
      }
      if(address.street.isNotEmpty){
        propAddress = propAddress + " " +  address.street;
      }
      if(address.streetNumber.isNotEmpty){
        propAddress = propAddress + " " +  address.streetNumber;
      }
      if(address.suburb.isNotEmpty){
        propAddress = propAddress + ", " + address.suburb;
      }
      if(address.state.isNotEmpty){
        propAddress = propAddress + " " + address.state;
      }
      if(address.postalCode.isNotEmpty){
        propAddress = propAddress + " " + address.postalCode;
      }
      return propAddress;
    } else {
      return propAddress;
    }

  }

}
