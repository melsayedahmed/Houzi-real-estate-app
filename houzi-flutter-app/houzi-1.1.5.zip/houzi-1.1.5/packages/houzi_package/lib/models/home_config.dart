import 'dart:convert';

HomeConfig homeConfigFromJson(String str) => HomeConfig.fromJson(json.decode(str));

String homeConfigToJson(HomeConfig data) => json.encode(data.toJson());

class HomeConfig {
  HomeConfig({
    this.homeLayout,
  });

  List<HomeLayout> homeLayout;

  factory HomeConfig.fromJson(Map<String, dynamic> json) => HomeConfig(
    homeLayout: List<HomeLayout>.from(json["home_layout"].map((x) => HomeLayout.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "home_layout": List<dynamic>.from(homeLayout.map((x) => x.toJson())),
  };
}

class HomeLayout {
  HomeLayout({
    this.sectionType,
    this.title,
    this.layoutDesign,
    this.subType,
    this.subTypeValue,
    this.sectionListingView,
    this.showFeatured = false,
  });

  String sectionType;
  String title;
  LayoutDesign layoutDesign;
  String subType;
  String subTypeValue;
  String sectionListingView;
  bool showFeatured;

  factory HomeLayout.fromJson(Map<String, dynamic> json) => HomeLayout(
    sectionType: json["section_type"],
    title: json["title"],
    layoutDesign: layoutDesignValues.map[json["layout_design"]],
    subType: json["sub_type"],
    subTypeValue: json["sub_type_value"],
    sectionListingView: json["section_listing_view"],
    showFeatured: json["show_featured"] ?? false,
  );

  Map<String, dynamic> toJson() => {
    "section_type": sectionType,
    "title": title,
    "layout_design": layoutDesignValues.reverse[layoutDesign],
    "sub_type": subType,
    "sub_type_value": subTypeValue,
    "section_listing_view": sectionListingView,
    "show_featured": showFeatured,
  };
}

enum LayoutDesign { EMPTY, DESIGN01, DESIGN02,DESIGN03,DESIGN04,DESIGN05,DESIGN06,DESIGN07,DESIGN08 }

final layoutDesignValues = EnumValues({
  "Design # 01": LayoutDesign.DESIGN01,
  "Design # 02": LayoutDesign.DESIGN02,
  "Design # 03": LayoutDesign.DESIGN03,
  "Design # 04": LayoutDesign.DESIGN04,
  "Design # 05": LayoutDesign.DESIGN05,
  "Design # 06": LayoutDesign.DESIGN06,
  "Design # 07": LayoutDesign.DESIGN07,
  "Design # 08": LayoutDesign.DESIGN08,
  "": LayoutDesign.EMPTY
});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap ??= map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
