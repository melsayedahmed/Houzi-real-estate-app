class Activity {
  String activityId;
  String userId;
  String time;
  String type;
  String subtype;
  String name;
  String email;
  String phone;
  String message;
  String scheduleTourType;
  String scheduleDate;
  String scheduleTime;
  String title;
  var listingId;
  String reviewTitle;
  var reviewId;
  String reviewStar;
  String reviewPostType;
  String reviewContent;
  String reviewLink;
  String userName;

  Activity({
    this.activityId,
    this.userId,
    this.time,
    this.type,
    this.subtype,
    this.name,
    this.email,
    this.phone,
    this.message,
    this.scheduleTourType,
    this.scheduleDate,
    this.scheduleTime,
    this.title,
    this.listingId,
    this.reviewPostType,
    this.userName,
    this.reviewContent,
    this.reviewId,
    this.reviewLink,
    this.reviewStar,
    this.reviewTitle,
  });
}

class LeadsFromActivity {
  var totalRecords;
  var itemsPerPage;
  var page;
  var lastDay;
  var lastTwo;
  var lastWeek;
  var last2Week;
  var lastMonth;
  var last2Month;

  LeadsFromActivity({
    this.totalRecords,
    this.itemsPerPage,
    this.page,
    this.lastDay,
    this.lastTwo,
    this.lastWeek,
    this.last2Week,
    this.lastMonth,
    this.last2Month,
  });
}

class DealsFromActivity {
  String activeCount = "";
  String wonCount = "";
  String lostCount = "";

  DealsFromActivity({
    this.activeCount,
    this.wonCount,
    this.lostCount,
  });
}

class DealsAndLeadsFromActivity {
  String activeCount = "";
  String wonCount = "";
  String lostCount = "";
  var lastDay;
  var lastTwo;
  var lastWeek;
  var last2Week;
  var lastMonth;
  var last2Month;

  DealsAndLeadsFromActivity({
    this.activeCount,
    this.wonCount,
    this.lostCount,
    this.lastDay,
    this.lastTwo,
    this.lastWeek,
    this.last2Week,
    this.lastMonth,
    this.last2Month,
  });


}
