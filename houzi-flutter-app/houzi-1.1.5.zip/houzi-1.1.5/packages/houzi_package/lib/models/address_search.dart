import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/dataProvider/place_api_provider.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

import '../files/generic_methods/generic_methods.dart';

class AddressSearch extends SearchDelegate<Suggestion> {
  // AddressSearch(this.sessionToken) {
  //   apiClient = PlaceApiProvider(sessionToken);
  // }

  AddressSearch(this.sessionToken,{this.forKeyWordSearch = false}) : super(keyboardType: TextInputType.text,
      textInputAction: TextInputAction.go) {
    if(!forKeyWordSearch){
      apiClient = PlaceApiProvider(sessionToken);
    }
  }

  final sessionToken;
  final bool forKeyWordSearch;
  PlaceApiProvider apiClient;

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        tooltip: GenericMethods.getLocalizedString("delete"),//AppLocalizations.of(context).delete,
        icon: Icon(AppThemePreferences.closeIcon),
        onPressed: () {
          query = '';
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      tooltip: GenericMethods.getLocalizedString("back"),//AppLocalizations.of(context).back,
      icon: Icon(AppThemePreferences.arrowBackIcon),
      onPressed: () {
        close(context, forKeyWordSearch ? Suggestion(query,query) : null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return SizedBox(
      height: 150.0,
      child: ListTile(
        title: GestureDetector(
            onTap: () {
              if(forKeyWordSearch){
                close(context, Suggestion(query,query));
              }
            },
            child: genericTextWidget(query,
                style: AppThemePreferences().appTheme.heading01TextStyle)),
      ),
    );
    // return null;
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return forKeyWordSearch ? Container()
        :
    FutureBuilder(
      future: query == "" ? null : apiClient.fetchSuggestions(query),
      builder: (context, snapshot) {
        return query == ''
            ? Container(
          padding: const EdgeInsets.all(16.0),
        )
            : snapshot.hasData
            ? ListView.builder(
          itemBuilder: (context, index) => ListTile(
            title: genericTextWidget(
                (snapshot.data[index] as Suggestion).description),
            onTap: () {
              close(context, snapshot.data[index] as Suggestion);
            },
          ),
          itemCount: snapshot.data.length,
        )
            : Container();
      },
    );
  }

}
