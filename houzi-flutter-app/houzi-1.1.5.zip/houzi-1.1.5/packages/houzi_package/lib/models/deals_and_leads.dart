class DealsAndLeads {
  String totalRecords;
  int itemsPerPage;
  int page;
  String resultStatus;
  String actions;
  String activeCount;
  String wonCount;
  String lostCount;
  String dealId;
  String userId;
  String title;
  String listingId;
  String resultLeadId;
  String agentId;
  String agentType;
  String leadStatus;
  String nextAction;
  String actionDueDate;
  String dealValue;
  String lastContactDate;
  String resultPrivateNote;
  String dealGroup;
  String resultTime;
  String agentName;
  String leadLeadId;
  String leadUserId;
  String prefix;
  String displayName;
  String firstName;
  String lastName;
  String email;
  String mobile;
  String homePhone;
  String workPhone;
  String address;
  String city;
  String state;
  String country;
  String zipcode;
  String type;
  String status;
  String source;
  String sourceLink;
  String enquiryTo;
  String enquiryUserType;
  String twitterUrl;
  String linkedinUrl;
  String facebookUrl;
  String leadPrivateNote;
  String message;
  String leadTime;

  DealsAndLeads(
      {this.totalRecords,
      this.itemsPerPage,
      this.page,
      this.resultStatus,
      this.actions,
      this.activeCount,
      this.wonCount,
      this.lostCount,
      this.dealId,
      this.userId,
      this.title,
      this.listingId,
      this.resultLeadId,
      this.agentId,
      this.agentType,
      this.leadStatus,
      this.nextAction,
      this.actionDueDate,
      this.dealValue,
      this.lastContactDate,
      this.resultPrivateNote,
      this.dealGroup,
      this.resultTime,
      this.agentName,
      this.leadLeadId,
      this.leadUserId,
      this.prefix,
      this.displayName,
      this.firstName,
      this.lastName,
      this.email,
      this.mobile,
      this.homePhone,
      this.workPhone,
      this.address,
      this.city,
      this.state,
      this.country,
      this.zipcode,
      this.type,
      this.status,
      this.source,
      this.sourceLink,
      this.enquiryTo,
      this.enquiryUserType,
      this.twitterUrl,
      this.linkedinUrl,
      this.facebookUrl,
      this.leadPrivateNote,
      this.message,
      this.leadTime});
}

//
//   Deals(
//       {this.results,
//         this.totalRecords,
//         this.itemsPerPage,
//         this.page,
//         this.status,
//         this.actions,
//         this.activeCount,
//         this.wonCount,
//         this.lostCount});
//
//   Deals.fromJson(Map<String, dynamic> json) {
//     if (json['results'] != null) {
//       results = new List<Results>();
//       json['results'].forEach((v) {
//         results.add(new Results.fromJson(v));
//       });
//     }
//     totalRecords = json['total_records'];
//     itemsPerPage = json['items_per_page'];
//     page = json['page'];
//     status = json['status'];
//     actions = json['actions'];
//     activeCount = json['active_count'];
//     wonCount = json['won_count'];
//     lostCount = json['lost_count'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.results != null) {
//       data['results'] = this.results.map((v) => v.toJson()).toList();
//     }
//     data['total_records'] = this.totalRecords;
//     data['items_per_page'] = this.itemsPerPage;
//     data['page'] = this.page;
//     data['status'] = this.status;
//     data['actions'] = this.actions;
//     data['active_count'] = this.activeCount;
//     data['won_count'] = this.wonCount;
//     data['lost_count'] = this.lostCount;
//     return data;
//   }
// }
//
// class Results {
//   String dealId;
//   String userId;
//   String title;
//   String listingId;
//   String leadId;
//   String agentId;
//   String agentType;
//   String status;
//   String nextAction;
//   String actionDueDate;
//   String dealValue;
//   String lastContactDate;
//   String privateNote;
//   String dealGroup;
//   String time;
//   String agentName;
//   Lead lead;
//
//   Results(
//       {this.dealId,
//         this.userId,
//         this.title,
//         this.listingId,
//         this.leadId,
//         this.agentId,
//         this.agentType,
//         this.status,
//         this.nextAction,
//         this.actionDueDate,
//         this.dealValue,
//         this.lastContactDate,
//         this.privateNote,
//         this.dealGroup,
//         this.time,
//         this.agentName,
//         this.lead});
//
//   Results.fromJson(Map<String, dynamic> json) {
//     dealId = json['deal_id'];
//     userId = json['user_id'];
//     title = json['title'];
//     listingId = json['listing_id'];
//     leadId = json['lead_id'];
//     agentId = json['agent_id'];
//     agentType = json['agent_type'];
//     status = json['status'];
//     nextAction = json['next_action'];
//     actionDueDate = json['action_due_date'];
//     dealValue = json['deal_value'];
//     lastContactDate = json['last_contact_date'];
//     privateNote = json['private_note'];
//     dealGroup = json['deal_group'];
//     time = json['time'];
//     agentName = json['agent_name'];
//     lead = json['lead'] != null ? new Lead.fromJson(json['lead']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['deal_id'] = this.dealId;
//     data['user_id'] = this.userId;
//     data['title'] = this.title;
//     data['listing_id'] = this.listingId;
//     data['lead_id'] = this.leadId;
//     data['agent_id'] = this.agentId;
//     data['agent_type'] = this.agentType;
//     data['status'] = this.status;
//     data['next_action'] = this.nextAction;
//     data['action_due_date'] = this.actionDueDate;
//     data['deal_value'] = this.dealValue;
//     data['last_contact_date'] = this.lastContactDate;
//     data['private_note'] = this.privateNote;
//     data['deal_group'] = this.dealGroup;
//     data['time'] = this.time;
//     data['agent_name'] = this.agentName;
//     if (this.lead != null) {
//       data['lead'] = this.lead.toJson();
//     }
//     return data;
//   }
// }
//
// class Lead {
//   String leadId;
//   String userId;
//   String prefix;
//   String displayName;
//   String firstName;
//   String lastName;
//   String email;
//   String mobile;
//   String homePhone;
//   String workPhone;
//   String address;
//   String city;
//   String state;
//   String country;
//   String zipcode;
//   String type;
//   String status;
//   String source;
//   String sourceLink;
//   String enquiryTo;
//   String enquiryUserType;
//   String twitterUrl;
//   String linkedinUrl;
//   String facebookUrl;
//   String privateNote;
//   String message;
//   String time;
//
//   Lead(
//       {this.leadId,
//         this.userId,
//         this.prefix,
//         this.displayName,
//         this.firstName,
//         this.lastName,
//         this.email,
//         this.mobile,
//         this.homePhone,
//         this.workPhone,
//         this.address,
//         this.city,
//         this.state,
//         this.country,
//         this.zipcode,
//         this.type,
//         this.status,
//         this.source,
//         this.sourceLink,
//         this.enquiryTo,
//         this.enquiryUserType,
//         this.twitterUrl,
//         this.linkedinUrl,
//         this.facebookUrl,
//         this.privateNote,
//         this.message,
//         this.time});
//
//   Lead.fromJson(Map<String, dynamic> json) {
//     leadId = json['lead_id'];
//     userId = json['user_id'];
//     prefix = json['prefix'];
//     displayName = json['display_name'];
//     firstName = json['first_name'];
//     lastName = json['last_name'];
//     email = json['email'];
//     mobile = json['mobile'];
//     homePhone = json['home_phone'];
//     workPhone = json['work_phone'];
//     address = json['address'];
//     city = json['city'];
//     state = json['state'];
//     country = json['country'];
//     zipcode = json['zipcode'];
//     type = json['type'];
//     status = json['status'];
//     source = json['source'];
//     sourceLink = json['source_link'];
//     enquiryTo = json['enquiry_to'];
//     enquiryUserType = json['enquiry_user_type'];
//     twitterUrl = json['twitter_url'];
//     linkedinUrl = json['linkedin_url'];
//     facebookUrl = json['facebook_url'];
//     privateNote = json['private_note'];
//     message = json['message'];
//     time = json['time'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['lead_id'] = this.leadId;
//     data['user_id'] = this.userId;
//     data['prefix'] = this.prefix;
//     data['display_name'] = this.displayName;
//     data['first_name'] = this.firstName;
//     data['last_name'] = this.lastName;
//     data['email'] = this.email;
//     data['mobile'] = this.mobile;
//     data['home_phone'] = this.homePhone;
//     data['work_phone'] = this.workPhone;
//     data['address'] = this.address;
//     data['city'] = this.city;
//     data['state'] = this.state;
//     data['country'] = this.country;
//     data['zipcode'] = this.zipcode;
//     data['type'] = this.type;
//     data['status'] = this.status;
//     data['source'] = this.source;
//     data['source_link'] = this.sourceLink;
//     data['enquiry_to'] = this.enquiryTo;
//     data['enquiry_user_type'] = this.enquiryUserType;
//     data['twitter_url'] = this.twitterUrl;
//     data['linkedin_url'] = this.linkedinUrl;
//     data['facebook_url'] = this.facebookUrl;
//     data['private_note'] = this.privateNote;
//     data['message'] = this.message;
//     data['time'] = this.time;
//     return data;
//   }
// }
