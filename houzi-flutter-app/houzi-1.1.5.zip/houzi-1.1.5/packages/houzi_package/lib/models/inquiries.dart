class Inquiries {
  String enquiryId;

  Inquiries({
    this.enquiryId,
    this.userId,
    this.leadId,
    this.listingId,
    this.negotiator,
    this.source,
    this.status,
    this.enquiryTo,
    this.enquiryUserType,
    this.message,
    this.enquiryType,
    this.privateNote,
    this.time,
    this.displayName,
    this.minBeds,
    this.maxBeds,
    this.minBaths,
    this.maxBaths,
    this.minPrice,
    this.maxPrice,
    this.minArea,
    this.maxArea,
    this.zipcode,
    this.propertyTypeName,
    this.propertyTypeSlug,
    this.countryTypeName,
    this.countryTypeSlug,
    this.stateTypeName,
    this.stateTypeSlug,
    this.cityTypeName,
    this.cityTypeSlug,
    this.areaTypeName,
    this.areaTypeSlug,
    this.matchedID,
    this.postAuthor,
    this.postDate,
    this.postDateGmt,
    this.postContent,
    this.postTitle,
    this.postExcerpt,
    this.postStatus,
    this.commentStatus,
    this.pingStatus,
    this.postPassword,
    this.postName,
    this.toPing,
    this.pinged,
    this.postModified,
    this.postModifiedGmt,
    this.postContentFiltered,
    this.postParent,
    this.guid,
    this.menuOrder,
    this.postType,
    this.postMimeType,
    this.commentCount,
    this.filter,
    this.location
  });

  String userId;
  String leadId;
  String listingId;
  String negotiator;
  String source;
  String status;
  String enquiryTo;
  String enquiryUserType;
  String message;
  String enquiryType;
  String privateNote;
  String time;
  String displayName;
  String minBeds;
  String maxBeds;
  String minBaths;
  String maxBaths;
  String minPrice;
  String maxPrice;
  String minArea;
  String maxArea;
  String zipcode;
  String propertyTypeName;
  String propertyTypeSlug;
  String countryTypeName;
  String countryTypeSlug;
  String stateTypeName;
  String stateTypeSlug;
  String cityTypeName;
  String cityTypeSlug;
  String areaTypeName;
  String areaTypeSlug;
  String location;

  // String leadId;
  // String userId;
  // String prefix;
  // String displayName;
  // String firstName;
  // String lastName;
  // String email;
  // String mobile;
  // String homePhone;
  // String workPhone;
  // String address;
  // String city;
  // String state;
  // String country;
  // String zipcode;
  // String type;
  // String status;
  // String source;
  // String sourceLink;
  // String enquiryTo;
  // String enquiryUserType;
  // String twitterUrl;
  // String linkedinUrl;
  // String facebookUrl;
  // String privateNote;
  // String message;
  // String time;
  int matchedID;
  String postAuthor;
  String postDate;
  String postDateGmt;
  String postContent;
  String postTitle;
  String postExcerpt;
  String postStatus;
  String commentStatus;
  String pingStatus;
  String postPassword;
  String postName;
  String toPing;
  String pinged;
  String postModified;
  String postModifiedGmt;
  String postContentFiltered;
  int postParent;
  String guid;
  int menuOrder;
  String postType;
  String postMimeType;
  String commentCount;
  String filter;
}
// String enquiryId;
// String userId;
// String leadId;
// String listingId;
// String negotiator;
// String source;
// String status;
// String enquiryTo;
// String enquiryUserType;
// String message;
// String enquiryType;
// String privateNote;
// String time;
// String minBeds;
// String maxBeds;
// String minBaths;
// String maxBaths;
// String minPrice;
// String maxPrice;
// String minArea;
// String maxArea;
// String zipcode;
//
// String propertyTypeName;
// String propertyTypeSlug;
// String countryTypeName;
// String countryTypeSlug;
// String stateTypeName;
// String stateTypeSlug;
// String cityTypeName;
// String cityTypeSlug;
// String areaTypeName;
// String areaTypeSlug;
//
// Inquiries({
//   this.enquiryId,
//   this.userId,
//   this.leadId,
//   this.listingId,
//   this.negotiator,
//   this.source,
//   this.status,
//   this.enquiryTo,
//   this.enquiryUserType,
//   this.message,
//   this.enquiryType,
//   this.privateNote,
//   this.time,
//   this.minBeds,
//   this.maxBeds,
//   this.minBaths,
//   this.maxBaths,
//   this.minPrice,
//   this.maxPrice,
//   this.minArea,
//   this.maxArea,
//   this.zipcode,
//   this.propertyTypeName,
//   this.propertyTypeSlug,
//   this.countryTypeName,
//   this.countryTypeSlug,
//   this.stateTypeName,
//   this.stateTypeSlug,
//   this.cityTypeName,
//   this.cityTypeSlug,
//   this.areaTypeName,
//   this.areaTypeSlug,
// });
