import 'dart:convert';

class PropertyMetaData{
  int id;
  int parent;
  int totalPropertiesCount;
  String name;
  String slug;
  String thumbnail;
  String fullImage;
  String taxonomy;

  PropertyMetaData({
    this.id,
    this.name,
    this.slug,
    this.parent,
    this.thumbnail,
    this.taxonomy,
    this.fullImage,
    this.totalPropertiesCount,
  });

  factory PropertyMetaData.fromJson(Map<String, dynamic> json) {
    return PropertyMetaData(
      id: json['id'],
      name: json['name'],
      slug: json['slug'],
      parent: json['parent'],
      thumbnail: json['thumbnail'],
      taxonomy: json['taxonomy'],
      fullImage: json['fullImage'],
      totalPropertiesCount: json['totalPropertiesCount'],
    );
  }

  static Map<String, dynamic> toMap(PropertyMetaData propertyMetaData) => {
    'id': propertyMetaData.id,
    'name': propertyMetaData.name,
    'slug': propertyMetaData.slug,
    'parent': propertyMetaData.parent,
    'thumbnail': propertyMetaData.thumbnail,
    'fullImage': propertyMetaData.fullImage,
    'taxonomy': propertyMetaData.taxonomy,
    'totalPropertiesCount': propertyMetaData.totalPropertiesCount,
  };

  static String encode(List<dynamic> propertyMetaDataList) {
    return json.encode(propertyMetaDataList.map<Map<String, dynamic>>((item) =>
        PropertyMetaData.toMap(item)).toList());
  }

  static List<dynamic> decode(String propertyMetaDataList) {
    return (json.decode(propertyMetaDataList) as List<dynamic>).map<PropertyMetaData>((item) => PropertyMetaData.fromJson(item)).toList();
  }

}

