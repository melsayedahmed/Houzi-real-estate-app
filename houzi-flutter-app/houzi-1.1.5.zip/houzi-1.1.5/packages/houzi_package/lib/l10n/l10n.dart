import 'package:flutter/material.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';

typedef LanguageHook = List<dynamic> Function();

class L10n {
  static List<Locale> all = getAllLanguagesLocale();

  // [
  //   const Locale('en'),
  //   const Locale('ar'),
  //   const Locale('fr'),
  //   const Locale('ur'),
  //   const Locale('zh'),
  //   const Locale('ku'),
  // ];

  static String getLanguageName(String code) {
    if (code == 'ar') {
      return 'Arabic';
    } else if (code == 'fr') {
      return 'French';
    } else if (code == 'ur') {
      return 'Urdu';
    } else if (code == 'ku') {
      return 'Kurdish';
    } else if (code == 'ar') {
      return 'Arabic';
    } else if (code == 'en') {
      return 'English';
    } else {
      if (code.isNotEmpty) {
        String languageName = findFromLanguageHook(code);
        if (languageName.isNotEmpty) {
          return languageName;
        }
      }

      return 'English';
    }

    // switch (code) {
    //   case 'ar':
    //     return 'Arabic';
    //   case 'fr':
    //     return 'French';
    //   case 'ur':
    //     return 'Urdu';
    //   case 'ku':
    //     return 'Kurdish';
    //   case 'zh':
    //     return 'Chinese';
    //   case 'en':
    //   default:
    //     return 'English';
    // }
  }

  static getAllLanguagesLocale() {
    LanguageHook languageHook = GenericMethods.languageNameAndCode;
    List<Locale> localeList = [
      const Locale('en'),
      const Locale('ar'),
      const Locale('fr'),
      const Locale('ur'),
      // const Locale('ku'),
    ];

    List<dynamic> languageList = languageHook();
    for (var languageMap in languageList) {
      languageMap.removeWhere((key, value) => value == null || value.isEmpty);
      if (languageMap != null && languageMap.isNotEmpty) {
        localeList.add(Locale(languageMap["languageCode"]));
      }
    }

    return localeList;
  }

  static String findFromLanguageHook(String code) {
    LanguageHook languageHook = GenericMethods.languageNameAndCode;
    List<dynamic> languageList = languageHook();
    Map<String, dynamic> map = languageList.firstWhere(
        (element) => element["languageCode"] == code,
        orElse: () => null);
    if (map != null) {
      return map["languageName"];
    }

    return "";
  }
}
