import 'dart:io' show Platform;

import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';

import 'package:houzi_package/models/realtor_model.dart';
import 'package:houzi_package/models/deals_and_leads.dart';
import 'package:houzi_package/models/property_meta_data.dart';


import 'package:houzi_package/models/inquiries.dart';

import 'package:houzi_package/models/activity.dart';

import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/models/saved_search.dart';
import 'package:houzi_package/models/user.dart';

import '../files/generic_methods/generic_methods.dart';

abstract class ApiProviderInterface{
  Uri provideLatestPropertiesApi(int page);
  Uri provideFilteredPropertiesApi();
  Uri provideFeaturedPropertiesApi(int page);
  Uri provideSinglePropertyApi(int id,{bool forEditing});
  Uri provideSimilarPropertiesApi(int propertyId);

  Uri provideActivitiesFromBoardApi(int page, int perPage,int userId);
  Uri provideInquiriesFromBoardApi(int page, int perPage,int userId);
  Uri provideLeadsFromActivityApi(int page, int userId);
  Uri provideDealsFromActivityApi(int page, int userId);
  Uri provideDealsFromBoardApi(int page,int perPage, String tab);
  Uri provideLeadsFromBoardApi(int page, int perPage);

  Uri providePropertyMetaDataApi();

  Uri provideSingleAgentInfoApi(int id);
  Uri provideSingleAgencyInfoApi(int id);

  Uri provideAgencyAgentsInfoApi(int agencyId);

  Uri provideAllAgentsInfoApi(int page, int perPage);
  Uri provideAllAgenciesInfoApi(int page, int perPage);

  Uri providePropertiesByAgentApi(int agentId, int page, int perPage);
  Uri providePropertiesByAgencyApi(int agencyId, int page, int perPage);

  Uri providePropertiesInCityApi(int cityId, int page, int perPage);
  Uri providePropertiesByTypesApi(int propertyTypeId, int page, int perPage);

  Uri providePropertiesInCityByTypeApi(int cityId, int typeId, int page, int perPage);

  Uri provideContactRealtorApi();
  Uri provideContactDeveloperApi();
  Uri provideScheduleATourApi();

  Uri provideSavePropertyApi();
  Uri provideSavePropertyImagesApi();



  Uri provideLoginApi();
  Uri provideSignUpApi();
  Uri provideForgetPasswordApi();
  Uri provideAllPropertiesApi(String status, int page, int perPage, int userId);
  Uri provideMyPropertiesApi(String status, int page, int perPage,int userId);

  Uri provideStatusOfPropertyApi(int id);
  Uri provideDeletePropertyApi(int id);
  Uri provideAddDealResponseApi();
  Uri provideDeleteDealApi(int id);
  Uri provideDeleteInquiryApi(int id);

  Uri provideAddInquiryApi();
  Uri provideTermDataApi(String termData);
  Uri provideAddOrRemoveFromFavApi();
  Uri provideFavPropertiesApi(int page, int perPage, String userIdStr);
  Uri provideDeleteLeadApi(id);
  Uri provideUpdatePropertyApi();

  Uri provideImagesForUpdateArticleApi();
  Uri provideLatLongArticlesApi(String lat, String long);
  Uri provideDeleteImageFromEditPropertyApi();
  Uri provideAddSavedSearchApi();
  Uri provideSavedSearches(int page, int perPage);
  Uri provideDeleteSavedSearchApi();
  Uri provideSavedSearchArticlesApi();
  Uri provideAddReviewApi();
  Uri provideArticlesReviewsApi(int id, String page, String perPage);
  Uri provideAgentAgencyAuthorReviewsApi(int id, String page, String perPage, String type);

  Uri provideUserInfoApi();
  Uri provideUpdateUserProfileApi();
  Uri provideUpdateUserProfileImageApi();
  Uri provideDealsAndLeadsFromActivityApi();
  Uri provideFixProfileImageResponseApi();

  Uri provideSearchAgentsApi(int page, int perPage, String search, String agentCity, String agentCategory);
  Uri provideSearchAgenciesApi(int page, int perPage, String search);

  Uri provideIsFavPropertyAp(String listingId);

  Uri provideSocialLoginApi();
  Uri providePropertiesByTypeApi(int page, int id, String type);
  Uri provideRealtorInfoApi(int page, String type);
  Uri provideDeleteUserAccountApi();
  Uri provideUpdateUserPasswordApi();
  Uri provideAddLeadResponseApi();
  Uri provideSingleArticleViaPermaLinkApi(String permaLink);

  Uri provideAddRequestPropertyApi();

  ApiParser getParser();

  Uri providePropertiesAdsResponseApi();
  Uri provideAddAgentResponseApi();
  Uri provideAgencyAllAgentListApi(int agencyId);
  Uri provideEditAgentResponseApi();
  Uri provideDeleteAgentResponseApi();

  Uri provideMultiplePropertiesApi(String propertiesId);

}
abstract class ApiParser {
  Article parseArticle(Map<String, dynamic> json);
  PropertyMetaData parseMetaDataMap(Map<String, dynamic> json);
  AgentMetaData parseAgentMetaData(Map<String, dynamic> json);
  Agent parseAgentInfo(Map<String, dynamic> json);
  Agency parseAgencyInfo(Map<String, dynamic> json);
  Activity parseActivities(Map<String, dynamic> json);
  Inquiries parseInquiries(Map<String, dynamic> json);
  LeadsFromActivity parseLeads(Map<String, dynamic> json);
  DealsFromActivity parseDeals(Map<String, dynamic> json);
  DealsAndLeads parseDealsAndLeadsFromBoard(Map<String, dynamic> json);
  SavedSearch parseSavedSearch(Map<String, dynamic> json);
  User parseUserInfo(Map<String, dynamic> json);
  DealsAndLeadsFromActivity parseDealsAndLeadsFromActivity(Map<String, dynamic> json);
}

class PropertyApiProvider{

  final Options _cacheOptions = buildCacheOptions(Duration(days: 7), forceRefresh: true);

  final ApiProviderInterface _apiProviderInterface;

  PropertyApiProvider(this._apiProviderInterface);

  static const int MAX_TRIES = 3;

  static const int GET = 0;
  static const int POST = 1;
  static const int PUT = 2;
  static const int DELETE = 3;


  ApiParser getCurrentParser() {
    return _apiProviderInterface.getParser();
  }

  Dio getDio() {
    String token = HiveStorageManager.getUserToken() ?? "";
    Map<String, dynamic> headerHookMap = HiveStorageManager.readSecurityKeyMapData() ?? {};
    Map<String, dynamic> headerMap = {};
    if(token != null && token.isNotEmpty){
      headerMap["Authorization"] = "Bearer $token";
    }

    headerHookMap.removeWhere((key, value) => value==null || value.isEmpty);
    if(headerHookMap.isNotEmpty) {
      headerMap.addAll(headerHookMap);
    }

    if(headerMap!=null && headerMap.isNotEmpty) {
      Dio dio = Dio()
        ..options.headers = headerMap
        ..interceptors.add(DioCacheManager(CacheConfig()).interceptor);
      return dio;
    }

    Dio dio = Dio()..interceptors.add(DioCacheManager(CacheConfig()).interceptor);
    return dio;
  }

  refreshToken() async {
    Map userInfoMapFromStorage = HiveStorageManager.readUserCredentials();
    if(userInfoMapFromStorage != null && userInfoMapFromStorage.isNotEmpty){
      Map<String, dynamic> userInfo = userInfoMapFromStorage.map((key, value) => MapEntry(key.toString(), value));
      if(userInfo != null && userInfo.isNotEmpty){
        var response;

        if(userInfo.containsKey(USER_SOCIAL_PLATFORM)){
          response = await fetchSocialSignOnResponse(userInfo);
        }else{
          response = await fetchLoginResponse(userInfo);
        }

        if(response.statusCode == 200){
          HiveStorageManager.storeUserLoginInfoData(response.data);
        }
      }
    }
  }

  String getDevicePlatform(){
    String platform = "";
    if (Platform.isAndroid) {
      platform = "android";
    } else if (Platform.isIOS) {
      platform = "ios";
    }

    return platform;
  }

  String getAppBuildNumber(){
    String appBuildNumber = "";
    Map appInfoMap = HiveStorageManager.readAppInfo() ?? {};
    if(appInfoMap.isNotEmpty){
      appBuildNumber = appInfoMap[APP_INFO_APP_BUILD_NUMBER];
    }

    return appBuildNumber;
  }

  String getAppVersion(){
    String appVersion = "";
    Map appInfoMap = HiveStorageManager.readAppInfo() ?? {};
    if(appInfoMap.isNotEmpty){
      appVersion = appInfoMap[APP_INFO_APP_VERSION];
    }

    return appVersion;
  }

  Future<Response> doRequestOnRoute(
      var uri,
      {
        Dio dio,
        int type = GET,
        Map<String, dynamic> dataMap,
        FormData formData,
        String tag = "",
        int tries = 1,
        bool handle500 = false,
        bool handle403 = true,
        bool useCache = true,
      }) async {
    try{
      if(dio == null){
        dio = getDio();
      }

      Map<String, String> tempQueryParameters = {};
      tempQueryParameters = {
        'app_version': "${getAppVersion()}",
        'houzi_version': "$HOUZI_VERSION",
        'app_build_number': "${getAppBuildNumber()}",
        'app_platform': "${getDevicePlatform()}",
      };
      tempQueryParameters.addAll(uri.queryParameters);
      Uri modifiedUri = uri.replace(
        queryParameters: tempQueryParameters,
      );

      print("uri: $modifiedUri");
      // print("queryParameters: ${modifiedUri.queryParameters}");

      if(handle500){
        dio.options.responseType = ResponseType.plain;
      }
      if (type == GET) {
        var response = await dio.getUri(modifiedUri, options: useCache ? _cacheOptions : null);
        return response;
      } else if (type == POST) {
        if(formData != null){
          var response = await dio.postUri(modifiedUri, data: formData);
          return response;
        }

        var response = await dio.postUri(modifiedUri, data: FormData.fromMap(dataMap));
        return response;
      }
    }on DioError catch (dioError) {
      if(dioError.response != null){
        if (handle500) {
          if (dioError.response != null) {
            print("dioError.response: ${dioError.response}");


            if(tag == "add or remove from favourites"){
              var tempResponse = dioError.response.toString();
              String temp1 = '"'+'added'+'"'+':'+'true'+','+'"'+'response'+'"'+':'+'"'+'Added'+'"';
              String temp2 = '"'+'added'+'"'+':'+'false'+','+'"'+'response'+'"'+':'+'"'+'Removed'+'"';
              if(dioError.response.statusCode == 500 && (tempResponse.contains(temp1) || tempResponse.contains(temp2))){
                return dioError.response;
              }
            }else if(tag == "delete image from edit property" || tag == "sign-up"){
              return dioError.response;
            }else{
              var tempResponse = dioError.response.toString();
              String temp1 = '"' + 'success' + '"' + ':' + 'true';
              if (dioError.response.statusCode == 500 && tempResponse.contains(temp1)) {
                return dioError.response;
              }
            }
          }
        }
        if(handle403){
          if(dioError.response.statusCode == 403 || dioError.response.statusCode == 401){
            if (tries <= MAX_TRIES) {
              refreshToken();
              return doRequestOnRoute(uri, type:type, dataMap: dataMap, tag: tag, tries: ++tries);
            }
          }
        }
        print("$tag: error code = ${dioError.response.statusCode}");
        print("$tag: error message = ${dioError.message}");
        return dioError.response;
      }else{
        print('$tag Response Error: ${dioError.error}');
        return Response(
          requestOptions: null,
          statusMessage: dioError.error.toString(),
          statusCode: null,
        );
      }
    }
    return null;
  }

  Future<Response> fetchLatestArticlesResponse(int page) async {
    var data = {
      'page': '$page',
      'per_page': '${FETCH_LATEST_PROPERTIES_PER_PAGE}',
      'agent_agency_info':"yes",
    };
    var uri = _apiProviderInterface.provideLatestPropertiesApi(page);
    return doRequestOnRoute(uri, type:POST, dataMap: data, tag:"latest article");
  }

  Future<Response> fetchFilteredArticlesResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideFilteredPropertiesApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"filtered article");
  }

  Future<Response> fetchFeaturedArticlesResponse(int page) async {
    var uri = _apiProviderInterface.provideFeaturedPropertiesApi(page);
    return doRequestOnRoute(uri, tag: "featured article");
  }

  Future<Response> fetchSimilarPropertiesResponse(int propertyId) async {
    var uri = _apiProviderInterface.provideSimilarPropertiesApi(propertyId);
    return doRequestOnRoute(uri, tag: "similar article");
  }

  Future<Response> fetchMultipleArticlesResponse(String propertiesId) async {
    var uri = _apiProviderInterface.provideMultiplePropertiesApi(propertiesId);
    String str = uri.toString();
    str = GenericMethods.parseHtmlString(str);


    if(str.contains("%3F")){
      str = str.replaceAll("%3F", "?");
    }
    if(str.contains("%2C")){
      str = str.replaceAll("%2C", ",");
    }
    Uri myUri = Uri.parse(str);
    return doRequestOnRoute(myUri, tag: "multiple articles");
  }

  Future<Response> fetchSingleArticleResponse(int id, {bool forEditing = false}) async {
    var uri = _apiProviderInterface.provideSinglePropertyApi(id,forEditing: forEditing);
    return doRequestOnRoute(uri, tag: "single article");
  }

  Future<Response> fetchPropertyMetaDataApi() async {
    var uri =  _apiProviderInterface.providePropertyMetaDataApi();
    return doRequestOnRoute(uri, tag: "property meta data");
  }

  Future<Response> fetchSingleAgencyInfoApi(int id) async {
    var uri =  _apiProviderInterface.provideSingleAgencyInfoApi(id);
    return doRequestOnRoute(uri, tag: "single agency");
  }

  Future<Response> fetchSingleAgentInfoApi(int id) async {
    var uri =  _apiProviderInterface.provideSingleAgentInfoApi(id);
    return doRequestOnRoute(uri, tag: "single agent");
  }

  Future<Response> fetchAgencyAgentInfoApi(int agencyId) async {
    var uri =  _apiProviderInterface.provideAgencyAgentsInfoApi(agencyId);
    return doRequestOnRoute(uri, tag: "agency agent info");
  }

  Future<Response> fetchAgencyAllAgentListApi(int agencyId) async {
    var uri =  _apiProviderInterface.provideAgencyAllAgentListApi(agencyId);
    return doRequestOnRoute(uri, tag: "agency all agent info");
  }

  Future<Response> fetchPropertiesByAgencyApi(int id, int page, int perPage) async {
    var uri =  _apiProviderInterface.providePropertiesByAgencyApi(id, page, perPage);
    return doRequestOnRoute(uri, tag: "agency properties");
  }

  Future<Response> fetchPropertiesByAgentApi(int id, int page, int perPage) async {
    var uri =  _apiProviderInterface.providePropertiesByAgentApi(id, page, perPage);
    return doRequestOnRoute(uri, tag: "agenct properties");
  }

  Future<Response> fetchAllAgentsApi(int page, int perPage) async {
    var uri =  _apiProviderInterface.provideAllAgentsInfoApi(page, perPage);
    return doRequestOnRoute(uri, tag: "all agents");
  }

  Future<Response> fetchAllAgenciesApi(int page, int perPage) async {
    var uri =  _apiProviderInterface.provideAllAgenciesInfoApi(page, perPage);
    return doRequestOnRoute(uri, tag: "all agencies");
  }

  Future<Response> fetchPropertiesInCityApi(int cityId, int page, int perPage) async {

    var uri =  _apiProviderInterface.providePropertiesInCityApi(cityId, page, perPage);
    return doRequestOnRoute(uri, tag: "city properties");
  }

  Future<Response> fetchPropertiesInCityByTypeApi(int cityId, int typeId, int page, int perPage) async {
      var uri =  _apiProviderInterface.providePropertiesInCityByTypeApi(cityId, typeId, page, perPage);
      return doRequestOnRoute(uri, tag: "city properties by type");
  }

  Future<Response> fetchPropertiesByTypeApi(int propertyTypeId, int page, int perPage) async {
      var uri =  _apiProviderInterface.providePropertiesByTypesApi(propertyTypeId, page, perPage);
      return doRequestOnRoute(uri, tag: "type properties");
  }

  Future<Response> fetchContactRealtorResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideContactRealtorApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "contact realtor", handle500: true);
  }

  Future<Response> fetchContactDeveloperResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideContactDeveloperApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "contact dev");

  }

  Future<Response> fetchScheduleATourResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideScheduleATourApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "schedule tour", handle500: true);
  }


  Future<Response> fetchAddPropertyResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideSavePropertyApi();
      return doRequestOnRoute(uri, type: POST, dataMap: dataMap, tag: "add prop");
  }

  Future<Response> fetchActivitiesFromBoardResponse(int page,int perPage,int userId, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideActivitiesFromBoardApi(page,perPage,userId);
    return doRequestOnRoute(uri, tag: "board activities");
  }

  Future<Response> fetchInquiriesFromBoardResponse(int page, int perPage,int userId, ) async {
    var uri = _apiProviderInterface.provideInquiriesFromBoardApi(page, perPage,userId);
    return doRequestOnRoute(uri, tag: "board inquiries");
  }

  Future<Response> fetchLeadsFromActivityResponse(int page, int userId, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideLeadsFromActivityApi(page,userId);
    return doRequestOnRoute(uri, tag: "board leads");
  }


  Future<Response> fetchLoginResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideLoginApi();
    Dio dio = Dio()
      ..interceptors.add(DioCacheManager(CacheConfig()).interceptor);
    return doRequestOnRoute(uri, dio: dio, type: POST, dataMap: dataMap, tag: "login", handle403: false);
  }

  Future<Response> fetchSignUpResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideSignUpApi();
    Dio dio = Dio()
      ..interceptors.add(DioCacheManager(CacheConfig()).interceptor);
    return doRequestOnRoute(uri, dio: dio, type: POST, dataMap: dataMap, tag: "sign-up", handle403: false, handle500: true);
  }

  Future<Response> fetchForgetPasswordResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideForgetPasswordApi();
    Dio dio = Dio()
      ..interceptors.add(DioCacheManager(CacheConfig()).interceptor);
    return doRequestOnRoute(uri, dio: dio, type: POST, dataMap: dataMap, tag: "forget password", handle403: false, handle500: true);
  }

  Future<Response> fetchAllProperties(String status, int page, int perPage, int userId, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideAllPropertiesApi(status,page,perPage, userId);
    return doRequestOnRoute(uri, tag: "all properties");
  }

  Future<Response> statusOfProperty(Map<String, dynamic> dataMap,int id) async {

    var uri = _apiProviderInterface.provideStatusOfPropertyApi(id);
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "prop status");
  }

  Future<Response> deleteProperty(int id) async {
    var uri = _apiProviderInterface.provideDeletePropertyApi(id);
    return doRequestOnRoute(uri, tag: "delete prop");
  }

  Uri provideSavePropertyImagesApi() {
    var uri = _apiProviderInterface.provideSavePropertyImagesApi();
    return uri;
  }

  Future<Response> fetchMyProperties(String status, int page, int perPage,int userId, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideMyPropertiesApi(status,page,perPage,userId);
    return doRequestOnRoute(uri, tag: "get my prop");
  }

  Future<Response> fetchDealsFromActivityResponse(int page, int userId, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideDealsFromActivityApi(page,userId);
    return doRequestOnRoute(uri, tag: "get activity deals");
  }

  Future<Response> fetchDealsFromBoardResponse(int page,int perPage, String tab, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideDealsFromBoardApi(page,perPage,tab);
    return doRequestOnRoute(uri, tag: "get deals");
  }

  Future<Response> fetchAddDealResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddDealResponseApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "add deal", handle500: true);
  }

  Future<Response> fetchLeadsFromBoard(int page, int perPage, {Map<String, dynamic> options}) async {
    var uri = _apiProviderInterface.provideLeadsFromBoardApi(page,perPage);
    return doRequestOnRoute(uri, tag: "get leads");
  }

  Future<Response> fetchDeleteDeal(int id) async {
    var uri = _apiProviderInterface.provideDeleteDealApi(id);
    return doRequestOnRoute(uri, tag: "delete deals");
  }

  Future<Response> fetchAddInquiryResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddInquiryApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "add inquiry", handle500: true);
  }

  Future<Response> fetchDeleteInquiry(int id) async {
    var uri = _apiProviderInterface.provideDeleteInquiryApi(id);
    return doRequestOnRoute(uri, tag: "delete inquiry");
  }

  Future<Response> fetchTermDataApi(String termData) async {
    var uri =  _apiProviderInterface.provideTermDataApi(termData);
    return doRequestOnRoute(uri, tag: "get terms");
  }

  Future<Response> fetchAddOrRemoveFromFavResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddOrRemoveFromFavApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "add or remove from favourites", handle500: true);
  }

  Future<Response> fetchFavProperties(int page, int perPage, String userIdStr) async {
    var uri = _apiProviderInterface.provideFavPropertiesApi(page, perPage, userIdStr);
    return doRequestOnRoute(uri, tag: "get fav prop", useCache: false);
  }

  Future<Response> fetchDeleteLead(int id) async {
    var uri = _apiProviderInterface.provideDeleteLeadApi(id);
    return doRequestOnRoute(uri, tag: "delete lead");
  }

  Future<Response> fetchUpdatePropertyResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideUpdatePropertyApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"update property");
  }

  Future<Response> fetchLatLongArticlesResponse(String lat,String long, String radius) async {
    var data = {
      'search_location': 'true',
      'use_radius': 'on',
      'search_lat': '$lat',
      'search_long': '$long',
      'search_radius': '$radius',
    };
    var uri = _apiProviderInterface.provideLatLongArticlesApi(lat,long);
    return doRequestOnRoute(uri, type:POST, dataMap: data, tag:"property on loc");
  }

  Future<Response> fetchDeleteImageFromEditProperty(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideDeleteImageFromEditPropertyApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "delete image from edit property", handle500: true);
  }

  Future<Response> fetchAddSavedSearch(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddSavedSearchApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"add saved property", handle500: true);
  }

  Future<Response> fetchSavedSearches(int page, int perPage) async {
    var uri = _apiProviderInterface.provideSavedSearches(page, perPage);
    return doRequestOnRoute(uri, tag:"saved searches", useCache: false);
  }

  Future<Response> fetchDeleteSavedSearch(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideDeleteSavedSearchApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"delete saved property", handle500: true);
  }

  Future<Response> fetchSavedSearchArticlesResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideSavedSearchArticlesApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"saved search articles");
  }

  Future<Response> fetchAddReviewResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddReviewApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"add review", handle500: true);
  }

  Future<Response> fetchArticlesReviewsResponse(int id, String page, String perPage) async {
    var uri = _apiProviderInterface.provideArticlesReviewsApi(id, page, perPage);
    return doRequestOnRoute(uri, tag:"article reviews");
  }

  Future<Response> fetchAgentAgencyAuthorReviewsResponse(int id, String page, String perPage, String type) async {
    var uri = _apiProviderInterface.provideAgentAgencyAuthorReviewsApi(id, page, perPage, type);
    return doRequestOnRoute(uri, tag:"agent agency author reviews");
  }

  Future<Response> fetchUserInfoResponse() async {
    var uri = _apiProviderInterface.provideUserInfoApi();
    return doRequestOnRoute(uri, tag:"user info");
  }

  Future<Response> fetchUpdateUserProfileResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideUpdateUserProfileApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"update user profile", handle500: true);
  }

  Future<Response> fetchUpdateUserProfileImageResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideUpdateUserProfileImageApi();
    var path = dataMap["imagepath"];
    var fileName = path.split('/').last;

    // Map data = {
    //   "houzez_file_data_name": await MultipartFile.fromFile(path, filename: fileName),
    // };
    // return doRequestOnRoute(uri, type:POST, dataMap: data, tag:"update user profile image", handle500: true);
    FormData formData = FormData.fromMap({
      "houzez_file_data_name": await MultipartFile.fromFile(path, filename: fileName),
    });
    return doRequestOnRoute(uri, type:POST, formData: formData, tag:"update user profile image", handle500: true);
  }

  Future<Response> fetchDealsAndLeadsFromActivityResponse() async {
    var uri = _apiProviderInterface.provideDealsAndLeadsFromActivityApi();
    return doRequestOnRoute(uri, tag: "board leads");
  }

  Future<Response> fetchSearchAgentsApi(int page, int perPage,String search,String agentCity,String agentCategory) async {
    var uri =  _apiProviderInterface.provideSearchAgentsApi(page, perPage,search,agentCity,agentCategory);
    return doRequestOnRoute(uri, tag: "search agents");
  }

  Future<Response> fetchSearchAgenciesApi(int page,int perPage,String search) async {
    var uri =  _apiProviderInterface.provideSearchAgenciesApi(page, perPage,search);
    return doRequestOnRoute(uri, tag: "Search agencies");
  }

  Future<Response> fetchFixProfileImageResponse() async {
    var uri = _apiProviderInterface.provideFixProfileImageResponseApi();
    return doRequestOnRoute(uri, type: POST, tag: "update user profile", handle500: true);
  }

  Future<Response> fetchIsFavPropertyApi(String listingId) async {
    var uri =  _apiProviderInterface.provideIsFavPropertyAp(listingId);
    return doRequestOnRoute(uri, tag: "is fav property");
  }

  Future<Response> fetchSocialSignOnResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideSocialLoginApi();
    Dio dio = Dio()
      ..interceptors.add(DioCacheManager(CacheConfig()).interceptor);
    return doRequestOnRoute(uri, dio: dio, type: POST, dataMap: dataMap, tag: "social-login", handle403: false);
  }

  Future<Response> fetchPropertiesByTypeResponse(int page,int id,String type) async {
    var uri = _apiProviderInterface.providePropertiesByTypeApi(page, id, type);
    return doRequestOnRoute(uri, tag: "properties by type");
  }

  Future<Response> fetchRealtorInfoApi(int page, String type) async {
    var uri =  _apiProviderInterface.provideRealtorInfoApi(page, type);
    return doRequestOnRoute(uri, tag: "realtor list");
  }

  Future<Response> fetchDeleteUserAccountResponse() async {
    var uri = _apiProviderInterface.provideDeleteUserAccountApi();
    return doRequestOnRoute(uri, type:POST,tag: "delete user account",handle500: true);
  }

  Future<Response> fetchUpdateUserPasswordResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideUpdateUserPasswordApi();
    return doRequestOnRoute(uri, type:POST, dataMap: dataMap, tag:"update password", handle500: true);
  }

  Future<Response> fetchAddLeadResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddLeadResponseApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "add lead", handle500: true);
  }

  Future<Response> fetchSingleArticleViaPermaLinkResponse(String permaLink) async {
    var uri = _apiProviderInterface.provideSingleArticleViaPermaLinkApi(permaLink);
    String str = uri.toString();
    str = GenericMethods.parseHtmlString(str);


    if(str.contains("%3A")){
      str = str.replaceAll("%3A", ":");
    }
    if(str.contains("%2F")){
      str = str.replaceAll("%2F", "/");
    }
    Uri myUri = Uri.parse(str);
    return doRequestOnRoute(myUri, tag: "single article permaLink");
  }

  Future<Response> fetchAddRequestPropertyResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddRequestPropertyApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "request property", handle500: true);
  }

  Future<Response> fetchPropertiesAdsResponse() async {
    Uri uri = _apiProviderInterface.providePropertiesAdsResponseApi();

    return doRequestOnRoute(uri, tag: "Properties Ads");
  }

  Future<Response> fetchAddAgentResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideAddAgentResponseApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "add agent", handle500: true);
  }

  Future<Response> fetchEditAgentResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideEditAgentResponseApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "edit agent", handle500: true);
  }

  Future<Response> fetchDeleteAgentResponse(Map<String, dynamic> dataMap) async {
    var uri = _apiProviderInterface.provideDeleteAgentResponseApi();
    return doRequestOnRoute(uri, type: POST,dataMap: dataMap, tag: "delete agent", handle500: true);
  }

}