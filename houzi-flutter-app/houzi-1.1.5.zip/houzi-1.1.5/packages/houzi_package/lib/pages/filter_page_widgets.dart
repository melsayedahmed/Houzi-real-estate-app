import 'package:flutter/material.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/custom_fields.dart';
import 'package:houzi_package/models/filter_page_config.dart';
import 'package:houzi_package/widgets/add_property_widgets/custom_fields_widgets.dart';
import 'package:houzi_package/widgets/filter_page_widgets/keyword_picker_widget.dart';
import 'package:houzi_package/widgets/filter_page_widgets/location_widget.dart';

import '../common/constants.dart';
import '../files/app_preferences/app_preferences.dart';
import '../files/generic_methods/general_notifier.dart';
import '../files/hive_storage_files/hive_storage_manager.dart';
import '../models/property_meta_data.dart';
import '../widgets/filter_page_widgets/range_slider_widget.dart';
import '../widgets/filter_page_widgets/string_picker.dart';
import '../widgets/filter_page_widgets/term_picker.dart';

typedef FilterPageWidgetsListener = void Function(Map<String,dynamic> filterPageWidgetsListener, String closeOption);

class FilterPageWidgets extends StatefulWidget {

  final FilterPageElement filterPageConfigData;
  final Map<String,dynamic> mapInitializeData;
  final FilterPageWidgetsListener filterPageWidgetsListener;

  const FilterPageWidgets({
    Key key,
    this.filterPageConfigData,
    this.mapInitializeData,
    this.filterPageWidgetsListener,
  }) : super(key: key);

  @override
  State<FilterPageWidgets> createState() => _FilterPageWidgetsState();
}

class _FilterPageWidgetsState extends State<FilterPageWidgets> {

  Map filterPageConfigElementMap = {};
  Map<String, dynamic> _dataInitializationMap = {};

  String _currency = '';
  String _areaType = '';
  String _selectedMinPrice = MIN_PRICE;
  String _selectedMaxPrice = MAX_PRICE;
  String _selectedMinArea = MIN_AREA;
  String _selectedMaxArea = MAX_AREA;
  String _keywordString = "";
  final String _selectedAreaSymbol = MEASUREMENT_UNIT_TEXT;
  final String _selectedCurrencySymbol = HiveStorageManager.readDefaultCurrencyInfoData() ?? "\$";

  List<dynamic> _selectedBedroomsList = [];
  List<dynamic> _selectedBathroomsList = [];

  final List<String> _bathroomsDataList = ["1", "2", "3", "4", "5", "6+"];
  final List<String> _bedroomsDataList = ["1", "2", "3", "4", "5", "6+"];

  Map<String, dynamic> propertyCitiesDataMap = {};
  Map<String, dynamic> propertyTypesDataMap = {};
  Map<String, dynamic> propertyStatusDataMap = {};
  Map<String, dynamic> propertyLabelDataMap = {};
  Map<String, dynamic> propertyAreaDataMap = {};
  Map<String, dynamic> propertyStateDataMap = {};
  Map<String, dynamic> propertyCountryDataMap = {};
  Map<String, dynamic> propertyFeaturesDataMap = {};

  List<dynamic> propertyCitiesDataList = [];
  List<dynamic> propertyTypesDataList = [];
  List<dynamic> propertyStatusDataList = [];
  List<dynamic> propertyLabelDataList = [];
  List<dynamic> propertyAreaDataList = [];
  List<dynamic> propertyStateDataList = [];
  List<dynamic> propertyCountryDataList = [];
  List<dynamic> propertyFeaturesDataList = [];

  List<dynamic> _selectedPropertyTypesList = [];
  List<dynamic> _selectedPropertyStatusList = [];
  List<dynamic> _selectedPropertyLabelsList = [];
  List<dynamic> _selectedPropertyAreasList = [];
  List<dynamic> _selectedPropertyStatesList = [];
  List<dynamic> _selectedPropertyCountriesList = [];
  List<dynamic> _selectedPropertyFeaturesList = [];

  List<dynamic> _selectedPropertyTypesSlugsList = [];
  List<dynamic> _selectedPropertyStatusSlugsList = [];
  List<dynamic> _selectedPropertyLabelsSlugsList = [];
  List<dynamic> _selectedPropertyAreasSlugsList = [];
  List<dynamic> _selectedPropertyStatesSlugsList = [];
  List<dynamic> _selectedPropertyCountriesSlugsList = [];
  List<dynamic> _selectedPropertyFeaturesSlugsList = [];

  List<dynamic> _customFieldsList = [];
  List<String> _customFieldsSectionTypeList = [];

  TextEditingController keywordTextController = TextEditingController();


  bool forReset = false;

  VoidCallback  generalNotifierLister;

  @override
  void initState() {
    super.initState();
    filterPageConfigElementMap = FilterPageElement.toMap(widget.filterPageConfigData);

    var data = HiveStorageManager.readCustomFieldsDataMaps();
    if(data != null){
      final custom = customFromJson(data);
      _customFieldsList = custom.customFields;
      if(_customFieldsList.isNotEmpty){
        for(var customFieldItem in _customFieldsList){
          _customFieldsSectionTypeList.add(CUSTOM_FIELDS_SECTION_TYPE_TEMPLATE_KEY + customFieldItem.label);
        }
      }
    }

    generalNotifierLister = () {
      if (GeneralNotifier().change == GeneralNotifier.RESET_FILTER_DATA) {
        resetData();
      }
    };
    GeneralNotifier().addListener(generalNotifierLister);
    _dataInitializationMap = widget.mapInitializeData;
    loadData();
  }


  bool checkConditionForCustomField() {
    String tempSectionTypeKey = filterPageConfigElementMap[sectionTypeKey] ?? "";
    if(_customFieldsSectionTypeList.isNotEmpty &&
        _customFieldsSectionTypeList.contains(tempSectionTypeKey)){
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyLocation() {
    if (filterPageConfigElementMap[sectionTypeKey] == locationPickerKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForTermPickerWidget() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyStatus() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyStatusDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyType() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyTypeDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyLabel() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyLabelDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyArea() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyAreaDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyState() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyStateDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyCountry() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyCountryDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyFeature() {
    if (filterPageConfigElementMap[sectionTypeKey] == termPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == propertyFeatureDataType) {
      return true;
    }
    return false;
  }
  bool checkConditionForRangePicker() {
    if (filterPageConfigElementMap[sectionTypeKey] == rangePickerKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyPriceRangePicker() {
    if (filterPageConfigElementMap[sectionTypeKey] == rangePickerKey &&
        filterPageConfigElementMap[dataTypeKey] == rangePickerPriceKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyAreaRangePicker() {
    if (filterPageConfigElementMap[sectionTypeKey] == rangePickerKey &&
        filterPageConfigElementMap[dataTypeKey] == rangePickerAreaKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForStringPickerWidget() {
    if (filterPageConfigElementMap[sectionTypeKey] == stringPickerKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyBedrooms() {
    if (filterPageConfigElementMap[sectionTypeKey] == stringPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == stringPickerBedroomsKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyBathrooms() {
    if (filterPageConfigElementMap[sectionTypeKey] == stringPickerKey &&
        filterPageConfigElementMap[dataTypeKey] == stringPickerBathroomsKey) {
      return true;
    }
    return false;
  }
  bool checkConditionForPropertyKeyword() {
    if (filterPageConfigElementMap[sectionTypeKey] == keywordPickerKey) {
      return true;
    }
    return false;
  }

  void loadData() {
    if (_dataInitializationMap != null) {
      if (checkConditionForPropertyType()) {
        if (_dataInitializationMap.containsKey(PROPERTY_TYPE_SLUG) &&
            _dataInitializationMap[PROPERTY_TYPE_SLUG] != null &&
            _dataInitializationMap[PROPERTY_TYPE_SLUG].isNotEmpty) {
          var tempSlugList = _dataInitializationMap[PROPERTY_TYPE_SLUG];
          if (tempSlugList is String) {
            _selectedPropertyTypesSlugsList = [tempSlugList];
          } else if (tempSlugList is List) {
            _selectedPropertyTypesSlugsList = tempSlugList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_TYPE) &&
            _dataInitializationMap[PROPERTY_TYPE] != null &&
            _dataInitializationMap[PROPERTY_TYPE].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_TYPE];
          if (tempList is String) {
            _selectedPropertyTypesList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyTypesList = tempList;
          }
        }
      }

      if (checkConditionForPropertyStatus()) {
        if (_dataInitializationMap.containsKey(PROPERTY_STATUS_SLUG) &&
            _dataInitializationMap[PROPERTY_STATUS_SLUG] != null &&
            _dataInitializationMap[PROPERTY_STATUS_SLUG].isNotEmpty) {
          var tempSlugList = _dataInitializationMap[PROPERTY_STATUS_SLUG];
          if (tempSlugList is String) {
            _selectedPropertyStatusSlugsList = [tempSlugList];
          } else if (tempSlugList is List) {
            _selectedPropertyStatusSlugsList = tempSlugList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_STATUS) &&
            _dataInitializationMap[PROPERTY_STATUS] != null &&
            _dataInitializationMap[PROPERTY_STATUS].isNotEmpty) {
          var tempStatusList = _dataInitializationMap[PROPERTY_STATUS];
          if (tempStatusList is String) {
            _selectedPropertyStatusList = [tempStatusList];
          } else if (tempStatusList is List) {
            _selectedPropertyStatusList = tempStatusList;
          }
        }
      }

      if (checkConditionForPropertyLabel()) {
        if (_dataInitializationMap.containsKey(PROPERTY_LABEL_SLUG) &&
            _dataInitializationMap[PROPERTY_LABEL_SLUG] != null &&
            _dataInitializationMap[PROPERTY_LABEL_SLUG].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_LABEL_SLUG];
          if (tempList is String) {
            _selectedPropertyLabelsSlugsList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyLabelsSlugsList = tempList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_LABEL) &&
            _dataInitializationMap[PROPERTY_LABEL] != null &&
            _dataInitializationMap[PROPERTY_LABEL].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_LABEL];
          if (tempList is String) {
            _selectedPropertyLabelsList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyLabelsList = tempList;
          }
        }
      }

      if (checkConditionForPropertyArea()) {
        if (_dataInitializationMap.containsKey(PROPERTY_AREA_SLUG) &&
            _dataInitializationMap[PROPERTY_AREA_SLUG] != null &&
            _dataInitializationMap[PROPERTY_AREA_SLUG].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_AREA_SLUG];
          if (tempList is String) {
            _selectedPropertyAreasSlugsList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyAreasSlugsList = tempList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_AREA) &&
            _dataInitializationMap[PROPERTY_AREA] != null &&
            _dataInitializationMap[PROPERTY_AREA].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_AREA];
          if (tempList is String) {
            _selectedPropertyAreasList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyAreasList = tempList;
          }
        }
      }

      if (checkConditionForPropertyState()) {
        if (_dataInitializationMap.containsKey(PROPERTY_STATE_SLUG) &&
            _dataInitializationMap[PROPERTY_STATE_SLUG] != null &&
            _dataInitializationMap[PROPERTY_STATE_SLUG].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_STATE_SLUG];
          if (tempList is String) {
            _selectedPropertyStatesSlugsList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyStatesSlugsList = tempList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_STATE) &&
            _dataInitializationMap[PROPERTY_STATE] != null &&
            _dataInitializationMap[PROPERTY_STATE].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_STATE];
          if (tempList is String) {
            _selectedPropertyStatesList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyStatesList = tempList;
          }
        }
      }

      if (checkConditionForPropertyCountry()) {
        if (_dataInitializationMap.containsKey(PROPERTY_COUNTRY_SLUG) &&
            _dataInitializationMap[PROPERTY_COUNTRY_SLUG] != null &&
            _dataInitializationMap[PROPERTY_COUNTRY_SLUG].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_COUNTRY_SLUG];
          if (tempList is String) {
            _selectedPropertyCountriesSlugsList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyCountriesSlugsList = tempList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_COUNTRY) &&
            _dataInitializationMap[PROPERTY_COUNTRY] != null &&
            _dataInitializationMap[PROPERTY_COUNTRY].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_COUNTRY];
          if (tempList is String) {
            _selectedPropertyCountriesList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyCountriesList = tempList;
          }
        }
      }

      if (checkConditionForPropertyFeature()) {
        if (_dataInitializationMap.containsKey(PROPERTY_FEATURES_SLUG) &&
            _dataInitializationMap[PROPERTY_FEATURES_SLUG] != null &&
            _dataInitializationMap[PROPERTY_FEATURES_SLUG].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_FEATURES_SLUG];
          if (tempList is String) {
            _selectedPropertyFeaturesSlugsList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyFeaturesSlugsList = tempList;
          }
        }

        if (_dataInitializationMap.containsKey(PROPERTY_FEATURES) &&
            _dataInitializationMap[PROPERTY_FEATURES] != null &&
            _dataInitializationMap[PROPERTY_FEATURES].isNotEmpty) {
          var tempList = _dataInitializationMap[PROPERTY_FEATURES];
          if (tempList is String) {
            _selectedPropertyFeaturesList = [tempList];
          } else if (tempList is List) {
            _selectedPropertyFeaturesList = tempList;
          }
        }
      }

      if (checkConditionForPropertyPriceRangePicker()) {
        if (_dataInitializationMap.containsKey(PRICE_MIN) &&
            _dataInitializationMap[PRICE_MIN] != null &&
            _dataInitializationMap[PRICE_MIN].isNotEmpty) {
          _selectedMinPrice = _dataInitializationMap[PRICE_MIN];
        } else {
          _selectedMinPrice = MIN_PRICE;
        }

        if (_dataInitializationMap.containsKey(PRICE_MAX) &&
            _dataInitializationMap[PRICE_MAX] != null &&
            _dataInitializationMap[PRICE_MAX].isNotEmpty) {
          _selectedMaxPrice = _dataInitializationMap[PRICE_MAX];
        } else {
          _selectedMaxPrice = MAX_PRICE;
        }
      }

      if (checkConditionForPropertyAreaRangePicker()) {
        if (_dataInitializationMap.containsKey(AREA_MIN) &&
            _dataInitializationMap[AREA_MIN] != null &&
            _dataInitializationMap[AREA_MIN].isNotEmpty) {
          _selectedMinArea = _dataInitializationMap[AREA_MIN];
        } else {
          _selectedMinArea = MIN_AREA;
        }

        if (_dataInitializationMap.containsKey(AREA_MAX) &&
            _dataInitializationMap[AREA_MAX] != null &&
            _dataInitializationMap[AREA_MAX].isNotEmpty) {
          _selectedMaxArea = _dataInitializationMap[AREA_MAX];
        } else {
          _selectedMaxArea = MAX_AREA;
        }
      }

      if (checkConditionForPropertyBedrooms()) {
        if (_dataInitializationMap.containsKey(BEDROOMS) &&
            _dataInitializationMap[BEDROOMS] != null &&
            _dataInitializationMap[BEDROOMS].isNotEmpty) {
          _selectedBedroomsList = _dataInitializationMap[BEDROOMS];
        } else {
          _selectedBedroomsList = [];
        }
      }

      if (checkConditionForPropertyBathrooms()) {
        if (_dataInitializationMap.containsKey(BATHROOMS) &&
            _dataInitializationMap[BATHROOMS] != null &&
            _dataInitializationMap[BATHROOMS].isNotEmpty) {
          _selectedBathroomsList = _dataInitializationMap[BATHROOMS];
        } else {
          _selectedBathroomsList = [];
        }
      }

      if (checkConditionForPropertyKeyword()) {
        if (_dataInitializationMap.containsKey(PROPERTY_KEYWORD) &&
            _dataInitializationMap[PROPERTY_KEYWORD] != null &&
            _dataInitializationMap[PROPERTY_KEYWORD].isNotEmpty) {
          _keywordString = _dataInitializationMap[PROPERTY_KEYWORD];
          keywordTextController.text = _keywordString;
        } else {
          _keywordString = "";
          keywordTextController.text = _keywordString;
        }
      }
      if (mounted) {
        setState(() {});
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (generalNotifierLister != null) {
      GeneralNotifier().removeListener(generalNotifierLister);
    }
  }


  @override
  Widget build(BuildContext context) {
    readTermDataFromStorage();

    return Column(
      children: [
        if (checkConditionForPropertyLocation())
          LocationWidget(
            filterPageConfigData: widget.filterPageConfigData,
            filterDataMap: _dataInitializationMap,
            locationWidgetListener: (Map<String,dynamic> filterData, String closeOption){
              widget.filterPageWidgetsListener(filterData, closeOption);
            },
          ),
        if(checkConditionForTermPickerWidget())
          genericTermPickerWidget(filterPageElement: widget.filterPageConfigData),

        if(checkConditionForRangePicker())
          genericRangePickerWidget(filterPageElement: widget.filterPageConfigData),

        if(checkConditionForStringPickerWidget())
          genericStringPickerWidget(filterPageElement: widget.filterPageConfigData),

        if(checkConditionForPropertyKeyword())
          genericKeywordWidget(filterPageElement: widget.filterPageConfigData),

        if(checkConditionForCustomField())
          genericCustomFieldWidget(filterPageElement: widget.filterPageConfigData),
      ],
    );
  }

  Widget genericCustomFieldWidget({
    @required FilterPageElement filterPageElement,
  }){
    String _tempSectionType = filterPageElement.sectionType;
    String _tempCustomFieldLabel = _tempSectionType.replaceAll(CUSTOM_FIELDS_SECTION_TYPE_TEMPLATE_KEY, "");
    if(_customFieldsList.isNotEmpty) {
      for (var customFieldItem in _customFieldsList) {
        if(customFieldItem.label == _tempCustomFieldLabel){
          return CustomFieldsWidget(
            fromSearchPage: true,
            customFieldData: customFieldItem,
            propertyInfoMap: _dataInitializationMap.containsKey(PROPERTY_CUSTOM_FIELDS) ?
            _dataInitializationMap[PROPERTY_CUSTOM_FIELDS] : {},
            customFieldsPageListener: (Map<String, dynamic> dataMap){
              if(dataMap != null && dataMap.isNotEmpty){
                Map tempDataMap = {};
                // _dataInitializationMap.addAll(dataMap);
                if(_dataInitializationMap.containsKey(PROPERTY_CUSTOM_FIELDS)){
                  tempDataMap.addAll(_dataInitializationMap[PROPERTY_CUSTOM_FIELDS]);
                  tempDataMap.addAll(dataMap);
                }else{
                  tempDataMap.addAll(dataMap);
                }

                if(tempDataMap.containsKey("selectedRadioButton")){
                  tempDataMap.remove("selectedRadioButton");
                }

                _dataInitializationMap[PROPERTY_CUSTOM_FIELDS] = tempDataMap;
                widget.filterPageWidgetsListener(_dataInitializationMap, "");
                setState(() {});
              }
            },
          );
        }
      }
    }

    return Container();

    // return CustomFieldsWidget(
    //   customFieldData: e,
    //   // propertyInfoMap: widget.propertyInfoMap,
    //   customFieldsPageListener: (Map<String, dynamic> _dataMap){
    //     // dataMap.addAll(_dataMap);
    //   },
    // );
  }


  Widget genericTermPickerWidget({
  @required FilterPageElement filterPageElement,
}){
    // IconData iconData = GenericMethods.fromJsonToIconData(filterPageElement.iconData);
    String title = filterPageElement.title;
    String dataType = filterPageElement.dataType;
    String pickerType = filterPageElement.pickerType;

    return TermPicker(
      pickerTitle: GenericMethods.getLocalizedString(title),
      pickerType: pickerType,
      pickerIcon: Icon(
        // iconData,
        getTermPickerIconData(dataType),
        size: AppThemePreferences.filterPageTermPickerIconSize,
        color: AppThemePreferences().appTheme.filterPageIconsColor,
      ),
      termsDataList: getTermDataList(dataType),
      termsDataMap: getTermDataMap(dataType),
      selectedTermsList: getSelectedTermDataList(dataType),
      selectedTermsSlugsList: getSelectedTermSlugsList(dataType),
      termPickerListener: (List<dynamic> selectedTermSlugs, List<dynamic> selectedTerms) {
        updateTermPickerData(
           termDataType: dataType,
           selectedTermsList: selectedTerms,
           selectedTermSlugsList: selectedTermSlugs,
        );
      },
    );
  }

  Widget genericStringPickerWidget({
    @required FilterPageElement filterPageElement,
  }){
    // IconData iconData = GenericMethods.fromJsonToIconData(filterPageElement.iconData);
    String title = filterPageElement.title;
    String dataType = filterPageElement.dataType;
    String pickerType = filterPageElement.pickerType;

    return StringPicker(
      pickerTitle: GenericMethods.getLocalizedString(title),
      pickerType: pickerType,
      pickerIcon: Icon(
        // iconData,
        getStringPickerIconData(dataType),
        size: AppThemePreferences.filterPageStringPickerIconSize,
        color: AppThemePreferences().appTheme.filterPageIconsColor,
      ),
      pickerDataList: getStringPickerDataList(dataType),
      selectedItemsList: getStringPickerSelectedItemsDataList(dataType),
      stringPickerListener: (List<dynamic> _selectedItemsList){
        updateStringPickerData(
          dataType: dataType,
          selectedItemsList: _selectedItemsList,
        );
      }
    );
  }

  Widget genericRangePickerWidget({
    @required FilterPageElement filterPageElement,
  }){
    // IconData iconData = GenericMethods.fromJsonToIconData(filterPageElement.iconData);
    String title = filterPageElement.title;
    String dataType = filterPageElement.dataType;
    String pickerType = filterPageElement.pickerType;
    String rangeMinValue = filterPageElement.minValue;
    String rangeMaxValue = filterPageElement.maxValue;

    return RangePickerWidget(
      pickerTitle: GenericMethods.getLocalizedString(title),
      pickerType: pickerType,
      pickerIcon: Icon(
        // iconData,
        getRangePickerIconData(dataType),
        size: AppThemePreferences.filterPageRangePickerIconSize,
        color: AppThemePreferences().appTheme.filterPageIconsColor,
      ),
      minRange: double.parse(rangeMinValue),
      maxRange: double.parse(rangeMaxValue),
      selectedMinRange: getSelectedMinRange(dataType, rangeMinValue),
      selectedMaxRange: getSelectedMaxRange(dataType, rangeMaxValue),
      pickerSelectedSymbol: getSelectedSymbol(dataType),
      // bottomSheetMenuTitle: getBottomSheetMenuTitle(dataType),
      // mapOfBottomSheetMenu: getBottomSheetMenu(dataType),
      rangePickerListener: (String _selectedSymbol, String _minSelectedRange, String _maxSelectedRange){
        updateRangePickerData(
          dataType: dataType,
          selectedSymbol: _selectedSymbol,
          selectedMinRange: _minSelectedRange,
          selectedMaxRange: _maxSelectedRange,
        );
      },
    );
  }

  Widget genericKeywordWidget({
    @required FilterPageElement filterPageElement,
  }){
    // IconData iconData = GenericMethods.fromJsonToIconData(filterPageElement.iconData);
    String title = filterPageElement.title;
    String pickerType = filterPageElement.pickerType;

    return KeywordPickerWidget(
      pickerTitle: GenericMethods.getLocalizedString(title),
      pickerType: pickerType,
      pickerIcon: Icon(
        // AppThemePreferences.keywordIcon,
        AppThemePreferences.keywordCupertinoIcon,
        size: AppThemePreferences.filterPageRangePickerIconSize,
        color: AppThemePreferences().appTheme.filterPageIconsColor,
      ),
      textEditingController: keywordTextController,
      keywordPickerWidgetListener: (String keyword){
        _keywordString = keyword;
        _dataInitializationMap[PROPERTY_KEYWORD] = _keywordString;
        widget.filterPageWidgetsListener(_dataInitializationMap, "");
        setState(() {});
      },
    );
  }


  resetData(){
    setState(() {
      _dataInitializationMap.clear();
      if(checkConditionForPropertyStatus()){
        _dataInitializationMap[PROPERTY_STATUS] = _selectedPropertyStatusList = [];
        _dataInitializationMap[PROPERTY_STATUS_SLUG] = _selectedPropertyStatusSlugsList = [];
      }
      if(checkConditionForPropertyType()){
        _dataInitializationMap[PROPERTY_TYPE] = _selectedPropertyTypesList =  [];
        _dataInitializationMap[PROPERTY_TYPE_SLUG] = _selectedPropertyTypesSlugsList =  [];
      }
      if(checkConditionForPropertyLabel()){
        _dataInitializationMap[PROPERTY_LABEL] = _selectedPropertyLabelsList = [];
        _dataInitializationMap[PROPERTY_LABEL_SLUG] = _selectedPropertyLabelsSlugsList = [];
      }
      if(checkConditionForPropertyArea()){
        _dataInitializationMap[PROPERTY_AREA] = _selectedPropertyAreasList = [];
        _dataInitializationMap[PROPERTY_AREA_SLUG] = _selectedPropertyAreasSlugsList = [];
      }
      if(checkConditionForPropertyState()){
        _dataInitializationMap[PROPERTY_STATE] = _selectedPropertyStatesList = [];
        _dataInitializationMap[PROPERTY_STATE_SLUG] = _selectedPropertyStatesSlugsList = [];
      }
      if(checkConditionForPropertyCountry()){
        _dataInitializationMap[PROPERTY_COUNTRY] = _selectedPropertyCountriesList = [];
        _dataInitializationMap[PROPERTY_COUNTRY_SLUG] = _selectedPropertyCountriesSlugsList = [];
      }
      if(checkConditionForPropertyFeature()){
        _dataInitializationMap[PROPERTY_FEATURES] = _selectedPropertyFeaturesList = [];
        _dataInitializationMap[PROPERTY_FEATURES_SLUG] = _selectedPropertyFeaturesSlugsList = [];
      }

      if(checkConditionForPropertyLocation()){
        _dataInitializationMap[CITY] = "";
        _dataInitializationMap[CITY_ID] = null;
        _dataInitializationMap[CITY_SLUG] = "";
        _dataInitializationMap[LATITUDE] = "";
        _dataInitializationMap[LONGITUDE] = "";
        _dataInitializationMap[SELECTED_LOCATION] = PLEASE_SELECT;
        _dataInitializationMap[RADIUS] = "50.0";
        _dataInitializationMap[USE_RADIUS] = "off";
        _dataInitializationMap[SEARCH_LOCATION] = "false";
      }

      if(checkConditionForPropertyPriceRangePicker()){
        _dataInitializationMap.remove(PRICE_MIN);
        _dataInitializationMap.remove(PRICE_MAX);
        _selectedMinPrice = MIN_PRICE;
        _selectedMaxPrice = MAX_PRICE;
      }

      if(checkConditionForPropertyAreaRangePicker()){
        _dataInitializationMap.remove(AREA_MIN);
        _dataInitializationMap.remove(AREA_MAX);
        _selectedMaxArea = MAX_AREA;
        _selectedMinArea = MIN_AREA;
      }

      if(checkConditionForPropertyBedrooms()){
        _selectedBedroomsList = [];
        _dataInitializationMap.remove(BEDROOMS);
      }
      if(checkConditionForPropertyBathrooms()){
        _selectedBathroomsList = [];
        _dataInitializationMap.remove(BATHROOMS);
      }
      if(checkConditionForPropertyKeyword()){
        _keywordString = "";
        _dataInitializationMap.remove(PROPERTY_KEYWORD);
        keywordTextController.text = "";
      }
    });
    HiveStorageManager.storeFilterDataInfo(map: _dataInitializationMap);
    widget.filterPageWidgetsListener(_dataInitializationMap, RESET);
  }

  IconData getTermPickerIconData(String dataType) {
    if(dataType == propertyStatusDataType){
      return AppThemePreferences.checkCircleIcon;
    }

    return AppThemePreferences.locationCityIcon;
  }

  List<dynamic> getTermDataList(String termDataType){
    if(termDataType == propertyStatusDataType){
      return propertyStatusDataList;
    }
    else if(termDataType == propertyTypeDataType){
      return propertyTypesDataList;
    }
    else if(termDataType == propertyLabelDataType){
      return propertyLabelDataList;
    }
    else if(termDataType == propertyAreaDataType){
      return propertyAreaDataList;
    }
    else if(termDataType == propertyStateDataType){
      return propertyStateDataList;
    }
    else if(termDataType == propertyCountryDataType){
      return propertyCountryDataList;
    }
    else if(termDataType == propertyFeatureDataType){
      return propertyFeaturesDataList;
    }
    return [];
  }

  Map<String, dynamic> getTermDataMap(String termDataType){
    if(termDataType == propertyStatusDataType){
      return propertyStatusDataMap;
    }
    else if(termDataType == propertyTypeDataType){
      return propertyTypesDataMap;
    }
    else if(termDataType == propertyLabelDataType){
      return propertyLabelDataMap;
    }
    else if(termDataType == propertyAreaDataType){
      return propertyAreaDataMap;
    }
    else if(termDataType == propertyStateDataType){
      return propertyStateDataMap;
    }
    else if(termDataType == propertyCountryDataType){
      return propertyCountryDataMap;
    }
    else if(termDataType == propertyFeatureDataType){
      return propertyFeaturesDataMap;
    }
    return {};
  }

  List<dynamic> getSelectedTermDataList(String termDataType){
    if(termDataType == propertyStatusDataType){
      return _selectedPropertyStatusList;
    }
    else if(termDataType == propertyTypeDataType){
      return _selectedPropertyTypesList;
    }
    else if(termDataType == propertyLabelDataType){
      return _selectedPropertyLabelsList;
    }
    else if(termDataType == propertyAreaDataType){
      return _selectedPropertyAreasList;
    }
    else if(termDataType == propertyStateDataType){
      return _selectedPropertyStatesList;
    }
    else if(termDataType == propertyCountryDataType){
      return _selectedPropertyCountriesList;
    }
    else if(termDataType == propertyFeatureDataType){
      return _selectedPropertyFeaturesList;
    }
    return [];
  }

  List<dynamic> getSelectedTermSlugsList(String termDataType){
    if(termDataType == propertyStatusDataType){
      return _selectedPropertyStatusSlugsList;
    }
    else if(termDataType == propertyTypeDataType){
      return _selectedPropertyTypesSlugsList;
    }
    else if(termDataType == propertyLabelDataType){
      return _selectedPropertyLabelsSlugsList;
    }
    else if(termDataType == propertyAreaDataType){
      return _selectedPropertyAreasSlugsList;
    }
    else if(termDataType == propertyStateDataType){
      return _selectedPropertyStatesSlugsList;
    }
    else if(termDataType == propertyCountryDataType){
      return _selectedPropertyCountriesSlugsList;
    }
    else if(termDataType == propertyFeatureDataType){
      return _selectedPropertyFeaturesSlugsList;
    }
    return [];
  }

  updateTermPickerData({
    @required String termDataType,
    @required List<dynamic> selectedTermsList,
    @required List<dynamic> selectedTermSlugsList,
}){
   if(termDataType == propertyStatusDataType){
     _selectedPropertyStatusList = selectedTermsList;
     _selectedPropertyStatusSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_STATUS] = _selectedPropertyStatusList.toSet().toList();
     _dataInitializationMap[PROPERTY_STATUS_SLUG] = _selectedPropertyStatusSlugsList.toSet().toList();
   }
   else if(termDataType == propertyTypeDataType){
     _selectedPropertyTypesList = selectedTermsList;
     _selectedPropertyTypesSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_TYPE] = _selectedPropertyTypesList.toSet().toList();
     _dataInitializationMap[PROPERTY_TYPE_SLUG] = _selectedPropertyTypesSlugsList.toSet().toList();
   }
   else if(termDataType == propertyLabelDataType){
     _selectedPropertyLabelsList = selectedTermsList;
     _selectedPropertyLabelsSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_LABEL] = _selectedPropertyLabelsList.toSet().toList();
     _dataInitializationMap[PROPERTY_LABEL_SLUG] = _selectedPropertyLabelsSlugsList.toSet().toList();
   }
   else if(termDataType == propertyAreaDataType){
     _selectedPropertyAreasList = selectedTermsList;
     _selectedPropertyAreasSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_AREA] = _selectedPropertyAreasList.toSet().toList();
     _dataInitializationMap[PROPERTY_AREA_SLUG] = _selectedPropertyAreasSlugsList.toSet().toList();
   }
   else if(termDataType == propertyStateDataType){
     _selectedPropertyStatesList = selectedTermsList;
     _selectedPropertyStatesSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_STATE] = _selectedPropertyStatesList.toSet().toList();
     _dataInitializationMap[PROPERTY_STATE_SLUG] = _selectedPropertyStatesSlugsList.toSet().toList();
   }
   else if(termDataType == propertyCountryDataType){
     _selectedPropertyCountriesList = selectedTermsList;
     _selectedPropertyCountriesSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_COUNTRY] = _selectedPropertyCountriesList.toSet().toList();
     _dataInitializationMap[PROPERTY_COUNTRY_SLUG] = _selectedPropertyCountriesSlugsList.toSet().toList();
   }
   else if(termDataType == propertyFeatureDataType){
     _selectedPropertyFeaturesList = selectedTermsList;
     _selectedPropertyFeaturesSlugsList = selectedTermSlugsList;
     _dataInitializationMap[PROPERTY_FEATURES] = _selectedPropertyFeaturesList.toSet().toList();
     _dataInitializationMap[PROPERTY_FEATURES_SLUG] = _selectedPropertyFeaturesSlugsList.toSet().toList();
   }
   widget.filterPageWidgetsListener(_dataInitializationMap, "");
   setState(() {});
  }
  
  readTermDataFromStorage(){
    if (checkConditionForPropertyStatus()){
      Map<String, dynamic> tempPropertyStatusMapMetaData = {};
      tempPropertyStatusMapMetaData = HiveStorageManager.readPropertyStatusMapData();
      propertyStatusDataList = HiveStorageManager.readPropertyStatusMetaData();

      if(propertyStatusDataList != null && propertyStatusDataList.isNotEmpty){
        if(propertyStatusDataList[0].name != "All"){
          propertyStatusDataList.insert(0, PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }

      if(tempPropertyStatusMapMetaData != null && tempPropertyStatusMapMetaData.isNotEmpty){
        // propertyStatusDataMap = tempPropertyStatusMapMetaData;
        if(!propertyStatusDataMap.containsKey("All")){
          // propertyStatusDataMap.clear();
          propertyStatusDataMap["All"] = [];
          propertyStatusDataMap.addAll(tempPropertyStatusMapMetaData);
        }
      }
    }
    
    if (checkConditionForPropertyType()){
      Map<String, dynamic> tempPropertyTypesMapMetaData = {};
      tempPropertyTypesMapMetaData = HiveStorageManager.readPropertyTypesMapData();
      propertyTypesDataList = HiveStorageManager.readPropertyTypesMetaData();

      if(propertyTypesDataList != null && propertyTypesDataList.isNotEmpty){
        if(propertyTypesDataList[0].name != "All"){
          propertyTypesDataList.insert(0,  PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }

      if(tempPropertyTypesMapMetaData != null && tempPropertyTypesMapMetaData.isNotEmpty){
        // propertyTypesDataMap = tempPropertyTypesMapMetaData;
        if(!propertyTypesDataMap.containsKey("All")){
          // propertyTypesDataMap.clear();
          propertyTypesDataMap["All"] = [];
          propertyTypesDataMap.addAll(tempPropertyTypesMapMetaData);
        }
      }
    }
    
    if (checkConditionForPropertyLabel()){
      propertyLabelDataList = HiveStorageManager.readPropertyLabelsMetaData();

      if(propertyLabelDataList != null && propertyLabelDataList.isNotEmpty){
        if(propertyLabelDataList[0].name != "All"){
          propertyLabelDataList.insert(0, PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }
    }
    
    if (checkConditionForPropertyArea()){
      propertyAreaDataList = HiveStorageManager.readPropertyAreaMetaData();

      if(propertyAreaDataList != null && propertyAreaDataList.isNotEmpty){
        if(propertyAreaDataList[0].name != "All"){
          propertyAreaDataList.insert(0, PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }
    }
    
    if (checkConditionForPropertyState()){
      propertyStateDataList = HiveStorageManager.readPropertyStatesMetaData();

      if(propertyStateDataList != null && propertyStateDataList.isNotEmpty){
        if(propertyStateDataList[0].name != "All"){
          propertyStateDataList.insert(0, PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }
    }
    
    if (checkConditionForPropertyCountry()){
      propertyCountryDataList = HiveStorageManager.readPropertyCountriesMetaData();

      if(propertyCountryDataList != null && propertyCountryDataList.isNotEmpty){
        if(propertyCountryDataList[0].name != "All"){
          propertyCountryDataList.insert(0, PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }
    }
    
    if (checkConditionForPropertyFeature()){
      propertyFeaturesDataList = HiveStorageManager.readPropertyFeaturesMetaData();

      if(propertyFeaturesDataList != null && propertyFeaturesDataList.isNotEmpty){
        if(propertyFeaturesDataList[0].name != "All"){
          propertyFeaturesDataList.insert(0, PropertyMetaData(id: 1, name:"All", slug:"all"));
        }
      }
    }
  }

  IconData getStringPickerIconData(String dataType) {
    if(dataType == stringPickerBedroomsKey){
      return AppThemePreferences.bedIcon;
    }
    else if(dataType == stringPickerBathroomsKey){
      return AppThemePreferences.bathtubIcon;
    }
    return null;
  }

  List<String> getStringPickerDataList(String dataType) {
    if(dataType == stringPickerBedroomsKey){
      return _bedroomsDataList;
    }
    else if(dataType == stringPickerBathroomsKey){
      return _bathroomsDataList;
    }
    return [];
  }

  List<dynamic> getStringPickerSelectedItemsDataList(String dataType) {
    if(dataType == stringPickerBedroomsKey){
      return _selectedBedroomsList;
    }
    else if(dataType == stringPickerBathroomsKey){
      return _selectedBathroomsList;
    }
    return [];
  }

  updateStringPickerData({
    @required String dataType,
    @required List<dynamic> selectedItemsList,
  }){
    if(dataType == stringPickerBedroomsKey){
      _selectedBedroomsList = selectedItemsList;
      _dataInitializationMap[BEDROOMS] = _selectedBedroomsList;
    }
    else if(dataType == stringPickerBathroomsKey){
      _selectedBathroomsList = selectedItemsList;
      _dataInitializationMap[BATHROOMS] = _selectedBathroomsList;
    }

    setState(() {});
    widget.filterPageWidgetsListener(_dataInitializationMap, "");
  }

  IconData getRangePickerIconData(String dataType) {
    if(dataType == rangePickerPriceKey){
      return AppThemePreferences.priceTagIcon;
    }
    else if(dataType == rangePickerAreaKey){
      return AppThemePreferences.areaSizeIcon;
    }
    return null;
  }

  double getSelectedMinRange(String dataType, String rangeMinValue) {
    if(dataType == rangePickerPriceKey){
      return double.parse(_selectedMinPrice);
    }
    else if(dataType == rangePickerAreaKey){
      return double.parse(_selectedMinArea);
    }
    return null;
  }

  double getSelectedMaxRange(String dataType, String rangeMaxValue) {
    if(dataType == rangePickerPriceKey){
      if(double.parse(_selectedMaxPrice) > double.parse(rangeMaxValue)){
        _selectedMaxPrice = rangeMaxValue;
        return double.parse(rangeMaxValue);
      }
      return double.parse(_selectedMaxPrice);
    }
    else if(dataType == rangePickerAreaKey){
      if(double.parse(_selectedMaxArea) > double.parse(rangeMaxValue)){
        _selectedMaxArea = rangeMaxValue;
        return double.parse(rangeMaxValue);
      }
      return double.parse(_selectedMaxArea);
    }
    return null;
  }

  String getSelectedSymbol(String dataType) {
    if(dataType == rangePickerPriceKey){
      return _selectedCurrencySymbol;
    }
    else if(dataType == rangePickerAreaKey){
      return _selectedAreaSymbol;
    }
    return null;
  }
  String getRangePickerNumberFormatter(String dataType) {
    if(dataType == rangePickerPriceKey){
      return "#,###";
    }
    return null;
  }

  updateRangePickerData({
    @required String dataType,
    @required String selectedSymbol,
    @required String selectedMinRange,
    @required String selectedMaxRange,
  }){
    if(dataType == rangePickerPriceKey){
      _currency = selectedSymbol;

      if(selectedMinRange.contains(",")){
        _selectedMinPrice = selectedMinRange.replaceAll(",", "");
      }else{
        _selectedMinPrice = selectedMinRange;
      }

      if(selectedMaxRange.contains(",")){
        _selectedMaxPrice = selectedMaxRange.replaceAll(",", "");
      }else{
        _selectedMaxPrice = selectedMaxRange;
      }

      _dataInitializationMap[CURRENCY_SYMBOL] = _currency;
      _dataInitializationMap[PRICE_MIN] = _selectedMinPrice;
      _dataInitializationMap[PRICE_MAX] = _selectedMaxPrice;
    }
    else if(dataType == rangePickerAreaKey){
      _areaType = selectedSymbol;

      if(selectedMinRange.contains(",")){
        _selectedMinArea = selectedMinRange.replaceAll(",", "");
      }else{
        _selectedMinArea = selectedMinRange;
      }

      if(selectedMaxRange.contains(",")){
        _selectedMaxArea = selectedMaxRange.replaceAll(",", "");
      }else{
        _selectedMaxArea = selectedMaxRange;
      }

      _dataInitializationMap[AREA_MAX] = _selectedMaxArea;
      _dataInitializationMap[AREA_MIN] = _selectedMinArea;
      _dataInitializationMap[AREA_TYPE] = _areaType;
    }

    setState(() {});
    widget.filterPageWidgetsListener(_dataInitializationMap, "");
  }

  // String getBottomSheetMenuTitle(String dataType) {
  //   if(dataType == rangePickerAreaKey){
  //     return AppLocalizations.of(context).change_area_unit;
  //   }
  //
  //   return null;
  // }
  //
  // Map<String, String> getBottomSheetMenu(String dataType) {
  //   if(dataType == rangePickerAreaKey){
  //     return _mapOfPropertyAreaRange;
  //   }
  //
  //   return null;
  // }
}