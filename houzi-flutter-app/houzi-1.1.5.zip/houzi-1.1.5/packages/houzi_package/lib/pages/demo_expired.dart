import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';

import '../files/generic_methods/generic_methods.dart';

class DemoExpired extends StatefulWidget {
  DemoExpired();

  @override
  _FavoritesState createState() => _FavoritesState();
}

class _FavoritesState extends State<DemoExpired> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        return Future.value(false);
      },
      child: Scaffold(
        body: noResultFoundPage(),
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      showBackNavigationIcon: false,
      hideGoBackButton: true,
      headerErrorText: GenericMethods.getLocalizedString("demo_version_expired"),
      bodyErrorText: GenericMethods.getLocalizedString("contact_developer_for_latest_version"),
    );
  }
}
