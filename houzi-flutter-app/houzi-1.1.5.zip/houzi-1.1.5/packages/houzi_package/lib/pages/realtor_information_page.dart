import 'package:dio/dio.dart';
import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/item_design_files/item_design_notifier.dart';
import 'package:houzi_package/files/user_log_provider.dart';
import 'package:houzi_package/models/realtor_model.dart';
import 'package:houzi_package/pages/property_details_page.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:houzi_package/pages/send_email_to_realtor.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/article_box_widgets/article_box_design.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/shimmer_effect_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:material_segmented_control/material_segmented_control.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../widgets/review_related_widgets/add_review_page.dart';
import '../widgets/review_related_widgets/reviews_widget.dart';
import 'home_screen_drawer_menu_pages/user_related/user_signin.dart';

class RealtorInformationDisplayPage extends StatefulWidget{
  final String heroId;
  final String agentType;
  final Map<String, dynamic> realtorInformation;

  @override
  State<StatefulWidget> createState() => RealtorInformationDisplayPageState();

  RealtorInformationDisplayPage({
    this.heroId,
    this.agentType,
    this.realtorInformation,
  });
}

class RealtorInformationDisplayPageState extends State<RealtorInformationDisplayPage> with TickerProviderStateMixin {

  var item;
  String totalRating = "";
  final PropertyBloc _propertyBloc = PropertyBloc();

  int realtorId;
  int page = 1;
  int perPage = 3;

  bool isAgent = false;
  bool isAgency = false;
  bool isAuthor = false;
  bool isReadMore = false;
  bool showListings = false;
  bool isSubRealtorsEmpty = false;
  bool isListingButtonClicked = true;
  bool isSubRealtorButtonClicked = false;
  bool showMoreButton = false;
  bool isLoggedIn = false;
  bool isInternetConnected = true;
  bool emailDeliveryCheck = true;

  String address = "";
  String license = "";
  String taxNumber = "";
  String phoneNumber = "";
  String mobileNumber = "";
  String faxNumber = "";
  String email = "";
  String image = "";
  String link = "";
  String title;
  // String title = "";
  String whatsappNumber = "";
  String content = "";
  String agentPosition = "";
  String agentCompany = "";
  String agentServiceAreas = "";
  String agentSpecialties = "";
  String articleBoxDesign = "";
  String reviewPostType = "";
  String appName = '';
  String type = '';

  List<dynamic> agencyOrAgentsList = [];
  List<dynamic> realtorListings = [];
  List<dynamic> tabList = [];

  Future<List<dynamic>> _futureProperties;
  Future<List<dynamic>> _futureSubRealtors;

  bool showReviews = true;
  bool showListingsFromTab = false;

  int _currentSelection = 0;

  int tempIndexListing = 0;
  int tempIndexRealtor = 1;

  bool showAgentAgency = false;
  bool showPropertyListings = false;

  String _userRole;

  @override
  void initState() {
    super.initState();

    appName = HiveStorageManager.readAppInfo()[APP_INFO_APP_NAME] ?? "";

    if(Provider.of<UserLoggedProvider>(context,listen: false).isLoggedIn){
      if(mounted){
        setState(() {
          isLoggedIn = true;
        });
      }
    }

    type = checkType(widget.agentType);

    if(widget.realtorInformation.containsKey(AGENCY_DATA)) {
      setState(() {
        isAgency = true;
        item = widget.realtorInformation[AGENCY_DATA];
        realtorId = item.id;
        image = item.thumbnail?? "";
        title = item.title;
        content = GenericMethods.stripHtmlIfNeeded(item.content);
        address = item.agencyMapAddress;
        license = item.agencyLicenseNumber;
        taxNumber = item.agencyTaxNumber;
        phoneNumber = item.agencyPhoneNumber;
        mobileNumber = item.agencyMobileNumber;
        faxNumber = item.agencyFaxNumber;
        email = item.email;
        link = item.agencyLink;
        whatsappNumber = item.agencyWhatsappNumber;
        var tempRatingData = item.totalRating;
        if(tempRatingData != null && tempRatingData.isNotEmpty){
          double tempTotalRating = double.parse(tempRatingData);
          totalRating = tempTotalRating.toStringAsFixed(0);
        }
      });
    }else if(widget.realtorInformation.containsKey(AGENT_DATA)) {
      setState(() {
        isAgent = true;
        item = widget.realtorInformation[AGENT_DATA];
        realtorId = item.id ?? int.tryParse(item.agentId);
        image = item.thumbnail ?? "";
        title = item.title;
        content = GenericMethods.stripHtmlIfNeeded(item.content) ?? "";
        address = item.agentAddress ?? "";
        license = item.agentLicenseNumber;
        taxNumber = item.agentTaxNumber;
        phoneNumber = item.agentOfficeNumber;
        mobileNumber = item.agentMobileNumber;
        faxNumber = item.agentFaxNumber;
        email = item.email;
        link = item.agentLink;
        var tempRatingData = item.totalRating;
        if(tempRatingData != null && tempRatingData.isNotEmpty) {
          double tempTotalRating = double.parse(tempRatingData);
          totalRating = tempTotalRating.toStringAsFixed(0);
        }
        agentPosition = item.agentPosition;
        agentCompany = item.agentCompany;
        agentServiceAreas = item.agentServiceArea;
        agentSpecialties = item.agentSpecialties;
        whatsappNumber = item.agentWhatsappNumber;
      });
    }else if(widget.realtorInformation.containsKey(AUTHOR_DATA)) {
      setState(() {
        isAuthor = true;
        isSubRealtorsEmpty = true;
        // isListingButtonClicked = false;

        item = widget.realtorInformation[AUTHOR_DATA];
        realtorId = item[tempRealtorIdKey];
        title = item[tempRealtorNameKey] ?? "";
        image = item[tempRealtorThumbnailKey] ?? "";
        mobileNumber = item[tempRealtorMobileKey] ?? "";
        phoneNumber = item[tempRealtorPhoneKey] ?? "";
        whatsappNumber = item[tempRealtorWhatsAppKey] ?? "";
        email = item[tempRealtorEmailKey] ?? "";

        // var tempRatingData = item.totalRating;
        // if(tempRatingData != null && tempRatingData.isNotEmpty){
        //   double tempTotalRating = double.parse(tempRatingData);
        //   totalRating = tempTotalRating.toStringAsFixed(0);
        // }
      });
    }
    loadData();
    // checkInternetAndLoadData();
  }

  checkInternetAndLoadData(){
    // InternetConnectionChecker().checkInternetConnection().then((value){
    //   if(value){
    //     setState(() {
    //       isInternetConnected = true;
    //     });
    //     loadData();
    //   }else{
    //     setState(() {
    //       isInternetConnected = false;
    //     });
    //   }
    //   return null;
    // });
    loadData();
  }

  loadData(){
    // if (SHOW_REVIEWS) {
    //   tabList = [GenericMethods.getLocalizedString("error_occurred")reviews];
    // }

    if(isAgency){
      _futureProperties = fetchProperties(realtorId, page, perPage);
      _futureProperties.then((value) {
        if(value.isNotEmpty){
          //if (_userRole == ROLE_ADMINISTRATOR) {
            _futureSubRealtors = fetchAgents(realtorId);
          //}
        }
        return null;
      });


    }else if(isAgent) {
      _futureProperties = fetchProperties(realtorId, page, perPage);
      _futureProperties.then((value) {
        if(value.isNotEmpty) {
          if (item.agentAgencies != null) {
            int agencyId = int.parse(item.agentAgencies[0]);
            //if (_userRole == ROLE_ADMINISTRATOR) {
              _futureSubRealtors = fetchAgency(agencyId);
            //}
          }
        }
        return null;
      });


    }else if(isAuthor){
      _futureProperties = fetchProperties(realtorId, page, perPage);
      _futureProperties.then((value) {
        if(value != null && value.isNotEmpty){
          if(mounted){
            setState(() {
              showListings = true;
              isListingButtonClicked = true;
            });
          }
        }
        return null;
      });
    }

    type = checkType(widget.agentType);
  }

  @override
  void didChangeDependencies() {
    if (SHOW_REVIEWS) {
      tabList = [GenericMethods.getLocalizedString("reviews")];
    }
    super.didChangeDependencies();
  }

  @override
  dispose() {
    realtorListings = [];
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
        context,
        appBarTitle: title ?? GenericMethods.getLocalizedString("realtor_info"),
      ),
      body: Stack(
        children: [
          RefreshIndicator(
            onRefresh: () async {
              setState(() {
                agencyOrAgentsList.clear();
                realtorListings.clear();
                tabList.clear();
                _currentSelection = 0;
                tempIndexListing = 0;
                tempIndexRealtor = 1;
              });
              loadData();
              return null;
            },
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children: [
                  realtorInfo(),
                  addressWidget(),
                  licenseNumberWidget(),
                  taxNumberWidget(),
                  serviceAreasAndSpecialitiesWidget(),
                  descriptionWidget(),
                  tabList.length == 1 ? Container() : tabBarViewWidget(),
                  if (SHOW_REVIEWS)
                    _currentSelection == 0
                        ? ReviewsWidget(
                      fromProperty: false,
                      idForReviews: realtorId,
                      link: link,
                      title: title,
                      totalRating: totalRating,
                      type: type,
                    )
                        : Container(),
                  if(showPropertyListings)
                    headingWidget(text:GenericMethods.getLocalizedString("listings")),
                  listings(_futureProperties),
                  if(showAgentAgency)
                    headingWidget(text: isAgent?GenericMethods.getLocalizedString("agency"):GenericMethods.getLocalizedString("agents")),
                  realtorInformationDisplayWidget(_futureSubRealtors),
                  moreElevatedButtonWidget(),
                  contactWidget(),
                ],
              ),
            ),
          ),

        ],
      ),
      bottomNavigationBar: BottomAppBar(

        child: bottomActionBarWidget(),
      ),
    );
  }
  String phoneOrMobile() {
    if (mobileNumber != null && mobileNumber.isNotEmpty) {
      return mobileNumber;
    }
    return phoneNumber;
  }

  Widget bottomActionBarWidget() {
    //if(!isInternetConnected) noInternetBottomActionBar(context, ()=> checkInternetAndLoadData())
    return SizedBox(
      height: 55,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: AppThemePreferences().appTheme.backgroundColor.withOpacity(0.8),
          border: Border(top: AppThemePreferences().appTheme.propertyDetailsPageBottomMenuBorderSide,),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 1,
              child: sendEmailElevatedButtonWidget(),
            ),
            phoneOrMobile() != null && phoneOrMobile().isNotEmpty ? const SizedBox(width: 5) : Container(),
            phoneOrMobile() != null && phoneOrMobile().isNotEmpty ?
            Expanded(
              flex: 1,
              child: callElevatedButtonWidget(phoneOrMobile()),
            ) : Container(),
            whatsappNumber != null && whatsappNumber.isNotEmpty ? const SizedBox(width: 5) : Container(),
            whatsappNumber != null && whatsappNumber.isNotEmpty ?
            Expanded(
              flex: 1,
              child: whatsappElevatedButtonWidget(),
            ) : Container(),
          ],
        ),
      ),
    );
  }

  Widget realtorInfo(){
    bool _validURL = GenericMethods.validateURL(image);
    return Container(
      alignment: Alignment.topLeft,
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
      child: Row(
        children: [
          Container(
            child: Container(
              decoration: BoxDecoration(
                color: AppThemePreferences().appTheme.containerBackgroundColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Card(
                shape: AppThemePreferences.roundedCorners(AppThemePreferences.realtorPageRoundedCornersRadius),
                child: SizedBox(
                  height: 90,
                  width: 90,
                  child: Hero(
                    tag: widget.heroId,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: !_validURL? shimmerEffectErrorWidget(iconSize: 100) : FancyShimmerImage(
                        imageUrl: GenericMethods.validateURL(image) ? image :shimmerEffectErrorWidget(iconSize: 100),
                        boxFit: BoxFit.cover,
                        shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
                        shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
                        errorWidget: shimmerEffectErrorWidget(iconSize: 70.0, iconData: AppThemePreferences.personIcon),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 15, right: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  genericTextWidget(
                    title,
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.heading01TextStyle,
                  ),
                  agentPositionWidget(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget imageWidget(){
    bool _validURL = GenericMethods.validateURL(image);
    return Card(
      shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
      child: SizedBox(
        width: double.infinity,
        height: 400,
        child: Hero(
          tag: widget.heroId,
          child: !_validURL? shimmerEffectErrorWidget(iconSize: 100) : FancyShimmerImage(
            // imageUrl: _validURL ? image :shimmerEffectErrorWidget(iconSize: 100),
            imageUrl: GenericMethods.validateURL(image) ? image :shimmerEffectErrorWidget(iconSize: 100),
            boxFit: BoxFit.cover,
            shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
            shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
            errorWidget: shimmerEffectErrorWidget(iconSize: 50.0),
          ),
        ),
      ),
    );
  }

  Widget agentPositionWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (agentPosition != null && agentPosition.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: genericTextWidget(
              "${item.agentPosition} at ",
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.bodyTextStyle,
            ),
          ),
        if (agentCompany != null && agentCompany.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: genericTextWidget(
              "${item.agentCompany}",
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.heading02TextStyle,
            ),
          ),
      ],
    );
  }

  Widget addressWidget(){
    return address != null && address.isNotEmpty ?
    Container(
      padding: const EdgeInsets.fromLTRB(10, 5, 20, 20),
      child: Row(
        children: [
          const Expanded(
            flex: 1,
            child: Icon(
              Icons.location_on,
            ),
          ),
          Expanded(
            flex: 9,
            child: genericTextWidget(
              address,
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.bodyTextStyle,
              textAlign: TextAlign.justify,
            ),
          ),
        ],
      ),
    )
        : Container(
      padding: const EdgeInsets.only(bottom: 20),
    );
  }

  Widget licenseNumberWidget(){
    return license !=null && license.isNotEmpty ? Container(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 5),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: genericTextWidget(
              GenericMethods.getLocalizedString("license"),
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.label01TextStyle,
            ),
          ),
          Expanded(
            flex: 3,
            child: genericTextWidget(
              license,
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.subBody01TextStyle,
            ),
          ),
        ],
      ),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: AppThemePreferences().appTheme.dividerColor)),
      ),
    ) : Container();
  }

  Widget taxNumberWidget(){
    return taxNumber!=null && taxNumber.isNotEmpty ? Container(
      padding: const EdgeInsets.fromLTRB(20, 5, 20, 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 2,
            child: genericTextWidget(
              GenericMethods.getLocalizedString("tax_number"),
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.label01TextStyle,
            ),
          ),
          Expanded(
            flex:3,
            child: genericTextWidget(
              taxNumber,
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.subBody01TextStyle,
            ),
          ),
        ],
      ),
    ): Container();
  }

  Widget serviceAreasAndSpecialitiesWidget(){
    return (agentServiceAreas!=null && agentServiceAreas.isNotEmpty) || (agentSpecialties !=null && agentSpecialties.isNotEmpty) ? Container(
      padding: const EdgeInsets.fromLTRB(20, 5, 20, 10),
      child: Column(
        children: [
          agentServiceAreas!=null && agentServiceAreas.isNotEmpty ? Container(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  flex: 2,
                  child: genericTextWidget(
                    GenericMethods.getLocalizedString("service_areas"),
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.label01TextStyle,

                  ),
                ),
                Expanded(
                  flex: 3,
                  child: genericTextWidget(
                    agentServiceAreas,
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.subBody01TextStyle,
                  ),
                ),
              ],
            ),
          ) : Container(),
          agentSpecialties!=null && agentSpecialties.isNotEmpty ? Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 2,
                child: genericTextWidget(
                  GenericMethods.getLocalizedString("specialties"),
                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                  style: AppThemePreferences().appTheme.label01TextStyle,
                ),
              ),
              Expanded(
                flex: 3,
                child: genericTextWidget(
                  agentSpecialties,
                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                  style: AppThemePreferences().appTheme.subBody01TextStyle,
                ),
              ),
            ],
          ) : Container(),
        ],
      ),
    )
        : Container();
  }

  Widget descriptionWidget(){
    final maxLines = isReadMore ? null : 6;
    final overFlow = isReadMore ? TextOverflow.visible : TextOverflow.ellipsis;

    return content!=null && content.isNotEmpty ? Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          child: headingWidget(text: GenericMethods.getLocalizedString("about")),
          decoration: BoxDecoration(border: Border(top: BorderSide(color: AppThemePreferences().appTheme.dividerColor)),),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
          child: genericTextWidget(
            content.replaceAll("\n", ""),
            strutStyle: StrutStyle(height: AppThemePreferences.bodyTextHeight),
            maxLines: maxLines,
            overflow: overFlow,
            style: AppThemePreferences().appTheme.bodyTextStyle,
            textAlign: TextAlign.justify,
          ),
        ),
        content.length > 300 ? Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 5),
              child: InkWell(
                onTap: (){
                  setState(() {
                    isReadMore = !isReadMore;
                  });
                },
                child: genericTextWidget(
                  isReadMore ? GenericMethods.getLocalizedString("read_less") : GenericMethods.getLocalizedString("read_more"),
                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                  style: AppThemePreferences().appTheme.readMoreTextStyle,
                ),
              ),
            ),
          ],
        ) : Container(),
        Container(
          padding: const EdgeInsets.only(top: 5),
          decoration: AppThemePreferences.dividerDecoration(),
        ),
      ],
    ) : Container();
  }

  _showToastWhileDataLoading(BuildContext context, String msg, bool forLogin) {
    !forLogin
        ? toastWidget(
      buildContext: context,
      text: msg,
    )
        : toastWidget(
      buildContext: context,
      showButton: true,
      buttonText: GenericMethods.getLocalizedString("login"),
      text: msg,
      toastDuration: 4,
      onButtonPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => UserSignIn(
                  (String closeOption) {
                if (closeOption == CLOSE) {
                  Navigator.pop(context);
                }
              },
            ),
          ),
        );
      },
    );
  }

  Widget tabBarViewWidget(){
    return tabList != null && tabList.isNotEmpty ? Container(
      padding: const EdgeInsets.fromLTRB(20, 30, 20, 10),
      child: MaterialSegmentedControl(
        // horizontalPadding: EdgeInsets.only(left: 5,right: 5),
        children: tabList.map((item) {
          var index = tabList.indexOf(item);
          return Container(
            padding:  const EdgeInsets.only(left: 20 ,right: 20),
            child: genericTextWidget(
              GenericMethods.getLocalizedString(item),
              style: TextStyle(
                fontSize: AppThemePreferences.realtorPageTabBarTitleFontSize,
                fontWeight: AppThemePreferences.tabBarTitleFontWeight,
                color: _currentSelection == index ? AppThemePreferences().appTheme.selectedItemTextColor :
                AppThemePreferences.unSelectedItemTextColorLight,
              ),),
          );
        },).toList().asMap(),

        selectionIndex: _currentSelection,
        unselectedColor: AppThemePreferences().appTheme.unSelectedItemBackgroundColor,
        selectedColor: AppThemePreferences().appTheme.selectedItemBackgroundColor,
        borderRadius: 5.0,
        verticalOffset: 8.0,
        onSegmentChosen: (index){
          setState(() {
            _currentSelection = index;
          });
        },
      ),
    ) : Container();
  }

  Widget contactWidget(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          child: headingWidget(text: GenericMethods.getLocalizedString("contact")),
          decoration: AppThemePreferences.dividerDecoration(top: true),
        ),
        address !=null && address.isNotEmpty ? Container(
          padding: const EdgeInsets.fromLTRB(10, 5, 20, 10),
          child: Row(
            children: [
              const Expanded(
                flex: 1,
                child: Icon(
                  Icons.location_on,
                ),
              ),
              Expanded(
                flex: 9,
                child: genericTextWidget(
                  address,
                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                  style: AppThemePreferences().appTheme.bodyTextStyle,
                  textAlign: TextAlign.justify,
                ),
              ),
            ],
          ),
        ) : Container(),
        Container(
          color: AppThemePreferences().appTheme.containerBackgroundColor,
          padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
          child: Column(
            children: [
              phoneNumber != null && phoneNumber.isNotEmpty ? SizedBox(
                height: 40,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      genericTextWidget(
                        GenericMethods.getLocalizedString("office"),
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.label01TextStyle,
                      ),
                      genericTextWidget(
                        phoneNumber,
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.subBody01TextStyle,
                      ),
                    ],
                  ),
                ),
              ) : Container(),
              mobileNumber!=null && mobileNumber.isNotEmpty ? SizedBox(
                height: 40,
                child: Container(
                  // color: AppThemePreferences().current.containerBackgroundColor,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      genericTextWidget(
                        GenericMethods.getLocalizedString("mobile_with_colon"),
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.label01TextStyle,
                      ),
                      genericTextWidget(
                        mobileNumber,
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.subBody01TextStyle,
                      ),
                    ],
                  ),
                ),
              ) : Container(),
              faxNumber!=null && faxNumber.isNotEmpty ? SizedBox(
                height: 40,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  // color: AppThemePreferences().current.containerBackgroundColor,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      genericTextWidget(
                        GenericMethods.getLocalizedString("fax_with_colon"),
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.label01TextStyle,
                      ),
                      genericTextWidget(
                        faxNumber,
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.subBody01TextStyle,
                      ),
                    ],
                  ),
                ),
              ) : Container(),
              email!=null && email.isNotEmpty ? SizedBox(
                height: 40,
                child: Container(
                  // color: AppThemePreferences().current.containerBackgroundColor,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      genericTextWidget(
                        GenericMethods.getLocalizedString("email_with_colon"),
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.label01TextStyle,
                      ),
                      genericTextWidget(
                        email,
                        strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                        style: AppThemePreferences().appTheme.subBody01TextStyle,
                      ),
                    ],
                  ),
                ),
              ) : Container(),
              const SizedBox(height: 55.0,),
            ],
          ),
        ),
        Container(height: 50),
      ],
    );
  }

  Widget sendEmailElevatedButtonWidget() {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("email_capital"),
      centeredContent: true,
      icon: const Icon(
        Icons.email_outlined,
        color: Colors.white,
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SendEmailToRealtor(
              informationMap: {
                SEND_EMAIL_REALTOR_ID: realtorId,
                SEND_EMAIL_REALTOR_TYPE: widget.agentType,
                SEND_EMAIL_REALTOR_EMAIL: email,
                SEND_EMAIL_MESSAGE: GenericMethods.getLocalizedString("realtor_message",inputWords: [title, appName,link]),
                SEND_EMAIL_REALTOR_NAME: title,
                SEND_EMAIL_THUMBNAIL: image,
                SEND_EMAIL_APP_BAR_TITLE: title,
                SEND_EMAIL_SITE_NAME: APP_NAME,
                // SEND_EMAIL_SITE_NAME: APP_NAME,
              },
            ),
          ),
        );
      },
    );
  }

  Widget callElevatedButtonWidget(String phonenum) {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("call_capital"),
      centeredContent: true,
      icon: Icon(
        AppThemePreferences.phoneIcon,
        color: AppThemePreferences.filledButtonIconColor,
      ),
      color: AppThemePreferences.callButtonBackgroundColor,
      onPressed: () {
        launch("tel://$phonenum");
      },
    );
  }

  Widget whatsappElevatedButtonWidget() {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("whatsapp"),
      centeredContent: true,
      color: AppThemePreferences.whatsAppBackgroundColor,
      onPressed: () async {
        String msg = GenericMethods.getLocalizedString("realtor_message",inputWords: [title, appName,link]);
        var whatsappUrl = "whatsapp://send?phone=$whatsappNumber&text=$msg";
        await canLaunch(whatsappUrl)
            ? launch(whatsappUrl)
            : launch("https://wa.me/$whatsappNumber");
      },
    );
  }

  Widget listings(Future<List<dynamic>> articlesList) {
    return Consumer<ItemDesignNotifier>(
      builder: (context, itemDesignNotifier, child){
        return _currentSelection == tempIndexListing ? FutureBuilder<List<dynamic>>(
          future: articlesList,
          builder: (context, articleSnapshot) {
            if (articleSnapshot.hasData) {
              if (articleSnapshot.data.isEmpty) return Container();
              return Column(
                children: articleSnapshot.data.map((item) {
                  final heroId = item.id.toString() + RELATED;
                  ArticleBoxDesign _articleBoxDesign = ArticleBoxDesign();
                  // articleBoxDesign = itemDesignNotifier.homeScreenItemDesign;
                  return SizedBox(
                    height: _articleBoxDesign.getArticleBoxDesignHeight(design: itemDesignNotifier.homeScreenItemDesign),
                    child: _articleBoxDesign.getArticleBoxDesign(
                      article: item,
                      heroId: heroId,
                      buildContext: context,
                      design: itemDesignNotifier.homeScreenItemDesign,
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PropertyDetailsPage(
                              article: item,
                              propertyID: item.id,
                              heroId: heroId,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                }).toList(),
              );
            } else if (articleSnapshot.hasError) {
              setState(() {
                showListings = false;
              });
              return Container();
            }
            return Container();
          },
        )
            : Container();
      },
    );

  }

  Widget moreElevatedButtonWidget() {
    return  realtorListings.length > 2 && _currentSelection == tempIndexListing ? SizedBox(
      // width: 140, //160
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            InkWell(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        SearchResult(
                          searchRelatedData: realtorDataMap(item),
                          // searchRelatedData: isAgent ? {AGENT_ID : item.id,} :
                          // isAgency ? {AGENCY_ID : item.id,} : {AUTHOR_ID : item.id},
                          searchPageListener: (Map<String, dynamic> map, String closeOption){
                            if(closeOption == CLOSE){
                              Navigator.pop(context);
                            }
                          },
                        ),
                  ),
                );
              },
              child: genericTextWidget(
                GenericMethods.getLocalizedString("see_more"),
                style: AppThemePreferences().appTheme.readMoreTextStyle,
              ),
            ),
          ],
        ),
      ),
    ) : Container();
  }

  Map<String, dynamic> realtorDataMap(dynamic item){
    Map<String, dynamic> realtorMap = {};
    if(isAgent){
      realtorMap = {
        REALTOR_SEARCH_TYPE : REALTOR_SEARCH_TYPE_AGENT,
        REALTOR_SEARCH_ID : item.id,
        REALTOR_SEARCH_NAME : item.title,
      };
    } else if(isAgency){
      realtorMap = {
        REALTOR_SEARCH_TYPE : REALTOR_SEARCH_TYPE_AGENCY,
        REALTOR_SEARCH_ID : item.id,
        REALTOR_SEARCH_NAME : item.title,
      };
    } else {
      realtorMap = {
        REALTOR_SEARCH_TYPE : REALTOR_SEARCH_TYPE_AUTHOR,
        REALTOR_SEARCH_ID : item.id,
        REALTOR_SEARCH_NAME : title,
      };
    }

    return realtorMap;
  }

  Future<List<dynamic>> fetchProperties(int id, int page, int perPage) async {
    List<dynamic> tempList = [];
    if(isAgent){
      tempList = await _propertyBloc.fetchPropertiesByAgentList(id, page, perPage);
    }else if(isAgency){
      tempList = await _propertyBloc.fetchPropertiesByAgencyList(id, page, perPage);
    }else if(isAuthor){
      tempList = await _propertyBloc.fetchAllProperties('any', page, perPage, id);
    }

    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if(tempList.isNotEmpty){
        if(mounted){
          setState(() {
            if(SHOW_REVIEWS){
              tempIndexListing = tempIndexListing + 1;
            }
            tabList.add(GenericMethods.getLocalizedString("listings"));
            if(tabList.length == 1){
              showPropertyListings = true;
            }
            realtorListings = tempList;
          });
        }
      }
    }

    return realtorListings;
  }

  Future<List<dynamic>> fetchAgents(int id) async {
    List<dynamic> tempList = await _propertyBloc.fetchAgencyAgentInfoList(id);
    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if(tempList.isNotEmpty){
        if(tempList[0].isNotEmpty){
          if(mounted){
            setState(() {
              if(tempIndexListing == 1){
                tempIndexRealtor = tempIndexRealtor + 1;
              }
              tabList.add(GenericMethods.getLocalizedString("agents"));
              if(tabList.length == 1){
                showAgentAgency = true;
              }
              showPropertyListings = false;
              agencyOrAgentsList = tempList;
            });
          }
        }
      }
    }

    return agencyOrAgentsList;
  }

  Future<List<dynamic>> fetchAgency(int id) async {
    List<dynamic> tempList =  await _propertyBloc.fetchSingleAgencyInfoList(id);
    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if (tempList.isNotEmpty) {
        if(mounted){
          setState(() {
            if(tempIndexListing == 1){
              tempIndexRealtor++;
            }
            tabList.add(GenericMethods.getLocalizedString("agency"));
            if(tabList.length == 1){
              showAgentAgency = true;
            }
            showPropertyListings = false;
            agencyOrAgentsList = tempList;
          });
        }
      }
    }

    return agencyOrAgentsList;
  }

  Widget realtorInformationDisplayWidget(Future<List<dynamic>> articlesList) {
    List<dynamic> dataList = [];
    return _currentSelection == tempIndexRealtor || showAgentAgency? FutureBuilder<List<dynamic>>(
      future: articlesList,
      builder: (context, articleSnapshot) {
        if (articleSnapshot.hasData) {
          if (articleSnapshot.data.isEmpty){
            return Container();
          }else if(articleSnapshot.data[0] is Agency || articleSnapshot.data[0] is Agent ||
              (articleSnapshot.data[0] is List<dynamic> && articleSnapshot.data[0].length > 0)) {
            if(articleSnapshot.data[0] is List<dynamic>){
              dataList = articleSnapshot.data[0];
            }else{
              dataList = articleSnapshot.data;
            }
            return Container(
              padding: const EdgeInsets.only(top: 5, bottom: 20),
              child: Column(
                children: <Widget>[
                  Column(
                    children: dataList.map((item) {
                      bool _validURL = GenericMethods.validateURL(item.thumbnail);
                      String heroId = HERO+item.id.toString();
                      String realtorPhone = isAgency ? item.agentOfficeNumber ?? "" : item.agencyPhoneNumber ?? "";
                      String realtorMobile = isAgency ? item.agentMobileNumber ?? "" : item.agencyMobileNumber ?? "";
                      return Container(
                        padding: const EdgeInsets.symmetric(vertical: 1, horizontal: 1),
                        color: AppThemePreferences().appTheme.containerBackgroundColor,
                        height: 150,
                        child: Card(
                          shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: const EdgeInsets.only(left: 10, top: 10),
                                child: SizedBox(
                                  height: 120,//150
                                  width: 110,//120
                                  child: Hero(
                                    tag: heroId,
                                    child: Stack(
                                      children: [
                                        ClipRRect(
                                          borderRadius: const BorderRadius.all(Radius.circular(10)),
                                          child: !_validURL?  shimmerEffectErrorWidget(iconSize: 100) : FancyShimmerImage(
                                            imageUrl: GenericMethods.validateURL(item.thumbnail) ? item.thumbnail :shimmerEffectErrorWidget(iconSize: 100),
                                            boxFit: BoxFit.cover,
                                            shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
                                            shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
                                            errorWidget: shimmerEffectErrorWidget(
                                              iconSize: 60,
                                              iconData: Icons.person_outlined,
                                            ),
                                          ),
                                        ),
                                        Positioned.fill(
                                          child: Material(
                                            color: Colors.transparent,
                                            child: InkWell(
                                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                                              onTap:()  {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => RealtorInformationDisplayPage(
                                                      heroId: heroId,
                                                      agentType: isAgent ? AGENT_INFO : AGENCY_INFO,
                                                      realtorInformation: isAgent ? {
                                                        AGENCY_DATA : item,
                                                      } : {
                                                        AGENT_DATA : item,
                                                      },
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.fromLTRB(10, 10, 0, 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      InkWell(
                                        borderRadius: BorderRadius.circular(5.0),
                                        onTap:()  {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => RealtorInformationDisplayPage(
                                                heroId: heroId,
                                                agentType: isAgent ? AGENT_INFO : AGENCY_INFO,
                                                realtorInformation: isAgent ? {
                                                  AGENCY_DATA : item,
                                                } : {
                                                  AGENT_DATA : item,
                                                },
                                              ),
                                            ),
                                          );
                                        },
                                        child: Row(
                                          children: [
                                            const Icon(Icons.person),
                                            Expanded(
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10),
                                                child: genericTextWidget(
                                                  item.title,
                                                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                                                  style: AppThemePreferences().appTheme.subBody01TextStyle,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      realtorPhone == null || realtorPhone.isEmpty ? Container() : InkWell(
                                        borderRadius: BorderRadius.circular(5.0),
                                        onTap: (){
                                          launch("tel://$realtorPhone");
                                        },
                                        child: Row(
                                          children: [
                                            const Icon(Icons.call),
                                            Expanded(
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10),
                                                child: genericTextWidget(
                                                  realtorPhone,
                                                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                                                  style: AppThemePreferences().appTheme.subBody01TextStyle,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      realtorMobile == null || realtorMobile.isEmpty ? Container() :InkWell(
                                        borderRadius: BorderRadius.circular(5.0),
                                        onTap: (){
                                          launch("tel://$realtorMobile");
                                          // isAgent ? launch("tel://${item.agencyMobileNumber}") :
                                          // launch("tel://${item.agentMobileNumber}");
                                        },
                                        child: Row(
                                          children: [
                                            const Icon(Icons.phone_android),
                                            Expanded(
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10),
                                                child: genericTextWidget(
                                                  realtorMobile,
                                                  strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                                                  style: AppThemePreferences().appTheme.subBody01TextStyle,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          }else{
            return Container();
          }

        } else if (articleSnapshot.hasError) {
          return Container();
        }
        return Container();
      },
    ) : Container();
  }

  Widget headingWidget({String text}){
    return headerWidget(
      text: text,
      padding: const EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 10.0),
    );
  }

  String checkType(String agentType) {
    if (agentType == AGENT_INFO) {
      return USER_ROLE_HOUZEZ_AGENT_VALUE;
    } else if (agentType == AGENCY_INFO) {
      return USER_ROLE_HOUZEZ_AGENCY_VALUE;
    } else {
      return USER_ROLE_HOUZEZ_AUTHOR_VALUE;
    }
  }

  void navigateToAddReviewPage({double initialStars}){
    String type = checkType(widget.agentType);
    isLoggedIn ? Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddReview(
          listingId: realtorId,
          listingTitle: title,
          reviewPostType: type,
          permaLink: link,
        ),
      ),
    ): _showToastWhileDataLoading(
      context,
      GenericMethods.getLocalizedString("you_must_login") +
          GenericMethods.getLocalizedString("before_leaving_a_review"),
      true,
    );
  }
}

