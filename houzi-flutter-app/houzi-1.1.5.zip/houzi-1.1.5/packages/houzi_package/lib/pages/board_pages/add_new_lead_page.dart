import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/mixins/validation_mixins.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';

import '../../blocs/property_bloc.dart';
import '../../common/constants.dart';
import '../../files/generic_methods/generic_methods.dart';
import '../../widgets/data_loading_widget.dart';
import '../../widgets/generic_text_field_widgets/drop_down_widget.dart';
import '../../widgets/generic_text_field_widgets/text_field_widget.dart';
import '../../widgets/header_widget.dart';
import '../../widgets/toast_widget.dart';

typedef AddNewLeadPageListener = void Function(bool reload);

class AddNewLeadPage extends StatefulWidget {

  AddNewLeadPageListener addNewLeadPageListener;


  AddNewLeadPage({this.addNewLeadPageListener});

  @override
  _AddNewLeadPageState createState() => _AddNewLeadPageState();
}

class _AddNewLeadPageState extends State<AddNewLeadPage> with ValidationMixin {
  bool isAgree = false;
  bool isInternetConnected = true;

  final PropertyBloc _propertyBloc = PropertyBloc();
  String _selectedUserTitle;

  List<String> _userSourceList = [];
  List<dynamic> _userTitleList = [];

  final formKey = GlobalKey<FormState>();

  String _selectedUserSource;

  bool _showWaitingWidget = false;

  Map<String, dynamic> addLeadInfoMap = {
    addLeadEmail: "",
    addLeadPrefix: "",
    addLeadFirstName: "",
    addLeadLastName: "",
    addLeadName: "",
    addLeadMobile: "",
    addLeadHomePhone: "",
    addLeadWorkPhone: "",
    addLeadUserType: "",
    addLeadAddress: "",
    addLeadCountry: "",
    addLeadCity: "",
    addLeadState: "",
    addLeadZip: "",
    addLeadSource: "",
    addLeadPrivateNote: "",
    "dashboard_lead": "yes",
  };

  @override
  void initState() {
    super.initState();
    loadData();
  }

  loadData() {
    _userTitleList = ['Mr', 'Mrs', 'Ms', 'Miss', 'Dr', 'Prof', 'Mr & Mrs'];
    _userSourceList = ['Website', 'Newspaper', 'Friend', 'Google', 'Facebook'];
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("lead_form"),
        ),
        body: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Form(
                  key: formKey,
                  child: Stack(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("information")),
                                inquiryUserTitleWidget(),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("first_name")+ " *",
                                  hintText: GenericMethods.getLocalizedString("enter_first_name"),
                                  key: addLeadFirstName,
                                  validate: true
                                ),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("last_name")+ " *",
                                  hintText: GenericMethods.getLocalizedString("enter_last_name"),
                                  key: addLeadLastName,
                                  validate: true
                                ),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("type"),
                                  hintText: GenericMethods.getLocalizedString("enter_user_type"),
                                  key: addLeadUserType,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("contact")),
                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("email")+ " *",
                                    hintText: GenericMethods.getLocalizedString("enter_email_address"),
                                    key: addLeadEmail,
                                    textInputType: TextInputType.emailAddress,
                                    isFirst: true,
                                    validate: false,
                                    emailValidation: true
                                ),
                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("mobile"),
                                    hintText: GenericMethods.getLocalizedString("enter_mobile_address"),
                                    key: addLeadMobile,
                                    textInputType: TextInputType.number,
                                ),
                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("home_number"),
                                    hintText: GenericMethods.getLocalizedString("enter_home_number"),
                                    key: addLeadHomePhone,
                                    textInputType: TextInputType.number,
                                ),
                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("work_number"),
                                    hintText: GenericMethods.getLocalizedString("enter_work_number"),
                                    key: addLeadWorkPhone,
                                    textInputType: TextInputType.number,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("address"),),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("address"),
                                  hintText: GenericMethods.getLocalizedString("enter_the_address"),
                                  key: addLeadAddress,
                                  isFirst: true
                                ),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("country"),
                                  hintText: GenericMethods.getLocalizedString("enter_the_country"),
                                  key: addLeadCountry,
                                ),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("city"),
                                  hintText: GenericMethods.getLocalizedString("enter_the_city"),
                                  key: addLeadCity,
                                ),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("states"),
                                  hintText: GenericMethods.getLocalizedString("enter_the_states"),
                                  key: addLeadState,
                                ),
                                setValuesInFields(
                                  labelText: GenericMethods.getLocalizedString("zip_code"),
                                  hintText: GenericMethods.getLocalizedString("enter_the_zip_code"),
                                  key: addLeadZip,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("source"),),
                                inquirySourceWidget(),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("social")),
                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("facebook"),
                                    hintText: GenericMethods.getLocalizedString("enter_facebook_profile_url"),
                                    key: addLeadFacebook,
                                    isFirst: true
                                ),

                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("twitter"),
                                    hintText: GenericMethods.getLocalizedString("enter_twitter_profile_url"),
                                    key: addLeadTwitter,
                                ),

                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("linkedIn"),
                                    hintText: GenericMethods.getLocalizedString("enter_linkedIn_profile_url"),
                                    key: addLeadLinkedIn,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("private_note")),
                                setValuesInFields(
                                    labelText: GenericMethods.getLocalizedString("private_note"),
                                    hintText: "",
                                    key: addLeadPrivateNote,
                                    isFirst: true,
                                ),
                                // privateNoteWidget(),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Container(
                              height: 50,
                              margin: const EdgeInsets.only(top: 20, bottom: 20),
                              child: saveButton(),
                            ),
                          ),
                        ],
                      ),
                      waitingWidget(),
                      bottomActionBarWidget(),
                    ],
                  ),
                  // Build this out in the next steps.
                ),
              ),
      ),
    );
  }

  Widget waitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 100,
            child: Center(
              child: Container(
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  // padding: EdgeInsets.only(top: 50),
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  Widget headerTextWidget(String text) {
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget setValuesInFields(
      {String labelText,
        String hintText,
        String key,
        TextInputType textInputType,
        String initialValue,
        bool isFirst = false,
        bool validate = false,
        bool emailValidation = false}) {
    return textFieldWidget(
      labelText: labelText,
      padding: EdgeInsets.fromLTRB(20, isFirst ? 20 : 0, 20, 20),
      hintText: hintText,
      keyboardType: textInputType ?? TextInputType.text,
      initialValue: initialValue ?? "",
      validator: emailValidation
          ? (value) => validateEmail(context, value)
          : validate
          ? (value) {
        if (value == null || value.isEmpty) {
          return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
        }
        return null;
      }
          : null,
      onSaved: (String value) {
        setState(() {
          addLeadInfoMap[key] = value;
        });
      },
    );
  }

  Widget inquiryUserTitleWidget() {
    return genericDropDownWidget(
      padding: const EdgeInsets.fromLTRB(20,20,20,20),
      labelText: GenericMethods.getLocalizedString("title")+ " *",
      hintText: GenericMethods.getLocalizedString("select"),
      value: _selectedUserTitle,
      validator: (String value) {
        if (value?.isEmpty ?? true) {
          return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
        }
        return null;
      },
      onSaved: (value) {
        setState(() {
          addLeadInfoMap[addLeadPrefix] = value;
        });
      },
      items: _userTitleList.map<DropdownMenuItem<String>>((item) {
        return DropdownMenuItem<String>(
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0),
            child: genericTextWidget(GenericMethods.getLocalizedString(item)),
          ),
          value: item,
        );
      }).toList(),
      onChanged: (val) {
        setState(() {
          addLeadInfoMap[addLeadPrefix] = val;
        });
      },
    );
  }

  Widget inquirySourceWidget() {
    return genericDropDownWidget(
      padding: const EdgeInsets.fromLTRB(20,20,20,20),
      labelText: GenericMethods.getLocalizedString("source"),
      hintText: GenericMethods.getLocalizedString("select"),
      value: _selectedUserSource,
      onSaved: (value) {
        setState(() {
          addLeadInfoMap[addLeadSource] = value;
        });
      },
      items: _userSourceList.map<DropdownMenuItem<String>>((item) {
        return DropdownMenuItem<String>(
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0),
            child: genericTextWidget(GenericMethods.getLocalizedString(item)),
          ),
          value: item,
        );
      }).toList(),
      onChanged: (val) {
        setState(() {
          addLeadInfoMap[addLeadSource] = val;
        });
      },
    );
  }


  Widget saveButton() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: buttonWidget(
        text: GenericMethods.getLocalizedString("add_new_lead"),
        onPressed: () async {
          if (formKey.currentState.validate()) {
            formKey.currentState.save();

            setState(() {
              _showWaitingWidget = true;
            });
            addLeadInfoMap[addLeadName] = "${addLeadInfoMap[addLeadFirstName]} ${addLeadInfoMap[addLeadLastName]}";

            final response = await _propertyBloc.fetchAddLeadResponse(addLeadInfoMap);

            if(response == null || response.statusCode == null){
              if(mounted){
                setState(() {
                  isInternetConnected = false;
                  _showWaitingWidget = false;
                });
              }
            }else{
              if(mounted){
                setState(() {
                  isInternetConnected = true;
                  _showWaitingWidget = false;
                });
              }

              String tempResponseString = response.toString().split("{")[1];
              Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");

              if(map["success"] == true){
                _showToast(context, map["msg"]);
                widget.addNewLeadPageListener(true);
                Navigator.of(context).pop();
              }
              else {
                _showToast(context, map["msg"]);
              }
            }
          }
        },
      ),
    );
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context,
              (){},
              showRetryButton: false,
            ),
          ],
        ),
      ),
    );
  }
}
