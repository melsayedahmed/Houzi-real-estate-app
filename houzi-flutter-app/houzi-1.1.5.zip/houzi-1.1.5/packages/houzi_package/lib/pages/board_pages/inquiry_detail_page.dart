import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/dialog_box_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';

import '../../files/generic_methods/generic_methods.dart';
import '../../files/hive_storage_files/hive_storage_manager.dart';
import '../property_details_page.dart';

typedef InquiryDetailPageListener = void Function(int index);


class InquiryDetailPage extends StatefulWidget {
  final inquiryDetail;
  final int index;
  final InquiryDetailPageListener inquiryDetailPageListener;

  InquiryDetailPage({
    this.inquiryDetail,
    this.index,
    this.inquiryDetailPageListener
  });

  @override
  _InquiryDetailPageState createState() => _InquiryDetailPageState();
}

class _InquiryDetailPageState extends State<InquiryDetailPage> {
  final PropertyBloc _propertyBloc = PropertyBloc();
  final String _selectedCurrencySymbol = HiveStorageManager.readDefaultCurrencyInfoData() ?? "\$";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("inquiry_detail"),
        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                dealDataLabel(GenericMethods.getLocalizedString("property_type")),
                dealDataValue(widget.inquiryDetail.propertyTypeName ?? ""),
                dealDataLabel(GenericMethods.getLocalizedString("price")),
                dealDataValue(_selectedCurrencySymbol+widget.inquiryDetail.minPrice ?? ""),
                dealDataLabel(GenericMethods.getLocalizedString("bedrooms")),
                dealDataValue(widget.inquiryDetail.minBeds ?? ""),
                dealDataLabel(GenericMethods.getLocalizedString("bathrooms")),
                dealDataValue(widget.inquiryDetail.minBaths ?? ""),
                dealDataLabel(GenericMethods.getLocalizedString("area_size")),
                dealDataValue(widget.inquiryDetail.minArea ?? ""),
                dealDataLabel(GenericMethods.getLocalizedString("location")),
                dealDataValue(widget.inquiryDetail.location ?? ""),
                dealDataLabel(GenericMethods.getLocalizedString("message")),
                dealDataValue(widget.inquiryDetail.message ?? ""),
                addActionButton(),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0, left: 16),
                  child: genericTextWidget(
                    GenericMethods.getLocalizedString("matching_list"),
                    style: AppThemePreferences().appTheme.headingTextStyle
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
                  child: matchingList(widget.inquiryDetail.matchedID ?? ""),
                )
              ],
            ),
          ),
        ),
      );
  }

  Widget dealDataLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(top:10,bottom: 5),
      child: genericTextWidget(
        label,
        style: AppThemePreferences().appTheme.label01TextStyle
      ),
    );
  }

  Widget dealDataValue(propertyType) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        genericTextWidget(
          propertyType,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: AppThemePreferences().appTheme.subBody01TextStyle
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
          decoration: AppThemePreferences.dividerDecoration(),
        )
      ],
    );
  }

  Widget addActionButton() {
    return buttonWidget(
        text: GenericMethods.getLocalizedString("action"),
        iconOnRightSide: true,
        centeredContent: true,
        icon: Icon(
         AppThemePreferences.arrowDropDownIcon, color: AppThemePreferences.filledButtonIconColor
        ),
        onPressed: () {
          _takeActionBottomSheet(context, widget.inquiryDetail.enquiryId ?? "");
        });
  }

  void _takeActionBottomSheet(context, inquiryID) {
    showModalBottomSheet(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        context: context,
        builder: (BuildContext bc) {
          return Wrap(
            children: <Widget>[
              // SizedBox(
              //   width: double.infinity,
              //   height: 70,
              //   child: TextButton(
              //     onPressed: () {},
              //     child: genericTextWidget(
              //       GenericMethods.getLocalizedString("enter_the_country")edit,
              //       style: AppThemePreferences().appTheme.heading02TextStyle,
              //     ),
              //   ),
              // ),
              SizedBox(
                height: 70,
                width: double.infinity,
                child: TextButton(
                  onPressed: () async {
                    dialogBoxWidget(
                      context,
                      title: GenericMethods.getLocalizedString("delete"),
                      content: genericTextWidget(
                          GenericMethods.getLocalizedString("delete_confirmation")),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
                        ),
                        TextButton(
                          onPressed: () async {
                            Navigator.pop(context);
                            if(inquiryID != null || inquiryID != ""){
                              int inquiryId = int.parse(inquiryID);
                              final response = await _propertyBloc.fetchDeleteInquiry(inquiryId);

                              if (response.statusCode == 200) {
                                Navigator.pop(context);
                                Navigator.pop(context);
                                widget.inquiryDetailPageListener(widget.index);
                                _showToast(context, GenericMethods.getLocalizedString("inquiry_delete_successfully"));
                              } else {
                                _showToast(context, GenericMethods.getLocalizedString("error_occurred"));
                              }
                            }

                          },
                          child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
                        ),
                      ],
                    );
                  },
                  child: genericTextWidget(
                    GenericMethods.getLocalizedString("delete_inquiry"),
                    style: AppThemePreferences().appTheme.heading02TextStyle,
                  ),
                ),
              ),
            ],
          );
        });
  }

  Widget matchingList(matchedId) {
    return Container(
      color: AppThemePreferences().appTheme.containerBackgroundColor,
      child: Column(
        children: [
          matchingListData(GenericMethods.getLocalizedString("id"), matchedId.toString()),
          matchingListData(GenericMethods.getLocalizedString("type"), widget.inquiryDetail.propertyTypeName ?? ""),
          matchingListData(GenericMethods.getLocalizedString("price"), _selectedCurrencySymbol+widget.inquiryDetail.minPrice ?? ""),
          matchingListData(GenericMethods.getLocalizedString("bedrooms"), widget.inquiryDetail.minBeds ?? ""),
          matchingListData(GenericMethods.getLocalizedString("bathrooms"), widget.inquiryDetail.minBaths ?? ""),
          matchingListData(GenericMethods.getLocalizedString("area_size"), widget.inquiryDetail.minArea ?? ""),
          toArticle(matchedId.toString()),
        ],
      ),
    );
  }

  Widget showDivider(){
    return Container(
      decoration: AppThemePreferences.dividerDecoration(),
    );
  }

  Widget matchingListData(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: AppThemePreferences.dividerDecoration(),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: genericTextWidget(
              label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppThemePreferences().appTheme.label01TextStyle
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 50),
            child: genericTextWidget(
              value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppThemePreferences().appTheme.subBody01TextStyle
            ),
          ),
        ],
      ),
    );
  }

  Widget toArticle(matchedId) {
    return Padding(
      padding: const EdgeInsets.only(top: 5.0),
      child: SizedBox(
        width: double.infinity,
        height: 40,
        child: InkWell(
          highlightColor: Theme.of(context).highlightColor.withOpacity(0.5),
          borderRadius: const BorderRadius.all(Radius.circular(10)),
          onTap: () {
            var propertyId;
            propertyId = matchedId;
            if (propertyId == "") {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PropertyDetailsPage(
                    propertyID: 0,
                    heroId: "0",
                  ),
                ),
              );
            } else {
              if(propertyId != "null" || propertyId != null) {
                int id = int.parse(propertyId);
                String propertyIdStr = propertyId.toString();
                String heroId = propertyIdStr + "-single";
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PropertyDetailsPage(
                      propertyID: id,
                      heroId: heroId,
                    ),
                  ),
                );
              }
            }
          },
          child: genericTextWidget(
            GenericMethods.getLocalizedString("view"),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppThemePreferences().appTheme.heading02TextStyle,
          ),
        ),
      ),
    );
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }
}
