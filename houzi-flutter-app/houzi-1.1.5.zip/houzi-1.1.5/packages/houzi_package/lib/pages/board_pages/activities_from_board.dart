import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/activity.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';
import 'package:pie_chart/pie_chart.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../files/generic_methods/generic_methods.dart';
import '../property_details_page.dart';

class ActivitiesFromBoard extends StatefulWidget {
  @override
  _ActivitiesFromBoardState createState() => _ActivitiesFromBoardState();
}

class _ActivitiesFromBoardState extends State<ActivitiesFromBoard> {
  final PropertyBloc _propertyBloc = PropertyBloc();
  final RefreshController _refreshController = RefreshController(initialRefresh: false);

  List<dynamic> activitiesFromBoardList = [];
  List<dynamic> dealsAndLeadsFromActivityList = [];

  Future<List<dynamic>> _futureActivitiesFromBoard;
  Future<List<dynamic>> _futureDealsAndLeadsFromActivity;

  bool isInternetConnected = true;
  int userId;

  String _title = "";
  String _name = "";
  String _email = "";
  String _phone = "";
  String _type = "";
  String _message = "";

  String activeCount = "";
  String wonCount = "";
  String lostCount = "";
  var lastDay;
  var lastTwo;
  var lastWeek;
  var last2Week;
  var lastMonth;
  var last2Month;

  var percentDay;
  String posOrNegDay;
  var percentWeek;
  String posOrNegWeek;
  var percentMonth;
  String posOrNegMonth;

  bool isRefreshing = false;
  bool shouldLoadMore = true;
  bool isLoading = false;
  int page = 1;
  int perPage = 10;

  Map<String, double> dealStatMap = {};

  @override
  void initState() {
    super.initState();
    userId = HiveStorageManager.getUserId();
    loadDataFromApi();
  }
  checkInternetAndLoadData(){
    if(mounted){
      setState(() {
        isRefreshing = false;
        shouldLoadMore = true;
        isLoading = false;
      });
    }

    userId = HiveStorageManager.getUserId();
    loadDataFromApi();

  }

  loadDataFromApi({bool forPullToRefresh = true}) {
    if (forPullToRefresh) {
      if (isLoading) {
        return;
      }
      if(mounted){
        setState(() {
          isRefreshing = true;
          isLoading = true;
        });
      }
      
      page = 1;
      loadLeadAndDealData();
      _futureActivitiesFromBoard = fetchActivitiesFromBoard(page, userId);
      _refreshController.refreshCompleted();
    } else {
      if (!shouldLoadMore || isLoading) {
        _refreshController.loadComplete();
        return;
      }
      if(mounted){
        setState(() {
          isRefreshing = false;
          isLoading = true;
        });
      }
      page++;
      _futureActivitiesFromBoard = fetchActivitiesFromBoard(page, userId);
      _refreshController.loadComplete();

    }
  }

  loadLeadAndDealData(){
    _futureDealsAndLeadsFromActivity = fetchDealsAndLeadsFromActivity();
    _futureDealsAndLeadsFromActivity.then((value) {
      if(value != null && value.isNotEmpty){
        if(mounted){
          setState(() {
            dealsAndLeadsFromActivityList = value;
            DealsAndLeadsFromActivity dealsAndLeadsFromActivity =
            dealsAndLeadsFromActivityList[0];

            activeCount = dealsAndLeadsFromActivity.activeCount;
            wonCount = dealsAndLeadsFromActivity.wonCount;
            lostCount = dealsAndLeadsFromActivity.lostCount;
            lastDay = dealsAndLeadsFromActivity.lastDay;
            lastTwo = dealsAndLeadsFromActivity.lastTwo;
            lastWeek = dealsAndLeadsFromActivity.lastWeek;
            last2Week = dealsAndLeadsFromActivity.last2Week;
            lastMonth = dealsAndLeadsFromActivity.lastMonth;
            last2Month = dealsAndLeadsFromActivity.last2Month;

            lastTwo = lastTwo - lastDay;
            setPercent(lastTwo, lastDay, DAY);
            last2Week = last2Week - lastWeek;
            setPercent(last2Week, lastWeek, WEEK);
            last2Month = last2Month - lastMonth;
            setPercent(last2Month, lastMonth, MONTH);

            dealStatMap = {
              GenericMethods.getLocalizedString("active"): double.parse(activeCount),
              GenericMethods.getLocalizedString("won"): double.parse(wonCount),
              GenericMethods.getLocalizedString("lost"): double.parse(lostCount),
            };

            isRefreshing = false;
          });
        }
      }else{
        if(mounted){
          setState(() {
            isRefreshing = false;
          });
        }
      }


      return null;
    });
  }

  void setPercent(oldNumber, newNumber, valueFor) {
    if (oldNumber != 0) {
      double percent = ((newNumber - oldNumber) / oldNumber * 100);
      if (valueFor == DAY) {
        percentDay = percent;
      } else if (valueFor == WEEK) {
        percentWeek = percent;
      } else if (valueFor == MONTH) {
        percentMonth = percent;
      }
    } else {
      if (valueFor == DAY) {
        percentDay = newNumber * 100;
      } else if (valueFor == WEEK) {
        percentWeek = newNumber * 100;
      } else if (valueFor == MONTH) {
        percentMonth = newNumber * 100;
      }
    }

    if (oldNumber > newNumber) {
      if (valueFor == DAY) {
        posOrNegDay = DANGER;
      } else if (valueFor == WEEK) {
        posOrNegWeek = DANGER;
      } else if (valueFor == MONTH) {
        posOrNegMonth = DANGER;
      }
    } else {
      if (valueFor == DAY) {
        posOrNegDay = SUCCESS;
      } else if (valueFor == WEEK) {
        posOrNegWeek = SUCCESS;
      } else if (valueFor == MONTH) {
        posOrNegMonth = SUCCESS;
      }
    }
  }

  Future<List<dynamic>> fetchActivitiesFromBoard(int page,int userId) async {
    if (page == 1) {
      if(mounted){
        setState(() {
          shouldLoadMore = true;
        });
      }
    }
    List<dynamic> tempList = await  _propertyBloc.fetchActivitiesFromBoard(page, perPage,userId);
    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          shouldLoadMore = false;
        });
      }
      return activitiesFromBoardList;
    }else{
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if(tempList.isEmpty || tempList.length < perPage){
        if(mounted){
          setState(() {
            shouldLoadMore = false;
          });
        }
      }

      if (page == 1) {
        activitiesFromBoardList.clear();
      }
      if (tempList.isNotEmpty) {
        activitiesFromBoardList.addAll(tempList);
      }
    }

    return activitiesFromBoardList;
  }

  Future<List<dynamic>> fetchDealsAndLeadsFromActivity() async {
    List<dynamic> tempList = await _propertyBloc.fetchDealsAndLeadsFromActivity();

    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
      return dealsAndLeadsFromActivityList;
    }else{
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      dealsAndLeadsFromActivityList.clear();
      dealsAndLeadsFromActivityList.addAll(tempList);
    }

    return dealsAndLeadsFromActivityList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
        context,
        appBarTitle: GenericMethods.getLocalizedString("activities"),//AppLocalizations.of(context).activities,
      ),
      body: Stack(
        children: [
          SmartRefresher(
            enablePullDown: true, enablePullUp: true,
            header: const MaterialClassicHeader(),
            controller: _refreshController,
            onRefresh: loadDataFromApi,
            onLoading: () => loadDataFromApi(forPullToRefresh: false),
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus mode) {
                Widget body;
                if (mode == LoadStatus.loading) {
                  if (shouldLoadMore) {
                    body = paginationLoadingWidget();
                  } else {
                    body = Container();
                  }
                }
                return SizedBox(
                  height: 55.0,
                  child: Center(child: body),
                );
              },
            ),
            child: SingleChildScrollView(
              physics: const ScrollPhysics(),
              child: Column(
                children: [
                  dealsAndLeadsFromActivityList.isEmpty ? const SizedBox(height: 50) : Container(
                    height: 250,
                    margin: const EdgeInsets.only(top: 10),
                    child: PageView(
                      controller: PageController(viewportFraction: 0.9),
                      children: <Widget>[
                        Container(
                          child: showLeads(),
                        ),
                        Container(
                          child: showDeals(),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    child: showActivitiesList(context, _futureActivitiesFromBoard),
                  ),
                ],
              ),
            ),
          ),
          if(isInternetConnected == false) internetConnectionErrorWidget(),
        ],
      ),
    );
  }

  Widget internetConnectionErrorWidget(){
    return Positioned(
        bottom: 0,
        child: SafeArea(
            top: false,
            child: noInternetBottomActionBar(context, ()=> checkInternetAndLoadData())));
  }

  Widget showLeads() {
    return dealsAndLeadsFromActivityList.isEmpty
        ? Container()
        // ? loadingIndicatorWidget()
        : Card(
          shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
          elevation: AppThemePreferences.boardPagesElevation,
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              children: [
                Container(
                  child: setLabelWidget(GenericMethods.getLocalizedString("leads")),//AppLocalizations.of(context).leads),
                ),
                Expanded(
                  child: Row(
                    children: [
                      setLeadDataWidget(
                        lastDay.toString(),
                        AppThemePreferences().appTheme.heading01TextStyle,
                      ),
                      setLeadDataWidget(
                        lastWeek.toString(),
                        AppThemePreferences().appTheme.heading01TextStyle,
                      ),
                      setLeadDataWidget(
                        lastMonth.toString(),
                        AppThemePreferences().appTheme.heading01TextStyle,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    children: [
                      percentWidget(percentDay.toStringAsFixed(0) + "%", posOrNegDay),
                      percentWidget(percentWeek.toStringAsFixed(0) + "%", posOrNegWeek),
                      percentWidget(percentMonth.toStringAsFixed(0) + "%", posOrNegMonth),
                    ],
                  ),
                ),
                Expanded(
                  child: Row(
                    children: [
                      setLeadDataWidget(
                        GenericMethods.getLocalizedString("last_24_hours"),//AppLocalizations.of(context).last_24_hours,
                        null,
                      ),
                      setLeadDataWidget(
                        GenericMethods.getLocalizedString("last_7_days"),//AppLocalizations.of(context).last_7_days,
                        null,
                      ),
                      setLeadDataWidget(
                        GenericMethods.getLocalizedString("last_30_days"),//AppLocalizations.of(context).last_30_days,
                        null,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
  }

  Widget setLeadDataWidget(String text, TextStyle style) {
    return Expanded(
      child: genericTextWidget(
        text,
        textAlign: TextAlign.center,
        maxLines: 2,
        style: style,
      ),
    );
  }

  Widget percentWidget(String textValue,String posNegValue){
    return Expanded(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          genericTextWidget(
            textValue,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: posNegValue == 'text-success'
                ? AppThemePreferences().appTheme.risingLeadsTextStyle
                : AppThemePreferences().appTheme.fallingLeadsTextStyle,
          ),
          Icon(
            posNegValue == 'text-success'?AppThemePreferences.upArrowIcon:AppThemePreferences.downArrowIcon,
            color: posNegValue == 'text-success'?AppThemePreferences.risingLeadsColor:AppThemePreferences.fallingLeadsColor,
            size: 50,
          )
        ],
      ),
    );
  }

  Widget setLabelWidget(String label){
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 10, top: 3, right: 0, bottom: 10),
          child: genericTextWidget(
            label,
            style: AppThemePreferences().appTheme.heading02TextStyle,
          ),
        ),
      ],
    );
  }

  Widget showDeals() {
    if (dealsAndLeadsFromActivityList.isEmpty) {
      return Container();
      // return loadingIndicatorWidget();
    } else {
      return Card(
        shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
        elevation: AppThemePreferences.boardPagesElevation,
        child: Container(
          height: MediaQuery.of(context).size.height * 0.3, //150, //490,
          padding: const EdgeInsets.all(15),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  setLabelWidget(GenericMethods.getLocalizedString("deals")),//AppLocalizations.of(context).deals),
                  Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: PieChart(
                      dataMap: dealStatMap,
                      animationDuration: const Duration(milliseconds: 800),
                      chartLegendSpacing: 32,
                      chartRadius: MediaQuery.of(context).size.width / 9.2,
                      chartType: ChartType.ring,
                      ringStrokeWidth: 15,
                      legendOptions: const LegendOptions(
                        showLegendsInRow: false,
                        legendPosition: LegendPosition.left,
                        showLegends: true,
                      ),
                      chartValuesOptions: const ChartValuesOptions(
                        showChartValueBackground: false,
                        showChartValues: false,
                        showChartValuesInPercentage: false,
                        showChartValuesOutside: false,
                      ),
                    ),
                  ),
                ],
              ),
              setDealDataWidget(GenericMethods.getLocalizedString("active"), activeCount),//AppLocalizations.of(context).active, activeCount),
              setDealDataWidget(GenericMethods.getLocalizedString("won"), wonCount),//AppLocalizations.of(context).won, wonCount),
              setDealDataWidget(GenericMethods.getLocalizedString("lost"), lostCount),//AppLocalizations.of(context).lost, lostCount),
            ],
          ),
        ),
      );
    }
  }

  Widget setDealDataWidget(String text,String dealCount){
    return Expanded(
      child: Row(
        children: [
          Expanded(
            child: genericTextWidget(text),
          ),
          const Expanded(
            flex: 3,
            child: Divider(
              thickness: 1,
            ),
          ),
          Expanded(
            child: genericTextWidget(
              dealCount,
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget showActivitiesList(BuildContext context, Future<List<dynamic>> futureActivitiesFromBoard) {
    return FutureBuilder<List<dynamic>>(
        future: futureActivitiesFromBoard,
        builder: (context, articleSnapshot) {
          isLoading = false;
          if (articleSnapshot.hasData) {
            if (articleSnapshot.data.isEmpty) {
              return noResultFoundPage();
            } else if (articleSnapshot.data.isNotEmpty) {

              List<dynamic> list = articleSnapshot.data;

              return ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: list.length,
                itemBuilder: (context, index) {
                  _title = "${list[index].title}";
                  _name = "${list[index].name}";
                  _email = "${list[index].email}";
                  _phone = "${list[index].phone}";
                  _type = "${list[index].type}";
                  _message = "${list[index].message}";
                  if(_type == "review") {
                    return Card(
                      shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                      elevation: AppThemePreferences.boardPagesElevation,
                      child: InkWell(
                        onTap: (){
                          navigateToProperty(list[index].listingId);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              genericTextWidget(GenericMethods.getLocalizedString("received_a_new_rating_from"),style: AppThemePreferences().appTheme.heading01TextStyle,),
                              Padding(
                                padding:  const EdgeInsets.only(top:15),
                                child: Row(
                                  children: [
                                    genericTextWidget("${list[index].userName}",style: AppThemePreferences().appTheme.heading02TextStyle,),
                                    starsWidget("${list[index].reviewStar}")
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top:15),
                                child: genericTextWidget("${list[index].reviewTitle}",style: AppThemePreferences().appTheme.heading01TextStyle,),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top:10),
                                child: genericTextWidget("${list[index].reviewContent}",style: AppThemePreferences().appTheme.bodyTextStyle,),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  } else if(_type == "lead") {
                    return Card(
                      shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                      elevation: AppThemePreferences.boardPagesElevation,
                      child: InkWell(
                        onTap: () {
                          navigateToProperty(list[index].listingId);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              labelAndValueWidget(GenericMethods.getLocalizedString("new_lead") + GenericMethods.getLocalizedString("from"), _title),
                              showDivider(),
                              labelAndValueWidget(GenericMethods.getLocalizedString("name"), _name),
                              showDivider(),
                              labelAndValueWidget(GenericMethods.getLocalizedString("email"), _email),
                              showDivider(),
                              labelAndValueWidget(GenericMethods.getLocalizedString("phone"), _phone),
                              showDivider(),
                              labelAndValueWidget(GenericMethods.getLocalizedString("type"), _type),
                              messageWidget(_message),
                            ],
                          ),
                        ),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              );
            }
          }
          return loadingIndicatorWidget();
        }
    );
  }

  navigateToProperty(int id){
    int propertyId;
    propertyId = id;
    if (propertyId == "") {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PropertyDetailsPage(
            propertyID: 0,
            heroId: "0",
          ),
        ),
      );
    } else {
      int id = propertyId;
      String propertyIdStr = propertyId.toString();
      String heroId = propertyIdStr + "-single";
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PropertyDetailsPage(
            propertyID: id,
            heroId: heroId,
          ),
        ),
      );
    }
  }

  Widget starsWidget(String totalRating) {
    return Padding(
      padding: const EdgeInsets.only(left: 5, right: 5),
      child: RatingBar.builder(
        initialRating: double.parse(totalRating),
        minRating: 1,
        itemSize: 20,
        direction: Axis.horizontal,
        allowHalfRating: true,
        ignoreGestures: true,
        itemCount: 5,
        itemPadding: const EdgeInsets.symmetric(horizontal: 1.0),
        itemBuilder: (context, _) => Icon(
          Icons.star,
          color: AppThemePreferences.ratingWidgetStarsColor,
        ),
        onRatingUpdate: (rating) {},
      ),
    );
  }

  Widget labelAndValueWidget(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 160,
          child: genericTextWidget(
            label,
            style: AppThemePreferences().appTheme.label01TextStyle
          ),
        ),
        Expanded(
          child: genericTextWidget(
            value,
            style: AppThemePreferences().appTheme.subBody01TextStyle
          ),
        ),
      ],
    );
  }

  Widget messageWidget(String message) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: genericTextWidget(
        message,
        style: AppThemePreferences().appTheme.bodyTextStyle
      ),
    );
  }

  Widget showDivider() {
    return const Divider(
      thickness: 1,
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
      bodyErrorText: GenericMethods.getLocalizedString("oops_activities_not_exist"),
    );
  }

  Widget loadingIndicatorWidget() {
    return Container(
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  Widget paginationLoadingWidget() {
    return Container(
      color: Theme.of(context).backgroundColor,
      alignment: Alignment.center,
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 50,
            child: loadingBallRotatingWidget(),
          ),
        ],
      ),
    );
  }

}
