
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../files/generic_methods/generic_methods.dart';
import 'add_new_inquiry_page.dart';
import 'inquiry_detail_page.dart';

class InquiriesFromBoard extends StatefulWidget {
  @override
  _InquiriesFromBoardState createState() => _InquiriesFromBoardState();
}

class _InquiriesFromBoardState extends State<InquiriesFromBoard> {
  final PropertyBloc _propertyBloc = PropertyBloc();

  //ScrollController _controller = new ScrollController();
  final RefreshController _refreshController = RefreshController(initialRefresh: false);

  Future<List<dynamic>> _futureInquiriesFromBoard;
  List<dynamic> inquiriesFromBoardList = [];

  bool shouldLoadMore = true;
  bool isLoading = false;
  bool isInternetConnected = true;

  int userId;
  int page = 1;
  int perPage = 10;



  @override
  void initState() {
    super.initState();
    userId = HiveStorageManager.getUserId();
    loadDataFromApi();
    // checkInternetAndLoadData();
  }

  checkInternetAndLoadData() {
    // InternetConnectionChecker().checkInternetConnection().then((value) {
    //   if (value) {
    //     setState(() {
    //       isInternetConnected = true;
    //     });
    //     userId = HiveStorageManager.getUserId();
    //     loadDataFromApi();
    //   } else {
    //     setState(() {
    //       isInternetConnected = false;
    //     });
    //   }
    //   return null;
    // });
    
    if(mounted){
      setState(() {
        shouldLoadMore = true;
        isLoading = false;
      });
    }

    userId = HiveStorageManager.getUserId();
    loadDataFromApi();
  }

  loadDataFromApi({bool forPullToRefresh = true}) {
    if (forPullToRefresh) {
      if (isLoading) {
        return;
      }
    } else {
      if (!shouldLoadMore || isLoading) {
        _refreshController.loadComplete();
        return;
      }
    }

    setState(() {
      if (forPullToRefresh) {
        page = 1;
      } else {
        page++;
      }
      isLoading = true;
    });

    _futureInquiriesFromBoard = fetchInquiriesFromBoard(page, userId);
    if (forPullToRefresh) {
      _refreshController.refreshCompleted();
    } else {
      _refreshController.loadComplete();
    }
  }

  Future<List<dynamic>> fetchInquiriesFromBoard(int page, int userId) async {
    if (page == 1) {
      setState(() {
        shouldLoadMore = true;
      });
    }
    List<dynamic> tempList = await _propertyBloc.fetchInquiriesFromBoard(page, perPage, userId);
    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
      return inquiriesFromBoardList;
    }else{
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if(tempList.isEmpty || tempList.length < perPage){
        if(mounted){
          setState(() {
            shouldLoadMore = false;
          });
        }
      }

      if (page == 1) {
        inquiriesFromBoardList.clear();
      }
      if (tempList.isNotEmpty) {
        inquiriesFromBoardList.addAll(tempList);
      }
    }
    return inquiriesFromBoardList;
  }

  @override
  void dispose() {
    //_bannerAd.dispose();
    super.dispose();

    // _controller.removeListener(_scrollListener);
    // _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: isInternetConnected == false
          ? appBarWidget(
              context,
              appBarTitle: GenericMethods.getLocalizedString("inquiries"),
            )
          : widgetAppBar(),
      body: isInternetConnected == false
          ? Align(
              alignment: Alignment.topCenter,
              child: noInternetConnectionErrorWidget(context, () {
                checkInternetAndLoadData();
              }),
            )
          : showInquiriesList(context, _futureInquiriesFromBoard),
    );
  }

  Widget widgetAppBar() {
    return appBarWidget(
      context,
      appBarTitle: GenericMethods.getLocalizedString("inquiries"),
      actions: <Widget>[
        Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
            icon: Icon(
              AppThemePreferences.addIcon,
              color: AppThemePreferences.backgroundColorLight,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddNewInquiry((bool reload) {
                    if (reload) {
                      loadDataFromApi();
                    }
                  }),
                ),
              );
            },
          ),
        )
      ],
    );
  }

  Widget showInquiriesList(
      BuildContext context, Future<List<dynamic>> futureInquiriesFromBoard) {
    return FutureBuilder<List<dynamic>>(
      future: futureInquiriesFromBoard,
      builder: (context, articleSnapshot) {
        isLoading = false;

        if (articleSnapshot.hasData) {
          if (articleSnapshot.data.isEmpty) {
            return noResultFoundPage();
          }
          // if (articleSnapshot.data.length < perPage) {
          //   shouldLoadMore = false;
          //   _refreshController.loadNoData();
          // }

          List<dynamic> list = articleSnapshot.data;

          // if (isRefreshing) {
          //   //need to clear the list if refreshing.
          //   inquiriesFromBoardList.clear();
          // }
          //inquiriesFromBoardList.addAll(list);

          return SmartRefresher(
            enablePullDown: true,
            enablePullUp: true,
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus mode) {
                Widget body;
                if (mode == LoadStatus.loading) {
                  if (shouldLoadMore) {
                    body = paginationLoadingWidget();
                  } else {
                    body = Container();
                  }
                }
                return SizedBox(
                  height: 55.0,
                  child: Center(child: body),
                );
              },
            ),
            header: const MaterialClassicHeader(),
            controller: _refreshController,
            onRefresh: loadDataFromApi,
            onLoading: () => loadDataFromApi(forPullToRefresh: false),
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                var inquiryDetail = list[index];
                // return Card(
                //   elevation: AppThemePreferences.boardPagesElevation,
                //   child: InkWell(
                //     borderRadius: BorderRadius.all(Radius.circular(10)),
                //     onTap: () {
                //       Navigator.push(
                //         context,
                //         MaterialPageRoute(
                //           builder: (context) => InquiryDetailPage(
                //             inquiryDetail: inquiryDetail,
                //             index: index,
                //             inquiryDetailPageListener: (int index) {
                //               setState(() {
                //                 list.removeAt(index);
                //               });
                //             },
                //           ),
                //         ),
                //       );
                //     },
                //     child: Container(
                //       width: double.infinity, //270,
                //       height: 150, //150, //490,
                //       padding: EdgeInsets.all(15),
                //       child: Column(
                //         crossAxisAlignment: CrossAxisAlignment.start,
                //         children: [
                //           propertyNameWidget(inquiryDetail.propertyTypeName),
                //           locationWidget(inquiryDetail.location.trim()),
                //           bedBathAreaWidget(inquiryDetail.minBeds,
                //               inquiryDetail.minBaths, inquiryDetail.minArea),
                //           nameAndPrice(inquiryDetail.displayName,
                //               "\$" + inquiryDetail.minPrice)
                //         ],
                //       ),
                //     ),
                //   ),
                // );
                // if (SHOW_ADS_ON_LISTINGS && index % 5 == 0 && index != 0)
                //   return Container(height:50,child: AdWidget(ad: BannerAdWidget.getBannerAd()..load()));
                //   // return BannerAdWidget();
                // // return Container(height:50,child: AdWidget(ad: getBannerAd()..load()));
                // else
                  return Card(
                    shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                    elevation: AppThemePreferences.boardPagesElevation,
                    child: InkWell(
                      borderRadius: const BorderRadius.all(Radius.circular(10)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => InquiryDetailPage(
                              inquiryDetail: inquiryDetail,
                              index: index,
                              inquiryDetailPageListener: (int index) {
                                setState(() {
                                  list.removeAt(index);
                                });
                              },
                            ),
                          ),
                        );
                      },
                      child: Container(
                        width: double.infinity, //270,
                        height: 150, //150, //490,
                        padding: const EdgeInsets.all(15),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 5.0),
                              child: propertyNameWidget(inquiryDetail.propertyTypeName),
                            ),
                            locationWidget(inquiryDetail.location.trim()),
                            bedBathAreaWidget(inquiryDetail.minBeds,
                                inquiryDetail.minBaths, inquiryDetail.minArea),
                            Padding(
                              padding: const EdgeInsets.only(left: 5.0),
                              child: nameAndPrice(inquiryDetail.displayName,
                                  "\$" + inquiryDetail.minPrice),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
              },
            ),
          );
        } else if (articleSnapshot.hasError) {
          return noResultFoundPage();
        }
        return loadingIndicatorWidget();
      },
    );
  }

  // Widget bannerAdWidget() {
  //   //setUpBannerAd();
  //   return StatefulBuilder(
  //     builder: (context, setState) => Container(
  //       height: _bannerAd.size.height.toDouble(),
  //       width: _bannerAd.size.width.toDouble(),
  //       child: AdWidget(ad: _bannerAd),
  //       // child: AdWidget(ad: _bannerAd),
  //       // width: _bannerAd.size.width.toDouble(),
  //       // height: 100.0,
  //       // alignment: Alignment.center,
  //     ),
  //   );
  // }

  //  BannerAd getBannerAd(){
  //   BannerAd _bannerAd = new BannerAd(size: AdSize.banner, adUnitId: , listener: BannerAdListener(
  //       onAdClosed: (Ad ad){
  //         //print("Ad Closed");
  //       },
  //       onAdFailedToLoad: (Ad ad,LoadAdError error){
  //         print("Failed to Load A Banner Ad: ${error.message}");
  //         ad.dispose();
  //       },
  //       onAdLoaded: (Ad ad){
  //         //print('Ad Loaded');
  //       },
  //       onAdOpened: (Ad ad){
  //         //print('Ad opened');
  //       }
  //   ), request: AdRequest());
  //   return _bannerAd;
  // }

  Widget propertyNameWidget(String propertyTypeName) {
    return propertyTypeName != null || propertyTypeName.isNotEmpty
        ? genericTextWidget(propertyTypeName,strutStyle: null,
            style: AppThemePreferences().appTheme.heading01TextStyle)
        : Container();
  }

  Widget locationWidget(String location) {
    return location.isNotEmpty
        ? Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                children: <Widget>[
                  Icon(
                    AppThemePreferences.locationIcon,
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 5),
                      child: genericTextWidget(location,
                          maxLines: 1,strutStyle: null,
                          overflow: TextOverflow.ellipsis,
                          style: AppThemePreferences().appTheme.bodyTextStyle),
                    ),
                  ),
                ],
              ),
            ),
          )
        : Container();
  }

  Widget bedBathAreaWidget(String bedrooms, String bathrooms, String areaSize) {
    return Expanded(
      child: Row(

        children: [
          bedrooms != null && bedrooms.isNotEmpty
              ? bathAndBedValueWidget(
                  bedrooms,
                  AppThemePreferences.bedIcon,isFirst: true
                )
              : Container(),
          bathrooms != null && bathrooms.isNotEmpty
              ? bathAndBedValueWidget(
                bathrooms,
                AppThemePreferences.bathtubIcon,
              )
              : Container(),
          areaSize != null && areaSize.isNotEmpty
              ? bathAndBedValueWidget(
                areaSize,
                AppThemePreferences.areaSizeIcon,
              )
              : Container(),
        ],
      ),
    );
  }

  Widget bathAndBedValueWidget(String value, IconData icon,{bool isFirst = false}) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Row(
        children: [
          Padding(
            padding: EdgeInsets.only(top: isFirst ?5: 0),
            child: Icon(
              icon,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 5),
            child: genericTextWidget(value,strutStyle: null,
                style: AppThemePreferences().appTheme.bodyTextStyle),
          ),
        ],
      ),
    );
  }

  Widget nameAndPrice(String displayName, String price) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          if (displayName != null)
            Padding(
              padding: const EdgeInsets.only(right: 5),
              child: genericTextWidget(displayName,
                  style: AppThemePreferences().appTheme.heading02TextStyle),
            ),
          genericTextWidget(price,
              style: AppThemePreferences().appTheme.heading01TextStyle),
        ],
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
      bodyErrorText: GenericMethods.getLocalizedString("oops_inquiries_not_exist"),
    );
  }

  Widget loadingIndicatorWidget() {
    return Container(
      height: (MediaQuery.of(context).size.height) / 2,
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  Widget paginationLoadingWidget() {
    return Container(
      color: Theme.of(context).backgroundColor,
      alignment: Alignment.center,
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 50,
            child: loadingBallRotatingWidget(),
          ),
        ],
      ),
    );
  }
}
