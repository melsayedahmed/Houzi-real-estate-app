import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/dialog_box_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../files/generic_methods/generic_methods.dart';
import 'add_new_lead_page.dart';

class LeadsFromBoard extends StatefulWidget {
  @override
  _LeadsFromBoardState createState() => _LeadsFromBoardState();
}

class _LeadsFromBoardState extends State<LeadsFromBoard> {
  final PropertyBloc _propertyBloc = PropertyBloc();
  final RefreshController _refreshController = RefreshController(initialRefresh: false);

  List<dynamic> leadsFromBoardList = [];
  Future<List<dynamic>> _futureLeadsFromBoard;

  bool isRefreshing = false;
  bool shouldLoadMore = true;
  bool isLoading = false;
  bool isInternetConnected = true;

  int userId;
  int page = 1;
  int perPage = 10;

  @override
  void initState() {
    super.initState();
    isRefreshing = true;
    loadDataFromApi();
  }

  checkInternetAndLoadData(){
    // InternetConnectionChecker().checkInternetConnection().then((value){
    //   if(value){
    //     setState(() {
    //       isInternetConnected = true;
    //     });
    //     isRefreshing = true;
    //     loadDataFromApi();
    //   }else{
    //     setState(() {
    //       isInternetConnected = false;
    //     });
    //   }
    //   return null;
    // });

    if(mounted){
      setState(() {
        isRefreshing = true;
        isLoading = false;
        shouldLoadMore = true;
      });
    }

    loadDataFromApi();
  }

  loadDataFromApi({bool forPullToRefresh = true}) {
    if (forPullToRefresh) {
      if (isLoading) {
        return;
      }
      setState(() {
        isRefreshing = true;
        isLoading = true;
      });

      page = 1;
      _futureLeadsFromBoard = fetchLeadsFromBoard(page);
      _refreshController.refreshCompleted();
    } else {
      if (!shouldLoadMore || isLoading) {
        _refreshController.loadComplete();
        return;
      }
      setState(() {
        isRefreshing = false;
        isLoading = true;
      });
      page++;
      _futureLeadsFromBoard = fetchLeadsFromBoard(page);
      _refreshController.loadComplete();

    }
  }

  Future<List<dynamic>> fetchLeadsFromBoard(int page) async {
    if (page == 1) {
      setState(() {
        shouldLoadMore = true;
      });
    }

    List<dynamic> tempList = await _propertyBloc.fetchLeadsFromBoard(page, perPage);
    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          shouldLoadMore = false;
        });
      }
      return leadsFromBoardList;
    }else{
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if(tempList.isEmpty || tempList.length < perPage){
        if(mounted){
          setState(() {
            shouldLoadMore = false;
          });
        }
      }

      if (page == 1) {
        leadsFromBoardList.clear();
      }
      if (tempList.isNotEmpty) {
        leadsFromBoardList.addAll(tempList);
      }
    }

    return leadsFromBoardList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: isInternetConnected == false ? appBarWidget(context,
        appBarTitle: GenericMethods.getLocalizedString("leads"),
      ): widgetAppBar(),
      body: isInternetConnected == false ? Align(
        alignment: Alignment.topCenter,
        child: noInternetConnectionErrorWidget(context, (){
          checkInternetAndLoadData();
        }),
      ):showLeadsList(context, _futureLeadsFromBoard),
    );
  }

  Widget widgetAppBar(){
    return appBarWidget(context,
      appBarTitle: GenericMethods.getLocalizedString("leads"),
      actions: <Widget>[
        Padding(
          padding: const EdgeInsets.only(right: 5),
          child: IconButton(
            icon: Icon(
              AppThemePreferences.addIcon,
              color: AppThemePreferences.backgroundColorLight,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddNewLeadPage(addNewLeadPageListener: (bool refresh) {
                    if (refresh) {
                      loadDataFromApi();
                    }
                  }),
                ),
              );
            },
          ),
        )
      ],
    );
  }

  Widget showLeadsList(
      BuildContext context, Future<List<dynamic>> futureLeadsFromBoard) {
    return FutureBuilder<List<dynamic>>(
      future: futureLeadsFromBoard,
      builder: (context, articleSnapshot) {
        isLoading = false;
        if (articleSnapshot.hasData) {
          if (articleSnapshot.data.isEmpty) {
            return noResultFoundPage();
          }

          List<dynamic> list = articleSnapshot.data;
          return SmartRefresher(
            enablePullDown: true,
            enablePullUp: true,
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus mode) {
                Widget body;
                if (mode == LoadStatus.loading) {
                  if (shouldLoadMore) {
                    body = paginationLoadingWidget();
                  } else {
                    body = Container();
                  }
                }
                return SizedBox(
                  height: 55.0,
                  child: Center(child: body),
                );
              },
            ),
            header: const MaterialClassicHeader(),
            controller: _refreshController,
            onRefresh: loadDataFromApi,
            onLoading: () => loadDataFromApi(forPullToRefresh: false),
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                var dealList = list[index];
                return Card(
                  shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                  elevation: AppThemePreferences.boardPagesElevation,
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        labelAndValueWidget(GenericMethods.getLocalizedString("name"), dealList.displayName),
                        showDivider(),
                        labelAndValueWidget(GenericMethods.getLocalizedString("email"), dealList.email),
                        showDivider(),
                        labelAndValueWidget(GenericMethods.getLocalizedString("phone"), dealList.mobile),
                        addActionButton(dealList.resultLeadId,index),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        } else if (articleSnapshot.hasError) {
          return noResultFoundPage();
          // return Container();
        }
        return loadingIndicatorWidget();
      },
    );
  }

  Widget labelAndValueWidget(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 180,
          child: genericTextWidget(
            label,
            style: AppThemePreferences().appTheme.label01TextStyle
          ),
        ),
        Expanded(
          child: genericTextWidget(
            value,
            style: AppThemePreferences().appTheme.subBody01TextStyle
          ),
        ),
      ],
    );
  }

  Widget showDivider() {
    return const Divider(
      thickness: 1,
    );
  }

  Widget addActionButton(String leadId, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: buttonWidget(
          buttonHeight: 40,
          text: GenericMethods.getLocalizedString("action"),
          iconOnRightSide: true,
          centeredContent: true,
          icon: Icon(
              AppThemePreferences.arrowDropDownIcon, color: AppThemePreferences.filledButtonIconColor
          ),
          onPressed: () {
            _takeActionBottomSheet(context, leadId,index);
          }),
    );
  }

  void _takeActionBottomSheet(context, String leadId, int index) {
    showModalBottomSheet(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        context: context,
        builder: (BuildContext bc) {
          return Wrap(
            children: <Widget>[
              // SizedBox(
              //   width: double.infinity,
              //   height: 70,
              //   child: TextButton(
              //     onPressed: () {},
              //     child: genericTextWidget(
              //       GenericMethods.getLocalizedString("")edit,
              //       style: AppThemePreferences().appTheme.heading02TextStyle,
              //     ),
              //   ),
              // ),
              SizedBox(
                height: 70,
                width: double.infinity,
                child: TextButton(
                  onPressed: () async {
                    dialogBoxWidget(
                      context,
                      title: GenericMethods.getLocalizedString("delete"),
                      content: genericTextWidget(
                          GenericMethods.getLocalizedString("delete_confirmation")),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
                        ),
                        TextButton(
                          onPressed: () async {
                            Navigator.pop(context);
                            int leadID = int.parse(leadId);
                            final response = await _propertyBloc.fetchDeleteLead(leadID);
                            if (response.statusCode == 200) {
                              setState(() {
                                leadsFromBoardList.removeAt(index);
                              });

                              Navigator.pop(context);

                              _showToast(context, GenericMethods.getLocalizedString("lead_deleted"));
                            } else {
                              _showToast(context, GenericMethods.getLocalizedString("error_occurred"),
                              );
                            }
                          },
                          child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
                        ),
                      ],
                    );
                  },
                  child: genericTextWidget(
                    GenericMethods.getLocalizedString("delete_lead"),
                    style: AppThemePreferences().appTheme.heading02TextStyle,
                  ),
                ),
              ),
            ],
          );
        });
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }

  Widget loadingIndicatorWidget() {
    return Container(
      height: (MediaQuery.of(context).size.height) / 2,
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
      bodyErrorText: GenericMethods.getLocalizedString("oops_leads_not_exist"),
    );
  }

  Widget paginationLoadingWidget() {
    return Container(
      color: Theme.of(context).backgroundColor,
      alignment: Alignment.center,
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 50,
            child: loadingBallRotatingWidget(),
          ),
        ],
      ),
    );
  }
}
