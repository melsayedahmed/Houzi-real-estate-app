import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/mixins/validation_mixins.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';

import '../../files/generic_methods/generic_methods.dart';
import '../../widgets/button_widget.dart';
import '../../widgets/generic_text_field_widgets/generic_add_room_widget.dart';

class AddPropertyRequest extends StatefulWidget {
  @override
  _AddPropertyRequestState createState() => _AddPropertyRequestState();
}

class _AddPropertyRequestState extends State<AddPropertyRequest>
    with ValidationMixin {
  bool isAgree = false;
  bool _showWaitingWidget = false;

  bool isInternetConnected = true;
  bool isDataLoadError = false;
  bool isSubmitButtonError = false;

  final PropertyBloc _propertyBloc = PropertyBloc();

  int _beds = 0;
  int _baths = 0;
  int perPage = 10;

  String _selectedInquiryType;

  List<String> _inquiryTypesList = [];
  List<dynamic> _locationsList = [];
  final List<dynamic> _propertyTypesList = [];
  List<dynamic> _propertyTypeMetaDataList = [];
  List<dynamic> _countryList = [];
  List<dynamic> _statesList = [];
  List<dynamic> _areaMetaDataList = [];
  List<dynamic> _areaList = [];
  List<dynamic> inquiriesFromBoardList = [];
  List<Map> contactList = [];

  Future<List<dynamic>> _futureAreaList;

  Map<String, dynamic> addRequestPropertyInfoMap;
  final formKey = GlobalKey<FormState>();

  final _bedroomsTextController = TextEditingController();
  final _bathroomsTextController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadData();
  }

  loadData() {
    _futureAreaList = fetchTermData("property_area");
    _futureAreaList.then((value) {
      _areaMetaDataList = value;
      if (_areaMetaDataList != null && _areaMetaDataList.isNotEmpty) {
        setState(() {
          _areaList = _areaMetaDataList;
        });
      }
      return null;
    });

    String inquiryTypes = HiveStorageManager.readInquiryTypeInfoData();
    _inquiryTypesList = inquiryTypes.split(', ');

    var cityData = HiveStorageManager.readCitiesMetaData();
    _propertyTypeMetaDataList = HiveStorageManager.readPropertyTypesMetaData();
    if (cityData != null && cityData.isNotEmpty) {
      _locationsList = cityData;
    }

    var countryData = HiveStorageManager.readPropertyCountriesMetaData();
    if (countryData != null && countryData.isNotEmpty) {
      _countryList = countryData;
    }

    var statusData = HiveStorageManager.readPropertyStatesMetaData();
    if (statusData != null && statusData.isNotEmpty) {
      _statesList = statusData;
    }

    if (_propertyTypeMetaDataList != null &&
        _propertyTypeMetaDataList.isNotEmpty) {
      List<dynamic> tempList = [];
      List<dynamic> tempList01 = [];
      for (int i = 0; i < _propertyTypeMetaDataList.length; i++) {
        if (_propertyTypeMetaDataList[i].parent == 0) {
          tempList.add(_propertyTypeMetaDataList[i]);
        }
      }

      for (int i = 0; i < tempList.length; i++) {
        for (int j = 0; j < _propertyTypeMetaDataList.length; j++) {
          if (tempList[i].id == _propertyTypeMetaDataList[j].parent) {
            tempList01.add(_propertyTypeMetaDataList[j]);
          }
        }
        _propertyTypesList.add(tempList[i]);
        _propertyTypesList.addAll(tempList01);
        tempList01 = [];
      }
    }

    addRequestPropertyInfoMap = {
      INQUIRY_LEAD_ID: "",
      INQUIRY_ENQUIRY_TYPE: "",
      INQUIRY_PROPERTY_TYPE: "",
      INQUIRY_PRICE: "",
      INQUIRY_BEDS: "",
      INQUIRY_BATHS: "",
      INQUIRY_AREA_SIZE: "",
      INQUIRY_COUNTRY: "",
      INQUIRY_STATE: "",
      INQUIRY_CITY: "",
      INQUIRY_AREA: "",
      INQUIRY_ZIP_CODE: "",
      INQUIRY_MSG: "",
      INQUIRY_FIRST_NAME: "",
      INQUIRY_LAST_NAME: "",
      INQUIRY_EMAIL: "",
      INQUIRY_MOBILE: "",
    };

    if (ADD_PROP_GDPR_ENABLED == "1") {
      addRequestPropertyInfoMap[INQUIRY_GDPR] = "1";
    }
  }

  Future<List<dynamic>> fetchTermData(String term) async {
    List<dynamic> termData = [];
    termData = await _propertyBloc.fetchTermData(term);
    if(termData != null && termData.isNotEmpty && termData[0].runtimeType == Response){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          isDataLoadError = true;
        });
      }
    }else{
      if(mounted){
        setState(() {
          isInternetConnected = true;
          isDataLoadError = false;
        });
      }
    }

    return termData;
  }

  @override
  void dispose() {
    _bedroomsTextController.dispose();
    _bathroomsTextController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("request_property"),
        ),
        body: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Form(
                  key: formKey,
                  child: Stack(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("contact")),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("first_name") + " *",
                                  GenericMethods.getLocalizedString("enter_first_name"),
                                  TextInputType.text,
                                  INQUIRY_FIRST_NAME,
                                  validate: true,
                                  giveTopPadding: true,
                                ),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("last_name") + " *",
                                  GenericMethods.getLocalizedString("enter_last_name"),
                                  TextInputType.text,
                                  INQUIRY_LAST_NAME,
                                  validate: true,
                                ),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("email") + " *",
                                  GenericMethods.getLocalizedString("enter_email_address"),
                                  TextInputType.emailAddress,
                                  INQUIRY_EMAIL,
                                  emailValidation: true,
                                ),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("mobile") + " *",
                                  GenericMethods.getLocalizedString("enter_mobile_address"),
                                  TextInputType.number,
                                  INQUIRY_MOBILE,
                                  validate: true,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("information")),
                                inquiryTypeWidget(),
                                dropDownWidget(
                                  GenericMethods.getLocalizedString("property_type") + " *",
                                  _propertyTypesList,
                                  INQUIRY_PROPERTY_TYPE,
                                  validate: true,
                                ),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("max_price"),
                                  GenericMethods.getLocalizedString("enter_the_max_price"),
                                  TextInputType.number,
                                  INQUIRY_PRICE,
                                  giveTopPadding: true
                                ),
                                addRoomsInformation(context),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("minimum_size"),
                                  GenericMethods.getLocalizedString("enter_the_min_size"),
                                  TextInputType.number,
                                  INQUIRY_AREA_SIZE,
                                  giveTopPadding: true,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("address")),
                                dropDownWidget(
                                  GenericMethods.getLocalizedString("country") + " *",
                                  _countryList,
                                  INQUIRY_COUNTRY,
                                  validate: true,
                                ),
                                dropDownWidget(
                                  GenericMethods.getLocalizedString("states"),
                                  _statesList,
                                  INQUIRY_STATE,
                                ),
                                dropDownWidget(
                                  GenericMethods.getLocalizedString("city") + " *",
                                  _locationsList,
                                  INQUIRY_CITY,
                                  validate: true,
                                ),
                                dropDownWidget(
                                  GenericMethods.getLocalizedString("area"),
                                  _areaList,
                                  INQUIRY_AREA,
                                ),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("zip_code"),
                                  GenericMethods.getLocalizedString("enter_the_zip_code"),
                                  TextInputType.number,
                                  INQUIRY_ZIP_CODE,
                                  giveTopPadding: true,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Column(
                              children: [
                                headerTextWidget(GenericMethods.getLocalizedString("message")),
                                setValuesInFields(
                                  GenericMethods.getLocalizedString("message"),
                                  "",
                                  TextInputType.text,
                                  INQUIRY_MSG,
                                  giveTopPadding: true,
                                ),
                              ],
                            ),
                          ),
                          Card(
                            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                            child: Container(
                              height: 50,
                              margin: const EdgeInsets.only(top: 20, bottom: 20),
                              child: saveButton(),
                            ),
                          ),
                        ],
                      ),
                      waitingWidget(),
                      bottomActionBarWidget(),
                    ],
                  ),
                ),
            ),
      ),
    );
  }

  Widget waitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 100,
            child: Center(
              child: Container(
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  // padding: EdgeInsets.only(top: 50),
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context, () {
                if(isDataLoadError){
                  loadData();
                }else if(isSubmitButtonError){
                  onSavePressed();
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget headerTextWidget(String text) {
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom:
              BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget setValuesInFields(
      String labelText,
      String hintText,
      TextInputType textInputType,
      String key,
      {emailValidation = false,
        bool validate = false,
        bool giveTopPadding = false
      }) {
    return Padding(
      padding: EdgeInsets.fromLTRB(0, giveTopPadding ? 20 : 0, 0, 20),
      child: textFieldWidget(
        labelText: labelText,
        keyboardType: textInputType,
        hintText: hintText,
        maxLines: key == INQUIRY_MSG ? 5 : 1,
        onSaved: (String value) {
          setState(() {
            addRequestPropertyInfoMap[key] = value;
          });
        },
        validator: emailValidation
            ? (value) => validateEmail(context, value)
            : validate
                ? (value) {
                    if (value == null || value.isEmpty) {
                      return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
                    }
                    return null;
                  }
                : null,
      ),
    );
  }

  Widget dropDownWidget(
      String text,
      List list,
      String key,
      {bool validate = false}
      ) {
    return list != null && list.isNotEmpty
        ? Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                genericTextWidget(text,
                    //GenericMethods.getLocalizedString("enter_the_country")type,
                    style: AppThemePreferences().appTheme.labelTextStyle),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: DropdownButtonFormField(
                    decoration: AppThemePreferences.formFieldDecoration(
                        hintText: GenericMethods.getLocalizedString("select")
                    ),
                    //value: _selectedInquiryType,
                    validator: validate
                        ? (String value) {
                            if (value?.isEmpty ?? true) {
                              return GenericMethods.getLocalizedString("this_field_cannot_be_empty"); //AppLocalizations.of(context).;
                            }
                            return null;
                          }
                        : null,
                    items: list.map<DropdownMenuItem<String>>((item) {
                      return DropdownMenuItem<String>(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10.0),
                          child: genericTextWidget(
                            item.name,
                          ),
                        ),
                        value: item.name,
                      );
                    }).toList(),
                    onChanged: (val) {
                      setState(() {
                        addRequestPropertyInfoMap[key] = val;
                      });
                    },
                  ),
                ),
              ],
            ),
          )
        : Container();
  }

  Widget inquiryTypeWidget() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          genericTextWidget(GenericMethods.getLocalizedString("type") + " *",
              style: AppThemePreferences().appTheme.labelTextStyle),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: DropdownButtonFormField(
              decoration: AppThemePreferences.formFieldDecoration(
                  hintText: GenericMethods.getLocalizedString("select")
              ),
              //focusColor: Colors.white,
              value: _selectedInquiryType,
              validator: (String value) {
                if (value?.isEmpty ?? true) {
                  return GenericMethods.getLocalizedString("this_field_cannot_be_empty"); //;
                }
                return null;
              },
              items: _inquiryTypesList.map<DropdownMenuItem<String>>((item) {
                return DropdownMenuItem<String>(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10.0),
                    child: genericTextWidget(
                      item,
                    ),
                  ),
                  value: item,
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  addRequestPropertyInfoMap[INQUIRY_ENQUIRY_TYPE] = val;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget addRoomsInformation(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(flex: 5, child: addNumberOfBedrooms()),
        Expanded(flex: 5, child: addNumberOfBathrooms()),
      ],
    );
  }

  Widget addNumberOfBedrooms() {
    return genericAddRoomsWidget(
      padding: const EdgeInsets.fromLTRB(10, 20, 20, 0),
      labelText: GenericMethods.getLocalizedString("bedrooms"),
      controller: _bedroomsTextController,
      onRemovePressed: () {
        if (_beds > 0) {
          setState(() {
            _beds -= 1;
            _bedroomsTextController.text = _beds.toString();
            addRequestPropertyInfoMap[INQUIRY_BEDS] = _beds.toString();
          });
        }
      },
      onAddPressed: () {
        if (_beds >= 0) {
          setState(() {
            _beds += 1;
            _bedroomsTextController.text = _beds.toString();
            addRequestPropertyInfoMap[INQUIRY_BEDS] = _beds.toString();
          });
        }
      },
      onChanged: (value) {
        setState(() {
          _beds = int.parse(value);
        });
      },
      validator: (String value) {
        return null;
      },
    );
  }

  Widget addNumberOfBathrooms() {
    return genericAddRoomsWidget(
      padding: const EdgeInsets.fromLTRB(10, 20, 20, 0),
      labelText: GenericMethods.getLocalizedString("bathrooms"),
      controller: _bathroomsTextController,
      onRemovePressed: () {
        if (_baths > 0) {
          setState(() {
            _baths -= 1;
            _bathroomsTextController.text = _baths.toString();

            addRequestPropertyInfoMap[INQUIRY_BATHS] = _baths.toString();
          });
        }
      },
      onAddPressed: () {
        if (_baths >= 0) {
          setState(() {
            _baths += 1;
            _bathroomsTextController.text = _baths.toString();
            addRequestPropertyInfoMap[INQUIRY_BATHS] = _baths.toString();
          });
        }
      },
      onChanged: (value) {
        setState(() {
          _baths = int.parse(value);
        });
      },
      validator: (String value) {
        return null;
      },
    );
  }

  Widget saveButton() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: buttonWidget(
        text: GenericMethods.getLocalizedString("request_property"),
        onPressed: ()=> onSavePressed(),
      ),
    );
  }

  onSavePressed() async {
    if (formKey.currentState.validate()) {
      formKey.currentState.save();
      setState(() {
        _showWaitingWidget = true;
      });

      final response = await _propertyBloc
          .fetchAddRequestPropertyResponse(addRequestPropertyInfoMap);

      if(response == null || response.statusCode == null){
        if(mounted){
          setState(() {
            isInternetConnected = false;
            _showWaitingWidget = false;
            isSubmitButtonError = true;
          });
        }
      }else{
        if(mounted){
          setState(() {
            isInternetConnected = true;
            _showWaitingWidget = false;
            isSubmitButtonError = false;
          });
        }

        String tempResponseString = response.toString().split("{")[1];
        Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");

        if (map["success"] == true) {
          _showToast(context, map["msg"]);
          Navigator.of(context).pop();
        } else {
          _showToast(context, map["msg"]);
        }
      }
    }
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }
}
