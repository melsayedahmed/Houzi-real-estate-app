import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/dialog_box_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';

import '../../files/generic_methods/generic_methods.dart';
import 'add_new_deal_page.dart';

typedef DealDetailPageListener = void Function({int index, bool refresh, String dealOption});

class DealDetailPage extends StatefulWidget {

  final Map<String,String> dealDetailMap;
  final DealDetailPageListener dealDetailPageListener;
  final int index;

  DealDetailPage({this.dealDetailMap, this.dealDetailPageListener,this.index});

  @override
  _DealDetailPageState createState() => _DealDetailPageState();
}

class _DealDetailPageState extends State<DealDetailPage> {
  final PropertyBloc _propertyBloc = PropertyBloc();

  final List<String> statusOptions = <String>[
    "New Lead",
    "Meeting Scheduled",
    "Qualified",
    "Proposal Sent",
    "Called",
    "Negotiation",
    "Email Sent",
  ];

  final List<String> nextActionOptions = <String>[
    "Qualification",
    "Demo",
    "Call",
    "Send a Proposal",
    "Send an Email",
    "Follow Up",
    "Meeting",
  ];

  String _statusValue = "New Lead";
  String _nextActionValue = "Qualification";

  @override
  void initState() {
    super.initState();
    _statusValue = widget.dealDetailMap[DEAL_DETAIL_STATUS]; 
    _nextActionValue = widget.dealDetailMap[DEAL_DETAIL_NEXT_ACTION];

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("deal_detail"),
        ),
        body: Column(
          children: [
            Card(
              shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
              elevation: AppThemePreferences.boardPagesElevation,
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    genericTextWidget(
                      widget.dealDetailMap[DEAL_DETAIL_TITLE],
                      style: AppThemePreferences().appTheme.heading01TextStyle
                    ),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("contact_name"), widget.dealDetailMap[DEAL_DETAIL_DISPLAY_NAME]),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("agent"), widget.dealDetailMap[DEAL_DETAIL_AGENT_NAME]),
                    showDivider(),
                    Row(
                      children: [
                        SizedBox(
                          width: 170,
                          child: genericTextWidget(
                            GenericMethods.getLocalizedString("status"),
                            maxLines: 1,
                            style: AppThemePreferences().appTheme.label01TextStyle
                          ),
                        ),
                        dropDownStatus(),
                      ],
                    ),
                    showDivider(),
                    Row(
                      children: [
                        SizedBox(
                          width: 170,
                          child: genericTextWidget(
                            GenericMethods.getLocalizedString("next_action"),
                            style: AppThemePreferences().appTheme.label01TextStyle
                          ),
                        ),
                        dropDownNextAction(),
                      ],
                    ),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("action_due_date"), widget.dealDetailMap[DEAL_DETAIL_ACTION_DUE_DATE]),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("deal_value"), widget.dealDetailMap[DEAL_DETAIL_VALUE]),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("last_contact_date"), widget.dealDetailMap[DEAL_DETAIL_LAST_CONTACT_DATE]),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("phone"), widget.dealDetailMap[DEAL_DETAIL_PHONE]),
                    showDivider(),
                    labelAndValueWidget(GenericMethods.getLocalizedString("email"), widget.dealDetailMap[DEAL_DETAIL_EMAIL])
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: addActionButton(),
            ),
          ],
        ),
      );
  }

  Widget labelAndValueWidget(String label, String value) {
    return Row(
      children: [
        SizedBox(
          width: 170,
          child: genericTextWidget(
            label,
            style: AppThemePreferences().appTheme.label01TextStyle
          ),
        ),
        Expanded(
          child: genericTextWidget(
            value,
            style: AppThemePreferences().appTheme.subBody01TextStyle
          ),
        ),
      ],
    );
  }

  Widget showDivider() {
    return const Divider(
      thickness: 1,
    );
  }

  Widget addActionButton() {
    return buttonWidget(
        text: GenericMethods.getLocalizedString("action"),
        iconOnRightSide: true,
        centeredContent: true,
        icon: Icon(AppThemePreferences.arrowDropDownIcon,color: AppThemePreferences.filledButtonIconColor),
        onPressed: () {
          _takeActionBottomSheetForDeal(context);
        });
  }

  void _takeActionBottomSheetForDeal(context) {
    showModalBottomSheet(
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        context: context,
        builder: (BuildContext bc) {
          return Wrap(
            children: <Widget>[
              SizedBox(
                width: double.infinity,
                height: 70,
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            AddNewDeal(dealDetailMap: widget.dealDetailMap,forEditDeal: true ,addNewDealPageListenerPageListener: (bool refresh,String dealOption){
                              widget.dealDetailPageListener(refresh: true, dealOption: dealOption);
                              Navigator.pop(context);
                              Navigator.pop(context);
                            }
                        ),
                      ),
                    );
                  },
                  child: genericTextWidget(
                    GenericMethods.getLocalizedString("edit"),
                    style: AppThemePreferences().appTheme.heading02TextStyle,
                  ),
                ),
              ),
              SizedBox(
                height: 70,
                width: double.infinity,
                child: TextButton(
                  onPressed: () async {
                    dialogBoxWidget(
                      context,
                      title: GenericMethods.getLocalizedString("delete"),
                      content: genericTextWidget(
                          GenericMethods.getLocalizedString("delete_confirmation")),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
                        ),
                        TextButton(
                          onPressed: () async {
                            Navigator.pop(context);
                            int dealID = int.parse(widget.dealDetailMap[DEAL_DETAIL_ID]);
                            final response = await _propertyBloc.fetchDeleteDeal(dealID);
                            if (response.statusCode == 200) {
                              Navigator.pop(context);
                              Navigator.pop(context);
                              widget.dealDetailPageListener(index: widget.index,refresh: false);
                              _showToast(context, GenericMethods.getLocalizedString("deal_deleted"));
                            } else {
                              _showToast(context, GenericMethods.getLocalizedString("error_occurred"),
                              );
                            }
                          },
                          child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
                        ),
                      ],
                    );
                  },
                  child: genericTextWidget(
                    GenericMethods.getLocalizedString("delete_deal"),
                    style: AppThemePreferences().appTheme.bottomSheetNegativeOptionsTextStyle,
                  ),
                ),
              ),
            ],
          );
        });
  }

  Widget dropDownStatus() {
    return Row(
      children: <Widget>[
        Center(
          child: DropdownButton(
            value: _statusValue.isNotEmpty ? _statusValue : null,
            onChanged: (value) {
              setState(() {
                _statusValue = value;
              });
            },
            items: statusOptions.map(
              (item) {
                return DropdownMenuItem(
                  value: item,
                  child: genericTextWidget(item),
                );
              },
            ).toList(),
          ),
        ),
      ],
    );
  }

  Widget dropDownNextAction() {
    return Row(
      children: <Widget>[
        Center(
          child: DropdownButton(
            value: _nextActionValue.isNotEmpty ? _nextActionValue : null,
            onChanged: (value) {
              setState(() {
                _nextActionValue = value;
              });
            },
            items: nextActionOptions.map(
              (item) {
                return DropdownMenuItem(
                  value: item,
                  child: genericTextWidget(item),
                );
              },
            ).toList(),
          ),
        ),
      ],
    );
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }
}
