import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/common/constants.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/models/dynamic_item.dart';
import 'package:houzi_package/widgets/add_property_widgets/additional_details_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/generic_add_room_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';
import 'package:houzi_package/widgets/light_button_widget.dart';

import '../../files/generic_methods/generic_methods.dart';
import '../../files/hive_storage_files/hive_storage_manager.dart';
import '../../models/custom_fields.dart';
import '../../widgets/add_property_widgets/custom_fields_widgets.dart';


typedef PropertyDetailsPageListener = void Function(Map<String, dynamic> _dataMap);
class PropertyDetails extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => PropertyDetailsState();
  final GlobalKey<FormState> formKey;
  final Map<String, dynamic> propertyInfoMap;
  final PropertyDetailsPageListener propertyDetailsPageListener;

  PropertyDetails({
    this.formKey,
    this.propertyInfoMap,
    this.propertyDetailsPageListener,
  });
}

class PropertyDetailsState extends State<PropertyDetails> {

  int _beds = 0;
  int _baths = 0;

  Map<String, dynamic> dataMap = {};

  final List<DynamicItem> _additionalDetailsList = [];

  final _bedroomsTextController = TextEditingController();
  final _bathroomsTextController = TextEditingController();
  final _areaSizeTextController = TextEditingController();
  final _sizePostfixTextController = TextEditingController();
  final _landAreaTextController = TextEditingController();
  final _landAreaSizePostfixTextController = TextEditingController();
  final _garagesTextController = TextEditingController();
  final _garageSizeTextController = TextEditingController();
  final _propertyIDTextController = TextEditingController();
  final _yearBuiltTextController = TextEditingController();

  List<dynamic> customList = [];

  @override
  void dispose() {
    _bedroomsTextController.dispose();
    _bathroomsTextController.dispose();
    _areaSizeTextController.dispose();
    _sizePostfixTextController.dispose();
    _landAreaTextController.dispose();
    _landAreaSizePostfixTextController.dispose();
    _garagesTextController.dispose();
    _garageSizeTextController.dispose();
    _propertyIDTextController.dispose();
    _yearBuiltTextController.dispose();
    super.dispose();
  }


  @override
  void initState() {
    Map tempMap = widget.propertyInfoMap;
    if (tempMap != null) {
      if (tempMap.containsKey(ADD_PROPERTY_BEDROOMS)) {
        _bedroomsTextController.text = tempMap[ADD_PROPERTY_BEDROOMS];
        try {
          _beds = int.parse(tempMap[ADD_PROPERTY_BEDROOMS]);
        } catch(e){}
      }
      if (tempMap.containsKey(ADD_PROPERTY_BATHROOMS)) {
        _bathroomsTextController.text = tempMap[ADD_PROPERTY_BATHROOMS];
        try {
          _baths = int.parse(tempMap[ADD_PROPERTY_BATHROOMS]);
        } catch(e){}
      }
      if (tempMap.containsKey(ADD_PROPERTY_SIZE)) {
        _areaSizeTextController.text = tempMap[ADD_PROPERTY_SIZE];
      }
      if (tempMap.containsKey(ADD_PROPERTY_SIZE_PREFIX)) {
        _sizePostfixTextController.text = tempMap[ADD_PROPERTY_SIZE_PREFIX];
      }
      if (tempMap.containsKey(ADD_PROPERTY_LAND_AREA)) {
        _landAreaTextController.text = tempMap[ADD_PROPERTY_LAND_AREA];
      }
      if (tempMap.containsKey(ADD_PROPERTY_LAND_AREA_PREFIX)) {
        _landAreaSizePostfixTextController.text = tempMap[ADD_PROPERTY_LAND_AREA_PREFIX];
      }
      if (tempMap.containsKey(ADD_PROPERTY_GARAGE)) {
        _garagesTextController.text = tempMap[ADD_PROPERTY_GARAGE];
      }
      if (tempMap.containsKey(ADD_PROPERTY_GARAGE_SIZE)) {
        _garageSizeTextController.text = tempMap[ADD_PROPERTY_GARAGE_SIZE];
      }
      if (tempMap.containsKey(ADD_PROPERTY_PROPERTY_ID)) {
        _propertyIDTextController.text = tempMap[ADD_PROPERTY_PROPERTY_ID];
      }
      if (tempMap.containsKey(ADD_PROPERTY_YEAR_BUILT)) {
        _yearBuiltTextController.text = tempMap[ADD_PROPERTY_YEAR_BUILT];
      }
      if(tempMap.containsKey(ADD_PROPERTY_ADDITIONAL_FEATURES)){
        List<Map<String, dynamic>> list = widget.propertyInfoMap[ADD_PROPERTY_ADDITIONAL_FEATURES];
        if(list != null && list.isNotEmpty){
          for(int i = 0; i < list.length; i++){
            var item = list[i];
            _additionalDetailsList.add(
              DynamicItem(
                key: "Key$i",
                dataMap: item,
              ),
            );
          }
        }
      }
    }

    var data = HiveStorageManager.readCustomFieldsDataMaps();

    if(data!=null){
      final custom = customFromJson(data);
      customList = custom.customFields;
    }
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Form(
          key: widget.formKey,
          child: Column(
            children: [
              Card(
                child: Column(
                  children: [
                    propertyAreaTextWidget(),
                    addRoomsInformation(),
                    addAreaInformation(),
                    addLandAreaInformation(),
                    addGarageInformation(),
                    addPropertyRelatedInformation(),
                    if(customList!=null && customList.isNotEmpty)
                      Column(
                        children: customList.map((e) {
                          return CustomFieldsWidget(
                            customFieldData: e,
                            propertyInfoMap: widget.propertyInfoMap,
                            customFieldsPageListener: (Map<String, dynamic> _dataMap){
                              dataMap.addAll(_dataMap);
                              widget.propertyDetailsPageListener(dataMap);
                            },
                          );
                        }).toList(),
                      ),
                  ],
                ),
              ),
              Card(
                child: Column(
                  children: [
                    additionalDetailsTextWidget(),
                    _additionalDetailsList != null && _additionalDetailsList.isNotEmpty ? Column(
                      children: _additionalDetailsList.map((dynamicItem) {
                        int itemIndex = _additionalDetailsList.indexOf(dynamicItem);
                        return GenericAdditionalDetailsWidget(
                          index: itemIndex,
                          dataMap: dynamicItem.dataMap,
                          genericAdditionalDetailsWidgetListener: (int index, Map<String,
                              dynamic> itemDataMap, bool removeItem){
                            if(removeItem){
                              if(mounted) {
                                setState(() {
                                  _additionalDetailsList.removeAt(index);
                                });
                              }
                            }else{
                              if(mounted) {
                                setState(() {
                                  _additionalDetailsList[index].dataMap = itemDataMap;
                                });
                              }
                            }

                            updateDataMap();
                          },
                        );
                      }).toList(),
                    ) : Container(),
                    addNewElevatedButton(),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget headingWidget({String text}){
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget labelWidget(String text){
    return genericTextWidget(
      text,
      style: AppThemePreferences().appTheme.labelTextStyle,
    );
  }

  Widget hintWidget(String text){
    return genericTextWidget(
      text,
      style: AppThemePreferences().appTheme.hintTextStyle,
    );
  }

  InputDecoration formFieldDecoration({String hintText}){
    return InputDecoration(
      hintText: hintText,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(5.0),
        borderSide: const BorderSide(),
      ),
    );
  }

  Widget propertyAreaTextWidget() {
    return headingWidget(text: GenericMethods.getLocalizedString("details"));//AppLocalizations.of(context).details);
  }

  Widget additionalDetailsTextWidget() {
    return headingWidget(text: GenericMethods.getLocalizedString("additional_details"));//AppLocalizations.of(context).additional_details);
  }

  Widget addRoomsInformation(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(flex: 5, child: addNumberOfBedrooms()),
        Expanded(flex: 5, child: addNumberOfBathrooms()),
      ],
    );
  }

  Widget addNumberOfBedrooms(){
    return genericAddRoomsWidget(
      padding: const EdgeInsets.fromLTRB(10, 20, 20, 0),
      labelText: GenericMethods.getLocalizedString("bedrooms"),//AppLocalizations.of(context).bedrooms,
      controller: _bedroomsTextController,
      onRemovePressed: () {
        if(_beds > 0){
          setState(() {
            _beds -= 1;
            _bedroomsTextController.text = _beds.toString();
          });
        }
      },
      onAddPressed: () {
        if(_beds >= 0){
          setState(() {
            _beds += 1;
            _bedroomsTextController.text = _beds.toString();
          });
        }
      },
      onChanged: (value){
        setState(() {
          _beds = int.parse(value);
        });
      },
      validator: (String value) {
        if(value != null && value.isNotEmpty) {
          setState(() {
            dataMap[ADD_PROPERTY_BEDROOMS] = value;
          });
          widget.propertyDetailsPageListener(dataMap);
        }
        return null;
      },
    );
  }

  Widget addNumberOfBathrooms(){
    return genericAddRoomsWidget(
      padding: const EdgeInsets.fromLTRB(10, 20, 20, 0),
      labelText: GenericMethods.getLocalizedString("bathrooms"),//AppLocalizations.of(context).bathrooms,
      controller: _bathroomsTextController,
      onRemovePressed: () {
        if(_baths > 0){
          setState(() {
            _baths -= 1;
            _bathroomsTextController.text = _baths.toString();
          });
        }
      },
      onAddPressed: () {
        if(_baths >= 0){
          setState(() {
            _baths += 1;
            _bathroomsTextController.text = _baths.toString();
          });
        }
      },
      onChanged: (value){
        setState(() {
          _baths = int.parse(value);
        });
      },
      validator: (String value) {
        if(value != null && value.isNotEmpty) {
          setState(() {
            dataMap[ADD_PROPERTY_BATHROOMS] = value;
          });
          widget.propertyDetailsPageListener(dataMap);
        }
        return null;
      },
    );
  }

  Widget addAreaInformation(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(flex: 5, child: addAreaSize()),
        Expanded(flex: 5, child: addSizePostfix()),
      ],
    );
  }

  Widget addAreaSize(){
    return textFieldWidget(
      padding: const EdgeInsets.fromLTRB(20, 30, 10, 0),
      labelText: GenericMethods.getLocalizedString("area_size"),//AppLocalizations.of(context).area_size,
      hintText: GenericMethods.getLocalizedString("enter_area_size"),//AppLocalizations.of(context).enter_area_size,
      additionalHintText: GenericMethods.getLocalizedString("only_digits"),//AppLocalizations.of(context).only_digits,

      validator: (String value) {
        if(value != null && value.isNotEmpty) {
          setState(() {
            dataMap[ADD_PROPERTY_SIZE] = value;
          });
          widget.propertyDetailsPageListener(dataMap);
        }
        return null;
      },
      controller: _areaSizeTextController,
      keyboardType: TextInputType.number,
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.digitsOnly,
      ],
    );
  }

  Widget addSizePostfix(){
    return Container(
      padding: const EdgeInsets.only(top: 30.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("size_postfix"),//AppLocalizations.of(context).size_postfix,
        hintText: GenericMethods.getLocalizedString("enter_size_postfix"),//AppLocalizations.of(context).enter_size_postfix,
        additionalHintText: GenericMethods.getLocalizedString("for_example") + MEASUREMENT_UNIT_TEXT,//AppLocalizations.of(context).for_example_Sq_Ft,
        validator: (String value) {
          if(value != null && value.isNotEmpty) {
            setState(() {
              dataMap[ADD_PROPERTY_SIZE_PREFIX] = value;
            });
            widget.propertyDetailsPageListener(dataMap);
          }
          return null;
        },
        controller: _sizePostfixTextController,
      ),
    );
  }

  Widget addLandAreaInformation(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(flex: 5, child: addLandArea()),
        Expanded(flex: 5, child: addLandAreaSizePostfix()),
      ],
    );
  }

  Widget addLandArea(){
    return textFieldWidget(
      padding: const EdgeInsets.fromLTRB(20, 20, 10, 0),
      labelText: GenericMethods.getLocalizedString("land_area"),//AppLocalizations.of(context).land_area,
      hintText: GenericMethods.getLocalizedString("enter_land_area"),//AppLocalizations.of(context).enter_land_area,
      additionalHintText: GenericMethods.getLocalizedString("only_digits"),//AppLocalizations.of(context).only_digits,
      controller: _landAreaTextController,
      keyboardType: TextInputType.number,
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.digitsOnly,
      ],
      validator: (String value) {
        if(value != null && value.isNotEmpty) {
          setState(() {
            dataMap[ADD_PROPERTY_LAND_AREA] = value;
          });
          widget.propertyDetailsPageListener(dataMap);
        }
        return null;
      },
    );
  }

  Widget addLandAreaSizePostfix(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("size_postfix"),//AppLocalizations.of(context).size_postfix,
        hintText: GenericMethods.getLocalizedString("enter_size_postfix"),//AppLocalizations.of(context).enter_size_postfix,
        additionalHintText: GenericMethods.getLocalizedString("for_example") + MEASUREMENT_UNIT_TEXT,//AppLocalizations.of(context).for_example_Sq_Ft,
        controller: _landAreaSizePostfixTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty) {
            setState(() {
              dataMap[ADD_PROPERTY_LAND_AREA_PREFIX] = value;
            });
            widget.propertyDetailsPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addGarageInformation(){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(flex: 5, child: addNumberOfGarages()),
        Expanded(flex: 5, child: addGarageSize()),
      ],
    );
  }

  Widget addNumberOfGarages(){
    return textFieldWidget(
      padding: const EdgeInsets.fromLTRB(20, 20, 10, 0),
      labelText: GenericMethods.getLocalizedString("garages"),//AppLocalizations.of(context).garages,
      hintText: GenericMethods.getLocalizedString("number_of_garages"),//AppLocalizations.of(context).number_of_garages,
      additionalHintText: GenericMethods.getLocalizedString("only_digits"),//AppLocalizations.of(context).only_digits,
      controller: _garagesTextController,
      keyboardType: TextInputType.number,
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.digitsOnly,
      ],
      validator: (String value) {
        if(value != null && value.isNotEmpty) {
          setState(() {
            dataMap[ADD_PROPERTY_GARAGE] = value;
          });
          widget.propertyDetailsPageListener(dataMap);
        }
        return null;
      },
    );
  }

  Widget addGarageSize(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        // ignorePadding: true,
        labelText: GenericMethods.getLocalizedString("garage_size"),//AppLocalizations.of(context).garage_size,
        hintText: GenericMethods.getLocalizedString("enter_garage_size"),//AppLocalizations.of(context).enter_garage_size,
        additionalHintText: GenericMethods.getLocalizedString("for_example") + MEASUREMENT_UNIT_TEXT,//AppLocalizations.of(context).for_example_Sq_Ft,
        controller: _garageSizeTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty) {
            setState(() {
              dataMap[ADD_PROPERTY_GARAGE_SIZE] = value;
            });
            widget.propertyDetailsPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addPropertyRelatedInformation(){
    return Container(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Expanded(flex: 5, child: addPropertyID()),
          Expanded(flex: 5, child: addYearBuilt()),
          Expanded(flex: 5, child: Container()),
        ],
      ),
    );
  }

  Widget addPropertyID(){
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 10, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          labelWidget(GenericMethods.getLocalizedString("property_id")),//AppLocalizations.of(context).property_id),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: TextFormField(
              controller: _propertyIDTextController,
              validator: (String value) {
                if(value != null && value.isNotEmpty) {
                  setState(() {
                    dataMap[ADD_PROPERTY_PROPERTY_ID] = value;
                  });
                  widget.propertyDetailsPageListener(dataMap);
                }
                return null;
              },
              decoration: formFieldDecoration(hintText: GenericMethods.getLocalizedString("enter_property_id")),//AppLocalizations.of(context).enter_property_id),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 5, left: 5),
            child: hintWidget(GenericMethods.getLocalizedString("for_example_hz_01")),//AppLocalizations.of(context).for_example_hz_01),
          ),
        ],
      ),
    );
  }

  Widget addYearBuilt(){
    return textFieldWidget(
      padding: const EdgeInsets.fromLTRB(20, 20, 10, 0),
      labelText: GenericMethods.getLocalizedString("year_built"),//AppLocalizations.of(context).year_built,
      hintText:GenericMethods.getLocalizedString("enter_year_built"),// AppLocalizations.of(context).enter_year_built,
      additionalHintText: GenericMethods.getLocalizedString("only_digits"),//AppLocalizations.of(context).only_digits,
      controller: _yearBuiltTextController,
      keyboardType: TextInputType.number,
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.digitsOnly,
      ],
      validator: (String value) {
        if(value != null && value.isNotEmpty) {
          setState(() {
            dataMap[ADD_PROPERTY_YEAR_BUILT] = value;
          });
          widget.propertyDetailsPageListener(dataMap);
          
        }
        return null;
      },
    );
  }

  Widget addNewElevatedButton(){
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      child: lightButtonWidget(
          text: GenericMethods.getLocalizedString("add_new"),//AppLocalizations.of(context).add_new,
          fontSize: AppThemePreferences.buttonFontSize,
          onPressed: (){
            setState(() {
              _additionalDetailsList.add(DynamicItem(
                key: _additionalDetailsList != null && _additionalDetailsList.isNotEmpty ?
                "Key${_additionalDetailsList.length}" : "Key0",
                dataMap: {
                  faveAdditionalFeatureTitle : "",
                  faveAdditionalFeatureValue : "",
                },
              ));
            });
          }
      ),
    );
  }

  updateDataMap(){
    List<Map<String, dynamic>> list = [];
    for(var item in _additionalDetailsList){
      list.add(item.dataMap);
    }
    dataMap[ADD_PROPERTY_ADDITIONAL_FEATURES] = list;
    widget.propertyDetailsPageListener(dataMap);

  }

}