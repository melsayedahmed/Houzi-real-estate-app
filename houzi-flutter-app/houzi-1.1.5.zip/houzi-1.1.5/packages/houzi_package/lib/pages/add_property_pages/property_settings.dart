import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';

import '../../files/generic_methods/generic_methods.dart';

typedef PropertySettingsPageListener = void Function(Map<String, dynamic> dataMap);

class PropertySettingsPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => PropertySettingsPageState();

  final GlobalKey<FormState> formKey;
  final Map<String, dynamic> propertyInfoMap;
  final PropertySettingsPageListener propertySettingsPageListener;

  PropertySettingsPage({
    Key key,
    this.formKey,
    this.propertyInfoMap,
    this.propertySettingsPageListener,
  });
}

class PropertySettingsPageState extends State<PropertySettingsPage> {

  Map<String, dynamic> dataMap = {};

  int _groupValueForFeaturedOption = 0;
  int _groupValueForLoggingOption = 0;

  final TextEditingController _propertyDisclaimerTextController = TextEditingController();

  // List<String> optionsList = [
  //   'Yes',
  //   'No',
  // ];

  @override
  void initState() {
    super.initState();

    Map tempMap = widget.propertyInfoMap;
    if(tempMap != null){
      String tempValue = '';
      if(tempMap.containsKey(ADD_PROPERTY_MAKE_PROPERTY_FEATURED)){
        tempValue = tempMap[ADD_PROPERTY_MAKE_PROPERTY_FEATURED];
        _groupValueForFeaturedOption = int.tryParse(tempValue) ?? 0;
      }
      if(tempMap.containsKey(ADD_PROPERTY_USER_LOGGED_IN_TO_VIEW)){
        tempValue = tempMap[ADD_PROPERTY_USER_LOGGED_IN_TO_VIEW];
        _groupValueForLoggingOption = int.tryParse(tempValue) ?? 0;
      }
      if(tempMap.containsKey(ADD_PROPERTY_DISCLAIMER)){
        _propertyDisclaimerTextController.text = tempMap[ADD_PROPERTY_DISCLAIMER];
      }
    }
  }

  @override
  void dispose() {
    if(_propertyDisclaimerTextController != null) _propertyDisclaimerTextController.dispose();
    dataMap = {};
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Form(
          key: widget.formKey,
          child: Column(
            children: [
              Card(
                child: Column(
                  children: [
                    propertySettingsTextWidget(),
                    makePropertyFeaturedTextWidget(),
                    userMustLoggedInTextWidget(),
                    addDisclaimer(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget propertySettingsTextWidget() {
    return headerWidget(
      text: GenericMethods.getLocalizedString("property_settings"),//AppLocalizations.of(context).property_settings,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: AppThemePreferences.dividerDecoration(),
    );
  }

  Widget labelWidget(String text){
    return  genericTextWidget(
      text,
      style: AppThemePreferences().appTheme.labelTextStyle,
    );
  }

  Widget makePropertyFeaturedTextWidget() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
            child: labelWidget(GenericMethods.getLocalizedString("do_you_want_to_mark_this_property_as_featured")),//AppLocalizations.of(context).do_you_want_to_mark_this_property_as_featured),
          ),
          Container(
            padding: const EdgeInsets.only(left: 5.0, bottom: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                userChoiceFromRadioButton(
                  value: 0,
                  groupValue: _groupValueForFeaturedOption,
                  onChanged: (value){
                    setState(() {
                      _groupValueForFeaturedOption = value;
                    });
                    dataMap[ADD_PROPERTY_MAKE_PROPERTY_FEATURED] = "$_groupValueForFeaturedOption";
                    widget.propertySettingsPageListener(dataMap);
                  },
                  optionText: GenericMethods.getLocalizedString("no"),//AppLocalizations.of(context).no,
                  // optionText: optionsList[0],
                ),
                userChoiceFromRadioButton(
                  value: 1,
                  groupValue: _groupValueForFeaturedOption,
                  onChanged: (value){
                    setState(() {
                      _groupValueForFeaturedOption = value;
                    });
                    dataMap[ADD_PROPERTY_MAKE_PROPERTY_FEATURED] = "$_groupValueForFeaturedOption";
                    widget.propertySettingsPageListener(dataMap);
                  },
                  optionText: GenericMethods.getLocalizedString("yes"),//AppLocalizations.of(context).yes,
                  // optionText: optionsList[1],
                ),
              ],
            ),
          ),
        ],
      ),
      decoration: AppThemePreferences.dividerDecoration(),
    );
  }

  Widget userChoiceFromRadioButton({
    @required int value,
    @required int groupValue,
    @required void Function(int) onChanged,
    @required String optionText,
}){
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Radio(
          activeColor: AppThemePreferences().appTheme.primaryColor,
          value: value,
          groupValue: groupValue,
          onChanged: onChanged,
        ),
        genericTextWidget(
          optionText,
          style: AppThemePreferences().appTheme.label01TextStyle,
        ),
      ],
    );
  }

  Widget userMustLoggedInTextWidget() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
            child: labelWidget(GenericMethods.getLocalizedString("the_user_must_be_logged_in_to_view_this_property")),//AppLocalizations.of(context).the_user_must_be_logged_in_to_view_this_property),
          ),
          Container(
            padding: const EdgeInsets.only(left: 5.0, bottom: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                userChoiceFromRadioButton(
                  value: 0,
                  groupValue: _groupValueForLoggingOption,
                  onChanged: (value){
                    setState(() {
                      _groupValueForLoggingOption = value;
                    });
                    dataMap[ADD_PROPERTY_USER_LOGGED_IN_TO_VIEW] = "$_groupValueForLoggingOption";
                    widget.propertySettingsPageListener(dataMap);
                  },
                  optionText: GenericMethods.getLocalizedString("no"),//AppLocalizations.of(context).no,
                  // optionText: optionsList[0],
                ),
                userChoiceFromRadioButton(
                  value: 1,
                  groupValue: _groupValueForLoggingOption,
                  onChanged: (value){
                    setState(() {
                      _groupValueForLoggingOption = value;
                    });
                    dataMap[ADD_PROPERTY_USER_LOGGED_IN_TO_VIEW] = "$_groupValueForLoggingOption";
                    widget.propertySettingsPageListener(dataMap);
                  },
                  optionText: GenericMethods.getLocalizedString("yes"),//AppLocalizations.of(context).yes,
                  // optionText: optionsList[1],
                ),
              ],
            ),
          ),
        ],
      ),
      decoration: AppThemePreferences.dividerDecoration(),
    );
  }

  Widget addDisclaimer(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0, bottom: 30.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("disclaimer"),//AppLocalizations.of(context).disclaimer,
        hintText: GenericMethods.getLocalizedString("disclaimer"),//AppLocalizations.of(context).disclaimer,
        keyboardType: TextInputType.multiline,
        maxLines: 7,
        controller: _propertyDisclaimerTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            setState(() {
              dataMap[ADD_PROPERTY_DISCLAIMER]  = value;
            });
            widget.propertySettingsPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }
}