import 'dart:convert';
import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart' as geo_locator;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/address.dart';
import 'package:houzi_package/models/address_search.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';
import 'package:houzi_package/widgets/shimmer_effect_error_widget.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:uuid/uuid.dart';

import '../../dataProvider/place_api_provider.dart';


typedef PropertyAddressPageListener = void Function(Map<String, dynamic> _dataMap);

class PropertyAddressPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => PropertyAddressPageState();

  final PropertyAddressPageListener propertyAddressPageListener;
  final GlobalKey<FormState> formKey;
  final Map<String, dynamic> propertyInfoMap;

  PropertyAddressPage({
    this.formKey,
    this.propertyInfoMap,
    this.propertyAddressPageListener,
  });

}

class PropertyAddressPageState extends State<PropertyAddressPage>{

  Map<String, dynamic> dataMap = {};

  double mapWidgetHeight = 300;
  double mapZoom = 12.0;

  String currentPositionLink = "";

  LatLng defaultLocation = const LatLng(37.4219999, -122.0862462);
  LatLng _initialPosition;
  LatLng _currentPosition;

  final _addressTextController = TextEditingController();
  final _addressLatitudeTextController = TextEditingController();
  final _addressLongitudeTextController = TextEditingController();
  final _addressCountryTextController = TextEditingController();
  final _addressCityTextController = TextEditingController();
  final _addressZipOrPostalCodeTextController = TextEditingController();
  final _addressStateTextController = TextEditingController();
  final _addressAreaTextController = TextEditingController();
  final _searchResultController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // _checkPermission();

    // _getUserLocation();

    double latitude;
    double longitude;
    Map<String, dynamic> _tempMapInfoMap = {};

    Map tempMap = widget.propertyInfoMap;
    if(tempMap != null){
      String address = "";
      if(tempMap.containsKey(ADD_PROPERTY_MAP_ADDRESS)){
        _addressTextController.text = tempMap[ADD_PROPERTY_MAP_ADDRESS];
        address = tempMap[ADD_PROPERTY_MAP_ADDRESS];
        _tempMapInfoMap[ADD_PROPERTY_MAP_ADDRESS] = tempMap[ADD_PROPERTY_MAP_ADDRESS];
      }
      if(tempMap.containsKey(ADD_PROPERTY_LATITUDE)){
        var lat = tempMap[ADD_PROPERTY_LATITUDE].toString();
        _addressLatitudeTextController.text = lat;
        if (lat != null && lat.isNotEmpty) {
          latitude = double.parse(lat);
        }
        _tempMapInfoMap[ADD_PROPERTY_LATITUDE] = _addressLatitudeTextController.text;
      }
      if(tempMap.containsKey(ADD_PROPERTY_LONGITUDE)){
        var lng = tempMap[ADD_PROPERTY_LONGITUDE].toString();
        _addressLongitudeTextController.text = lng;
        if (lng != null && lng.isNotEmpty) {
          longitude = double.parse(lng);
        }
        _tempMapInfoMap[ADD_PROPERTY_LONGITUDE] = _addressLongitudeTextController.text;
      }
      if(tempMap.containsKey(ADD_PROPERTY_COUNTRY)){
        _addressCountryTextController.text = tempMap[ADD_PROPERTY_COUNTRY];
        _tempMapInfoMap[ADD_PROPERTY_COUNTRY] = tempMap[ADD_PROPERTY_COUNTRY];
      }
      if(tempMap.containsKey(ADD_PROPERTY_CITY)){
        _addressCityTextController.text = tempMap[ADD_PROPERTY_CITY];
        _tempMapInfoMap[ADD_PROPERTY_CITY] = tempMap[ADD_PROPERTY_CITY];
      }
      if(tempMap.containsKey(ADD_PROPERTY_POSTAL_CODE)){
        _addressZipOrPostalCodeTextController.text = tempMap[ADD_PROPERTY_POSTAL_CODE];
        _tempMapInfoMap[ADD_PROPERTY_POSTAL_CODE] = tempMap[ADD_PROPERTY_POSTAL_CODE];
      }
      if(tempMap.containsKey(ADD_PROPERTY_STATE_OR_COUNTY)){
        _addressStateTextController.text = tempMap[ADD_PROPERTY_STATE_OR_COUNTY];
        _tempMapInfoMap[ADD_PROPERTY_STATE_OR_COUNTY] = tempMap[ADD_PROPERTY_STATE_OR_COUNTY];
      }
      if(tempMap.containsKey(ADD_PROPERTY_AREA)){
        _addressAreaTextController.text = tempMap[ADD_PROPERTY_AREA];
        _tempMapInfoMap[ADD_PROPERTY_AREA] = tempMap[ADD_PROPERTY_AREA];
      }
      // print("latitude: $latitude\nlongitude: $longitude");
      if (latitude != null && longitude != null) {
        _initialPosition = LatLng(latitude, longitude);
        if(mounted){
          setState(() {
            currentPositionLink = getStaticMapURLOfPosition(_initialPosition);
            updateFormFields(_currentPosition);
          });
        }
      }
    }

    if(_tempMapInfoMap.isEmpty || latitude == null || longitude == null){
      // print("_tempMapInfoMap is Empty............................");
      _getUserLocation();
    }
    // googleGeocoding = GoogleGeocoding("AIzaSyBGeQ2q8KpzrQTI79DjKAPlUMaQEmeNUks");
  }

  @override
  void dispose() {
    _addressTextController.dispose();
    _addressLatitudeTextController.dispose();
    _addressLongitudeTextController.dispose();
    _addressCountryTextController.dispose();
    _addressCityTextController.dispose();
    _addressZipOrPostalCodeTextController.dispose();
    _addressStateTextController.dispose();
    _addressAreaTextController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Form(
          key: widget.formKey,
          child: Column(
            children: [
              Card(
                child: Column(
                  children: [
                    googlePlaceSearchWidget(),
                    mapRelatedTextWidget(),
                    _getPropertyAddressFromMap(),
                    addLatitude(),
                    addLongitude(),
                  ],
                ),
              ),

              Card(
                child: Column(
                  children: [
                    locationTextWidget(),
                    addPropertyAddress(),
                    addPropertyCountry(),
                    addPropertyStateOrCounty(),
                    addPropertyCity(),
                    addPropertyArea(),
                    addPropertyZipOrPostalCode(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget headingWidget({String text}){
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }


  // Widget mapTextWidget() {
  //   return headingWidget(text: AppLocalizations.of(context).map);
  // }
  Widget googlePlaceSearchWidget() {
    return SHOW_SEARCH_BY_LOCATION ? Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      decoration: BoxDecoration(
        color: AppThemePreferences().appTheme.searchBarBackgroundColor,
        borderRadius: BorderRadius.circular(24.0),
      ),
      child:
        TextField(
          readOnly: true,
          controller: _searchResultController,
          onTap: () async {
            ///https://developers.google.com/maps/documentation/places/web-service/session-tokens
            final sessionToken = const Uuid().v4();
            final Suggestion result = await showSearch(
              context: context,
              delegate: AddressSearch(sessionToken),
            );
            if (result != null) {
              var response = await PlaceApiProvider.getPlaceDetailFromPlaceId(result.placeId);
              Map addressMap = response.data;
              if(addressMap != null && addressMap.isNotEmpty){
                if(mounted){
                  setState(() {
                    _searchResultController.text = addressMap["result"]["formatted_address"];
                    double latitude = addressMap["result"]["geometry"]["location"]["lat"];
                    double longitude = addressMap["result"]["geometry"]["location"]["lng"];
                    // _handleTap(LatLng(latitude, longitude), animateCamera: true);
                    _currentPosition = LatLng(latitude, longitude);
                    currentPositionLink = getStaticMapURLOfPosition(_currentPosition);
                    updateFormFields(_currentPosition);
                  });
                }
              }
            }
          },
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(24.0),
              borderSide: BorderSide(
                color: AppThemePreferences().appTheme.primaryColor,
                width: 1.0,
              ),
            ),

            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(24.0),
              borderSide: BorderSide(
                // color: AppThemePreferences().appTheme.searchBarBackgroundColor,
                color: AppThemePreferences().appTheme.primaryColor,
                width: 1.0,
              ),
            ),
            contentPadding: const EdgeInsets.only(top: 5, left: 15, right: 15),
            fillColor: AppThemePreferences().appTheme.searchBarBackgroundColor,
            filled: true,
            hintText: GenericMethods.getLocalizedString("search"),//AppLocalizations.of(context).search,
            hintStyle: AppThemePreferences().appTheme.searchBarTextStyle,
            suffixIcon: Padding(
              padding: const EdgeInsets.only(right: 10, left: 10),
              child: AppThemePreferences().appTheme.homeScreenSearchBarIcon,
            ),
          ),

        ),
    ): headingWidget(text: GenericMethods.getLocalizedString("map"));

  }

  Widget mapRelatedTextWidget() {
    return Container(
      alignment: Alignment.topLeft,
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      child: genericTextWidget(
        GenericMethods.getLocalizedString("add_property_map_additional_hint"),
        textAlign: TextAlign.left,
        style: AppThemePreferences().appTheme.hintTextStyle,
      ),
    );
  }

  Widget _getPropertyAddressFromMap() {
    return _initialPosition == null
        ? _loading()
        : ClipRRect(
      borderRadius: const BorderRadius.all(Radius.circular(0)),
      child: GestureDetector(
        child: currentPositionLink.isEmpty
            ? Container()
            : FancyShimmerImage(
          imageUrl: currentPositionLink,
          boxFit: BoxFit.fill,
          shimmerBaseColor:
          AppThemePreferences().appTheme.shimmerEffectBaseColor,
          shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
          width: MediaQuery.of(context).size.width,
          height: mapWidgetHeight,
          errorWidget: shimmerEffectErrorWidget(),
        ),
        onTap: (){
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddressFromMap(
              initialLatLng: _currentPosition ?? _initialPosition,
              zoomLevel: mapZoom,
              addressFromMapListener: (LatLng position, double zoomLevel){
                if(position != null){
                  if(mounted){
                    setState(() {
                      _currentPosition = position;
                      currentPositionLink = getStaticMapURLOfPosition(_currentPosition);
                      updateFormFields(_currentPosition);
                      _searchResultController.text = "";
                      if(zoomLevel != mapZoom){
                        mapZoom = zoomLevel;
                      }
                    });
                  }
                }
              },
            ),
            ),
          );
        },
      ),
    );
    // Container(
    //   padding: const EdgeInsets.only(top: 10),
    //       width: MediaQuery.of(context).size.width,
    //       height: mapWidgetHeight,
    //       child: GoogleMap(
    //         // Do Not take any suggestions
    //         // Don not covert to Set literal
    //         // Leave it as it is
    //         // gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>[
    //         //   new Factory<OneSequenceGestureRecognizer>(
    //         //           () => new EagerGestureRecognizer()),
    //         // ].toSet(),
    //         // onTap: _handleTap,
    //         compassEnabled: false,
    //         markers: _markers,
    //         initialCameraPosition: CameraPosition(
    //           target: _initialPosition!,
    //           zoom: 12.0,
    //         ),
    //         scrollGesturesEnabled: false,
    //         myLocationButtonEnabled: false,
    //         zoomGesturesEnabled: false,
    //         tiltGesturesEnabled: false,
    //         zoomControlsEnabled: false,
    //         onMapCreated: (controller) {
    //           _googleMapController = controller;
    //           //_googleMapController.showMarkerInfoWindow(MarkerId("marker"));
    //           // return _googleMapController;
    //         },
    //         // myLocationEnabled: true,
    //         onTap: (position){
    //           Navigator.push(
    //             context,
    //             MaterialPageRoute(builder: (context) => AddressFromMap(
    //                 initialLatLng: _currentPosition ?? _initialPosition,
    //                 addressFromMapListener: (LatLng position){
    //                   if(position != null){
    //                     _currentPosition = position;
    //                     _markers = {};
    //                     _handleTap(position, animateCamera: true);
    //                   }
    //                 },
    //               ),
    //             ),
    //           );
    //         },
    //       ),
    //     );
  }

  Widget addLatitude(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("latitude"),
        hintText: GenericMethods.getLocalizedString("enter_address_latitude"),
        controller: _addressLatitudeTextController,
        keyboardType: TextInputType.number,
        inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly,],
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_LATITUDE]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addLongitude(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0, bottom: 30.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("longitude"),
        hintText: GenericMethods.getLocalizedString("enter_address_longitude"),
        controller: _addressLongitudeTextController,
        keyboardType: TextInputType.number,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.digitsOnly,
        ],
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_LONGITUDE]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget locationTextWidget() {
    return headingWidget(text: GenericMethods.getLocalizedString("location"));//AppLocalizations.of(context).location);
  }

  Widget addPropertyAddress() {
    return Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("address")+" *",//AppLocalizations.of(context).address_star,
        hintText: GenericMethods.getLocalizedString("enter_your_property_address"),//AppLocalizations.of(context).enter_your_property_address,
        controller: _addressTextController,
        validator: (String value) {
          if (value?.isEmpty ?? true) {
            return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
          }
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_MAP_ADDRESS]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addPropertyCountry() {
    return !SHOW_COUNTRY_NAME_FIELD ? Container() : Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("country"),//AppLocalizations.of(context).country,
        hintText: GenericMethods.getLocalizedString("enter_the_country"),//AppLocalizations.of(context).enter_the_country,
        controller: _addressCountryTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_COUNTRY]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addPropertyStateOrCounty() {
    return !SHOW_STATE_COUNTY_FIELD ? Container() : Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("states"),//AppLocalizations.of(context).states,
        hintText: GenericMethods.getLocalizedString("enter_the_states"),//AppLocalizations.of(context).enter_the_states,
        controller: _addressStateTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_STATE_OR_COUNTY]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addPropertyCity() {
    return !SHOW_LOCALITY_FIELD ? Container() : Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("city"),//AppLocalizations.of(context).city,
        hintText: GenericMethods.getLocalizedString("enter_the_city"),//AppLocalizations.of(context).enter_the_city,
        controller: _addressCityTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_CITY]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addPropertyArea() {
    return !SHOW_NEIGHBOURHOOD_FIELD ? Container() : Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("area"),//AppLocalizations.of(context).area,
        hintText: GenericMethods.getLocalizedString("enter_the_area"),//AppLocalizations.of(context).enter_the_area,
        controller: _addressAreaTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_AREA]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget addPropertyZipOrPostalCode() {
    return Container(
      padding: const EdgeInsets.only(top: 20.0, bottom: 30.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("zip_code"),//AppLocalizations.of(context).zip_code,
        hintText: GenericMethods.getLocalizedString("enter_the_zip_code"),//AppLocalizations.of(context).enter_the_zip_code,
        controller: _addressZipOrPostalCodeTextController,
        validator: (String value) {
          if(value != null && value.isNotEmpty){
            if(mounted){
              setState(() {
                dataMap[ADD_PROPERTY_POSTAL_CODE]  = value;
              });
            }
            widget.propertyAddressPageListener(dataMap);
          }
          return null;
        },
      ),
    );
  }

  Widget _loading() {
    return Container(
      alignment: Alignment.center,
      child: SizedBox(
        width: 70,
        height: MediaQuery.of(context).size.height - 340,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  updateFormFields(LatLng location) async {
    String cordLoc =  location.latitude.toString() +","+location.longitude.toString();
    // print("location: $cordLoc");

    Map placeMap = {};
    List<PlaceAddress> addressDataList = [];
    PlaceAddress addressItem;

    var response = await PlaceApiProvider.getPlaceDetailFromCordinates(cordLoc);
    Map tempMap = response.data;
    if(tempMap != null && tempMap.isNotEmpty && tempMap.containsKey("results")){
      addressDataList = AddressFromJson(jsonEncode(tempMap["results"]));
      if(addressDataList != null && addressDataList.isNotEmpty){
        addressItem = addressDataList[0];
        List<dynamic> addressComponentsList = addressItem.addressComponents;
        if(addressComponentsList != null && addressComponentsList.isNotEmpty){
          for(var item in addressComponentsList){
            var addressComponentsItem = item.types[0];
            // print("${item.types[0]}: ${item.longName}");

            if(addressComponentsItem == "country"){
              placeMap[ADD_PROPERTY_COUNTRY] = "${item.longName}";
            }
            if(addressComponentsItem == "administrative_area_level_1"){
              placeMap[ADD_PROPERTY_STATE_OR_COUNTY] = "${item.longName}";
            }
            if(addressComponentsItem == "locality"){
              placeMap[ADD_PROPERTY_CITY] = "${item.longName}";
            }
            if(addressComponentsItem == "neighborhood"){
              placeMap[ADD_PROPERTY_AREA] = "${item.longName}";
            }
            if(addressComponentsItem == "postal_code"){
              placeMap[ADD_PROPERTY_POSTAL_CODE] = "${item.longName}";
            }
          }
        }

        placeMap[ADD_PROPERTY_MAP_ADDRESS] = addressItem.formattedAddress;
        // print("addressComponents: ${addressItem.addressComponents}");
        // print("formattedAddress: ${addressItem.formattedAddress}");
      }
    }

    // print("placeMap: $placeMap");

    if(mounted){
      setState(() {
        _addressTextController.text = '';
        _addressLatitudeTextController.text= '';
        _addressLongitudeTextController.text= '';
        _addressCountryTextController.text= '';
        _addressStateTextController.text= '';
        _addressCityTextController.text= '';
        _addressZipOrPostalCodeTextController.text= '';
        _addressAreaTextController.text= '';
        
        
        if(location.latitude != null && location.latitude.toString().isNotEmpty){
          _addressLatitudeTextController.text = location.latitude.toString();
        }
        if(location.longitude.toString() != null && location.longitude.toString().isNotEmpty){
          _addressLongitudeTextController.text = location.longitude.toString();
        }
        if(placeMap.containsKey(ADD_PROPERTY_MAP_ADDRESS) &&
            placeMap[ADD_PROPERTY_MAP_ADDRESS] != null &&
            placeMap[ADD_PROPERTY_MAP_ADDRESS].isNotEmpty){
          _addressTextController.text = placeMap[ADD_PROPERTY_MAP_ADDRESS];
        }
        if(placeMap.containsKey(ADD_PROPERTY_COUNTRY) && 
            placeMap[ADD_PROPERTY_COUNTRY] != null &&
            placeMap[ADD_PROPERTY_COUNTRY].isNotEmpty){
          _addressCountryTextController.text = placeMap[ADD_PROPERTY_COUNTRY];
        }
        if(placeMap.containsKey(ADD_PROPERTY_STATE_OR_COUNTY) && 
            placeMap[ADD_PROPERTY_STATE_OR_COUNTY] != null && 
            placeMap[ADD_PROPERTY_STATE_OR_COUNTY].isNotEmpty){
          _addressStateTextController.text = placeMap[ADD_PROPERTY_STATE_OR_COUNTY];
        }
        if(placeMap.containsKey(ADD_PROPERTY_CITY) && 
            placeMap[ADD_PROPERTY_CITY] != null && 
            placeMap[ADD_PROPERTY_CITY].isNotEmpty){
          _addressCityTextController.text = placeMap[ADD_PROPERTY_CITY];
        }
        if(placeMap.containsKey(ADD_PROPERTY_POSTAL_CODE) && 
            placeMap[ADD_PROPERTY_POSTAL_CODE] != null && 
            placeMap[ADD_PROPERTY_POSTAL_CODE].isNotEmpty){
          _addressZipOrPostalCodeTextController.text = placeMap[ADD_PROPERTY_POSTAL_CODE];
        }
        if(placeMap.containsKey(ADD_PROPERTY_AREA) &&
            placeMap[ADD_PROPERTY_AREA] != null &&
            placeMap[ADD_PROPERTY_AREA].isNotEmpty){
          _addressAreaTextController.text = placeMap[ADD_PROPERTY_AREA];
        }
      });
    }
    //
  }

  void _getUserLocation() async {
    geo_locator.Position position = await geo_locator.Geolocator.getCurrentPosition(desiredAccuracy: geo_locator.LocationAccuracy.high);
    // final coordinates = new Coordinates(position.latitude, position.longitude);
    // var addresses = await Geocoder.local.findAddressesFromCoordinates(coordinates);
    // var first = addresses.first;
    if(mounted){
      setState(() {
        _initialPosition = LatLng(position.latitude, position.longitude);
        // _addressTextController.text = first.addressLine.toString();
        // _addressLatitudeTextController.text = position.latitude.toString();
        // _addressLongitudeTextController.text = position.longitude.toString();
        // _addressCountryTextController.text = first.countryName.toString();
        // _addressStateTextController.text = first.adminArea.toString() + " / " + first.subAdminArea.toString();
        // _addressCityTextController.text = first.locality.toString();
        // _addressZipOrPostalCodeTextController.text = first.postalCode.toString();
        // _addressAreaTextController.text = first.thoroughfare.toString();


        _initialPosition ??= defaultLocation;

        currentPositionLink = getStaticMapURLOfPosition(_initialPosition);

        /// if (_initialPosition == null) {
        ///   _initialPosition = defaultLocation;
        /// } == _initialPosition ??= defaultLocation;

      });
    }
  }

  String getStaticMapURLOfPosition(LatLng position){
    String staticMapURL = "";
    String _latitude = position.latitude.toString();
    String _longitude = position.longitude.toString();
    staticMapURL = GenericMethods.getStaticMapUrl(
      lat: _latitude,
      lng: _longitude,
      height: mapWidgetHeight,
      width: MediaQuery.of(context).size.width,
      zoomValue: mapZoom,
    );

    // print("staticMapURL: $staticMapURL");

    return staticMapURL;

  }
}

typedef AddressFromMapListener = void Function(LatLng locationLatLng, double zoomLevel);

class AddressFromMap extends StatefulWidget {
  final LatLng initialLatLng;
  final double zoomLevel;
  final AddressFromMapListener addressFromMapListener;
  const AddressFromMap({
    Key key,
    this.initialLatLng,
    this.zoomLevel,
    this.addressFromMapListener,
  }) : super(key: key);

  @override
  State<AddressFromMap> createState() => _AddressFromMapState();
}

class _AddressFromMapState extends State<AddressFromMap> {

  Set<Marker> _markers = {};

  LatLng _initialPosition;
  LatLng _userSelectedPosition;

  double zoomLevel = 12.0;

  final _searchResultController = TextEditingController();

  GoogleMapController _googleMapController;


  @override
  void initState() {
    _initialPosition = widget.initialLatLng;

    if(_initialPosition != null){
      _markers.add(Marker(
        markerId: const MarkerId("marker"),
        position: _initialPosition,
        // infoWindow: InfoWindow(
        //   title: address,
        // ),
      ));
    }

    if(widget.zoomLevel != null){
      zoomLevel = widget.zoomLevel;
    }

    super.initState();
  }

  @override
  void dispose() {
    if(_googleMapController != null){
      _googleMapController.dispose();
    }

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
        context,
        appBarTitle: GenericMethods.getLocalizedString("choose_location"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(top: 23, left: 20, right: 20),
            child: GestureDetector(
              onTap: (){
                if(_userSelectedPosition != null){
                  widget.addressFromMapListener(_userSelectedPosition, zoomLevel);
                }else{
                  widget.addressFromMapListener(_initialPosition, zoomLevel);
                }
                Navigator.pop(context);
              },
              child: genericTextWidget(
                GenericMethods.getLocalizedString("done"),
                style: AppThemePreferences().appTheme.appBarActionWidgetsTextStyle,
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          _getPropertyAddressFromMap(),
          pageHeaderWidgets(),
        ],
      ),
    );
  }

  Widget headingWidget({@required String text}){
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget pageHeaderWidgets(){
    return Container(
      height: 110,
      width: double.infinity,
      child: Card(
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        elevation: 0,
        margin: EdgeInsets.zero,
        child: Column(
          children: [
            googlePlaceSearchWidget(),
            mapRelatedTextWidget(),
          ],
        ),
      ),
    );
  }

  Widget googlePlaceSearchWidget() {
    return SHOW_SEARCH_BY_LOCATION ? Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      decoration: BoxDecoration(
        color: AppThemePreferences().appTheme.searchBarBackgroundColor,
        borderRadius: BorderRadius.circular(24.0),
      ),
      child:
      TextField(
        readOnly: true,
        controller: _searchResultController,
        onTap: () async {
          ///https://developers.google.com/maps/documentation/places/web-service/session-tokens
          final sessionToken = const Uuid().v4();
          final Suggestion result = await showSearch(
            context: context,
            delegate: AddressSearch(sessionToken),
          );
          if (result != null) {
            var response = await PlaceApiProvider.getPlaceDetailFromPlaceId(result.placeId);
            Map addressMap = response.data;
            if(addressMap != null && addressMap.isNotEmpty){
              if(mounted){
                setState(() {
                  _searchResultController.text = addressMap["result"]["formatted_address"];
                  double latitude = addressMap["result"]["geometry"]["location"]["lat"];
                  double longitude = addressMap["result"]["geometry"]["location"]["lng"];
                  _userSelectedPosition = LatLng(latitude, longitude);
                });
              }

              _handleTap(_userSelectedPosition, animateCamera: true);
              // _handleTap(LatLng(latitude, longitude), animateCamera: true);
              // widget.addressFromMapListener!(LatLng(latitude, longitude), zoomLevel);
            }
          }
        },
        decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(24.0),
            borderSide: BorderSide(
              color: AppThemePreferences().appTheme.primaryColor,
              width: 1.0,
            ),
          ),

          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(24.0),
            borderSide: BorderSide(
              // color: AppThemePreferences().appTheme.searchBarBackgroundColor,
              color: AppThemePreferences().appTheme.primaryColor,
              width: 1.0,
            ),
          ),
          contentPadding: const EdgeInsets.only(top: 5, left: 15, right: 15),
          fillColor: AppThemePreferences().appTheme.searchBarBackgroundColor,
          filled: true,
          hintText: GenericMethods.getLocalizedString("search"),//AppLocalizations.of(context).search,
          hintStyle: AppThemePreferences().appTheme.searchBarTextStyle,
          suffixIcon: Padding(
            padding: const EdgeInsets.only(right: 10, left: 10),
            child: AppThemePreferences().appTheme.homeScreenSearchBarIcon,
          ),
        ),

      ),
    ): headingWidget(text: GenericMethods.getLocalizedString("map"));

  }

  Widget mapRelatedTextWidget() {
    return Container(
      alignment: Alignment.topLeft,
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      child: genericTextWidget(
        GenericMethods.getLocalizedString("drag_and_drop_the_pin_on_map_to_find_exact_location"),
        textAlign: TextAlign.left,
        style: AppThemePreferences().appTheme.hintTextStyle,
      ),
    );
  }

  Widget _getPropertyAddressFromMap() {
    return _initialPosition == null
        ? _loading()
        : Container(
      padding: const EdgeInsets.only(top: 10),
      width: MediaQuery.of(context).size.width,
      child: GoogleMap(
        onTap: _handleTap,
        compassEnabled: true,
        markers: _markers,
        initialCameraPosition: CameraPosition(
          target: _initialPosition,
          zoom: zoomLevel,
        ),
        scrollGesturesEnabled: true,
        myLocationButtonEnabled: true,
        zoomGesturesEnabled: true,
        tiltGesturesEnabled: true,
        zoomControlsEnabled: true,
        onMapCreated: (controller) {
          _googleMapController = controller;
        },
        onCameraMove: (position){
          if(position.zoom != zoomLevel){
            if(mounted){
              setState(() {
                zoomLevel = position.zoom;
              });
            }
          }
        },
        myLocationEnabled: true,
      ),
    );
  }

  Widget _loading() {
    return Container(
      alignment: Alignment.center,
      child: SizedBox(
        width: 70,
        // height: mapWidgetHeight,
        // height: MediaQuery.of(context).size.height - 340,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  _handleTap(LatLng location,{bool animateCamera = false}) async {
    if(mounted){
      setState(() {
        _markers.add(Marker(
          markerId: const MarkerId("marker"),
          position: location,
        ));
        _googleMapController.showMarkerInfoWindow(const MarkerId("marker"));
        if(animateCamera){
          CameraUpdate cameraUpdate = CameraUpdate.newLatLng(location);
          _googleMapController.animateCamera(cameraUpdate);
        }

        if(location != _userSelectedPosition){
          _userSelectedPosition = location;
        }
      });
    }
  }
}
