import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import '../files/generic_methods/general_notifier.dart';
import '../files/generic_methods/generic_methods.dart';
import '../models/filter_page_config.dart';
import 'filter_page_widgets.dart';

typedef FilterPageListener = void Function(Map<String, dynamic> filterDataMap, String closeOption);

class FilterPage extends StatefulWidget{
  @override
  State<FilterPage> createState() => _FilterPageState();

  final FilterPageListener filterPageListener;
  final Map<String,dynamic> mapInitializeData;

  FilterPage({
    this.mapInitializeData,
    this.filterPageListener,
  });

}

class _FilterPageState extends State<FilterPage>{

  Map<String, dynamic> _dataInitializationMap = {};
  List<dynamic> filterPageConfigElementsList = [];

  VoidCallback  generalNotifierListener;


  @override
  void initState() {
    super.initState();
    loadAndInitializeData();

    /// General Notifier Listener
    generalNotifierListener = () {
      if (GeneralNotifier().change == GeneralNotifier.APP_CONFIGURATIONS_UPDATED) {
        print("Filter Page: APP_CONFIGURATIONS_UPDATED...");

        getFilterPageConfigFile();

        // print("homeConfigList: $homeConfigList");
        // print("drawerConfigList: $drawerConfigList");
      }
    };

    GeneralNotifier().addListener(generalNotifierListener);
  }

  getFilterPageConfigFile() {
    var filterConfigListData = HiveStorageManager.readFilterConfigListData() ?? [];
    if (filterConfigListData != null && filterConfigListData.isNotEmpty) {
      filterPageConfigElementsList.clear();
      if(mounted) {
        setState(() {
          filterPageConfigElementsList = FilterPageElement.decode(jsonDecode(filterConfigListData));
        });
      }
    }
  }

  loadAndInitializeData() {
    getFilterPageConfigFile();
    _dataInitializationMap = widget.mapInitializeData;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        backgroundColor: Theme.of(context).backgroundColor,
        appBar: appBarWidget(
            context,
            appBarTitle: GenericMethods.getLocalizedString("filters"),
            onBackPressed: (){
              HiveStorageManager.storeFilterDataInfo(map: _dataInitializationMap);
              widget.filterPageListener(_dataInitializationMap, CLOSE);
            }
        ),
        body: Stack(
          children:[
            SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children: [
                  Column(
                    children: filterPageConfigElementsList.map((filterPageConfigElement) {
                      return FilterPageWidgets(
                        filterPageConfigData: filterPageConfigElement,
                        mapInitializeData: widget.mapInitializeData,

                        filterPageWidgetsListener: (Map<String,dynamic> filterPageWidgetsListener,String closeOption){
                          _dataInitializationMap.addAll(filterPageWidgetsListener);
                          HiveStorageManager.storeFilterDataInfo(map: _dataInitializationMap);
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 60),
                ],
              ),
            ),
            bottomPageButtonsWidget(),
          ],
        ),
      ),

    );
  }

  Widget bottomPageButtonsWidget(){
    return Positioned(
      bottom: 0,
      width: MediaQuery.of(context).size.width,
      child: Container(
        decoration: BoxDecoration(
          color: AppThemePreferences().appTheme.backgroundColor,
          border: Border(
            top: AppThemePreferences().appTheme.filterPageBorderSide,
          ),
        ),
        child: SafeArea(
          top: false,
          child: Container(
            height: 60,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Expanded(flex: 2, child: Container()),
                Expanded(flex: 0, child: resetButton()),
                Expanded(flex: 3,child: doneButton()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget resetButton(){
    return Padding(
      padding: const EdgeInsets.only(right: 15.0, left: 15.0),
      child: InkWell(
        onTap: () {
          GeneralNotifier().publishChange(GeneralNotifier.RESET_FILTER_DATA);
          GeneralNotifier().publishChange(GeneralNotifier.CITY_DATA_UPDATE);
        },
        child: genericTextWidget(
          GenericMethods.getLocalizedString("reset"),
          style: AppThemePreferences().appTheme.filterPageResetTextStyle,
        ),
      ),
    );
  }

  Widget doneButton(){
    return buttonWidget(
      buttonHeight: AppThemePreferences.filterPageSearchButtonHeight,
      fontSize: AppThemePreferences.filterPageSearchButtonTextFontSize,
      text: GenericMethods.getLocalizedString("search"),
      onPressed: () {
        if(_dataInitializationMap != null &&
            _dataInitializationMap[SELECTED_INDEX_FOR_TAB] != null){
          if(_dataInitializationMap[SELECTED_INDEX_FOR_TAB] == 0){
            _dataInitializationMap[LATITUDE]  = "";
            _dataInitializationMap[LONGITUDE] =  "";
            // _dataInitializationMap[SELECTED_LOCATION] = PLEASE_SELECT;
            _dataInitializationMap[RADIUS] = "50.0";
            _dataInitializationMap[USE_RADIUS] = "off";
            _dataInitializationMap[SEARCH_LOCATION] = "false";
          }else if(_dataInitializationMap[SELECTED_INDEX_FOR_TAB] == 1){
            // if(_dataInitializationMap[SELECTED_LOCATION] != null && _dataInitializationMap[SELECTED_LOCATION] != PLEASE_SELECT){
            //   _dataInitializationMap[SELECTED_LOCATION] = _dataInitializationMap[SELECTED_LOCATION];
            // }
            if(_dataInitializationMap[RADIUS] == null || _dataInitializationMap[RADIUS].isEmpty) {
              _dataInitializationMap[RADIUS] = "50";
            }
            if (_dataInitializationMap[LATITUDE] != null && _dataInitializationMap[LONGITUDE] != null && _dataInitializationMap[RADIUS] != null) {
              if (_dataInitializationMap[LATITUDE].isNotEmpty
                  && _dataInitializationMap[LONGITUDE].isNotEmpty
                  && _dataInitializationMap[RADIUS].isNotEmpty) {
                _dataInitializationMap[USE_RADIUS] = "on";
                _dataInitializationMap[SEARCH_LOCATION] = "true";
              }
              _dataInitializationMap[CITY] = "";
              _dataInitializationMap[CITY_ID] = null;
              _dataInitializationMap[CITY_SLUG] = "";
            }
          }
        }

        // if (kDebugMode) {
        //   print("Map From Filter Screen: $_dataInitializationMap");
        // }
        HiveStorageManager.storeFilterDataInfo(map: _dataInitializationMap);

        GenericMethods.storeOrUpdateRecentSearches(_dataInitializationMap);

        widget.filterPageListener(_dataInitializationMap, DONE);

      },
    );
  }
}



