import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/user.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:image_picker/image_picker.dart';

import '../../../Mixins/validation_mixins.dart';
import '../../../files/generic_methods/generic_methods.dart';
import '../../../widgets/header_widget.dart';

class EditProfile extends StatefulWidget {

  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> with ValidationMixin {
  final formKey = GlobalKey<FormState>();
  final PropertyBloc _propertyBloc = PropertyBloc();

  TextEditingController registerPass = TextEditingController();
  TextEditingController registerPassRetype = TextEditingController();

  Map<String,dynamic> userInfoMap = {
    FIRST_NAME : "",
    LAST_NAME : "",
    USER_LANGS : "",
    USER_TITLE : "",
    DESCRIPTION : "",
    USER_COMPANY : "",
    USER_PHONE : "",
    USER_MOBILE : "",
    FAX_NUMBER : "",
    SERVICE_AREA : "",
    SPECIALITIES : "",
    LICENSE : "",
    TAX_NUMBER : "",
    USER_ADDRESS : "",
    FACEBOOK : "",
    TWITTER : "",
    LINKEDIN : "",
    INSTAGRAM : "",
    YOUTUBE : "",
    PINTEREST : "",
    VIMEO : "",
    SKYPE : "",
    WEBSITE : ""
  };


  User _userInfo;
  final picker = ImagePicker();

  List<dynamic> userInfoList = [];
  List<dynamic> displayNameOptionsList = [];
  Future<List<dynamic>> _futureUserInfo;

  bool isInternetConnected = true;
  bool _showWaitingWidget = false;
  bool showFields = false;

  String id = "";
  String _displayName;
  String profile = "";

  String selectedDisplayName;

  @override
  void initState() {
    super.initState();
    loadData();
    // checkInternet();
  }

  checkInternet() {
    // InternetConnectionChecker().checkInternetConnection().then((value) {
    //   if (value) {
    //     isInternetConnected = true;
    //     loadData();
    //   } else {
    //     isInternetConnected = false;
    //   }
    //   if(mounted){
    //     setState(() {});
    //   }
    //   return null;
    // });
    loadData();
  }

  void loadData() {
    if(mounted){
      setState(() {
        _showWaitingWidget = true;
      });
    }

    _futureUserInfo = fetchUserInfo();

    _futureUserInfo.then((value) {
      if(value == null || (value.isNotEmpty && value[0] == null) || (value.isNotEmpty && value[0].runtimeType == Response)){
        if(mounted){
          setState(() {
            isInternetConnected = false;
            _showWaitingWidget = false;
          });
        }
      }else{
        if (mounted) {
          setState(() {
            isInternetConnected = true;
            _showWaitingWidget = false;
          });
        }
        if(value.isNotEmpty){
          userInfoList = value;
          _userInfo = userInfoList[0];
          if(mounted){
            setState(() {
              userInfoMap[USER_NAME] = _userInfo.username;
              userInfoMap[FIRST_NAME] = _userInfo.firstName;
              userInfoMap[LAST_NAME] = _userInfo.lastName;
              userInfoMap[USER_LANGS] = _userInfo.userlangs;
              userInfoMap[USER_TITLE] = _userInfo.userTitle;
              userInfoMap[USER_COMPANY] = _userInfo.userCompany;
              userInfoMap[USER_PHONE] = _userInfo.userPhone;
              userInfoMap[USER_MOBILE] = _userInfo.userMobile;
              userInfoMap[FAX_NUMBER] = _userInfo.faxNumber;
              userInfoMap[SERVICE_AREA] = _userInfo.serviceAreas;
              userInfoMap[SPECIALITIES] = _userInfo.specialties;
              userInfoMap[LICENSE] = _userInfo.license;
              userInfoMap[TAX_NUMBER] = _userInfo.taxNumber;
              userInfoMap[USER_ADDRESS] = _userInfo.userAddress;
              userInfoMap[DISPLAY_NAME] = _userInfo.displayName;
              userInfoMap[USER_EMAIL] = _userInfo.userEmail;
              userInfoMap[USER_WHATSAPP] = _userInfo.userWhatsapp;
              userInfoMap[DESCRIPTION] = _userInfo.description;
              userInfoMap[FACEBOOK] = _userInfo.facebook;
              userInfoMap[TWITTER] = _userInfo.twitter;
              userInfoMap[INSTAGRAM] = _userInfo.instagram;
              userInfoMap[LINKEDIN] = _userInfo.linkedin;
              userInfoMap[YOUTUBE] = _userInfo.youtube;
              userInfoMap[PINTEREST] = _userInfo.pinterest;
              userInfoMap[VIMEO] = _userInfo.vimeo;
              userInfoMap[SKYPE] = _userInfo.skype;
              userInfoMap[WEBSITE] = _userInfo.website;

              var nameForDisplay = _userInfo.displayNameOptions;
              if(nameForDisplay is List){
                displayNameOptionsList = nameForDisplay.toSet().toList();
              }

              id = _userInfo.id;
              _displayName = _userInfo.displayName;
              profile = _userInfo.profile;

              showFields = true;
            });
          }
        }
      }

      return null;
    });
  }

  Future<List<dynamic>> fetchUserInfo() async {
    userInfoList = await _propertyBloc.fetchUserInfo();
    return userInfoList;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("edit_profile"),
        ),
        body: isInternetConnected == false
            ? Align(
                alignment: Alignment.topCenter,
                child: noInternetConnectionErrorWidget(context, () {
                  checkInternet();
                }),
              )
            : Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: showUserInfo(context),
              ),
      ),
    );
  }

  Widget showUserInfo(BuildContext context) {
    return Stack(
      children: [
        showFields ? SingleChildScrollView(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(5),
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("user_name"), initialValue: userInfoMap[USER_NAME], keyboardType: TextInputType.text, key: USER_NAME,readOnly: true,enabled: false),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("first_name"), initialValue: userInfoMap[FIRST_NAME], keyboardType: TextInputType.text, key: FIRST_NAME),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("last_name"),initialValue: userInfoMap[LAST_NAME], keyboardType: TextInputType.text, key: LAST_NAME),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("email"),initialValue: userInfoMap[USER_EMAIL], keyboardType: TextInputType.emailAddress, key: USER_EMAIL),
                  displayNameWidget(context),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("title_position"),initialValue: userInfoMap[USER_TITLE], keyboardType: TextInputType.text, key: USER_TITLE),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("license"),initialValue: userInfoMap[LICENSE], keyboardType: TextInputType.text, key: LICENSE),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("mobile"),initialValue: userInfoMap[USER_MOBILE], keyboardType: TextInputType.number, key: USER_MOBILE),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("whatsApp"),initialValue: userInfoMap[USER_WHATSAPP], keyboardType: TextInputType.number, key: USER_WHATSAPP),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("tax_number"),initialValue: userInfoMap[TAX_NUMBER], keyboardType: TextInputType.text, key: TAX_NUMBER),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("phone"),initialValue: userInfoMap[USER_PHONE], keyboardType: TextInputType.number, key: USER_PHONE),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("fax_number"),initialValue: userInfoMap[FAX_NUMBER], keyboardType: TextInputType.number, key: FAX_NUMBER),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("language_label"),initialValue: userInfoMap[USER_LANGS], keyboardType: TextInputType.text, key: USER_LANGS),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("company_name"),initialValue: userInfoMap[USER_COMPANY], keyboardType: TextInputType.text, key: USER_COMPANY),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("address"),initialValue: userInfoMap[USER_ADDRESS], keyboardType: TextInputType.text, key: USER_ADDRESS),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("service_areas"),initialValue: userInfoMap[SERVICE_AREA], keyboardType: TextInputType.text, key: SERVICE_AREA),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("specialties"),initialValue: userInfoMap[SPECIALITIES], keyboardType: TextInputType.text, key: SPECIALITIES),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("about_me"),initialValue: userInfoMap[DESCRIPTION], keyboardType: TextInputType.text, key: DESCRIPTION, maxLines: 5),
                  headerTextWidget(GenericMethods.getLocalizedString("social")),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("facebook"),initialValue: userInfoMap[FACEBOOK], keyboardType: TextInputType.text, key: FACEBOOK),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("twitter"),initialValue: userInfoMap[TWITTER], keyboardType: TextInputType.text, key: TWITTER),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("linkedIn"),initialValue: userInfoMap[LINKEDIN], keyboardType: TextInputType.text, key: LINKEDIN),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("instagram"),initialValue: userInfoMap[INSTAGRAM], keyboardType: TextInputType.text, key: INSTAGRAM),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("youtube"),initialValue: userInfoMap[YOUTUBE], keyboardType: TextInputType.text, key: YOUTUBE),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("pinterest"),initialValue: userInfoMap[PINTEREST], keyboardType: TextInputType.text, key: PINTEREST),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("vimeo"),initialValue: userInfoMap[VIMEO], keyboardType: TextInputType.text, key: VIMEO),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("skype"),initialValue: userInfoMap[SKYPE], keyboardType: TextInputType.text, key: SKYPE),
                  setValuesInFields(labelText : GenericMethods.getLocalizedString("website"),initialValue: userInfoMap[WEBSITE], keyboardType: TextInputType.text, key: WEBSITE),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: updateProfileButtonWidget(context),
                  ),
                ],
              ),
            ),
          ),
        ) : Container(),
        waitingWidget(),
      ],
    );
  }

  Widget setValuesInFields({
    @required String labelText,
    @required String initialValue,
    @required TextInputType keyboardType,
    @required String key,
    int maxLines = 1,
    bool readOnly = false,
    bool enabled = true,
  }) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        enabled: enabled,
        readOnly: readOnly,
        maxLines: maxLines,
        labelText: labelText,
        initialValue: initialValue,
        keyboardType: keyboardType,
        onSaved: (String value) {
          setState(() {
            userInfoMap[key] = value;
          });
        },
      ),
    );
  }

  Widget headerTextWidget(String text) {
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget displayNameWidget(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          genericTextWidget(GenericMethods.getLocalizedString("display_name"),
              style: AppThemePreferences().appTheme.labelTextStyle),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: DropdownButtonFormField(
              decoration: AppThemePreferences.formFieldDecoration(hintText: GenericMethods.getLocalizedString("display_name")),
              value: _displayName,
              onSaved: (val) {
                setState(() {
                  selectedDisplayName = val;
                  userInfoMap[DISPLAY_NAME] = val;
                });
              },
              items: displayNameOptionsList.map<DropdownMenuItem<String>>((item) {
                return DropdownMenuItem<String>(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10.0),
                    child: genericTextWidget(
                      item,
                    ),
                  ),
                  value: item,
                );
              }).toList(),
              onChanged: (val) {
                setState(() {
                  selectedDisplayName = val;
                  userInfoMap[DISPLAY_NAME] = val;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget addPassword(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("password"),
        hintText: GenericMethods.getLocalizedString("enter_your_password"),
        controller: registerPass,
        obscureText: true,
        keyboardType: TextInputType.visiblePassword,
        validator: (value) => validatePassword(context,value),
      ),
    );
  }

  Widget reTypePassword(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("confirm_password"),
        hintText: GenericMethods.getLocalizedString("confirm_your_password"),
        obscureText: true,
        controller: registerPassRetype,
        keyboardType: TextInputType.visiblePassword,
        validator: (String value) {
          if (value.length < 8) {
            return GenericMethods.getLocalizedString("password_length_at_least_eight");
          }
          if (value.isEmpty) {
            return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
          }

          if (registerPass.text != registerPassRetype.text) {
            return GenericMethods.getLocalizedString("password_does_not_match");
          }
          return null;
        },
      ),
    );
  }

  Widget updateProfileButtonWidget(BuildContext context) {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("update_profile"),
      onPressed: () async {
        setState(() {
          _showWaitingWidget = true;
        });

        formKey.currentState.save();

        if(NEED_TO_FIX_PROFILE_PIC == 0){
          final response = await _propertyBloc.fetchUpdateUserProfileResponse(userInfoMap);
          if(mounted){
            setState(() {
              _showWaitingWidget = false;
            });
          }
          if (response.statusCode == 200) {
            HiveStorageManager.setUserDisplayName(userInfoMap[DISPLAY_NAME]);
            HiveStorageManager.setUserEmail(userInfoMap[USER_EMAIL]);
            GeneralNotifier().publishChange(GeneralNotifier.USER_PROFILE_UPDATE);
            _showToast(context,GenericMethods.getLocalizedString("profile_updated_successfully"));
          } else {
            _showToast(context, GenericMethods.getLocalizedString("error_occurred"));
          }
          /// If need to fix agent profile image
        }else if(NEED_TO_FIX_PROFILE_PIC == 1){
          if(mounted){
            setState(() {
              _showWaitingWidget = false;
            });
          }

          _propertyBloc.fetchUpdateUserProfileResponse(userInfoMap).then((value) async {
            String tempResponseString = value.toString().split("{")[1];
            Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
            if(map["success"] == true){
              final responseForFix = await _propertyBloc.fetchFixProfileImageResponse();

              final success = responseForFix.data["success"];
              if (success) {
                HiveStorageManager.setUserDisplayName(userInfoMap[DISPLAY_NAME]);
                HiveStorageManager.setUserEmail(userInfoMap[USER_EMAIL]);
                GeneralNotifier().publishChange(GeneralNotifier.USER_PROFILE_UPDATE);
                _showToast(context, GenericMethods.getLocalizedString("profile_updated_successfully"));
                Navigator.pop(context);
              }
              else{
                _showToast(context, GenericMethods.getLocalizedString("error_occurred"));
              }
            }

            return null;
          });
        }
      },
    );
  }

  Widget waitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  _showToast(BuildContext context, String text) {
    toastWidget(
      buildContext: context,
      text: text,
    );
  }

}
