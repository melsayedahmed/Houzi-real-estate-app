import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:houzi_package/Mixins/validation_mixins.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/user_log_provider.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/phone_sign_in_widgets/user_get_phone_number.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_forget_password.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_signup.dart';
import 'package:houzi_package/pages/main_screen_pages/my_home_page.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_link_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:provider/provider.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

import '../../../files/app_preferences/app_preferences.dart';
import '../../../widgets/generic_text_widget.dart';

typedef UserSignInPageListener = void Function(String closeOption);

class UserSignIn extends StatefulWidget {

  UserSignInPageListener userSignInPageListener;
  final bool fromBottomNavigator;

  UserSignIn(this.userSignInPageListener,{this.fromBottomNavigator = false});

  @override
  State<StatefulWidget> createState() => UserSignInState();
}

class UserSignInState extends State<UserSignIn> with ValidationMixin {
  final formKey = GlobalKey<FormState>();
  final PropertyBloc _propertyBloc = PropertyBloc();
  final TextEditingController controller = TextEditingController();


  bool _showWaitingWidget = false;
  bool _isLoggedIn = false;
  bool isInternetConnected = true;
  bool obscure = true;

  String usernameEmail = '', password = '', username = '';



  @override
  void initState() {
    super.initState();

  }


  void onBackPressed() {
    widget.userSignInPageListener(CLOSE);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        widget.userSignInPageListener(CLOSE);
        return Future.value(false);
      },
      child: GestureDetector(
        onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
        child: Scaffold(
          appBar: appBarWidget(
            context,
            onBackPressed: onBackPressed,
            automaticallyImplyLeading: widget.fromBottomNavigator ? false : true,
            appBarTitle: GenericMethods.getLocalizedString("login"),
          ),
          body:
          // isInternetConnected == false ? Align(
          //   alignment: Alignment.topCenter,
          //   child: noInternetConnectionErrorWidget(context, (){
          //     checkInternet();
          //   }),
          // ):
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Form(
              key: formKey,
              child: Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                    child: Column(
                      children: [
                        addEmail(),
                        addPassword(),
                        buttonSignInWidget(),
                        doNotHaveAnAccountTextWidget(),
                        forgotPasswordTextWidget(),
                        socialLoginButtonsWidgets(),
                      ],
                    ),
                  ),
                  loginWaitingWidget(),
                  bottomActionBarWidget(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget socialLoginButtonsWidgets() {
    return !SHOW_SOCIAL_LOGIN
        ? Container()
        : Container(
            padding: const EdgeInsets.symmetric(vertical: 30.0),
            child: Column(
              children: [
                SHOW_LOGIN_WITH_PHONE ? phoneLoginButtonWidget() : Container(),

                Platform.isIOS
                    ? Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: SHOW_LOGIN_WITH_APPLE
                            ? appleSocialLoginButtonWidget()
                            : Container(),
                      )
                    : Container(),
                if (SHOW_LOGIN_WITH_GOOGLE && SHOW_LOGIN_WITH_FACEBOOK)
                  Row(
                    children: [
                      Expanded(
                          flex: 9,
                          child: SHOW_LOGIN_WITH_GOOGLE
                              ? googleSocialLoginButtonWidget()
                              : Container()),
                      Expanded(child: Container()),
                      Expanded(
                          flex: 9,
                          child: SHOW_LOGIN_WITH_FACEBOOK
                              ? facebookSocialLoginButtonWidget()
                              : Container()),
                    ],
                  )
                else if (SHOW_LOGIN_WITH_GOOGLE)
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: googleSocialLoginButtonWidget(buildShort: false),
                  )
                else if (SHOW_LOGIN_WITH_FACEBOOK)
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: facebookSocialLoginButtonWidget(buildShort: false),
                  )
              ],
            ),
          );
  }

  Widget appleSocialLoginButtonWidget(){
    return longSocialLoginButtonWidget(
      label: GenericMethods.getLocalizedString("log_in_apple"),
      iconImagePath: AppThemePreferences.appleLightIconImagePath,
      bgColor: AppThemePreferences().appTheme.googleSignInButtonColor,
      style: AppThemePreferences().appTheme.googleSignInButtonTextStyle,
      onPressed: _signInWithApple,
    );
  }

  Widget phoneLoginButtonWidget(){
    return longSocialLoginButtonWidget(
      label: GenericMethods.getLocalizedString("log_in_phone"),
      iconImagePath: AppThemePreferences.phoneIconImagePath,
      bgColor: AppThemePreferences().appTheme.googleSignInButtonColor,
      style: AppThemePreferences().appTheme.googleSignInButtonTextStyle,
      onPressed: navigateToPhoneNumberScreen,
    );
  }

  navigateToPhoneNumberScreen(){
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UserPhoneNumberPage(),
      ),
    );
  }

  Widget googleSocialLoginButtonWidget({bool buildShort = true}){
    return buildShort ? Padding(
      padding: const EdgeInsets.only(top: 20),
      child: shortSocialLoginButtonWidget(
        label: GenericMethods.getLocalizedString(""),
        iconImagePath: AppThemePreferences.googleIconImagePath,
        bgColor: AppThemePreferences().appTheme.googleSignInButtonColor,
        style: AppThemePreferences().appTheme.googleSignInButtonTextStyle,
        onPressed: _googleSignOnMethod,
      ),
    ) : longSocialLoginButtonWidget(
      label: GenericMethods.getLocalizedString("log_in_google"),
      iconImagePath: AppThemePreferences.googleIconImagePath,
      bgColor: AppThemePreferences().appTheme.googleSignInButtonColor,
      style: AppThemePreferences().appTheme.googleSignInButtonTextStyle,
      onPressed: _googleSignOnMethod,
    );
  }

  Widget facebookSocialLoginButtonWidget({bool buildShort = true}){
    return buildShort ? Padding(
      padding: const EdgeInsets.only(top: 20),
      child: shortSocialLoginButtonWidget(
        label: GenericMethods.getLocalizedString(""),
        iconImagePath: AppThemePreferences.facebookIconImagePath,
        bgColor: AppThemePreferences().appTheme.googleSignInButtonColor,
        style: AppThemePreferences().appTheme.facebookSignInButtonTextStyle,
        onPressed: _facebookSignOnMethod,
      ),
    ) : shortSocialLoginButtonWidget(
      label: GenericMethods.getLocalizedString("log_in_facebook"),
      iconImagePath: AppThemePreferences.facebookIconImagePath,
      bgColor: AppThemePreferences().appTheme.googleSignInButtonColor,
      style: AppThemePreferences().appTheme.facebookSignInButtonTextStyle,
      onPressed: _facebookSignOnMethod,
    );
  }

  Widget addEmail() {
    return textFieldWidget(
      padding: const EdgeInsets.only(top: 15),
      labelText: GenericMethods.getLocalizedString("user_name_email"),
      hintText: GenericMethods.getLocalizedString("enter_the_email_address_or_user_name"),
      keyboardType: TextInputType.text,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
        }
        return null;
      },
      onSaved: (String value) {
        setState(() {
          usernameEmail = value;
        });
      },
    );
  }

  Widget addPassword() {
    return textFieldWidget(
      padding: const EdgeInsets.only(top: 15),
      labelText: GenericMethods.getLocalizedString("password"),
      hintText: GenericMethods.getLocalizedString("enter_your_password"),
      obscureText: obscure,
      validator: (value) => validatePassword(context, value),
      suffixIcon: GestureDetector(
        onTap: () {
          setState(() {
            obscure = !obscure;
          });
        },
        child: Icon(obscure?AppThemePreferences.visibilityIcon:AppThemePreferences.invisibilityIcon),
      ),
      onSaved: (String value) {
        setState(() {
          password = value;
        });
      },
    );
  }

  Widget buttonSignInWidget() {
    return Container(
      padding: const EdgeInsets.only(top: 30),
      child: buttonWidget(
        text: GenericMethods.getLocalizedString("login"),
        onPressed: () async {
          FocusScope.of(context).requestFocus(FocusNode());
          if (formKey.currentState.validate()) {
            setState(() {
              _showWaitingWidget = true;
            });
            formKey.currentState.save();

            Map<String, dynamic> userInfo = {
              USER_NAME: usernameEmail,
              PASSWORD: password,
            };

            final response = await _propertyBloc.fetchLoginResponse(userInfo);

            if(response == null || response.statusCode == null){
              if(mounted){
                setState(() {
                  isInternetConnected = false;
                  _showWaitingWidget = false;
                });
              }
            }else{
              if(mounted){
                setState(() {
                  isInternetConnected = true;
                  _showWaitingWidget = false;
                });
              }
            }

            // print(response);
            bool canLogin = false;
            if(response.toString().contains("token")){
              canLogin = true;
            }

            if (response == null || response.statusCode != 200) {
              // setState(() {
              //   _showWaitingWidget = false;
              // });
              _showToastForUserLogin(context);
            } else if (response.statusCode == 200 && canLogin) {
              setState(() {
                // _showWaitingWidget = false;
                _isLoggedIn = true;
              });
              _showToastForUserLogin(context);
              HiveStorageManager.storeUserLoginInfoData(response.data);
              Map<String, dynamic> userInfo = {
                USER_NAME: usernameEmail,
                PASSWORD: password,
              };
              HiveStorageManager.storeUserCredentials(userInfo);

              GeneralNotifier().publishChange(GeneralNotifier.USER_LOGGED_IN);

              Provider.of<UserLoggedProvider>(context,listen: false).loggedIn();

              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => MyHomePage()),
                      (Route<dynamic> route) => false);
            } else {
              _showToast(context,GenericMethods.cleanContent(response.data["message"]));
              setState(() {
                _showWaitingWidget = false;
              });
            }
          }
        },
      ),
    );
  }

  _showToast(BuildContext context,String msg) {
    toastWidget(
        buildContext: context,
        text: msg
    );
  }

  Widget longSocialLoginButtonWidget({
    @required String label,
    @required String iconImagePath,
    @required void Function() onPressed,
    double width = double.infinity,
    double height =  50.0,
    Color bgColor,
    @required TextStyle style,
  }){
    return SizedBox(
      width: width,
      height: height,
      child: OutlinedButton(
        onPressed: onPressed,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset(iconImagePath, width: 30.0, height: 30.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: genericTextWidget(
                  label,
                  style: style,
              ),
            ),
          ],
        ),

        style: ElevatedButton.styleFrom(

          elevation: 1.0,
          primary: bgColor ?? AppThemePreferences().appTheme.primaryColor,

          // primary: bgColor != null ? bgColor : AppThemePreferences().appTheme.cardColor,
        ),
      ),
    );
  }

  Widget shortSocialLoginButtonWidget({
    @required String label,
    @required String iconImagePath,
    @required void Function() onPressed,
    double width = double.infinity,
    double height =  50.0,
    Color bgColor,
    @required TextStyle style,
  }){
    return SizedBox(
      width: width,
      height: height,
      child: OutlinedButton(
        onPressed: onPressed,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(iconImagePath, width: 30.0, height: 30.0),

          ],
        ),

        style: ElevatedButton.styleFrom(
          elevation: 1.0,
          primary: bgColor ?? AppThemePreferences().appTheme.primaryColor,
          // primary: bgColor != null ? bgColor : AppThemePreferences().appTheme.cardColor,
        ),
      ),
    );
  }

  Widget doNotHaveAnAccountTextWidget() {
    return Container(
      padding: const EdgeInsets.only(top: 30),
      child: genericLinkWidget(
        context: context,
        preLinkText: GenericMethods.getLocalizedString("do_not_have_an_account"),
        linkText: GenericMethods.getLocalizedString("sign_up_capital"),
        onLinkPressed: () {
          Route route = MaterialPageRoute(builder: (context) => UserSignUp());
          Navigator.pushReplacement(context, route);
        },
      ),
    );
  }

  Widget forgotPasswordTextWidget() {
    return Container(
      padding: const EdgeInsets.only(top: 15),
      child: genericLinkWidget(
        context: context,
        linkText: GenericMethods.getLocalizedString("forgot_password_with_question_mark"),
        onLinkPressed: () {
          GenericMethods.navigateToRoute(
            context: context,
            builder: (context) => UserForgetPassword(),
          );
        },
      ),
    );
  }

  _showToastForUserLogin(BuildContext context) {
    toastWidget(
      buildContext: context,
      text: _isLoggedIn == true
          ? GenericMethods.getLocalizedString("user_Login_successfully")
          : GenericMethods.getLocalizedString("user_login_failed"),
    );
  }

  Widget loginWaitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0,
            right: 0,
            top: 90,
            bottom: 0,
            child: Center(
              child: Container(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context,
              (){},
              showRetryButton: false,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _googleSignOnMethod()  async {
    try {
      setState(() {
        _showWaitingWidget = true;
      });
      GoogleSignIn _googleSignIn = GoogleSignIn();
      GoogleSignInAccount googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        setState(() {
          _showWaitingWidget = false;
        });
        //_showToast(context, "CANCELLED_SIGN_IN");
        return Future.error("CANCELLED_SIGN_IN");
      }

      //GoogleSignInAuthentication googleAuth = await googleUser?.authentication;
      //String token = googleAuth?.idToken;

      Map<String, dynamic> userInfo = {
        USER_SOCIAL_EMAIL: googleUser?.email,
        USER_SOCIAL_ID: googleUser?.id,
        USER_SOCIAL_PLATFORM: SOCIAL_PLATFORM_GOOGLE,
        USER_SOCIAL_DISPLAY_NAME: googleUser?.displayName,
        USER_SOCIAL_PROFILE_URL: googleUser?.photoUrl ?? ""
      };

      _signOnMethod(userInfo);

    }
    catch(error) {
      setState(() {
        _showWaitingWidget = false;
      });
      switch (error.code) {
        case "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL":
          _showToast(context, "Account already exists with a different credential.");
          break;
        case "ERROR_INVALID_CREDENTIAL":
          _showToast(context, "Invalid credential.");
          break;
        case "ERROR_INVALID_EMAIL":
          _showToast(context, "Your email address appears to be malformed.");
          break;
        case "ERROR_WRONG_PASSWORD":
          _showToast(context, "Your password is wrong.");
          break;
        case "ERROR_USER_NOT_FOUND":
          _showToast(context, "User with this email doesn't exist.");
          break;
        case "ERROR_USER_DISABLED":
          _showToast(context, "User with this email has been disabled.");
          break;
        case "ERROR_TOO_MANY_REQUESTS":
          _showToast(context, "Too many requests. Try again later.");
          break;
        case "ERROR_OPERATION_NOT_ALLOWED":
          _showToast(context, "Signing in with Email and Password is not enabled.");
          break;
        default:

      }
    }

  }

  Future<void> _facebookSignOnMethod() async {
    setState(() {
      _showWaitingWidget = true;
    });
    final LoginResult result = await FacebookAuth.instance.login(permissions: ['email', 'public_profile'] );
    if (result.status == LoginStatus.success) {
      //final AccessToken accessToken = result.accessToken;

      final userData = await FacebookAuth.instance.getUserData();

      Map<String, dynamic> userInfo = {
        USER_SOCIAL_EMAIL: userData["email"],
        USER_SOCIAL_ID: userData["id"],
        USER_SOCIAL_PLATFORM: SOCIAL_PLATFORM_FACEBOOK,
        USER_SOCIAL_DISPLAY_NAME: userData["name"],
        USER_SOCIAL_PROFILE_URL: userData["picture"]["data"]["url"] ?? "",
      };

      _signOnMethod(userInfo);
    } else {
      setState(() {
        _showWaitingWidget = false;
      });
      if (kDebugMode) {
        print(result.status);
        print(result.message);
      }
    }
  }

  /// Generates a cryptographically secure random nonce, to be included in a
  /// credential request.
  String generateNonce([int length = 32]) {
    const charset =
        '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
    final random = Random.secure();
    return List.generate(length, (_) => charset[random.nextInt(charset.length)])
        .join();
  }

  /// Returns the sha256 hash of [input] in hex notation.
  String sha256ofString(String input) {
    final bytes = utf8.encode(input);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }


  Future<void> _signInWithApple() async {
    setState(() {
      _showWaitingWidget = true;
    });
    final rawNonce = generateNonce();
    final nonce = sha256ofString(rawNonce);

    final appleCredential = await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
      webAuthenticationOptions: WebAuthenticationOptions(
        // TODO: Set the `clientId` and `redirectUri` arguments to the values you entered in the Apple Developer portal during the setup
        clientId: APPLE_SIGN_ON_CLIENT_ID,
        redirectUri: Uri.parse(APPLE_SIGN_ON_REDIRECT_URI),
      ),
      nonce: nonce,

    );
    //print("Apple[Credentials]: $appleCredential");
    if(appleCredential.userIdentifier !=null && appleCredential.userIdentifier.isNotEmpty){
      Map<String, dynamic> userInfo = {
        USER_SOCIAL_EMAIL: appleCredential.email ?? "",
        USER_SOCIAL_ID: appleCredential.userIdentifier,
        USER_SOCIAL_PLATFORM: SOCIAL_PLATFORM_APPLE,
        USER_SOCIAL_DISPLAY_NAME: appleCredential.givenName ?? "",
        USER_SOCIAL_PROFILE_URL: "",
      };

      _signOnMethod(userInfo);
    }else{
      setState(() {
        _showWaitingWidget = false;
      });
    }


  }

  Future<void> _signOnMethod(Map<String, dynamic> userInfo) async {
    if (kDebugMode) {
      print("info $userInfo");
    }
    final response = await _propertyBloc.fetchSocialSignOnResponse(userInfo);
    //print("response $response");
    if(response == null || response.statusCode == null){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          _showWaitingWidget = false;
        });
      }
    }else{
      if(mounted){
        setState(() {
          isInternetConnected = true;
          _showWaitingWidget = false;
        });
      }
    }

    if (response == null || response.statusCode != 200) {
      _showToast(context,GenericMethods.getLocalizedString("user_login_failed"));
      // _showToastForUserLogin(context);
    } else if (response.statusCode == 200) {
      setState(() {
        _isLoggedIn = true;
      });
      _showToast(context,GenericMethods.getLocalizedString("user_Login_successfully"));
      // _showToastForUserLogin(context);
      Map loggedInUserData = response.data;
      HiveStorageManager.storeUserLoginInfoData(loggedInUserData);
      HiveStorageManager.storeUserCredentials(userInfo);

      Provider.of<UserLoggedProvider>(context,listen: false).loggedIn();

      GeneralNotifier().publishChange(GeneralNotifier.USER_LOGGED_IN);
      GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => MyHomePage());
    }
  }
}
