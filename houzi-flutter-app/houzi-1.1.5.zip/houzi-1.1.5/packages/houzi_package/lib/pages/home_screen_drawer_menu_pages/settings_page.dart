import 'package:dio/dio.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/item_design_files/item_design_notifier.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/models/property_meta_data.dart';
import 'package:houzi_package/pages/app_settings_pages/about.dart';
import 'package:houzi_package/pages/app_settings_pages/dark_mode_setting.dart';
import 'package:houzi_package/pages/app_settings_pages/language_settings.dart';
import 'package:houzi_package/pages/app_settings_pages/web_page.dart';
import 'package:houzi_package/pages/main_screen_pages/my_home_page.dart';
import 'package:houzi_package/parsers/houzez_parser.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/article_box_widgets/article_box_design.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/dialog_box_widget.dart';
import 'package:houzi_package/widgets/explore_by_type_design_widgets/explore_by_type_design.dart';
import 'package:houzi_package/widgets/generic_settings_row_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

typedef SettingsHook = List<dynamic> Function(BuildContext context);

class HomePageSettings extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => HomePageSettingsState();
}

class HomePageSettingsState extends State<HomePageSettings> {

  SettingsHook settingsHook = GenericMethods.settingsOption;

  bool _showLoadingWidget = false;
  String appName = "";

  String _selectedItemDesign;
  String _selectedExploreByTypeDesign;

  final Article _article = Article(
    title: "Title",
  );

  final Address _address = Address(
    address: "Address",
  );

  final Features _features = Features(
    landArea: "1000",
    landAreaUnit: "SqFt",
    bedrooms: "2",
    bathrooms: "2",
    garage: "1",
  );
  final PropertyInfo _propertyInfo = PropertyInfo(
    propertyStatus: "For Sale",
    price: "\$1000000",
    featured: "1",
    propertyType: "Villa",
  );

  final PropertyMetaData _propertyMetaData01 = PropertyMetaData(
    id: 01,
    name: "Title",
    slug: "title",
    parent: 0,
    totalPropertiesCount: 10,
    fullImage:  "assets/settings/dummy_property_image_01.jpg",
  );

  final PropertyMetaData _propertyMetaData02 = PropertyMetaData(
    id: 02,
    name: "Title",
    slug: "title",
    parent: 0,
    totalPropertiesCount: 10,
    fullImage:  "assets/settings/dummy_property_image_02.jpg",
  );

  final PropertyMetaData _propertyMetaData03 = PropertyMetaData(
    id: 03,
    name: "Title",
    slug: "title",
    parent: 0,
    totalPropertiesCount: 10,
    fullImage:  "assets/settings/dummy_property_image_03.jpg",
  );

  List<dynamic> propertyMetaDataListForThemeDesign = [];


  String _wordpressUrlAuthority = '';
  String _wordpressUrl = '';
  String heroId = "";
  final formKey = GlobalKey<FormState>();

  final ArticleBoxDesign _articleBoxDesign = ArticleBoxDesign();
  final ExploreByTypeDesign _exploreByTypeDesign = ExploreByTypeDesign();

  static const String ITEM_THEME_DESIGN = "itemThemeDesign";
  static const String EXPLORE_BY_TYPE_ITEM_THEME_DESIGN = "exploreByTypeItemThemeDesign";

  List<Widget> preferencesHookWidgetsList = [];
  List<Widget> communityStandardsAndLegalPoliciesHookWidgetsList = [];
  List<Widget> hooksWidgetsList = [];

  @override
  void initState() {
    super.initState();

    appName = HiveStorageManager.readAppInfo()[APP_INFO_APP_NAME] ?? "";

    _article.address = _address;
    _article.features = _features;
    _article.propertyInfo = _propertyInfo;
    _article.propertyDetailsMap["Price"] = "1000000";

    propertyMetaDataListForThemeDesign = [_propertyMetaData01, _propertyMetaData02, _propertyMetaData03];

    List<dynamic> tempList = [];
    tempList = settingsHook(context);
    if(tempList != null && tempList.isNotEmpty){
      for(var item in tempList){
        if(item != null && item is Map && item.isNotEmpty){
          if(item["sectionType"] == "preferences"){
            preferencesHookWidgetsList.add(item["menuItem"]);
          }else if(item["sectionType"] == "community_standards_and_legal_policies"){
            communityStandardsAndLegalPoliciesHookWidgetsList.add(item["menuItem"]);
          }else{
            hooksWidgetsList.add(item["menuItem"]);
          }
        }
      }
    }

  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ItemDesignNotifier>(
      builder: (context, itemDesignNotifier, child){
        return GestureDetector(
          onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
          child: Scaffold(
            appBar: appBarWidget(
              context,
              appBarTitle: GenericMethods.getLocalizedString("setting_and_privacy"),
            ),
            body: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Stack(
                children: [
                  Column(
                    children: [
                      demoConfigWidget(),
                      itemThemeDesignsWidget(context, itemDesignNotifier),
                      exploreByTypeThemeDesignsWidget(context, itemDesignNotifier),
                      preferencesWidget(),
                      communityStandardsAndLegalPoliciesWidget(),
                      if(hooksWidgetsList != null && hooksWidgetsList.isNotEmpty) Column(
                        children: hooksWidgetsList,
                      ),
                    ],
                  ),
                  loadingIndicatorWidget(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget demoConfigWidget(){
    return SHOW_DEMO_CONFIGURATIONS ? genericSettingsWidget(
      headingText: GenericMethods.getLocalizedString("demo_configuration"),
      headingSubTitleText: GenericMethods.getLocalizedString("enter_your_own_wordpress"),
      body:  textFieldWidget(
        additionalHintText: GenericMethods.getLocalizedString("web_example"),
        ignorePadding: true,
        readOnly: true,
        hintText: GenericMethods.getLocalizedString("enter_your_wordpress_url"),
        suffixIcon: Icon(
          AppThemePreferences.linkIcon,
          color: AppThemePreferences().appTheme.hintColor,
        ),
        onTap: (){
          _enterUrlDialog(context);
          FocusScope.of(context).unfocus();
        },
      ),
    ) : Container();
  }

  Future _enterUrlDialog(BuildContext context){
    return dialogBoxWidget(
      context,
      title: GenericMethods.getLocalizedString("enter_your_wordpress_url"),
      actionsPadding: const EdgeInsets.symmetric(horizontal: 20.0),
      content: Form(
        key: formKey,
        child: TextFormField(
          textInputAction: TextInputAction.search,
          validator: (value){
            if(!value.contains(HTTP) && !value.contains(HTTPS)){
              return GenericMethods.getLocalizedString("please_enter_a_complete_url");
            }
            return null;
          },
          onSaved: (value){
            setState(() {
              _wordpressUrl = value;
            });
          },
          onFieldSubmitted: (value){
            setState(() {
              _wordpressUrl = value;
            });
          },
          decoration: InputDecoration(
            hintText: DEMO_URL,
            // hintText: HiveStorageManager.readUrl() ?? DEMO_URL,
            focusedBorder: OutlineInputBorder(
              borderRadius: const BorderRadius.all(Radius.circular(24.0),),
              borderSide: BorderSide(color: Theme.of(context).primaryColor,),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: const BorderRadius.all(Radius.circular(24.0),),
              borderSide: BorderSide(color: Colors.grey.shade300,),
            ),
            contentPadding: const EdgeInsets.only(top: 15, left: 20, right: 20),
          ),

          keyboardType: TextInputType.url,
        ),
      ),
      actions: <Widget>[
        resetButton(),
        cancelButton(),
        saveButton(),
      ],
    );
  }

  Widget resetButton(){
    return TextButton(
      onPressed: (){
        //Need to remove login data, because new website cannot work with previous webiste token.
        HiveStorageManager.deleteUserLoginInfoData();
        HiveStorageManager.deleteAllData();
        String communicationProtocol = '';
        _wordpressUrl = DEMO_URL;
        _wordpressUrlAuthority = WORDPRESS_URL_DOMAIN;
        communicationProtocol = HTTP;
        HiveStorageManager.storeUrl(url: _wordpressUrl);
        HiveStorageManager.storeUrlAuthority(authority: _wordpressUrlAuthority);
        HiveStorageManager.storeCommunicationProtocol(protocol: communicationProtocol);
        GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => const MyHomePage());
        // GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => MyApp());
      },
      child:  genericTextWidget(
        GenericMethods.getLocalizedString("reset"),
        style: TextStyle(color: AppThemePreferences.errorColor),
      ),
    );
  }

  Widget cancelButton(){
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: TextButton(
        onPressed: () => Navigator.of(context).pop(),
        child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
      ),
    );
  }

  Widget saveButton(){
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: TextButton(
        onPressed: () async {
          FocusScope.of(context).requestFocus(FocusNode());
          if(formKey.currentState.validate()){
            formKey.currentState.save();

            setState(() {
              _showLoadingWidget = true;
            });

            String communicationProtocol = '';
            if(_wordpressUrl.contains('http://')){
              communicationProtocol = 'http';
            }else if(_wordpressUrl.contains('https://')){
              communicationProtocol = 'https';
            }

            String temp = _wordpressUrl.split('//')[1];
            _wordpressUrlAuthority = temp;

            if(_wordpressUrlAuthority.contains('/')){
              temp = _wordpressUrlAuthority.split('/')[0];
              _wordpressUrlAuthority = temp;
            }


            // WORDPRESS_URL_DOMAIN = _wordpressUrlAuthority;

            Dio dio = Dio();
            var queryParameters = {
              'app_version':"${1}",
            };
            try{
              Uri uri;

              if(communicationProtocol == HTTP){
                uri = Uri.http(_wordpressUrlAuthority, HOUZEZ_META_DATA_PATH, queryParameters);
              }else if(communicationProtocol == HTTPS){
                uri = Uri.https(_wordpressUrlAuthority, HOUZEZ_META_DATA_PATH, queryParameters);
              }

              var response = await dio.getUri(uri);
              if(response.statusCode == 200){
                setState(() {
                  _showLoadingWidget = false;
                });
                //Need to remove login data, because new website cannot work with previous webiste token.
                HiveStorageManager.deleteUserLoginInfoData();
                HiveStorageManager.deleteAllData();
                HiveStorageManager.storeUrl(url: _wordpressUrl);
                HiveStorageManager.storeUrlAuthority(authority: _wordpressUrlAuthority);
                HiveStorageManager.storeCommunicationProtocol(protocol: communicationProtocol);
                GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => const MyHomePage());
                // GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => MyApp());
              }else{
                setState(() {
                  _showLoadingWidget = false;
                });
                _responseErrorDialog(context);
              }
            }on DioError catch (e) {
              setState(() {
                _showLoadingWidget = false;
              });
              Navigator.of(context).pop();
              _responseErrorDialog(context);
              print("Demo Config Property Meta: ${e.response.statusCode}");
              print("Demo Config Property Meta:" + e.message);
            }
          }
        },
        child: genericTextWidget(GenericMethods.getLocalizedString("save")),
      ),
    );
  }

  Future _responseErrorDialog(BuildContext context){
    return dialogBoxWidget(
        context,
        title: GenericMethods.getLocalizedString("this_app_requires_plugin"),
        actionsPadding: const EdgeInsets.symmetric(horizontal: 20),
        actions: <Widget>[
          TextButton(
            onPressed: () => launch(HOUZI_URL_PLUG_IN),
            child: genericTextWidget(GenericMethods.getLocalizedString("plug_in_text")),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 0),
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: genericTextWidget(GenericMethods.getLocalizedString("ok")),
            ),
          ),
        ],
    );
  }

  Widget loadingIndicatorWidget() {
    return _showLoadingWidget == false ? Container() :  Positioned(
      left: 0,
      right: 0,
      top: 0,
      bottom: 0,
      child: Center(
        child: Container(
          alignment: Alignment.center,
          child: SizedBox(
            width: 80,
            height: 20,
            child: loadingBallBeatWidget(),
          ),
        ),
      ),
    );
  }

  Widget itemThemeDesignsWidget(BuildContext context, ItemDesignNotifier itemDesignNotifier){
    return genericSettingsWidget(
        headingText: GenericMethods.getLocalizedString("item_theme_design"),
        headingSubTitleText: GenericMethods.getLocalizedString("customise_your_item_theme_design"),
        body: themeDesignDropDownWidget(
          tag: ITEM_THEME_DESIGN,
          design: itemDesignNotifier.homeScreenItemDesign ?? GenericMethods.getLocalizedString("select"),
          designList: HOME_SCREEN_ITEM_DESIGN_LIST,
          onChanged: (String val) {
            setState(() {
              _selectedItemDesign = val;
            });
            itemDesignNotifier.setHomeScreenItemDesign(_selectedItemDesign);
            _showToast(context, GenericMethods.getLocalizedString("item_design_is_successfully_updated"));
          },
        ),
    );
  }

  Widget exploreByTypeThemeDesignsWidget(BuildContext context, ItemDesignNotifier itemDesignNotifier){
    return genericSettingsWidget(
      headingText: GenericMethods.getLocalizedString("explore_by_type_theme_design"),
      headingSubTitleText: GenericMethods.getLocalizedString("customise_your_item_theme_design"),
      body: themeDesignDropDownWidget(
        tag: EXPLORE_BY_TYPE_ITEM_THEME_DESIGN,
        design: itemDesignNotifier.exploreByTypeItemDesign ?? GenericMethods.getLocalizedString("select"),
        designList: EXPLORE_BY_TYPE_ITEM_DESIGN_LIST,
        onChanged: (String val) {
          setState(() {
            _selectedExploreByTypeDesign = val;
          });
          itemDesignNotifier.setExploreByTypeItemDesign(_selectedExploreByTypeDesign);
          _showToast(context, GenericMethods.getLocalizedString("explore_by_type_is_successfully_updated"));
        },
      ),
    );
  }

  Widget preferencesWidget(){
    return genericSettingsWidget(
      headingText: GenericMethods.getLocalizedString("preference"),
      headingSubTitleText: GenericMethods.getLocalizedString("customise_your_experience_on_app",inputWords:[appName] ),
      // headingSubTitleText: AppLocalizations.of(context).customise_your_experience_on_app(appName),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          genericWidgetRow(
            iconData: AppThemePreferences.darkModeIcon,
            text: GenericMethods.getLocalizedString("dark_mode"),
            removeDecoration: true,
            onTap: ()=> onDarkModeSettingsTap(context),
          ),
          genericWidgetRow(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            iconData: AppThemePreferences.languageIcon,
            text: GenericMethods.getLocalizedString("language_label"),
            removeDecoration: true,
            onTap: ()=> onLanguageSettingsTap(context),
          ),
          if(preferencesHookWidgetsList != null && preferencesHookWidgetsList.isNotEmpty) Column(
            children: preferencesHookWidgetsList,
          ),
        ],
      ),
    );
  }

  void onDarkModeSettingsTap(BuildContext context){
    GenericMethods.navigateToRoute(
      context: context,
      builder: (context) => DarkModeSettings(),
    );
  }

  void onLanguageSettingsTap(BuildContext context){
    GenericMethods.navigateToRoute(
        context: context,
        builder: (context) => LanguageSettings(),
    );
  }

  Widget communityStandardsAndLegalPoliciesWidget(){
    return genericSettingsWidget(
      headingText: GenericMethods.getLocalizedString("community_standards_and_legal_policies"),
      removeDecoration: true,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          genericWidgetRow(
            iconData: AppThemePreferences.gravelIcon,
            text: GenericMethods.getLocalizedString("terms_and_conditions"),
            removeDecoration: true,
            onTap: ()=> onTermsAndConditionsTap(context),
          ),
          genericWidgetRow(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10.0),
            iconData: AppThemePreferences.policyIcon,
            text: GenericMethods.getLocalizedString("privacy_policy"),
            removeDecoration: true,
            onTap: (){
              onPrivacyTap(context);
            },
          ),
          genericWidgetRow(
            padding: const EdgeInsets.only(top: 10.0),
            iconData: AppThemePreferences.infoIcon,
            text: GenericMethods.getLocalizedString("about"),
            removeDecoration: true,
            onTap: ()=> onAboutTap(context),
          ),
          if(communityStandardsAndLegalPoliciesHookWidgetsList != null && communityStandardsAndLegalPoliciesHookWidgetsList.isNotEmpty) Column(
            children: communityStandardsAndLegalPoliciesHookWidgetsList,
          ),
        ],
      ),
    );
  }

  void onTermsAndConditionsTap(BuildContext context){
    GenericMethods.navigateToRoute(
        context: context,
        builder: (context) => WebPage(APP_TERMS_URL, GenericMethods.getLocalizedString("terms_and_conditions")));
  }

  void onPrivacyTap(BuildContext context){
    GenericMethods.navigateToRoute(
        context: context,
        builder: (context) => WebPage(APP_PRIVACY_URL, GenericMethods.getLocalizedString("privacy_policy")));
  }

  void onAboutTap(BuildContext context){
    SHOW_DEMO_CONFIGURATIONS ? GenericMethods.navigateToRoute(
        context: context,
        builder: (context) => About()) :
    GenericMethods.navigateToRoute(
        context: context,
        builder: (context) => WebPage(COMPANY_URL, GenericMethods.getLocalizedString("about")));
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }

  double getExpandableOptionHeight({
    @required String tag,
    @required String design
  }){
    if(tag == ITEM_THEME_DESIGN){
      return _articleBoxDesign.getArticleBoxDesignHeight(design: design);
    }else if(tag == EXPLORE_BY_TYPE_ITEM_THEME_DESIGN){
      return _exploreByTypeDesign.getExploreByTypeDesignHeight(design: design);
    }
    return null;
  }

  Widget getExpandableOptionDesignWidget({
    @required String tag,
    @required String design,
  }){
    if(tag == ITEM_THEME_DESIGN){
      return _articleBoxDesign.getArticleBoxDesign(article: _article, heroId: heroId, buildContext: context, design: design, isInMenu: true);
    }else if(tag == EXPLORE_BY_TYPE_ITEM_THEME_DESIGN){
      return _exploreByTypeDesign.getExploreByTypeDesign(design: design, buildContext: context, metaDataList: propertyMetaDataListForThemeDesign, isInMenu: true);
    }
    return Container();
  }


  Widget themeDesignDropDownWidget({
    @required String tag,
    @required String design,
    @required List<String> designList,
    @required void Function(String) onChanged,
  }){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 15.0),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton(
            itemHeight: null,
            isExpanded: true,
            icon: Padding(
              padding: const EdgeInsets.only(right: 10.0,left: 10.0),
              child: Icon(AppThemePreferences.arrowDropDownIcon),
            ),
            hint: Container(
              padding: const EdgeInsets.only(right: 10.0,left: 10.0),
              child: genericTextWidget(design ?? GenericMethods.getLocalizedString("select")),
            ),
            items: designList.map<DropdownMenuItem<String>>((item) {
              heroId = "hero-" + item;
              return DropdownMenuItem<String>(
                value: item,
                child: ExpandablePanel(
                  theme: ExpandableThemeData(iconColor: AppThemePreferences.appIconsMasterColorLight),
                  header: genericTextWidget(item),
                  expanded: SizedBox(
                    height: getExpandableOptionHeight(tag: tag, design: item),
                    child: getExpandableOptionDesignWidget(tag: tag, design: item),
                  ),
                  collapsed: Container(),
                ),
              );
            }).toList(),
            onChanged: onChanged,
          ),
        ),
      ),
    );
  }

  // Widget genericSettingsWidget({
  //   @required String headingText,
  //   String headingSubTitleText,
  //   @required Widget body,
  //   bool removeDecoration = false,
  // }){
  //   return Container(
  //     decoration: removeDecoration ? null : AppThemePreferences.dividerDecoration(),
  //     padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20.0),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         headingWidget(text: headingText),
  //         headingSubTitleText == null || headingSubTitleText.isEmpty ?  Container(): headingSubTitleWidget(text: headingSubTitleText),
  //         body,
  //       ],
  //     ),
  //   );
  // }
  //
  // Widget headingWidget({String text}){
  //   return genericTextWidget(
  //     text,
  //     style: AppThemePreferences().appTheme.settingHeadingTextStyle,
  //     strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //   );
  // }
  //
  // Widget headingSubTitleWidget({String text}){
  //   return Container(
  //     padding: const EdgeInsets.only(top: 3),
  //     child: genericTextWidget(
  //       text,
  //       style: AppThemePreferences().appTheme.settingHeadingSubTitleTextStyle,
  //       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //     ),
  //   );
  // }
}