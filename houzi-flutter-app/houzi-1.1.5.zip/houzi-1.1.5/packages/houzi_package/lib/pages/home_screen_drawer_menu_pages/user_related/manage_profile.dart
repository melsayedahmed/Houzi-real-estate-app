import 'dart:convert';
import 'dart:io';

import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/change_password.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/edit_pofile.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/shimmer_effect_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:image_picker/image_picker.dart';

import '../../../Mixins/validation_mixins.dart';
import '../../../files/generic_methods/generic_methods.dart';
import '../../../widgets/dialog_box_widget.dart';
import '../../../widgets/generic_settings_row_widget.dart';
import '../../../widgets/header_widget.dart';
import '../../main_screen_pages/my_home_page.dart';

class ManageProfile extends StatefulWidget {

  @override
  _ManageProfileState createState() => _ManageProfileState();
}

class _ManageProfileState extends State<ManageProfile> with ValidationMixin {
  final formKey = GlobalKey<FormState>();
  final PropertyBloc _propertyBloc = PropertyBloc();

  final picker = ImagePicker();
  File imageFile;

  bool isInternetConnected = true;
  bool _showWaitingWidget = false;
  bool _showWaitingWidgetForPicUpload = false;
  bool _showUploadPhotoButton = false;
  VoidCallback  generalNotifierLister;

  String userRole = "";
  String userEmail = "";
  String userName = "";
  String userAvatar;

  @override
  void initState() {
    super.initState();
    fetchUserData();
    generalNotifierLister = () {
      if (GeneralNotifier().change == GeneralNotifier.USER_PROFILE_UPDATE) {
        fetchUserData();
      }
    };

    GeneralNotifier().addListener(generalNotifierLister);
  }

  fetchUserData(){
    setState(() {
      userEmail = HiveStorageManager.getUserEmail();
      userName = HiveStorageManager.getUserName();
      userAvatar = HiveStorageManager.getUserAvatar();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("manage_profile"),
        ),
        body: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: showUserInfo(context),
              ),
      ),
    );
  }

  Widget showUserInfo(BuildContext context) {
    return Stack(
      children: [
        SingleChildScrollView(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Stack(
                    children: [
                      Center(
                        child: GestureDetector(
                            onTap: () => chooseImageOption(context),
                            child: imageWidget(context)
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        left: 90,
                        right: 0,
                        child: GestureDetector(
                          onTap: () => chooseImageOption(context),
                          child: CircleAvatar(
                            radius: 13,
                            backgroundColor: AppThemePreferences().appTheme.selectedItemTextColor,
                            child: Icon(
                              AppThemePreferences.editIcon,
                              size: AppThemePreferences.editProfilePictureIconSize,
                              color:  AppThemePreferences.filledButtonIconColor,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        updateProfileImageButtonWidget(context),
                        Padding(
                          padding: const EdgeInsets.only(top: 20.0),
                          child: Column(
                            children: [
                              genericTextWidget(
                                userName,
                                style: AppThemePreferences().appTheme.heading01TextStyle,
                              ),
                              Divider(thickness: 0,color: AppThemePreferences.homeScreenDrawerTextColorDark,),
                              genericTextWidget(
                                userEmail,
                                style: AppThemePreferences().appTheme.heading01TextStyle,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    decoration: AppThemePreferences.dividerDecoration(),
                  ),

                  genericWidgetRow(
                    iconData: AppThemePreferences.editIcon,
                    text: GenericMethods.getLocalizedString("edit_profile"),
                    onTap: onEditProfileTap,
                  ),
                  genericWidgetRow(
                    iconData: AppThemePreferences.changePassword,
                    text: GenericMethods.getLocalizedString("change_password"),
                    onTap: onChangePasswordTap,
                  ),
                ],
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: deleteAccountButtonWidget(context),
          ),
        ),
        waitingWidget(),
        bottomActionBarWidget(),
      ],
    );
  }

  navigateToRoute(WidgetBuilder builder) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: builder,
      ),
    );
  }

  void onChangePasswordTap() {
    navigateToRoute((context) => const ChangePassword());
  }

  void onEditProfileTap() {
    navigateToRoute((context) => EditProfile());
  }

  chooseImageOption(BuildContext context) {
    dialogBoxWidget(
      context,
      title: GenericMethods.getLocalizedString("select_image"),
      style: AppThemePreferences().appTheme.heading02TextStyle,
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          InkWell(
            onTap: () {
              _getImageFile(context, ImageSource.camera);
              Navigator.pop(context);
            },
            child: Container(
                width: double.infinity,
                padding: const EdgeInsets.only(top: 5, bottom: 5),
                child: genericTextWidget(
                  GenericMethods.getLocalizedString("from_camera"),
                  style: AppThemePreferences().appTheme.bodyTextStyle,
                )),
          ),
          const Divider(
            thickness: 1,
          ),
          InkWell(
            onTap: () {
              _getImageFile(context, ImageSource.gallery);
              Navigator.pop(context);
            },
            child: Container(
                width: double.infinity,
                padding: const EdgeInsets.only(
                  top: 10,
                  bottom: 10,
                ),
                child: genericTextWidget(
                  GenericMethods.getLocalizedString("from_gallery"),
                  style: AppThemePreferences().appTheme.bodyTextStyle,
                )),
          ),
        ],
      ),
    );
  }

  Future _getImageFile(BuildContext context, ImageSource source) async {
    var pickedFile =
        await picker.pickImage(source: source, maxHeight: 1000, maxWidth: 1000);

    if (pickedFile != null) {
      setState(() {
        _showUploadPhotoButton = true;
        imageFile = File(pickedFile.path);
      });
      imageWidget(context);
    } else {
      if (kDebugMode) {
        print('No image selected.');
      }
    }
  }

  Widget imageWidget(BuildContext context) {
    if (imageFile == null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(100.0),
        child: FancyShimmerImage(
          imageUrl: userAvatar,
          boxFit: BoxFit.cover,
          shimmerBaseColor:
              AppThemePreferences().appTheme.shimmerEffectBaseColor,
          shimmerHighlightColor:
              AppThemePreferences().appTheme.shimmerEffectHighLightColor,
          width: 200,
          height: 200,
          errorWidget: shimmerEffectErrorWidget(),
        ),
      );
    } else {
      return ClipRRect(
        borderRadius: BorderRadius.circular(100.0),
        child: SizedBox(
          width: 200,
          height: 200,
          child: Stack(
            children: [
              Image.file(
                imageFile,
                fit: BoxFit.cover,
                width: 200,
                height: 200,
              ),
              _showWaitingWidgetForPicUpload
                  ? loadingIndicatorWidget(context)
                  : Container()
            ],
          ),
        ),
      );
    }
  }

  Widget headerTextWidget(String text) {
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom:
              BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget updateProfileImageButtonWidget(BuildContext context) {
    return _showUploadPhotoButton == false
        ? Container()
        : buttonWidget(
            text: GenericMethods.getLocalizedString("upload_photo"),
            onPressed: () {
              setState(() {
                _showWaitingWidgetForPicUpload = true;
              });
              uploadPhoto(context);
            },
          );
  }

  Future<void> uploadPhoto(BuildContext context) async {
    Map<String, dynamic> userInfo = {
      "imagepath": imageFile.path,
    };

    final response = await _propertyBloc.fetchUpdateUserProfileImageResponse(userInfo);

    if(response == null || response.statusCode == null){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          _showUploadPhotoButton = false;
          _showWaitingWidgetForPicUpload = false;
        });
      }
    }else{
      if(mounted){
        setState(() {
          isInternetConnected = true;
          _showUploadPhotoButton = false;
        });
      }
      String tempResponseString = response.toString().split("{")[1];
      Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
      if (response.statusCode == 200) {
        if (map["success"] == true) {
          final url = map["url"];
          HiveStorageManager.setUserAvatar(url);
          //profile = url;
          _showUploadPhotoButton = false;
          GeneralNotifier().publishChange(GeneralNotifier.USER_PROFILE_UPDATE);

          setState(() {
            _showWaitingWidgetForPicUpload = false;
          });
        }

        _showToast(
            context, GenericMethods.getLocalizedString("profile_updated_successfully"));
      } else {
        setState(() {
          _showWaitingWidgetForPicUpload = false;
        });
        _showToast(context, map["message"] ?? GenericMethods.getLocalizedString("error_occurred"));
      }

    }
  }

  Widget deleteAccountButtonWidget(BuildContext context) {
    return buttonWidget(
      buttonStyle:
          ElevatedButton.styleFrom(elevation: 0.0, primary: const Color(0xFFFF0000)),
          // ElevatedButton.styleFrom(elevation: 0.0, primary: AppThemePreferences.errorColor),
      text: GenericMethods.getLocalizedString("delete_my_account"),
      onPressed: () async {
        dialogBoxWidget(
          context,
          title: GenericMethods.getLocalizedString("delete_account"),
          content: genericTextWidget(GenericMethods.getLocalizedString("delete_account_confirmation")),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
            ),
            TextButton(
              onPressed: onPositiveButtonPressed,
              child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
            ),
          ],
        );


      },
    );
  }

  Future logOutConfirmation({
    @required BuildContext context,
    @required Function() onPositiveButtonPressed,
  }) {
    return dialogBoxWidget(
      context,
      title: GenericMethods.getLocalizedString("log_out"),
      content: genericTextWidget(GenericMethods.getLocalizedString("are_you_sure_you_want_to_log_out")),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
        ),
        TextButton(
          onPressed: onPositiveButtonPressed,
          child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
        ),
      ],
    );
  }

  Widget waitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context,
                  (){},
              showRetryButton: false,
            ),
          ],
        ),
      ),
    );
  }

  _showToast(BuildContext context, String text) {
    toastWidget(
      buildContext: context,
      text: text,
    );
  }

  Widget loadingIndicatorWidget(BuildContext context) {
    return Container(
      height: (MediaQuery.of(context).size.height) / 2,
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: loadingBallBeatWidget(),
      ),
    );
  }

  Future<void> onPositiveButtonPressed() async {
    Navigator.of(context).pop();
    setState(() {
      _showWaitingWidget = true;
    });
    final response = await _propertyBloc.fetchDeleteUserAccountResponse();

    if(response == null || response.statusCode == null){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          _showWaitingWidget = false;
        });
      }
    }else{
      if(mounted){
        setState(() {
          isInternetConnected = true;
          _showWaitingWidget = false;
        });
      }
      String tempResponseString = response.toString().split("{")[1];
      Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
      if(map["success"] == true){
        HiveStorageManager.deleteUserLoginInfoData();
        GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => const MyHomePage());
      }else{
        _showToast(context, map["msg"]);
      }
    }
  }
}
