import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/light_button_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../files/generic_methods/general_notifier.dart';
import '../filter_page.dart';

class SavedSearches extends StatefulWidget {
  final bool showAppBar;

  SavedSearches({this.showAppBar = false});

  @override
  _SavedSearchesState createState() => _SavedSearchesState();
}

class _SavedSearchesState extends State<SavedSearches>  with AutomaticKeepAliveClientMixin<SavedSearches>{

  final RefreshController _refreshController = RefreshController(initialRefresh: false);
  final PropertyBloc _propertyBloc = PropertyBloc();

  List<dynamic> savedSearchesList = [];
  Future<List<dynamic>> _futureSavedSearches;

  List<dynamic> citiesMetaDataList = [];
  List<dynamic> propertyTypesMetaData = [];
  List<dynamic> propertyStatusMetaData = [];
  Map<String, dynamic> propertyTypesMap = {};

  bool isInternetConnected = true;
  bool isRefreshing = false;
  bool shouldLoadMore = true;
  bool isLoading = false;

  int page = 1;
  int perPage = 10;

  String _query = "";
  String _id = "";

  VoidCallback  generalNotifierLister;
  String _idToDelete = null;
  
  @override
  void initState() {
    super.initState();

    citiesMetaDataList = HiveStorageManager.readCitiesMetaData();
    propertyTypesMap = HiveStorageManager.readPropertyTypesMapData();
    propertyTypesMetaData = HiveStorageManager.readPropertyTypesMetaData();
    propertyStatusMetaData = HiveStorageManager.readPropertyStatusMetaData();
    loadDataFromApi();

    if(mounted){
      setState(() {});
    }

    generalNotifierLister = () {
      if (GeneralNotifier().change == GeneralNotifier.NEW_SAVED_SEARCH_ADDED) {
        loadDataFromApi();
      }
    };

    GeneralNotifier().addListener(generalNotifierLister);

  }

  retryLoadData() {
    citiesMetaDataList = HiveStorageManager.readCitiesMetaData();
    propertyTypesMap = HiveStorageManager.readPropertyTypesMapData();
    propertyTypesMetaData = HiveStorageManager.readPropertyTypesMetaData();
    propertyStatusMetaData = HiveStorageManager.readPropertyStatusMetaData();
    isLoading = false;
    loadDataFromApi();
    if(mounted){
      setState(() {});
    }
  }

  loadDataFromApi({bool forPullToRefresh = true}) {
    if (isLoading) {
      return;
    }
    if(mounted){
      setState(() {
        isRefreshing = true;
        isLoading = true;
      });
    }

    page = 1;
    _futureSavedSearches = fetchSavedSearches(page);
    _refreshController.refreshCompleted();
  }

  Future<List<dynamic>> fetchSavedSearches(int page) async {
    List<dynamic> tempList = await _propertyBloc.fetchSavedSearches(page, perPage);
    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
          shouldLoadMore = false;
        });
      }
      return savedSearchesList;
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
          shouldLoadMore = false;
        });
      }
      if (page == 1) {
        savedSearchesList.clear();
      }
      if (tempList.isNotEmpty) {
        savedSearchesList.addAll(tempList);
      }
    }

    return savedSearchesList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.showAppBar ? appBarWidget(
        context,
        appBarTitle: GenericMethods.getLocalizedString("saved_searches"),
      ) : null,
      body: Stack(
        children: [
          showSavedSearchList(context,_futureSavedSearches),
          bottomActionBarWidget(),
        ],
      ),
      // body: isInternetConnected == false
      //     ? Align(
      //   alignment: Alignment.topCenter,
      //   child: noInternetConnectionErrorWidget(context, () {
      //     retryLoadData();
      //   }),
      // )
      //     : showSavedSearchList(context,_futureSavedSearches),
    );
  }

  // @override
  // Widget build(BuildContext context) {
  //   return WillPopScope(
  //     onWillPop: onWillPop,
  //     child: Scaffold(
  //       appBar: !widget.showAppBar ? null :  appBarWidget(
  //         context,
  //         appBarTitle: GenericMethods.getLocalizedString("error_occurred")saved_searches,
  //         onBackPressed: onBackPressed,
  //         automaticallyImplyLeading: widget.showAppBarBackOption,
  //       ),
  //       body: isInternetConnected == false ? Align(
  //               alignment: Alignment.topCenter,
  //               child: noInternetConnectionErrorWidget(context, () {
  //                 retryLoadData();
  //               }),
  //             )
  //           : showSavedSearchList(context, _futureSavedSearches),
  //     ),
  //   );
  // }

  // Map getQueryMap(String query){
  //   Map<String,dynamic> queryMap ={};
  //
  //   if (query.contains("Status:")) {
  //     String tempQueryString = query.split("Status:")[1];
  //     String status = tempQueryString.split("/")[0].trim();
  //
  //     if (status.contains(", ")) {
  //       List<String> tempStatusList = status.split(', ');
  //       List<String> statusSlugs = [];
  //       List<String> statusTerms = [];
  //       for (String statusTerm in tempStatusList) {
  //         String statusSlug = getStatusSlug(statusTerm);
  //         if (statusSlug != null && statusSlug.isNotEmpty) {
  //           statusSlugs.add(statusSlug);
  //         }
  //         statusTerms.add(GenericMethods.getLocalizedString(statusTerm));
  //       }
  //       queryMap[PROPERTY_STATUS_SLUG] = statusSlugs;
  //       queryMap[PROPERTY_STATUS] = statusTerms;
  //     } else {
  //       queryMap[PROPERTY_STATUS] = [GenericMethods.getLocalizedString(status)];
  //       String statusSlug = getStatusSlug(status);
  //       if (statusSlug != null && statusSlug.isNotEmpty) {
  //         queryMap[PROPERTY_STATUS_SLUG] = [statusSlug];
  //       }
  //     }
  //
  //   }
  //   if (query.contains("City:")) {
  //     String tempQueryString = query.split("City:")[1];
  //     String city = tempQueryString.split("/")[0].trim();
  //
  //     queryMap[CITY] = city;
  //     queryMap[CITY_SLUG] = getCitySlug(city);
  //     queryMap[CITY_ID]= getCityId(city);
  //   }
  //   if (query.contains("Type:")) {
  //     List<dynamic> _selectedTitleList = [];
  //     List<dynamic> _selectedTitleSlugList = [];
  //     List<dynamic> _selectedOptionList = [];
  //     List<dynamic> _selectedOptionSlugList = [];
  //     String splitiedQuery = query.split("Type:")[1];
  //     String tempTypesString = splitiedQuery.split("/")[0].trim();
  //
  //     List<String> tempTypesList = tempTypesString.split(', ');
  //
  //     List<String> queryTypeList = [];
  //     for(int i = 0; i < tempTypesList.length; i++){
  //       queryTypeList.add(GenericMethods.getLocalizedString(tempTypesList[i]));
  //     }
  //
  //     for(int i = 0; i < tempTypesList.length; i++){
  //       int itemIndex = propertyTypesMetaData.indexWhere((element) => element.name == tempTypesList[i]);
  //       if(itemIndex != null && itemIndex != -1){
  //
  //         //it might be a parent category.
  //         int parentId = propertyTypesMetaData[itemIndex].parent;
  //         if(parentId != null && parentId == 0){
  //           String title = propertyTypesMetaData[itemIndex].name;
  //           String slug = propertyTypesMetaData[itemIndex].slug;
  //           _selectedTitleList.add(title);
  //           _selectedTitleSlugList.add(slug);
  //         }
  //         //add type name and slug to the lists.
  //         String option = propertyTypesMetaData[itemIndex].name;
  //         if(option != null && option.isNotEmpty){
  //           _selectedOptionList.add(option);
  //         }
  //         String slug = propertyTypesMetaData[itemIndex].slug;
  //         if(slug != null && slug.isNotEmpty){
  //           _selectedOptionSlugList.add(slug);
  //         }
  //       }
  //     }
  //     //find parent category of selected types from meta data.
  //     if((_selectedTitleList == null || _selectedTitleList.isEmpty) &&
  //         (_selectedOptionSlugList != null && _selectedOptionSlugList.isNotEmpty)){
  //       for(int i = 0; i < _selectedOptionSlugList.length; i++){
  //         int itemIndex = propertyTypesMetaData.indexWhere((element) => element.slug == _selectedOptionSlugList[i]);
  //         if(itemIndex != null && itemIndex != -1){
  //           int parentId = propertyTypesMetaData[itemIndex].parent;
  //           itemIndex = propertyTypesMetaData.indexWhere((element) => element.id == parentId);
  //           if(itemIndex != null && itemIndex != -1){
  //             String title = propertyTypesMetaData[itemIndex].name;
  //             String slug = propertyTypesMetaData[itemIndex].slug;
  //             _selectedTitleList.add(title);
  //             _selectedTitleSlugList.add(slug);
  //           }
  //         }
  //       }
  //     }
  //
  //     if (queryTypeList != null && queryTypeList.isNotEmpty) {
  //       queryMap[QUERY_TYPE] = queryTypeList.join(", ");
  //     }
  //     //if we've found selected parent category, then append this to selected option
  //     //array, because our filter widget consider the first item to be a parent (tabs)
  //     //and all subsequent items as child (chips).
  //     if (_selectedTitleList.isNotEmpty && _selectedTitleSlugList.isNotEmpty) {
  //       _selectedOptionList.insert(0, _selectedTitleList.first);
  //       _selectedOptionSlugList.insert(0, _selectedTitleSlugList.first);
  //     }
  //     if (_selectedOptionSlugList.isNotEmpty) {
  //       queryMap[PROPERTY_TYPE_SLUG] = _selectedOptionSlugList;
  //     }
  //     if (_selectedOptionList.isNotEmpty) {
  //       queryMap[PROPERTY_TYPE] = _selectedOptionList;
  //     }
  //   }
  //   if (query.contains("Bedrooms:")) {
  //     String tempQueryString = query.split("Bedrooms:")[1];
  //
  //     String bedrooms = tempQueryString.split("/")[0].trim();
  //     List bedroomsList = [];
  //     if(bedrooms.contains(",")){
  //       bedroomsList = bedrooms.split(",");
  //     }else{
  //       bedroomsList.add(bedrooms);
  //     }
  //
  //     queryMap[BEDROOMS] = bedroomsList;
  //     // print("BedRooms: $bedrooms");
  //     // print("queryMap[BEDROOMS]: ${queryMap[BEDROOMS]}");
  //     // print("queryMap[BEDROOMS].length: ${queryMap[BEDROOMS].length}");
  //     // print("list: $bedroomsList");
  //     // print("list.length: ${bedroomsList.length}");
  //
  //     queryMap[QUERY_BEDROOMS] = bedrooms;
  //   }
  //   if (query.contains("Bathrooms:")) {
  //     String tempQueryString = query.split("Bathrooms:")[1];
  //
  //     String bathrooms = tempQueryString.split("/")[0].trim();
  //     List bathroomsList = [];
  //     if(bathrooms.contains(",")){
  //       bathroomsList = bathrooms.split(",");
  //     }else{
  //       bathroomsList.add(bathrooms);
  //     }
  //
  //     queryMap[BATHROOMS] = bathroomsList;
  //     queryMap[QUERY_BATHROOM] = bathrooms;
  //   }
  //   if (query.contains("Price:")) {
  //     String tempQueryString = query.split("Price:")[1];
  //
  //     String price = tempQueryString.split("/")[0].trim();
  //     queryMap[QUERY_PRICE] = price;
  //
  //     //check if we two ranges min max
  //     if(price.contains("-")){
  //       String firstPrice = price.split("-")[0].trim();
  //       String secondPrice = price.split("-")[1].trim();
  //       queryMap[PRICE_MAX] = secondPrice;
  //       queryMap[PRICE_MIN] = firstPrice;
  //     } else {
  //       //we've only one in the range, that's max.
  //       queryMap[PRICE_MAX] = price;
  //     }
  //   }
  //   if (query.contains("Size:")) {
  //     String tempQueryString = query.split("Size:")[1];
  //
  //     String area = tempQueryString.split("/")[0].trim();
  //     queryMap[QUERY_AREA] = area;
  //
  //     //check if we two ranges min max
  //     if(area.contains("-")){
  //
  //       String firstArea = area.split("-")[0].trim();
  //       String secondArea = area.split("-")[1].trim();
  //
  //       queryMap[AREA_MIN] = firstArea;
  //       queryMap[AREA_MAX] = secondArea;
  //     } else {
  //       //we've only one in the range, that's max.
  //       queryMap[AREA_MAX] = area;
  //     }
  //   }
  //   if (query.contains("Size:")) {
  //     String tempQueryString = query.split("Size:")[1];
  //
  //     String area = tempQueryString.split("/")[0].trim();
  //     queryMap[QUERY_AREA] = area;
  //
  //     if(area.contains("-")){
  //       String forFirstArea = query.split("Size:")[1];
  //       String firstArea = forFirstArea.split("-")[0].trim();
  //       String forSecondArea = query.split(" - ")[1];
  //       String secondArea = forSecondArea.replaceAll("/", "").trim();
  //
  //       queryMap[AREA_MIN] = firstArea;
  //       queryMap[AREA_MAX] = secondArea;
  //
  //     }
  //   }
  //   return queryMap;
  // }

  Map getUrlMap(String query){
    Map<String,dynamic> queryMap ={};

    if(query != null && query.isNotEmpty){
      String cleanContent = GenericMethods.cleanContent(query,decodeComponent: true);
      final split = cleanContent.split('&');

      for(var element in split){
        final splitted = element.split("=");
        String key = "";
        String value = "";
        if(splitted.isNotEmpty){
          key = splitted[0].trim();
          if(splitted.length > 1){
            value = splitted[1].trim();
          }
        }
        // key = element.split("=")[0].trim();
        // value = element.split("=")[1].trim();
        if(key == BATHROOMS || key == BEDROOMS){
          List tempList = [];
          if(value.contains(",")){
            tempList = value.split(",");
          }else{
            tempList.add(value);
          }
          queryMap[key] = tempList;
        }
        else if(key == "max_area"){
          queryMap[AREA_MAX] = value;
        }
        else if(key == "min_area"){
          queryMap[AREA_MIN] = value;
        }
        else if(key == "min_price"){
          queryMap[PRICE_MIN] = value;
        }
        else if(key == "max_price"){
          queryMap[PRICE_MAX] = value;
        }
        else if(key == "location[0]"){

          queryMap[CITY_SLUG] = value;
          queryMap[CITY] = getCityName(value);
          queryMap[CITY_ID]= getCityId(queryMap[CITY]);
          // queryMap[PRICE_MAX] = value;
        }
        // else if(key == "page"){
        //   //queryMap[key] = value;
        // }
        // else if(key == "per_page"){
        //   //queryMap[key] = value;
        // }
        // else {
        //   queryMap[key] = value;
        // }
        else if(key != null && key.isNotEmpty &&
            value != null && value.isNotEmpty &&
            key != "page" && key != "per_page"){
          queryMap[key] = value;
        }
      }

      var priceMin = queryMap[PRICE_MIN];
      var priceMax = queryMap[PRICE_MAX];
      if(priceMin!=null && priceMin.isNotEmpty){
        queryMap[QUERY_PRICE] = "$priceMin - $priceMax";
      }

      var areaMin = queryMap[AREA_MIN];
      var areaMax = queryMap[AREA_MAX];
      if(areaMin!=null && areaMin.isNotEmpty){
        queryMap[QUERY_AREA] = "$areaMin - $areaMax";
      }


      List statusSlugList = [];
      queryMap.forEach((key, value) {
        if(key.contains("status")){
          statusSlugList.add(value);
        }
      });
      List<String> statusSlugs = [];
      List<String> statusTerms = [];
      if(statusSlugList.isNotEmpty){
        for (String statusTerm in statusSlugList) {
          String statusSlug = getStatusName(statusTerm);
          if (statusSlug != null && statusSlug.isNotEmpty) {
            statusSlugs.add(statusSlug);
          }
          statusTerms.add(GenericMethods.getLocalizedString(statusTerm));
        }
        queryMap[PROPERTY_STATUS_SLUG] = statusTerms;
        queryMap[PROPERTY_STATUS] = statusSlugs;
      }



      List typeSlugList = [];
      queryMap.forEach((key, value) {
        if(key.contains("type")){
          typeSlugList.add(value);
        }
      });
      if(typeSlugList.isNotEmpty){
        List<String> queryTypeList = [];
        for(int i = 0; i < typeSlugList.length; i++){
          queryTypeList.add(GenericMethods.getLocalizedString(typeSlugList[i]));
        }

        List<dynamic> _selectedTitleList = [];
        List<dynamic> _selectedTitleSlugList = [];
        List<dynamic> _selectedOptionList = [];
        List<dynamic> _selectedOptionSlugList = [];

        for(int i = 0; i < typeSlugList.length; i++){
          int itemIndex = propertyTypesMetaData.indexWhere((element) => element.slug == typeSlugList[i]);
          if(itemIndex != null && itemIndex != -1){

            //it might be a parent category.
            int parentId = propertyTypesMetaData[itemIndex].parent;
            if(parentId != null && parentId == 0){
              String title = propertyTypesMetaData[itemIndex].name;
              String slug = propertyTypesMetaData[itemIndex].slug;
              _selectedTitleList.add(title);
              _selectedTitleSlugList.add(slug);
            }
            //add type name and slug to the lists.
            String option = propertyTypesMetaData[itemIndex].name;
            if(option != null && option.isNotEmpty){
              _selectedOptionList.add(option);
            }
            String slug = propertyTypesMetaData[itemIndex].slug;
            if(slug != null && slug.isNotEmpty){
              _selectedOptionSlugList.add(slug);
            }
          }
        }
        //find parent category of selected types from meta data.
        if((_selectedTitleList == null || _selectedTitleList.isEmpty) &&
            (_selectedOptionSlugList != null && _selectedOptionSlugList.isNotEmpty)){
          for(int i = 0; i < _selectedOptionSlugList.length; i++){
            int itemIndex = propertyTypesMetaData.indexWhere((element) => element.slug == _selectedOptionSlugList[i]);
            if(itemIndex != null && itemIndex != -1){
              int parentId = propertyTypesMetaData[itemIndex].parent;
              itemIndex = propertyTypesMetaData.indexWhere((element) => element.id == parentId);
              if(itemIndex != null && itemIndex != -1){
                String title = propertyTypesMetaData[itemIndex].name;
                String slug = propertyTypesMetaData[itemIndex].slug;
                _selectedTitleList.add(title);
                _selectedTitleSlugList.add(slug);
              }
            }
          }
        }

        if (queryTypeList != null && queryTypeList.isNotEmpty) {
          queryMap[QUERY_TYPE] = queryTypeList.join(", ");
        }
        //if we've found selected parent category, then append this to selected option
        //array, because our filter widget consider the first item to be a parent (tabs)
        //and all subsequent items as child (chips).
        if (_selectedTitleList.isNotEmpty && _selectedTitleSlugList.isNotEmpty) {
          _selectedOptionList.insert(0, _selectedTitleList.first);
          _selectedOptionSlugList.insert(0, _selectedTitleSlugList.first);
        }
        if (_selectedOptionSlugList.isNotEmpty) {
          queryMap[PROPERTY_TYPE_SLUG] = _selectedOptionSlugList;
        }
        if (_selectedOptionList.isNotEmpty) {
          queryMap[PROPERTY_TYPE] = _selectedOptionList;
        }
      }
    }


    if(queryMap.isEmpty){
      queryMap[TEMP_TITLE] = GenericMethods.getLocalizedString("latest_properties");
    }

    // print(queryMap);
    return queryMap;
  }

  String getStatusName(String status) {
    int itemIndex = propertyStatusMetaData.indexWhere((element) => element.slug == status);
    if (itemIndex != null && itemIndex != -1) {
      String name = propertyStatusMetaData[itemIndex].name;
      if (name != null && name.isNotEmpty) {
        return name;
      }
    }
    return "";
  }

  Widget showSavedSearchList(BuildContext context, Future<List<dynamic>> futureInquiriesFromBoard) {
    return FutureBuilder<List<dynamic>>(
      future: futureInquiriesFromBoard,
      builder: (context, articleSnapshot) {
        isLoading = false;
        if (articleSnapshot.hasData) {
          if (articleSnapshot.data.isEmpty) {
            return noResultFoundPage();
          }

          List<dynamic> list = articleSnapshot.data;

          return SmartRefresher(
            enablePullDown: true,
            //enablePullUp: true,
            // footer: CustomFooter(
            //   builder: (BuildContext context, LoadStatus mode) {
            //     Widget body;
            //     if (mode == LoadStatus.loading) {
            //       if (shouldLoadMore) {
            //         body = paginationLoadingWidget();
            //       } else {
            //         body = Container();
            //       }
            //     }
            //     return Container(
            //       height: 55.0,
            //       child: Center(child: body),
            //     );
            //   },
            // ),
            header: const MaterialClassicHeader(),
            controller: _refreshController,
            onRefresh: loadDataFromApi,
            //onLoading: () => loadDataFromApi(forPullToRefresh: false),
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, index) {
                var item = list[index];
                _query = item.query;
                _id = item.id;
                String url = item.url;
                Map<String,dynamic> queryMap = getUrlMap(url);
                // Map<String,dynamic> queryMap = {};
                // if(url != null || url.isNotEmpty){
                //   queryMap = getUrlMap(url);
                // }
                // Map<String,dynamic> queryMap = getQueryMap(_query);
                return queryMap != null && queryMap.isNotEmpty ? Padding(
                  padding: const EdgeInsets.all(1),
                  child: Card(
                    shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
                    elevation: AppThemePreferences.savedSearchElevation,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          showDataWidget(queryMap[CITY] ?? "",AppThemePreferences.locationIcon),
                          showDataWidget(queryMap[PROPERTY_STATUS] != null ? queryMap[PROPERTY_STATUS].join(", ") : "",AppThemePreferences.checkCircleIcon),
                          showDataWidget(queryMap[PROPERTY_TYPE] != null ? queryMap[PROPERTY_TYPE].join(", ") : "",AppThemePreferences.locationCityIcon),
                          if(queryMap.containsKey(TEMP_TITLE))showDataWidget(queryMap[TEMP_TITLE] != null ? queryMap[TEMP_TITLE] : "", AppThemePreferences.locationCityIcon),
                          showDataWidget(queryMap[QUERY_PRICE],AppThemePreferences.priceTagIcon),
                          showDataWidget(queryMap[QUERY_AREA],AppThemePreferences.areaSizeIcon),
                          showBedAndBathData(queryMap[BEDROOMS]!= null ?queryMap[BEDROOMS].join(", ") : "",AppThemePreferences.bedIcon,queryMap[BATHROOMS]!= null ?queryMap[BATHROOMS].join(", ") : "",AppThemePreferences.bathtubIcon),
                          Padding(
                            padding: const EdgeInsets.only(left:10,right:10,top: 5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(flex: 3,child: deleteDataWidget(_id,index)),
                                Expanded(flex: 1,child: Container()),
                                Expanded(flex: 3,child: editDataWidget(queryMap)),
                                Expanded(flex: 1,child: Container()),
                                Expanded(flex: 9,child: viewDataWidget(initializationMap: queryMap)),
                                // Expanded(flex: 9,child: viewDataWidget(id: item.id, initializationMap: queryMap)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ):Container();              },
            ),
          );
        } else if (articleSnapshot.hasError) {
          return noResultFoundPage();
        }
        return loadingIndicatorWidget();
      },
    );
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context, ()=> retryLoadData(),
            ),
          ],
        ),
      ),
    );
  }


  Widget showDataWidget(String value, IconData icon) {
    return value != null && value.isNotEmpty
        ? Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Icon(icon),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: genericTextWidget(
                value,
                overflow: TextOverflow.ellipsis,
                style: AppThemePreferences().appTheme.body01TextStyle
            ),
          ),
        ),
      ],
    )
        : Container();
  }

  Widget showBedAndBathData(String bed,IconData bedIcon,String bath,IconData bathIcon){
    return
      Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          if(bed != null && bed.isNotEmpty)
            Icon(bedIcon),
          if(bed != null && bed.isNotEmpty)
            Expanded(child: Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 8.0),
              child: genericTextWidget(bed,overflow: TextOverflow.ellipsis,style: AppThemePreferences().appTheme.body01TextStyle,),
            )),
          if(bath != null && bath.isNotEmpty)
            Icon(bathIcon),
          if(bath != null && bath.isNotEmpty)
            Expanded(child: Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 8.0),
              child: genericTextWidget(bath,overflow: TextOverflow.ellipsis,style: AppThemePreferences().appTheme.body01TextStyle,),
            )),

        ],
      );
  }

  Widget deleteDataWidget(String dataId,int index){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 5),
      alignment: Alignment.center,
      child: lightButtonWidget(
        text: "",
        icon: Icon(
          AppThemePreferences.deleteIcon,
          color: AppThemePreferences().appTheme.selectedItemTextColor,
        ),
        onPressed: () {
          showDialog<String>(
            context: context,
            barrierDismissible: false,
            builder: (BuildContext context) => AlertDialog(
              title: genericTextWidget(GenericMethods.getLocalizedString("delete")),
              content: genericTextWidget(GenericMethods.getLocalizedString("delete_confirmation")),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
                ),
                TextButton(
                  onPressed: () async {
                    if (_idToDelete != null && _idToDelete == dataId) {
                      return;
                    }
                    _idToDelete = dataId;
                    Map<String, dynamic> deleteSavedSearchInfo = {
                      "id": dataId,
                    };
                    final response = await _propertyBloc.fetchDeleteSavedSearch(deleteSavedSearchInfo);

                    String tempResponseString = response.toString().split("{")[1];
                    Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
                    _idToDelete = null;
                    if (map['success'] == true) {

                      setState(() {
                        savedSearchesList.removeAt(index);
                      });
                      Navigator.pop(context);
                      if (savedSearchesList.isEmpty) {
                        savedSearchesList.clear();
                      }
                      _showToast(context, map['msg']);
                    } else if(map['success'] == false) {
                      Navigator.pop(context);
                      if(map['msg'] != "you don&#039;t have the right to delete this"){
                        _showToast(context, GenericMethods.cleanContent(map['msg']));
                      }
                    }
                    else{
                      _showToast(context, GenericMethods.getLocalizedString("error_occurred"));
                    }
                  },
                  child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget editDataWidget(Map<String, dynamic> queryMap){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 5),
      alignment: Alignment.center,
      child: lightButtonWidget(
        text: "",
        icon: Icon(
          AppThemePreferences.editIcon,
          color: AppThemePreferences().appTheme.selectedItemTextColor,
        ),
        onPressed: () {
          GenericMethods.navigateToRoute(
            context: context,
            builder: (context) => FilterPage(
              mapInitializeData: queryMap,
              filterPageListener: (Map<String, dynamic> dataMap, String closeOption) {
                if(closeOption == DONE){
                  navigateToSearchResultScreen(dataInitializationMap: queryMap);
                }
                if(closeOption == CLOSE){
                  Navigator.of(context).pop();
                }
              },
            ),
          );
        },
      ),
    );
  }

  void navigateToSearchResultScreen({
    Map<String, dynamic> dataInitializationMap,
    Map<String, dynamic> searchRelatedData
  }){
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchResult(
          dataInitializationMap: dataInitializationMap,
          //searchRelatedData: searchRelatedData,
          searchPageListener: (Map<String, dynamic> map, String closeOption){
            if(closeOption == CLOSE){
              Navigator.of(context).pop();
            }
          },
        ),
      ),
    );
  }

  Widget viewDataWidget({@required Map<String, dynamic> initializationMap}){
  // Widget viewDataWidget({dynamic id, Map<String, dynamic> initializationMap}){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 5),
      alignment: Alignment.center,
      child: lightButtonWidget(
        text: GenericMethods.getLocalizedString("view_result"),
        onPressed: () {
          HiveStorageManager.storeFilterDataInfo(map: initializationMap);
          navigateToSearchResultScreen(dataInitializationMap: initializationMap);
          // Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => SearchResult(
          //       isSavedSearch: true,
          //       savedSearchId: id,
          //       // dataInitializationMap: initializationMap,
          //       searchPageListener: (Map<String, dynamic> map, String closeOption) {
          //         if (closeOption == CLOSE) {
          //           Navigator.of(context).pop();
          //         }
          //       },
          //     ),
          //   ),
          // );
        },
      ),
    );
  }

  Widget loadingIndicatorWidget() {
    return Container(
      height: (MediaQuery.of(context).size.height) / 2,
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
          width: 80,
          height: 20,
          child: loadingBallBeatWidget()
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
        context,
        headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
        bodyErrorText: GenericMethods.getLocalizedString("no_saved_searches_found"),
        hideGoBackButton: !widget.showAppBar
    );
  }

  _showToast(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }

  String getCitySlug(String city){
    if(citiesMetaDataList.isNotEmpty){
      String title = city;
      int index = citiesMetaDataList.indexWhere((element) => element.name == title);
      if(index != null && index != -1){
        String slug = citiesMetaDataList[index].slug;
        if(slug != null && slug.isNotEmpty){
          return slug;
        }
      }
    }

    return "";
  }

  String getCityName(String city){
    if(citiesMetaDataList.isNotEmpty){
      String title = city;
      int index = citiesMetaDataList.indexWhere((element) => element.slug == title);
      if(index != null && index != -1){
        String slug = citiesMetaDataList[index].name;
        if(slug != null && slug.isNotEmpty){
          return slug;
        }
      }
    }

    return "";
  }

  int getCityId(String city){
    String title = city;
    int index = citiesMetaDataList.indexWhere((element) => element.name == title);
    if(index != null && index != -1){
      int id = citiesMetaDataList[index].id;
      if(id != null){
        return id;
      }
    }
    return -1;
  }

  String getStatusSlug(String status) {
    int itemIndex = propertyStatusMetaData.indexWhere((element) => element.name == status);
    if (itemIndex != null && itemIndex != -1) {
      String slug = propertyStatusMetaData[itemIndex].slug;
      if (slug != null && slug.isNotEmpty) {
        return slug;
      }
    }
    return "";
  }

  Widget paginationLoadingWidget() {
    return Container(
      color: Theme.of(context).backgroundColor,
      alignment: Alignment.center,
      child: Column(
        children: [
          SizedBox(
            width: 60,
            height: 50,
            child: loadingBallRotatingWidget(),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
