import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/user_log_provider.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/properties.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/request_demo.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/settings_page.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/manage_profile.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_signin.dart';
import 'package:houzi_package/pages/main_screen_pages/my_home_page.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/dialog_box_widget.dart';
import 'package:houzi_package/widgets/generic_settings_row_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/shimmer_effect_error_widget.dart';
import 'package:provider/provider.dart';

import '../add_property.dart';
import 'admin_user_signup.dart';

typedef ProfileHook = List<Widget> Function(BuildContext context);

typedef UserProfilePageListener = void Function(String closeOption);

class UserProfile extends StatefulWidget {
  final UserProfilePageListener userProfilePageListener;
  final bool fromBottomNavigator;

  UserProfile({this.userProfilePageListener,this.fromBottomNavigator = false});

  @override
  _UserProfileState createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  String userRole = "";
  String userEmail = "";
  String userName = "";
  String userAvatar;
  String appVersion = '';
  String appName = '';
  bool isLoggedIn = false;
  VoidCallback  generalNotifierLister;

  ProfileHook profileHook = GenericMethods.profileItemHook;

  @override
  void initState() {
    super.initState();

    // if(HiveStorageManager.isUserLoggedIn()){
    //   setState(() {
    //     isLoggedIn = true;
    //   });
    // }

    // UserLoggedProvider provider = Provider.of<UserLoggedProvider>(context,listen: false);
    // isLoggedIn = provider.isLoggedIn;

    userRole = HiveStorageManager.getUserRole() ?? "";
    userEmail = HiveStorageManager.getUserEmail() ?? "";
    userName = HiveStorageManager.getUserName() ?? "";
    userAvatar = HiveStorageManager.getUserAvatar() ?? "";
    appVersion = HiveStorageManager.readAppInfo()[APP_INFO_APP_VERSION] ?? "";
    appName = HiveStorageManager.readAppInfo()[APP_INFO_APP_NAME] ?? "";

    generalNotifierLister = () {
      if (GeneralNotifier().change == GeneralNotifier.USER_PROFILE_UPDATE) {
        setState(() {
          userRole = GenericMethods.chkRoleValueAndConvertToOption(HiveStorageManager.getUserRole());
          userEmail = HiveStorageManager.getUserEmail();
          userName = HiveStorageManager.getUserName();
          userAvatar = HiveStorageManager.getUserAvatar();
        });
      }
      // if (GeneralNotifier().change == GeneralNotifier.CHANGE_LOCALIZATION) {
      //   setState(() {});
      // }
    };

    GeneralNotifier().addListener(generalNotifierLister);
  }


  @override
  void dispose() {
    super.dispose();
    if (generalNotifierLister != null) {
      GeneralNotifier().removeListener(generalNotifierLister);
    }
  }

  void onBackPressed() {
    widget.userProfilePageListener(CLOSE);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        widget.userProfilePageListener(CLOSE);
        return Future.value(false);
      },
      child: Consumer<UserLoggedProvider>(
        builder: (context, login, child) {
          isLoggedIn = login.isLoggedIn;
          return Scaffold(
            backgroundColor: Theme.of(context).backgroundColor,
            appBar: appBarWidget(
              context,
              onBackPressed: onBackPressed,
              automaticallyImplyLeading: widget.fromBottomNavigator ? false : true,
              appBarTitle: GenericMethods.getLocalizedString("user_profile"),
            ),
            body: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  userAvatarWidget(),
                  userNameWidget(),
                  userRelatedActionsWidget(),
                ],
              ),
            ),
          );
        }
      ),
    );
  }

  Widget userAvatarWidget(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(100.0),
        child: FancyShimmerImage(
          imageUrl: isLoggedIn ? userAvatar : "",
          boxFit: BoxFit.cover,
          shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
          shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
          width: 150,
          height: 150,
          errorWidget: shimmerEffectErrorWidget(iconData: AppThemePreferences.personIcon,),
        ),
      ),
    );
  }

  Widget userNameWidget() {
    return !isLoggedIn ?
    Container(
      padding: const EdgeInsets.all(15),
      child: buttonWidget(
          text: GenericMethods.getLocalizedString("log_in_to_your_account"),
          onPressed: () => onLogInTap(context),),
    ) : Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: genericTextWidget(
          userName,
          style: AppThemePreferences().appTheme.heading01TextStyle,
        ),
      );
  }

  Widget userRelatedActionsWidget(){
    return Container(
      padding: const EdgeInsets.only(top: 20.0),
      child: Column(
        children: [
          Card(
            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                children: [
                  isLoggedIn ? genericWidgetRow(
                  iconData: AppThemePreferences.manageProfile,
                  text: GenericMethods.getLocalizedString("manage_profile"),
                  onTap: onEditProfileTap,)
                  : Container(),
                  if(userRole != null && userRole != USER_ROLE_HOUZEZ_BUYER_VALUE)
                    genericWidgetRow(
                      iconData: AppThemePreferences.propertiesIcon,
                      text: GenericMethods.getLocalizedString("properties"),
                      onTap: onPropertiesTap,
                    ),
                  if(userRole != null && userRole != USER_ROLE_HOUZEZ_BUYER_VALUE && SHOW_ADD_PROPERTY_IN_PROFILE)
                    genericWidgetRow(
                      padding: const EdgeInsets.only(top: 20.0, bottom: 15.0),
                      iconData: AppThemePreferences.addPropertyIcon,
                      text: GenericMethods.getLocalizedString("add_property"),
                      removeDecoration: userRole == ROLE_ADMINISTRATOR ? false : true,
                      onTap: onAddPropertyTap,
                    ),
                  userRole == ROLE_ADMINISTRATOR ? genericWidgetRow(
                    padding: const EdgeInsets.only(top: 20.0, bottom: 15.0),
                    iconData: AppThemePreferences.addNewAgentIcon,
                    text: GenericMethods.getLocalizedString("add_user"),
                    removeDecoration: true,
                    onTap: onAdminUserSignUpTap,)
                      : Container(),
                ],
              ),
            ),
          ),
          Container(height: 20.0),
          if(profileHook(context) != null) Card(
            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                children: profileHook(context),
              ),
            ),
          ),
          Container(height: 20.0),
          Card(
            shape: AppThemePreferences.roundedCorners(AppThemePreferences.globalRoundedCornersRadius),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                children: [
                  genericWidgetRow(
                    iconData: AppThemePreferences.settingsIcon,
                    text: GenericMethods.getLocalizedString("settings"),
                    onTap: onSettingsTap,
                  ),
                  SHOW_DEMO_CONFIGURATIONS ? genericWidgetRow(
                    iconData: AppThemePreferences.requestDemoIcon,
                    text: GenericMethods.getLocalizedString("request_demo"),
                    onTap: onRequestDemoTap,
                  ) : Container(),
                  isLoggedIn ? genericWidgetRow(
                    padding: const EdgeInsets.only(top: 20.0, bottom: 15.0),
                    iconData: AppThemePreferences.logOutIcon,
                    text: GenericMethods.getLocalizedString("log_out"),
                    removeDecoration: true,
                    onTap: () {
                      onLogOutTap(context);
                    },
                  )
                  : genericWidgetRow(
                      padding: const EdgeInsets.only(top: 20.0, bottom: 15.0),
                      iconData: AppThemePreferences.loginIcon,
                      text: GenericMethods.getLocalizedString("login"),
                      removeDecoration: true,
                      onTap: () {
                        onLogInTap(context);
                      },
                    ),
                ],
              ),
            ),
          ),
          Container(height: 20.0),
          appInfoWidget(),
        ],
      ),
    );
  }

  Widget appInfoWidget(){
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          appInfoTextWidget(appName),
          Padding(
            padding: const EdgeInsets.only(top: 5.0),
            child: appInfoTextWidget("${GenericMethods.getLocalizedString("version_text")} $appVersion"),
          ),
        ],
      ),
    );
  }

  Widget appInfoTextWidget(String text){
    return genericTextWidget(
      text,
      textAlign: TextAlign.center,
      style: AppThemePreferences().appTheme.appInfoTextStyle,
    );
  }

  navigateToRoute(WidgetBuilder builder){
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: builder,
      ),
    );
  }

  // void onEditProfileTap(){
  //   navigateToRoute((context) => EditProfile(userName, userAvatar));
  // }
  void onEditProfileTap(){
    navigateToRoute((context) => ManageProfile());
  }

  void onPropertiesTap(){
    isLoggedIn
        ? navigateToRoute((context) => Properties())
        : onLogInTap(context);
  }

  void onAddPropertyTap() {
    isLoggedIn
        ? navigateToRoute((context) => AddProperty())
        : onLogInTap(context);
  }

  void onAdminUserSignUpTap() {
    navigateToRoute((context) => AdminUserSignUp());
  }

  void onSettingsTap(){
    navigateToRoute((context) => HomePageSettings());
  }

  void onRequestDemoTap(){
    navigateToRoute((context) => ContactDeveloper());
  }

  onLogOutTap(BuildContext context){
    userLogOutConfirmation(context);
  }

  onLogInTap(BuildContext context) {
    navigateToRoute(
      (context) => UserSignIn(
        (String closeOption) {
          if (closeOption == CLOSE) {
            Navigator.pop(context);
          }
        },
      ),
    );
  }

  Future userLogOutConfirmation(BuildContext context) {
    return dialogBoxWidget(
      context,
      title: GenericMethods.getLocalizedString("log_out"),
      content:
      genericTextWidget(GenericMethods.getLocalizedString("are_you_sure_you_want_to_log_out")),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context);
            GenericMethods.userLogOut(
              context: context,
              builder: (context) => const MyHomePage(),
            );
          },
          child: genericTextWidget(GenericMethods.getLocalizedString("yes")),
        ),
      ],
    );
  }


  // Widget editProfileButtonWidget() {
  //   return buttonWidget(
  //     text: GenericMethods.getLocalizedString("edit_profile"),
  //     onPressed: () {
  //       navigateToRoute((context) => EditProfile(userName, userAvatar));
  //     },
  //   );
  // }


}
