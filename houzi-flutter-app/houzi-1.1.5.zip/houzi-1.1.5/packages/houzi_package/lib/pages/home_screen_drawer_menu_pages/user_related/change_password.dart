
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';

import '../../../Mixins/validation_mixins.dart';
import '../../../common/constants.dart';
import '../../../files/generic_methods/generic_methods.dart';
import '../../../files/hive_storage_files/hive_storage_manager.dart';
import '../../../widgets/header_widget.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key key}) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> with ValidationMixin {
  final formKey = GlobalKey<FormState>();
  final PropertyBloc _propertyBloc = PropertyBloc();

  TextEditingController registerPass = TextEditingController();
  TextEditingController registerPassRetype = TextEditingController();

  bool isInternetConnected = true;
  bool _showWaitingWidget = false;

  @override
  void initState() {
    super.initState();

  }



  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("change_password"),
        ),
        body: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: showUserInfo(context),
              ),
      ),
    );
  }

  Widget showUserInfo(BuildContext context) {
    return Stack(
      children: [
        SingleChildScrollView(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(5),
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  addPassword(context),
                  reTypePassword(context),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: updatePasswordButtonWidget(context),
                  ),
                ],
              ),
            ),
          ),
        ),
        waitingWidget(),
        bottomActionBarWidget(),
      ],
    );
  }

  Widget headerTextWidget(String text) {
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom:
              BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget addPassword(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("password"),
        hintText: GenericMethods.getLocalizedString("enter_your_password"),
        controller: registerPass,
        obscureText: true,
        keyboardType: TextInputType.visiblePassword,
        validator: (value) => validatePassword(context, value),
      ),
    );
  }

  Widget reTypePassword(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: textFieldWidget(
        labelText: GenericMethods.getLocalizedString("confirm_password"),
        hintText: GenericMethods.getLocalizedString("confirm_your_password"),
        obscureText: true,
        controller: registerPassRetype,
        keyboardType: TextInputType.visiblePassword,
        validator: (String value) {
          if (value.length < 8) {
            return GenericMethods.getLocalizedString("password_length_at_least_eight");
          }
          if (value.isEmpty) {
            return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
          }

          if (registerPass.text != registerPassRetype.text) {
            return GenericMethods.getLocalizedString("password_does_not_match");
          }
          return null;
        },
      ),
    );
  }

  Widget updatePasswordButtonWidget(BuildContext context) {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("update_password"),
      onPressed: () async {
        if (formKey.currentState.validate()) {
          formKey.currentState.save();
          if(mounted){
            setState(() {
              _showWaitingWidget = true;
            });
          }

          Map<String, dynamic> userInfo = {
            "newpass": registerPass.text,
            "confirmpass": registerPassRetype.text,
          };

          final response = await _propertyBloc.fetchUpdateUserPasswordResponse(userInfo);

          if(response.statusCode == null){
            if(mounted){
              setState(() {
                isInternetConnected = false;
                _showWaitingWidget = false;
              });
            }
          }else{
            if(mounted){
              setState(() {
                isInternetConnected = true;
                _showWaitingWidget = false;
              });
            }

            if(response == null){
              _showToast(context, GenericMethods.getLocalizedString("error_occurred"));
            }else{
              String tempString = response.toString();
              if(tempString.contains("{")){
                String tempResponseString = response.toString().split("{")[1];
                Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
                if(map["success"] == true){
                  _showToast(context, map["msg"]);

                  Map userInfoMapFromStorage = HiveStorageManager.readUserCredentials();
                  Map<String, dynamic> userInfo = {
                    USER_NAME: userInfoMapFromStorage["username"],
                    PASSWORD: registerPass.text,
                  };
                  HiveStorageManager.storeUserCredentials(userInfo);
                  Navigator.of(context).pop();
                }else{
                  _showToast(context, map["msg"]);
                }
              }else{
                _showToast(context, GenericMethods.getLocalizedString("error_occurred"));
              }

            }
          }
        }
      },
    );
  }

  Widget waitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context,
                  (){},
              showRetryButton: false,
            ),
          ],
        ),
      ),
    );
  }

  _showToast(BuildContext context, String text) {
    toastWidget(
      buildContext: context,
      text: text,
    );
  }
}
