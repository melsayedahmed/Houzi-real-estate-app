
import 'package:dio/dio.dart';
import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/show_dialog_for_search.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';
import 'package:houzi_package/widgets/shimmer_effect_error_widget.dart';

import '../../files/generic_methods/generic_methods.dart';
import '../realtor_information_page.dart';

class AllAgency extends StatefulWidget {
  @override
  _AllAgencyState createState() => _AllAgencyState();
}

class _AllAgencyState extends State<AllAgency> {

  final PropertyBloc _propertyBloc = PropertyBloc();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  Future<List<dynamic>> _futureAgenciesList;
  List<dynamic> agenciesList = [];

  bool isInternetConnected = true;
  bool isRefreshing = false;
  bool showSearchDialog = false;

  @override
  void initState() {
    super.initState();
    _futureAgenciesList = fetchAllAgenciesInfo(1, 16, false, false, null);
  }

  checkInternetAndLoadData(){
    _onRefresh();
  }



  Future<void> _onRefresh() async {

    if(mounted){
      setState(() {
        isRefreshing = true;
      });
    }
    _futureAgenciesList = fetchAllAgenciesInfo(1, 16, true, false, null);
  }


  Future<List<dynamic>> fetchAllAgenciesInfo(int page, int perPage,bool refreshing,bool forSearch,Map agentSearchMap) async {
    if(refreshing){
      agenciesList.clear();
    }
    List<dynamic> tempList = [];
    if(forSearch){
      if(mounted){
        setState(() {
          isRefreshing = true;
        });
      }
      tempList = await _propertyBloc.fetchSearchAgenciesList(page, perPage,agentSearchMap[SEARCH_KEYWORD]);
      if(mounted){
        setState(() {
          isRefreshing = false;
        });
      }
    }
    else  {
      tempList = await _propertyBloc.fetchAllAgenciesInfoList(page, perPage);
    }

    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
      return agenciesList;
    }else{
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      agenciesList.addAll(tempList);
    }

    return agenciesList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
        context,
        appBarTitle: GenericMethods.getLocalizedString("agency"),
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 5),
            child: IconButton(
              icon: Icon(
                AppThemePreferences.searchIcon,
                color: AppThemePreferences().appTheme.genericAppBarIconsColor,
              ),
              onPressed: () => searchDialog(true, null),
            ),
          )
        ],
      ),
      body: isInternetConnected == false
          ? Align(
              alignment: Alignment.topCenter,
              child: noInternetConnectionErrorWidget(context, () {
                checkInternetAndLoadData();
              }),
            )
          : RefreshIndicator(
              child: Stack(children: [
                SingleChildScrollView(
                  child:
                      _horizontalListForAgencies(context, _futureAgenciesList),
                ),
                showSearchDialog
                    ? ShowSearchDialog(
                        fromAgent: false,
                        searchDialogPageListener: (bool showDialog, Map<String, dynamic> agencySearchMap) {
                          searchDialog(showDialog, agencySearchMap);
                        })
                    : Container(),
              ]),
              onRefresh: _onRefresh,
            ),
    );
  }

  void searchDialog(bool showDialog, Map searchMap) {
    setState(() {
      showSearchDialog = showDialog;
    });
    if (searchMap != null) {
      _futureAgenciesList = fetchAllAgenciesInfo(1, 16,true,true,searchMap);
    }
  }

  String stripHtmlIfNeeded(String text) {
    return text.replaceAll(RegExp(r'<[^>]*>|&[^;]+;'), '');
  }

  Widget _horizontalListForAgencies(BuildContext context, Future<List<dynamic>> agentsAndAgenciesInfoList) {
    return FutureBuilder<List<dynamic>>(
        future: agentsAndAgenciesInfoList,
        builder: (context, articleSnapshot) {
          if (articleSnapshot.hasData) {
            List tempList = articleSnapshot.data;
            if (tempList.isEmpty  && isRefreshing != true) {
              return noResultFoundPage();
            } else if (tempList.isNotEmpty) {
              if(tempList[0] == null || tempList[0].isEmpty){
                return noResultFoundPage();
              }
            }
            if(tempList.isNotEmpty && tempList[0] != null && tempList[0].isNotEmpty){
              List<dynamic> _agentOrAgencyInfoList = tempList[0].map((e) => e).toList();
              return ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                scrollDirection: Axis.vertical,
                itemCount: _agentOrAgencyInfoList.length,
                itemBuilder: (context, index) {
                  var item = _agentOrAgencyInfoList[index];
                  String stringContent = stripHtmlIfNeeded(item.content);
                  String heroId = HERO + item.id.toString();

                  return Container(
                    padding: const EdgeInsets.only(bottom: 10, right: 5),
                    child: Card(
                      shape: AppThemePreferences.roundedCorners(AppThemePreferences.realtorPageRoundedCornersRadius),
                      elevation: AppThemePreferences.agentAgencyPageElevation,
                      child: InkWell(
                        borderRadius: const BorderRadius.all(Radius.circular(10)),
                        onTap: () {
                          navigateToRealtorInformationDisplayPage(
                            heroId: heroId,
                            realtorType: AGENCY_INFO,
                            realtorInfo: {
                              AGENCY_DATA : item,
                            },
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Column(
                            children: [
                              Row(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding:
                                    const EdgeInsets.symmetric(vertical: 10),
                                    child: Hero(
                                      tag: heroId,
                                      child: ClipRRect(
                                        borderRadius:
                                        BorderRadius.circular(10),
                                        child: FancyShimmerImage(
                                          imageUrl: item.thumbnail,
                                          boxFit: BoxFit.cover,
                                          shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
                                          shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
                                          width: 80,
                                          height: 90,
                                          errorWidget: shimmerEffectErrorWidget(iconSize: 50),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(left: 10, top: 15),
                                          child: genericTextWidget(
                                            item.title,
                                            textAlign: TextAlign.left,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: AppThemePreferences().appTheme.homeScreenRealtorTitleTextStyle,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.fromLTRB(10, 16, 10, 0),
                                          child: genericTextWidget(
                                            stringContent,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            style: AppThemePreferences().appTheme.subBodyTextStyle,
                                            textAlign: TextAlign.justify,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }
          }else if(articleSnapshot.hasError){
            return noResultFoundPage();
          }

          return loadingIndicatorWidget();
        }
    );
  }

  Widget loadingIndicatorWidget() {
    return Container(
      height: (MediaQuery.of(context).size.height) / 2,
      margin: const EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: loadingBallBeatWidget(),
      ),
    );
  }


  void navigateToRealtorInformationDisplayPage({String heroId, Map<String, dynamic> realtorInfo,String realtorType}){
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RealtorInformationDisplayPage(
          heroId: heroId,
          realtorInformation: realtorInfo,
          agentType: realtorType,
        ),
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
      bodyErrorText: GenericMethods.getLocalizedString("no_agencies_found"),
    );
  }




}
