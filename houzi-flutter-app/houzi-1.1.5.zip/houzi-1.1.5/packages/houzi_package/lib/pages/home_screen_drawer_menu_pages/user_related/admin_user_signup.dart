import 'dart:convert';

import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/Mixins/validation_mixins.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/pages/app_settings_pages/web_page.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/user_related/user_signin.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/data_loading_widget.dart';
import 'package:houzi_package/widgets/generic_link_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/drop_down_widget.dart';
import 'package:houzi_package/widgets/generic_text_field_widgets/text_field_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';

import '../../../files/generic_methods/generic_methods.dart';
import '../../../files/hive_storage_files/hive_storage_manager.dart';

class AdminUserSignUp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => AdminUserSignUpState();
}

class AdminUserSignUpState extends State<AdminUserSignUp> with ValidationMixin {
  final formKey = GlobalKey<FormState>();
  final PropertyBloc _propertyBloc = PropertyBloc();

  TextEditingController registerPass = TextEditingController();
  TextEditingController registerPassRetype = TextEditingController();

  bool _showWaitingWidget = false;

  String userName;
  String email;
  String phoneNumber;
  bool termsAndConditions = false;
  String termsAndConditionsValue = "off";

  bool isInternetConnected = true;

  var userRoleList = [];
  String _roleValue;

  @override
  void initState() {
    super.initState();
    userRoleList = HiveStorageManager.readAdminUserRoleListData() ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(FocusNode()),
      child: Scaffold(
        appBar: appBarWidget(
          context,
          appBarTitle: GenericMethods.getLocalizedString("add_user"),
        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Form(
            key: formKey,
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
                  child: Column(
                    children: [
                      addUserName(context),
                      addEmail(context),
                      addPhone(),
                      addPassword(context),
                      reTypePassword(context),
                      dropDownRole(userRoleList, GenericMethods.getLocalizedString("select_your_account_type"), GenericMethods.getLocalizedString("select")),
                      termsAndConditionAgreementWidget(),
                      buttonSignUpWidget(),
                      // alreadySignedUpTextWidget(),
                    ],
                  ),
                ),
                loginWaitingWidget(),
                bottomActionBarWidget(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget addUserName(BuildContext context) {
    return textFieldWidget(
      padding: const EdgeInsets.only(top: 15.0),
      labelText: GenericMethods.getLocalizedString("user_name"),
      hintText: GenericMethods.getLocalizedString("enter_your_user_name"),
      keyboardType: TextInputType.text,
      validator: (value) => validateUserField(context,value),
      onSaved: (text) {
        userName = text;
      },
    );
  }

  Widget addEmail(BuildContext context) {
    return textFieldWidget(
      padding: const EdgeInsets.only(top: 15.0),
      labelText: GenericMethods.getLocalizedString("email"),
      hintText: GenericMethods.getLocalizedString("enter_email_address"),
      keyboardType: TextInputType.emailAddress,
      validator: (value) => validateEmail(context, value),
      onSaved: (text) {
        email = text;
      },
    );
  }

  Widget addPhone() {
    return !SHOW_SIGNUP_ENTER_PHONE_FIELD ? Container() : textFieldWidget(
      padding: const EdgeInsets.only(top: 15.0),
      labelText: GenericMethods.getLocalizedString("phone"),
      hintText: GenericMethods.getLocalizedString("enter_your_phone_number"),
      keyboardType: TextInputType.phone,
      validator: (value) => validatePhoneNumber(context, value),
      onSaved: (text) {
        phoneNumber = text;
      },
    );
  }

  Widget addPassword(BuildContext context) {
    return textFieldWidget(
      padding: const EdgeInsets.only(top: 15.0),
      labelText: GenericMethods.getLocalizedString("password"),
      hintText: GenericMethods.getLocalizedString("enter_your_password"),
      controller: registerPass,
      obscureText: true,
      keyboardType: TextInputType.visiblePassword,
      validator: (value) => validatePassword(context,value),
    );
  }

  Widget reTypePassword(BuildContext context) {
    return textFieldWidget(
      padding: const EdgeInsets.only(top: 15.0),
      labelText: GenericMethods.getLocalizedString("confirm_password"),
      hintText: GenericMethods.getLocalizedString("confirm_your_password"),
      obscureText: true,
      controller: registerPassRetype,
      keyboardType: TextInputType.visiblePassword,
      validator: (String value) {
        if (value.length < 8) {
          return GenericMethods.getLocalizedString("password_length_at_least_eight");
        }
        if (value.isEmpty) {
          return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
        }

        if (registerPass.text != registerPassRetype.text) {
          return GenericMethods.getLocalizedString("password_does_not_match");
        }
        return null;
      },
    );
  }

  Widget dropDownRole(List list,String title ,String hintText){
    return genericDropDownWidget(
      padding: const EdgeInsets.fromLTRB(0,15,0,0),
      labelText: title,
      hintText: hintText,
      value: _roleValue,
      items: list.map<DropdownMenuItem<String>>((item) {
        return DropdownMenuItem<String>(
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0),
            child: Text(
              item,
            ),
          ),
          value: item
        );
      }).toList(),
      onChanged: (value) {
        _roleValue = value;
      },
      validator: (value) {
        if (value == null || value.isEmpty) {
          return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
        }
        return null;
      },
    );
  }
  // Widget dropDownRole() {
  //   return userRoleList.length == 1 ? Container() : Container(
  //     margin: const EdgeInsets.only(top: 25),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         labelWidget(GenericMethods.getLocalizedString("select_your_account_type")),
  //         Padding(
  //           padding: const EdgeInsets.only(top: 10),
  //           child: DropdownButtonFormField(
  //             decoration: AppThemePreferences.formFieldDecoration(
  //                 hintText: GenericMethods.getLocalizedString("select")),
  //             // items: roleOptions.map((description, value) {
  //             //       return MapEntry(description,
  //             //           DropdownMenuItem<String>(
  //             //             value: value,
  //             //             child: genericTextWidget(description),
  //             //           ));
  //             //     }).values.toList(),
  //             items: userRoleList.map((map) {
  //               return DropdownMenuItem(
  //                 child: Text(map['option']),
  //                 value: map['value'],
  //               );
  //             }).toList(),
  //             value: _roleValue,
  //             onChanged: (value) {
  //               _roleValue = value;
  //             },
  //             validator: (value) {
  //               if (value == null || value.isEmpty) {
  //                 return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
  //               }
  //               return null;
  //             },
  //             // onChanged: (String newValue) {
  //             //   if (newValue != null) {
  //             //     setState(() {
  //             //       _roleValue = newValue;
  //             //     });
  //             //   }
  //             // },
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }

  Widget termsAndConditionAgreementWidget() {
    return Container(
      margin: const EdgeInsets.only(top: 15),
      child: FormField<bool>(
        builder: (state) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Checkbox(
                    value: termsAndConditions,
                    activeColor: Theme.of(context).primaryColor,
                    onChanged: (value) {
                      setState(() {
                        termsAndConditions = value;
                        if (termsAndConditions) {
                          termsAndConditionsValue = "on";
                        }
                        state.didChange(value);
                      });
                    },
                  ),
                  Expanded(
                    child: genericInlineLinkWidget(
                        context: context,
                        text: GenericMethods.getLocalizedString("term_and_agreement_message",inputWords: [GenericMethods.getLocalizedString("terms_and_conditions")]),
                        linkText: GenericMethods.getLocalizedString("terms_and_conditions"),
                        onLinkPressed: (){
                          GenericMethods.navigateToRoute(context: context,
                              builder: (context) => WebPage(APP_TERMS_OF_USE_URL, GenericMethods.getLocalizedString("terms_of_use")));
                        }
                    ),
                  ),
                ],
              ),
              state.errorText == null ? Container(padding: const EdgeInsets.only(bottom: 10),) : Padding(
                padding: const EdgeInsets.only(left: 20, bottom: 20),
                child: genericTextWidget(
                  state.errorText ?? '',
                  style: AppThemePreferences().appTheme.formFieldErrorTextStyle,
                ),
              )
            ],
          );
        },
        validator: (value) {
          if (!termsAndConditions) {
            return GenericMethods.getLocalizedString("please_accept_terms_text");
          }
          return null;
        },
      ),
    );
  }

  Widget buttonSignUpWidget() {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("sign_up"),
      onPressed: () async {
        FocusScope.of(context).requestFocus(FocusNode());
        if (formKey.currentState.validate()) {
          formKey.currentState.save();
          setState(() {
            _showWaitingWidget = true;
          });
          Map<String, dynamic> userSignupInfo = {
            "username": userName,
            "useremail": email,
            "register_pass": registerPass.text,
            "register_pass_retype": registerPassRetype.text,
            "term_condition": termsAndConditionsValue,
            "role": _roleValue
          };
          print(userSignupInfo);
          final response = await _propertyBloc.fetchSigupResponse(userSignupInfo);

          if(response == null || response.statusCode == null){
            if(mounted){
              setState(() {
                isInternetConnected = false;
                _showWaitingWidget = false;
              });
            }
          }else{
            if(mounted){
              setState(() {
                isInternetConnected = true;
                _showWaitingWidget = false;
              });
            }
          }

          if(response == null){
            _showToastForUserLogin(context, GenericMethods.getLocalizedString("error_occurred"));
          }else{
            String tempString = response.toString();
            if(tempString.contains("{")){
              String tempResponseString = response.toString().split("{")[1];
              Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
              if (map['success'] == true) {
                _showToastForUserLogin(context, map['msg']);
                Navigator.pop(context);

              } else if(map['success'] == false){
                _showToastForUserLogin(context, map['msg']);
              } else{
                _showToastForUserLogin(context, map['msg']);
              }
            }else{
              _showToastForUserLogin(context, GenericMethods.getLocalizedString("error_occurred"));
            }
          }
        }
      },
    );
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: SafeArea(
        child: Column(
          children: [
            if(!isInternetConnected) noInternetBottomActionBar(
              context,
                  (){},
              showRetryButton: false,
            ),
          ],
        ),
      ),
    );
  }

  Widget alreadySignedUpTextWidget() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
      child: genericLinkWidget(
        context: context,
        preLinkText: GenericMethods.getLocalizedString("already_have_an_account"),
        linkText: GenericMethods.getLocalizedString("login_capital"),
        onLinkPressed: () {
          Route route = MaterialPageRoute(
            builder: (context) => UserSignIn(
                  (String closeOption) {
                if (closeOption == CLOSE) {
                  Navigator.pop(context);
                }
              },
            ),
          );
          Navigator.pushReplacement(context, route);
        },
      ),
    );
  }

  Widget loginWaitingWidget() {
    return _showWaitingWidget == true
        ? Positioned(
            left: 0, right: 0, top: 0, bottom: 0,
            child: Center(
              child: Container(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 80,
                  height: 20,
                  child: loadingBallBeatWidget(),
                ),
              ),
            ),
          )
        : Container();
  }

  _showToastForUserLogin(BuildContext context, String msg) {
    toastWidget(
      buildContext: context,
      text: msg,
    );
  }
}
