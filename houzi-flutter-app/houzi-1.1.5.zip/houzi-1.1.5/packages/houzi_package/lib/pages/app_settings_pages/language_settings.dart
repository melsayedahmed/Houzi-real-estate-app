import 'package:flutter/material.dart';
import 'package:houzi_package/dataProvider/locale_provider.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/l10n/l10n.dart';
import 'package:houzi_package/widgets/app_bar_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';
import 'package:provider/provider.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../common/constants.dart';
import '../../files/generic_methods/general_notifier.dart';
import '../main_screen_pages/my_home_page.dart';

class LanguageSettings extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => LanguageSettingsState();

}

class LanguageSettingsState extends State<LanguageSettings> {

  // Provider provider;
  // Provider<LocaleProvider> provider;
  LocaleProvider provider;
  Locale locale;

  List list = [];

  String _selectedLanguage;


  @override
  void initState() {
    super.initState();
    DefaultLanguageCodeHook defaultLanguageCodeHook = GenericMethods.defaultLanguageCode;
    String defaultLanguage = defaultLanguageCodeHook();
    String localeFromStorage = HiveStorageManager.readLanguageSelection() ?? defaultLanguage;
    Locale tempLocale = Locale(localeFromStorage);
    if(tempLocale != null){
      final tempFlag = L10n.getLanguageName(tempLocale.languageCode);
      _selectedLanguage = tempFlag;
    }
  }

  @override
  Widget build(BuildContext context) {
    provider = Provider.of<LocaleProvider>(context);
    // locale = provider.locale ?? Locale('en');

    return Scaffold(
      appBar: appBarWidget(
        context,
        appBarTitle: GenericMethods.getLocalizedString("language_label"),//AppLocalizations.of(context).language_label,
      ),
      body: Column(
        children: [
          headingWidget(text: GenericMethods.getLocalizedString("select_language")),//AppLocalizations.of(context).select_language),
          selectLanguageWidget(),
        ],
      ),
    );
  }

  Widget headingWidget({String text}){
    return headerWidget(
      text: text,
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
      alignment: Alignment.topLeft,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppThemePreferences().appTheme.dividerColor),
        ),
      ),
    );
  }

  Widget selectLanguageWidget(){
    return Column(
      children: L10n.all.map((locale) {
        final flag = L10n.getLanguageName(locale.languageCode);
        return  genericRadioListTile(
          title: genericTextWidget(flag),
          value: flag,
          groupValue: _selectedLanguage,
          onChanged: (value) {
            setState(() {
              _selectedLanguage = value;

              // For Saknquare:
              // if(locale == Locale("en")){
              //   WORDPRESS_URL_PATH = "/en";
              // }
              // if(locale == Locale("ar")){
              //   WORDPRESS_URL_PATH = "";
              // }
            });
            // For Saknquare:
            // if(locale == Locale("en") || locale == Locale("ar")){
            //   GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => MyHomePage());
            // }

            provider = Provider.of<LocaleProvider>(context, listen: false);
            provider.setLocale(locale);
            GenericMethods.navigateToRouteByPushAndRemoveUntil(context: context, builder: (context) => const MyHomePage());
            // GeneralNotifier().publishChange(GeneralNotifier.CHANGE_LOCALIZATION);
            // Navigator.pop(context);
          },
        );
      }).toList(),
    );
  }


  Widget genericRadioListTile({
    ListTileControlAffinity controlAffinity = ListTileControlAffinity.trailing,
    EdgeInsetsGeometry contentPadding = const EdgeInsets.symmetric(horizontal: 20),
    @required Widget title,
    Widget subtitle,
    @required String value,
    @required String groupValue,
    @required void Function(String) onChanged,
  }){
    return RadioListTile(
      controlAffinity: controlAffinity,
      contentPadding: contentPadding,
      title: title,
      subtitle: subtitle,
      value: value,
      groupValue: groupValue,
      activeColor: AppThemePreferences().appTheme.primaryColor,
      onChanged: onChanged,
    );
  }


}
