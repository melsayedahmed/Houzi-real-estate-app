import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/pages/home_page_screens/home_screen.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_search_bar_widget/home_screen_search_bar_generic.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_sliver_app_bar_widgets/search_by_id_widget.dart';


typedef HomeRightBarButtonWidgetHook = Widget Function(BuildContext context);
typedef HomeTabbedSliverAppBarListener = void Function(Map<String, dynamic> filterInfo);

class HomeTabbedSliverAppBar extends StatefulWidget{

  final String userName;
  final Map<String, dynamic> propertyMetaDataMap;
  final Function() onLeadingIconPressed;
  final HomeTabbedSliverAppBarListener homeTabbedSliverAppBarListener;

  HomeTabbedSliverAppBar({
    Key key,
    this.userName,
    @required this.propertyMetaDataMap,
    @required this.onLeadingIconPressed,
    this.homeTabbedSliverAppBarListener,
  }) : super(key: key);
  
  @override
  State<StatefulWidget> createState() => HomeTabbedSliverAppBarState();
}

class HomeTabbedSliverAppBarState extends State<HomeTabbedSliverAppBar>  with TickerProviderStateMixin{
  HomeRightBarButtonWidgetHook searchByIdWidgetHook = GenericMethods.homeRightBarButtonWidget;
  bool isCollapsed = false;
  bool isStretched = true;
  bool increasePadding = true;
  bool reducePadding = false;

  // double extendedHeight = MediaQuery.of(context).size.height * 0.5;
  double extendedHeight = 185.0;
  double padding = 15.0;
  double currentHeight = 0.0;
  double previousHeight = 0.0;

  TabController controller;

  @override
  void initState(){
    super.initState();
    controller = TabController(length: 3, vsync: this);
  }


  @override
  Widget build(BuildContext context) {
    extendedHeight = MediaQuery.of(context).size.height * 0.35; //0.5
    return SliverAppBar(
      systemOverlayStyle: HomeScreen().getSystemUiOverlayStyle(design: HOME_SCREEN_DESIGN),
      backgroundColor: AppThemePreferences().appTheme.primaryColor,
      pinned: true,
      expandedHeight: extendedHeight,
      leading: IconButton(
        padding: const EdgeInsets.all(0),
        onPressed: widget.onLeadingIconPressed,
        icon:  Icon(
          AppThemePreferences.drawerMenuIcon,
          color: AppThemePreferences.tabbedHomeSliverAppBarIconColor,
        ),
        // icon:  AppThemePreferences().appTheme.drawerMenuIcon,
        tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
      ),
      flexibleSpace: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            isCollapsed = constraints.biggest.height ==  MediaQuery.of(context).padding.top + kToolbarHeight ? true : false;
            isStretched = constraints.biggest.height ==  MediaQuery.of(context).padding.top + extendedHeight ? true : false;
            currentHeight = constraints.maxHeight;
            if(previousHeight < currentHeight){
              increasePadding = false;
              reducePadding = true;
              previousHeight = currentHeight;
            }
            if(previousHeight > currentHeight){
              increasePadding = true;
              reducePadding = false;
              previousHeight = currentHeight;
            }
            if(isCollapsed){
              padding = 60;
              increasePadding = false;
              reducePadding = true;
            }
            if(isStretched){
              padding = 15;
              increasePadding = true;
              reducePadding = false;
            }

            if(increasePadding){
              double temp = padding + (constraints.maxHeight) / 100;
              if(temp <= 60){
                padding = temp;
              }else{
                temp = temp - (temp - 60);
                padding = temp;
              }
            }
            if(reducePadding){
              double temp = padding - (constraints.maxHeight) / 100;
              if(temp >= 10){
                padding = temp;
              }else{
                temp = temp + (10 - temp);
                padding = temp;
              }
            }

            return FlexibleSpaceBar(
              // expandedTitleScale: 1.5,
              centerTitle: false,
              titlePadding: EdgeInsets.only(left: GenericMethods.isRTL(context) ? 15 : padding, bottom: 10, right: GenericMethods.isRTL(context) ? padding : 15),
              title: SearchBarWidget(
                  borderRadius: BorderRadius.circular(10.0),
                  propertyMetaDataMap: widget.propertyMetaDataMap,
                  searchBarWidgetListener: (filterDataMap){
                    widget.homeTabbedSliverAppBarListener(filterDataMap);
                  }
              ),

              background:  SafeArea(
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.only(top: 15.0, left: 20, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          searchByIdWidgetHook(context) ?? Container(),
                        ],
                      ),
                    ),
                    Flexible(child:  Row(
                      children: [
                        getTitleWidget(),
                      ],
                    )),
                  ],
                ),
              ),
            );
          }),
      elevation: 0,
    );
  }
  Widget getTitleWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

          genericTextWidget(

            "${GenericMethods.getLocalizedString("Hello")},",
            style: AppThemePreferences().appTheme.sliverGreetingsTextStyle,
          ),
          if(widget.userName != null && widget.userName.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: genericTextWidget(
                "${widget.userName.split(" ")[0]}!",
                strutStyle: const StrutStyle(
                  height: 3.0,
                  forceStrutHeight: true,
                ),
                style: AppThemePreferences().appTheme.sliverUserNameTextStyle,
              ),
            ),

          Padding(
            padding: EdgeInsets.only(top: widget.userName != null && widget.userName.isNotEmpty ? 15 : 30),
            child: genericTextWidget(
              GenericMethods.getLocalizedString(TABBED_HOME_QUOTE),
              style: AppThemePreferences().appTheme.sliverQuoteTextStyle,
            ),
          ),
        ],
      ),
    );
  }

}

