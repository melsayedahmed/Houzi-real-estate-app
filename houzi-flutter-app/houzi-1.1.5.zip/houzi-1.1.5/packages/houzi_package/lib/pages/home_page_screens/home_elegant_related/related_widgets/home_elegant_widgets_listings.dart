import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/dataProvider/locale_provider.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/theme_service_files/theme_storage_manager.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/all_agency.dart';
import 'package:houzi_package/pages/home_screen_drawer_menu_pages/all_agents.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/header_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_properties_related_widgets/explore_properties_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_properties_related_widgets/latest_featured_properties_widget/properties_listing_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_realtors_related_widgets/home_screen_realtors_list.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_recent_searches_widget/home_screen_recent_searches.dart';
import 'package:houzi_package/widgets/type_status_row_widget.dart';
import 'package:provider/provider.dart';


typedef HomeElegantListingsWidgetListener = void Function(bool errorWhileLoading);

class HomeElegantListingsWidget extends StatefulWidget {
  final homeScreenData;
  bool refresh;
  final HomeElegantListingsWidgetListener homeScreen02ListingsWidgetListener;

  HomeElegantListingsWidget({
    this.homeScreenData,
    this.refresh = false,
    this.homeScreen02ListingsWidgetListener,
  });

  @override
  State<HomeElegantListingsWidget> createState() => _HomeElegantListingsWidgetState();
}

class _HomeElegantListingsWidgetState extends State<HomeElegantListingsWidget> {
  List<dynamic> homeScreenList = [];
  Future<List<dynamic>> _futureHomeScreenList;
  final PropertyBloc _propertyBloc = PropertyBloc();

  int page = 1;

  bool isDataLoaded = false;
  bool noDataReceived = false;

  Map homeConfigMap = {};
  NativeAd _nativeAd;
  bool _isNativeAdLoaded = false;

  VoidCallback  generalNotifierLister;
  String arrowDirection = " >";

  @override
  void initState() {
    super.initState();

    generalNotifierLister = () {
      if (GeneralNotifier().change == GeneralNotifier.CITY_DATA_UPDATE) {
        if(homeConfigMap[sectionTypeKey] == allPropertyKey &&
            homeConfigMap[subTypeKey] == propertyCityDataType){
          setState(() {
            Map map = HiveStorageManager.readSelectedCityInfo();

            if(homeConfigMap[subTypeValueKey] != map[CITY_ID].toString()){
              homeScreenList = [];
              isDataLoaded = false;
              noDataReceived = false;
              if (map[CITY_ID] != null) {
                homeConfigMap[subTypeValueKey] = map[CITY_ID].toString();
              } else {
                homeConfigMap[subTypeValueKey] = "";
              }

              homeConfigMap[titleKey] = "";
              if(map[CITY] != null && map[CITY].isNotEmpty && map[CITY_ID] != null){
                homeConfigMap[titleKey] = GenericMethods.getLocalizedString(
                    "latest_properties_in_city",inputWords: [map[CITY]]);
              }
              else{
                homeConfigMap[titleKey] = GenericMethods.getLocalizedString("latest_properties");
              }

              loadData();
            }
          });
        }else if(homeConfigMap[sectionTypeKey] == propertyKey && homeConfigMap[subTypeKey] == propertyCityDataType &&
            homeConfigMap[subTypeValueKey] == userSelectedString){
          setState(() {
            Map map = HiveStorageManager.readSelectedCityInfo();

            homeScreenList = [];
            isDataLoaded = false;
            noDataReceived = false;

            homeConfigMap[titleKey] = "";
            if(map[CITY] != null && map[CITY].isNotEmpty && map[CITY_ID] != null){
              homeConfigMap[titleKey] = GenericMethods.getLocalizedString(
                  "latest_properties_in_city",inputWords: [map[CITY]]);
            }
            else{
              homeConfigMap[titleKey] = GenericMethods.getLocalizedString("latest_properties");
            }

            loadData();
          });
        }

      } else if(GeneralNotifier().change == GeneralNotifier.RECENT_DATA_UPDATE &&
          homeConfigMap[sectionTypeKey] == recentSearchKey){
        setState(() {
          homeScreenList.clear();
          homeScreenList = HiveStorageManager.readRecentSearchesInfo() ?? [];
          setState(() {
            isDataLoaded = true;
          });
        });
      }
    };

    GeneralNotifier().addListener(generalNotifierLister);
  }

  @override
  void dispose() {
    super.dispose();

    if(_nativeAd != null){
      _nativeAd.dispose();
    }
    homeScreenList = [];
    homeConfigMap = {};
    if (generalNotifierLister != null) {
      GeneralNotifier().removeListener(generalNotifierLister);
    }
  }

  setUpNativeAd() {
    print("CALLING ADS");
    String themeMode = ThemeStorageManager.readData(THEME_MODE_INFO) ?? LIGHT_THEME_MODE;
    bool isDarkMode = false;
    if (themeMode == DARK_THEME_MODE) {
      isDarkMode = true;
    }
    _nativeAd = NativeAd(
      customOptions: {"isDarkMode": isDarkMode},
      adUnitId: Platform.isAndroid ? ANDROID_NATIVE_AD_ID : IOS_NATIVE_AD_ID,
      factoryId: 'homeNativeAd',
      request: const AdRequest(),
      listener: NativeAdListener(
        onAdLoaded: (_) {
          setState(() {
            _isNativeAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          if (kDebugMode) {
            print(
              'Ad load failed (code=${error.code} message=${error.message})',
            );
          }
        },
      ),
    );

    _nativeAd.load();
  }

  loadData() {
    _futureHomeScreenList = fetchRelatedList(context, page);
    _futureHomeScreenList.then((value) {
      if (value == null || value.isEmpty) {
        noDataReceived = true;
      } else {
        if(value[0].runtimeType == Response){
          // print("Generic Home Listing (Error Code): ${value[0].statusCode}");
          // print("Generic Home Listing (Error Msg): ${value[0].statusMessage}");
          noDataReceived = true;
          widget.homeScreen02ListingsWidgetListener(true);
        }else{
          homeScreenList = value;
          isDataLoaded = true;
        }
      }

      if(mounted){
        setState(() {});
      }

      return null;
    });
  }

  Future<List<dynamic>> fetchRelatedList(BuildContext context, int page) async {
    List<dynamic> tempList = [];
    try {
      /// Fetch featured properties
      if (homeConfigMap[sectionTypeKey] == featuredPropertyKey) {
        tempList = await _propertyBloc.fetchFeaturedArticles(page);
      }

      /// Fetch All_properties
      else if (homeConfigMap[sectionTypeKey] == allPropertyKey && homeConfigMap[subTypeKey] != propertyCityDataType) {
        String key = GenericMethods.getSearchKey(homeConfigMap[subTypeKey]);
        String value = homeConfigMap[subTypeValueKey];
        Map<String, dynamic> dataMap = {};
        if(value != 'all' && value.isNotEmpty){
          dataMap = {key: value};
        }
        Map<String, dynamic> tempMap = await _propertyBloc.fetchFilteredArticles(dataMap);
        tempList.addAll(tempMap["result"]);
      }

      /// Fetch properties
      else if (homeConfigMap[sectionTypeKey] == propertyKey) {
        Map<String, dynamic> dataMap = {};
        if(homeConfigMap[subTypeKey] == propertyCityDataType &&
            homeConfigMap[subTypeValueKey] == userSelectedString) {
          Map map = HiveStorageManager.readSelectedCityInfo();
          if (map != null && map.isNotEmpty && map[CITY_ID] != null) {
            if (homeConfigMap[titleKey] != "Please Select") {
              homeConfigMap[titleKey] = "";
              homeConfigMap[titleKey] = GenericMethods.getLocalizedString(
                  "latest_properties_in_city", inputWords: [map[CITY]]);
            }
            String citySlug = map[CITY_SLUG];
            if (citySlug != null && citySlug.isNotEmpty) {
              dataMap[SEARCH_RESULTS_LOCATION] = citySlug;
            }
          }
        }else{
          String key = GenericMethods.getSearchKey(homeConfigMap[subTypeKey]);
          String value = homeConfigMap[subTypeValueKey];
          if(value != 'all' && value.isNotEmpty){
            dataMap = {key: value};
          }
        }

        if(homeConfigMap[showFeaturedKey]){
          dataMap[SEARCH_RESULTS_FEATURED] = 1;
        }

        Map<String, dynamic> tempMap = await _propertyBloc.fetchFilteredArticles(dataMap);
        tempList.addAll(tempMap["result"]);
      }


      /// Fetch latest and city selected properties
      else if (homeConfigMap[sectionTypeKey] == allPropertyKey && homeConfigMap[subTypeKey] == propertyCityDataType) {
        Map map = HiveStorageManager.readSelectedCityInfo();
        if (map != null && map[CITY_ID] != null) {
          homeConfigMap[subTypeValueKey] = map[CITY_ID].toString();
          if (homeConfigMap[titleKey] != "Please Select") {
            homeConfigMap[titleKey] = "";
            homeConfigMap[titleKey] = GenericMethods.getLocalizedString(
                "latest_properties_in_city",inputWords: [map[CITY]]);
          }
        }
        if (homeConfigMap[subTypeValueKey] == userSelectedString || homeConfigMap[subTypeValueKey] == ""
            || homeConfigMap[subTypeValueKey] == "all") {
          tempList = await _propertyBloc.fetchLatestArticles(page);
        } else {
          int id = int.parse(homeConfigMap[subTypeValueKey]);
          tempList = await _propertyBloc.fetchPropertiesInCityList(id, page, 16);
        }
      }


      /// Fetch realtors list
      else if (homeConfigMap[sectionTypeKey] == "agencies" ||
          homeConfigMap[sectionTypeKey] == "agents") {
        if (homeConfigMap[subTypeKey] == REST_API_AGENT_ROUTE) {
          tempList = await _propertyBloc.fetchAllAgentsInfoList(page, 16);
        } else {
          tempList = await _propertyBloc.fetchAllAgenciesInfoList(page, 16);
        }
      }


      /// Fetch Terms
      else if (homeConfigMap[sectionTypeKey] == termKey) {
        tempList = await _propertyBloc.fetchTermData(homeConfigMap[subTypeKey]);
      }

      /// Fetch taxonomies
      else if (homeConfigMap[sectionTypeKey] == termWithIconsTermKey) {
        tempList = [1];
      }

      else {
        tempList = [];
      }
    } on SocketException {
      throw 'No Internet connection';
    }
    return tempList;
  }

  setRouteToNavigate() async {
    StatefulWidget Function(dynamic context) navigateTo;
    if (homeConfigMap[sectionTypeKey] == featuredPropertyKey) {
      navigateTo = getSearchResultPath(onlyFeatured: true);
    }
    else if (homeConfigMap[sectionTypeKey] == allPropertyKey &&
        homeConfigMap[subTypeKey] != propertyCityDataType) {
      Map<String, dynamic> dataMap = {
        GenericMethods.getSearchKey(homeConfigMap[subTypeKey]): "",
      };
      navigateTo = getSearchResultPath(map: dataMap);
    } else if (homeConfigMap[sectionTypeKey] == propertyKey) {
      Map<String, dynamic> dataMap = {
        GenericMethods.getSearchKey(homeConfigMap[subTypeKey]):
            homeConfigMap[subTypeValueKey],
      };
      navigateTo = getSearchResultPath(map: dataMap);
    } else if (homeConfigMap[sectionTypeKey] == termKey) {
      Map<String, dynamic> dataMap = {
        GenericMethods.getSearchKey(homeConfigMap[subTypeKey]): "",
      };
      navigateTo = getSearchResultPath(map: dataMap);
    } else if (homeConfigMap[subTypeKey] == "agencies") {
      navigateTo = (context) => AllAgency();
    } else if (homeConfigMap[subTypeKey] == "agents") {
      navigateTo = (context) => AllAgents();
    } else if (homeConfigMap[sectionTypeKey] == allPropertyKey &&
        homeConfigMap[subTypeKey] == propertyCityDataType) {
      Map<String, dynamic> dataMap = {};
      Map cityInfoMap = HiveStorageManager.readSelectedCityInfo() ?? {};
      if (cityInfoMap != null && cityInfoMap[CITY_ID] != null) {
        dataMap = {SEARCH_RESULTS_LOCATION: cityInfoMap[CITY_SLUG]};
      } else {
        dataMap = {};
      }
      navigateTo = getSearchResultPath(map: dataMap);
    } else {
      navigateTo = null;
    }
    navigateToRoute(navigateTo);
  }

  getSearchResultPath({Map<String, dynamic> map, bool onlyFeatured = false}){
    return (context) => SearchResult(
      dataInitializationMap: onlyFeatured ? null : map,
      fetchFeatured: onlyFeatured,
      searchPageListener: (Map<String, dynamic> map, String closeOption) {
        if (closeOption == CLOSE) {
          Navigator.of(context).pop();
        }
      },
    );
  }

  navigateToRoute(WidgetBuilder builder) {
    if (builder != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: builder,
        ),
      );
    }
  }

  bool needToLoadData(Map oldDataMap, Map newDataMap){
    if(oldDataMap[sectionTypeKey] != newDataMap[sectionTypeKey] ||
        oldDataMap[subTypeKey] != newDataMap[subTypeKey] ||
        oldDataMap[subTypeValueKey] != newDataMap[subTypeValueKey]){
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {

    if (widget.homeScreenData != homeConfigMap) {
      // Make sure new Home item is Map
      var newHomeConfigMap = widget.homeScreenData;
      if (newHomeConfigMap is! Map) {
        newHomeConfigMap = widget.homeScreenData.toJson();
      }

      if (!(mapEquals(newHomeConfigMap, homeConfigMap))) {
        if (homeConfigMap[sectionTypeKey] != newHomeConfigMap[sectionTypeKey] &&
            newHomeConfigMap[sectionTypeKey] == recentSearchKey) {
          homeScreenList.clear();
          homeScreenList = HiveStorageManager.readRecentSearchesInfo() ?? [];
        } else if (
        // homeConfigMap[sectionTypeKey] != newHomeConfigMap[sectionTypeKey] &&
            newHomeConfigMap[sectionTypeKey] == adKey) {
          if (SHOW_ADS_ON_HOME) {
            if(!_isNativeAdLoaded){
              setUpNativeAd();
            }

          }
        } else if (needToLoadData(homeConfigMap, newHomeConfigMap)){
          // Update Home Item
          homeConfigMap = newHomeConfigMap;
          loadData();
        }

        // Update Home Item
        homeConfigMap = newHomeConfigMap;
      }
    }

    // if (widget.homeScreenData != homeConfigMap) {
    //   if (widget.homeScreenData is! Map) {
    //     homeConfigMap = widget.homeScreenData.toJson();
    //   } else {
    //     homeConfigMap = widget.homeScreenData;
    //   }
    //
    //   if(!widget.updateUI) {
    //     if (homeConfigMap[sectionTypeKey] == recentSearchKey) {
    //       homeScreenList.clear();
    //       homeScreenList = HiveStorageManager.readRecentSearchesInfo() ?? [];
    //     } else if (homeConfigMap[sectionTypeKey] == adKey) {
    //       if (SHOW_ADS_ON_HOME) {
    //         setUpNativeAd();
    //       }
    //     } else {
    //       loadData();
    //     }
    //   }
    // }

    if(widget.refresh && homeConfigMap[sectionTypeKey] != adKey && homeConfigMap[sectionTypeKey] != recentSearchKey ){
      homeScreenList = [];
      isDataLoaded = false;
      noDataReceived = false;
      loadData();
      widget.refresh = false;
    }

    return Consumer<LocaleProvider>(
        builder: (context, localeProvider, child) {
          if (homeConfigMap[sectionTypeKey] == allPropertyKey &&
          homeConfigMap[subTypeKey] == propertyCityDataType) {
            Map map = HiveStorageManager.readSelectedCityInfo();
            if (map != null && map[CITY_ID] != null) {
              homeConfigMap[subTypeValueKey] = map[CITY_ID].toString();
              if (homeConfigMap[titleKey] != "Please Select") {
                homeConfigMap[titleKey] = "";
                homeConfigMap[titleKey] = GenericMethods.getLocalizedString(
                    "latest_properties_in_city",
                    inputWords: [map[CITY]]);
              }
            }
          }

          return noDataReceived
              ? Container()
              : Column(
                  children: [
                    if(homeConfigMap[sectionTypeKey] != adKey)
                      if(homeScreenList != null && homeScreenList.isNotEmpty)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            home02HeaderWidget(
                              text: GenericMethods.getLocalizedString(homeConfigMap[titleKey]),
                              textStyle: AppThemePreferences().appTheme.titleTextStyle,
                              padding: const EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 15.0),
                            ),
                            if(homeConfigMap[sectionTypeKey] != recentSearchKey )
                              if(homeConfigMap[sectionTypeKey] != termWithIconsTermKey)
                                GestureDetector(
                                  onTap: () {
                                    setRouteToNavigate();
                                  },
                                  child: Padding(
                                    padding: EdgeInsets.only(left : GenericMethods.isRTL(context) ? 20 : 0,right: GenericMethods.isRTL(context) ? 0 : 20,top: 5),
                                    child: genericTextWidget(
                                      GenericMethods.getLocalizedString("see_all") + arrowDirection,
                                      style: AppThemePreferences().appTheme.readMoreTextStyle,
                                    ),
                                  ),
                                ),
                          ],
                        ),
                    if (homeConfigMap[sectionTypeKey] == termWithIconsTermKey)
                      const TermWithIconsWidget(),
                    if(homeConfigMap[sectionTypeKey] == recentSearchKey)
                      homeScreenRecentSearchesWidget(
                        context: context,
                        recentSearchesInfoList: HiveStorageManager.readRecentSearchesInfo() ?? [],
                        // recentSearchesInfoList: homeScreenList,
                        listingView: homeConfigMap[sectionListingViewKey] ?? homeScreenWidgetsListingCarouselView,
                      ),
                    if(homeConfigMap[sectionTypeKey] == adKey && SHOW_ADS_ON_HOME && _isNativeAdLoaded)
                      Container(
                        padding: const EdgeInsets.only(left: 10,right: 10),
                        height: 50,
                        child: AdWidget(ad: _nativeAd),
                      ),
                    if (homeConfigMap[sectionTypeKey] == allPropertyKey || homeConfigMap[sectionTypeKey] == propertyKey || homeConfigMap[sectionTypeKey] == featuredPropertyKey)
                      if (isDataLoaded)
                        PropertiesListingGenericWidget(
                            propertiesList: homeScreenList,
                            design: homeConfigMap[designKey],
                            listingView: homeConfigMap[sectionListingViewKey] ?? homeScreenWidgetsListingCarouselView,
                        )
                      else
                        genericLoadingWidgetForCarousalWithShimmerEffect(context),
                    if (homeConfigMap[sectionTypeKey] == termKey)
                      if (isDataLoaded)
                        explorePropertiesWidget(
                          context: context,
                          design: homeConfigMap[designKey],
                          tag: homeConfigMap[subTypeKey],
                          propertiesData: homeScreenList,
                          listingView: homeConfigMap[sectionListingViewKey] ?? homeScreenWidgetsListingCarouselView,
                          explorePropertiesWidgetListener: (
                              {filterDataMap,
                                recentSearchesDataMapList,
                                loadProperties}) {
                            if (filterDataMap != null && filterDataMap.isNotEmpty) {}
                          },
                        )
                      else
                        genericLoadingWidgetForCarousalWithShimmerEffect(context),
                    if (homeConfigMap[sectionTypeKey] == REST_API_AGENCY_ROUTE || homeConfigMap[sectionTypeKey] == REST_API_AGENT_ROUTE)
                      if (isDataLoaded && homeScreenList[0] is List)
                        realtorListingWidget(
                          context: context,
                          listingView: homeConfigMap[sectionListingViewKey] ?? homeScreenWidgetsListingCarouselView,
                          tag: homeConfigMap[subTypeKey] == REST_API_AGENT_ROUTE
                              ? AGENTS_TAG
                              : AGENCIES_TAG,
                          realtorInfoList: homeScreenList[0],
                        )
                      else
                        genericLoadingWidgetForCarousalWithShimmerEffect(context),
                  ],
          );
    });
  }


}
