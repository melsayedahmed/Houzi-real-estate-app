import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/pages/city_picker.dart';
import 'package:houzi_package/pages/property_details_page.dart';
import 'package:houzi_package/widgets/dialog_box_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';


typedef HomeRightBarButtonWidgetHook = Widget Function(BuildContext context);

typedef HomeLocationTopBarWidgetListener = void Function({
  Map<String, dynamic> filterDataMap,
  bool loadProperties,
});

class HomeLocationTopBarWidget extends StatefulWidget {
  final Map<String, dynamic> propertyMetaDataMap;
  final List<dynamic> cityMetaDataList;
  final String city;
  final HomeLocationTopBarWidgetListener homeScreen03TopBarWidgetListener;

  const HomeLocationTopBarWidget({
    Key key,
    @required this.city,
    @required this.propertyMetaDataMap,
    @required this.cityMetaDataList,
    this.homeScreen03TopBarWidgetListener,
  }) : super(key: key);

  @override
  State<HomeLocationTopBarWidget> createState() => _HomeLocationTopBarWidgetState();
}

class _HomeLocationTopBarWidgetState extends State<HomeLocationTopBarWidget> {

  HomeRightBarButtonWidgetHook searchByIdWidgetHook = GenericMethods.homeRightBarButtonWidget;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 15.0, left: 20, right: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          // homeScreenLocationWidget(
          //   context: context,
          //   city: city,
          //   propertyMetaDataMap: propertyMetaDataMap,
          //   cityMetaDataList: cityMetaDataList,
          //   homeScreenLocationWidgetListener: ({filterDataMap, loadProperties}){
          //     homeScreen03TopBarWidgetListener(
          //       filterDataMap: filterDataMap,
          //       loadProperties: loadProperties,
          //     );
          //   },
          // ),
          searchByIdWidgetHook(context) ?? Container(),
        ],
      ),
    );
  }
}

Widget homeScreenLocationWidget({
  @required BuildContext context,
  @required String city,
  @required Map<String, dynamic> propertyMetaDataMap,
  @required List<dynamic> cityMetaDataList,
  final HomeLocationTopBarWidgetListener homeScreenLocationWidgetListener,
}){
  return GestureDetector(
    onTap: () {
      if(propertyMetaDataMap == null){
        toastWidget(buildContext: context, text: GenericMethods.getLocalizedString("data_loading"));
      }else{
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CityPicker(
                citiesMetaDataList: cityMetaDataList,
                cityPickerListener: (String pickedCity, int pickedCityId, String pickedCitySlug) {
                  Map<String, dynamic> filterDataMap = HiveStorageManager.readFilterDataInfo();
                  filterDataMap[CITY] = pickedCity;
                  filterDataMap[CITY_ID] = pickedCityId;
                  filterDataMap[CITY_SLUG] = pickedCitySlug;
                  HiveStorageManager.storeFilterDataInfo(map: filterDataMap);

                  homeScreenLocationWidgetListener(
                    filterDataMap: filterDataMap,
                    loadProperties: true,
                  );
                }),
          ),
        );
      }
    },
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        const SizedBox(width: 35),
        Padding(
          padding: const EdgeInsets.only(left: 15),
          child: AppThemePreferences().appTheme.homeScreenTopBarLocationIcon,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              genericTextWidget(
                GenericMethods.getLocalizedString("location"),
                strutStyle: const StrutStyle(forceStrutHeight: true),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 2.0),
                child: genericTextWidget(
                  city,
                  strutStyle: const StrutStyle(forceStrutHeight: true),
                  style:  AppThemePreferences().appTheme.locationWidgetTextStyle,
                ),
              ),
            ],
          ),
        ),
        Padding(
            padding: const EdgeInsets.only(left: 5, top: 20),
            child: CircleAvatar(
              radius: 7,
              backgroundColor: AppThemePreferences().appTheme.homeScreenTopBarRightArrowBackgroundColor,
              // backgroundColor: AppThemePreferences().appTheme.primaryColor,
              child: AppThemePreferences().appTheme.homeScreenTopBarRightArrowIcon,
            )),
      ],
    ),
  );
}


Widget homeScreenSearchPropertyByIdWidget({
  @required BuildContext context,
}){
  return GestureDetector(
    child: Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        AppThemePreferences().appTheme.homeScreenTopBarSearchIcon,
        genericTextWidget(
          GenericMethods.getLocalizedString("id"),
          style: AppThemePreferences().appTheme.searchByIdTextStyle,
        ),
      ],
    ),
    onTap: () {
      FocusScope.of(context).requestFocus(FocusNode());
      _searchByPropertyIdDialog(context);
    },
  );
}

Future _searchByPropertyIdDialog(BuildContext context) {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String propertyId;
  return dialogBoxWidget(
    context,
    title: GenericMethods.getLocalizedString("search_by_property_id"),
    textAlign: TextAlign.center,
    content: Form(
      key: formKey,
      child: TextFormField(
        textInputAction: TextInputAction.search,
        keyboardType: TextInputType.number,
        inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly,],
        onFieldSubmitted: (text) {
          if(formKey.currentState.validate()){
            searchByIdOnSubmit(context, propertyId);
          }
        },
        onChanged: (text){
          propertyId = text;
        },
        validator: (text){
          if(text == null || text.isEmpty){
            return GenericMethods.getLocalizedString("this_field_cannot_be_empty");
          }
          return null;
        },
        decoration: InputDecoration(
          hintText: GenericMethods.getLocalizedString("search"),
          focusedBorder: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(24.0)),
            borderSide: BorderSide(color: AppThemePreferences().appTheme.primaryColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(24.0)),
            borderSide: BorderSide(color: Colors.grey[300]),
          ),
          suffixIcon: AppThemePreferences().appTheme.searchBarIcon,
          contentPadding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 20.0),
        ),
      ),
    ),
    actions: <Widget>[
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: genericTextWidget(GenericMethods.getLocalizedString("cancel")),
      ),
      TextButton(
        child: genericTextWidget(GenericMethods.getLocalizedString("go")),
        onPressed: () {
          if(formKey.currentState.validate()){
            searchByIdOnSubmit(context, propertyId);
          }
        },
      ),
    ],
  );
}

void searchByIdOnSubmit(BuildContext context, String propertyId){
  int id = int.parse(propertyId);
  String heroId = propertyId + SINGLE;

  Route route = MaterialPageRoute(
    builder: (context) => PropertyDetailsPage(
      propertyID: id,
      heroId: heroId,
    ),
  );
  Navigator.pushReplacement(context, route);
}