import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/dataProvider/place_api_provider.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/address_search.dart';
import 'package:houzi_package/pages/city_picker.dart';
import 'package:houzi_package/pages/filter_page.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_sliver_app_bar_widgets/search_by_id_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';


typedef HomeRightBarButtonWidgetHook = Widget Function(BuildContext context);

typedef HomeElegantSliverAppBarListener = void Function({Map<String, dynamic> filterDataMap});

class HomeElegantSliverAppBarWidget extends StatefulWidget {
  final String city;
  final int selectedStatusIndex;
  final Function() onLeadingIconPressed;
  final Map<String, dynamic> propertyMetaDataMap;
  final List<dynamic> cityMetaDataList;
  final HomeElegantSliverAppBarListener homeElegantSliverAppBarListener;
  
  const HomeElegantSliverAppBarWidget({
    Key key,
    @required this.city,
    @required this.selectedStatusIndex,
    @required this.onLeadingIconPressed,
    @required this.propertyMetaDataMap,
    @required this.cityMetaDataList,
    this.homeElegantSliverAppBarListener,
  }) : super(key: key);

  @override
  State<HomeElegantSliverAppBarWidget> createState() => _HomeElegantSliverAppBarWidgetState();
}

class _HomeElegantSliverAppBarWidgetState extends State<HomeElegantSliverAppBarWidget> {

  bool isCollapsed = false;
  bool isStretched = true;
  bool increasePadding = true;
  bool reducePadding = false;
  double extendedHeight = 140.0;
  double padding = 10.0;
  double currentHeight = 0.0;
  double previousHeight = 0.0;

  HomeRightBarButtonWidgetHook rightBarButtonIdWidgetHook = GenericMethods.homeRightBarButtonWidget;

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: AppThemePreferences().appTheme.homeScreen02StatusBarColor,
          statusBarIconBrightness: AppThemePreferences().appTheme.statusBarIconBrightness,
          statusBarBrightness:AppThemePreferences().appTheme.statusBarBrightness
      ),
      backgroundColor: AppThemePreferences().appTheme.sliverAppBar02BackgroundColor,
      pinned: true,
      expandedHeight: extendedHeight,
      leading: IconButton(
        padding: const EdgeInsets.all(0),
        onPressed: widget.onLeadingIconPressed,
        icon:  AppThemePreferences().appTheme.drawer02MenuIcon,
        tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
      ),

      flexibleSpace: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            isCollapsed = constraints.biggest.height ==  MediaQuery.of(context).padding.top + kToolbarHeight ? true : false;
            isStretched = constraints.biggest.height ==  MediaQuery.of(context).padding.top + extendedHeight ? true : false;
            currentHeight = constraints.maxHeight;
            if(previousHeight < currentHeight){
              increasePadding = false;
              reducePadding = true;
              previousHeight = currentHeight;
            }
            if(previousHeight > currentHeight){
              increasePadding = true;
              reducePadding = false;
              previousHeight = currentHeight;
            }
            if(isCollapsed){
              padding = 60;
              increasePadding = false;
              reducePadding = true;
            }
            if(isStretched){
              padding = 10;
              increasePadding = true;
              reducePadding = false;
            }

            if(increasePadding){
              double temp = padding + (constraints.maxHeight) / 100;
              if(temp <= 60){
                padding = temp;
              }else{
                temp = temp - (temp - 60);
                padding = temp;
              }
            }
            if(reducePadding){
              double temp = padding - (constraints.maxHeight) / 100;
              if(temp >= 10){
                padding = temp;
              }else{
                temp = temp + (10 - temp);
                padding = temp;
              }
            }

            return FlexibleSpaceBar(
              centerTitle: false,
              // titlePadding: const EdgeInsets.only(left: 20, bottom: 10, right: 20),
              titlePadding: EdgeInsets.only(left: GenericMethods.isRTL(context) ? 10 : padding, bottom: 10, right: GenericMethods.isRTL(context) ? padding : 10),
              title: home02ScreenSearchBarWidget(
                  context: context,
                  propertyMetaDataMap: widget.propertyMetaDataMap,
                  home02ScreenSearchBarWidgetListener: ({filterDataMap, recentSearchesDataMapList, loadProperties}){
                    widget.homeElegantSliverAppBarListener(filterDataMap: filterDataMap);
                  }
              ),
              background: Column(
                children: [
                  home02ScreenTopBarWidget(
                    context: context,
                    city: widget.city,
                    cityMetaDataList: widget.cityMetaDataList,
                    propertyMetaDataMap: widget.propertyMetaDataMap,
                    home02ScreenTopBarWidgetListener:  ({filterDataMap, loadProperties}){
                      widget.homeElegantSliverAppBarListener(filterDataMap: filterDataMap);
                    },
                    searchByIdWidget: rightBarButtonIdWidgetHook(context) ?? Container(),
                  ),
                  // HomeScreenSearchTypeWidget(
                  //   homeScreenSearchTypeWidgetListener: (String selectedItem, String selectedItemSlug){
                  //     // Do something here
                  //   }
                  // ),
                ],
              ),
            );
          }),
      elevation: 5,
    );
  }
}


// Widget homeElegantSliverAppBarWidget({
//   @required BuildContext context,
//   @required String city,
//   @required int selectedStatusIndex,
//   @required Function() onLeadingIconPressed,
//   @required Map<String, dynamic> propertyMetaDataMap,
//   @required List<dynamic> cityMetaDataList,
//   final HomeElegantSliverAppBarListener homeElegantSliverAppBarListener,
//
//   bool isCollapsed = false,
//   bool isStretched = true,
//   bool increasePadding = true,
//   bool reducePadding = false,
//   double extendedHeight = 140.0,
//   double padding = 10.0,
//   double currentHeight = 0.0,
//   double previousHeight = 0.0,
// }){
//   return SliverAppBar(
//     systemOverlayStyle: SystemUiOverlayStyle(
//       statusBarColor: AppThemePreferences().appTheme.homeScreen02StatusBarColor,
//       statusBarIconBrightness: AppThemePreferences().appTheme.statusBarIconBrightness,
//       statusBarBrightness:AppThemePreferences().appTheme.statusBarBrightness
//     ),
//     backgroundColor: AppThemePreferences().appTheme.sliverAppBar02BackgroundColor,
//     pinned: true,
//     expandedHeight: extendedHeight,
//     leading: IconButton(
//       padding: const EdgeInsets.all(0),
//       onPressed: onLeadingIconPressed,
//       icon:  AppThemePreferences().appTheme.drawer02MenuIcon,
//       tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
//     ),
//
//     flexibleSpace: LayoutBuilder(
//         builder: (BuildContext context, BoxConstraints constraints) {
//           isCollapsed = constraints.biggest.height ==  MediaQuery.of(context).padding.top + kToolbarHeight ? true : false;
//           isStretched = constraints.biggest.height ==  MediaQuery.of(context).padding.top + extendedHeight ? true : false;
//           currentHeight = constraints.maxHeight;
//           if(previousHeight < currentHeight){
//             increasePadding = false;
//             reducePadding = true;
//             previousHeight = currentHeight;
//           }
//           if(previousHeight > currentHeight){
//             increasePadding = true;
//             reducePadding = false;
//             previousHeight = currentHeight;
//           }
//           if(isCollapsed){
//             padding = 60;
//             increasePadding = false;
//             reducePadding = true;
//           }
//           if(isStretched){
//             padding = 10;
//             increasePadding = true;
//             reducePadding = false;
//           }
//
//           if(increasePadding){
//             double temp = padding + (constraints.maxHeight) / 100;
//             if(temp <= 60){
//               padding = temp;
//             }else{
//               temp = temp - (temp - 60);
//               padding = temp;
//             }
//           }
//           if(reducePadding){
//             double temp = padding - (constraints.maxHeight) / 100;
//             if(temp >= 10){
//               padding = temp;
//             }else{
//               temp = temp + (10 - temp);
//               padding = temp;
//             }
//           }
//
//           return FlexibleSpaceBar(
//             centerTitle: false,
//             // titlePadding: const EdgeInsets.only(left: 20, bottom: 10, right: 20),
//             titlePadding: EdgeInsets.only(left: GenericMethods.isRTL(context) ? 10 : padding, bottom: 10, right: GenericMethods.isRTL(context) ? padding : 10),
//             title: home02ScreenSearchBarWidget(
//                 context: context,
//                 propertyMetaDataMap: propertyMetaDataMap,
//                 home02ScreenSearchBarWidgetListener: ({filterDataMap, recentSearchesDataMapList, loadProperties}){
//                   homeElegantSliverAppBarListener(filterDataMap: filterDataMap);
//                 }
//             ),
//             background: Column(
//               children: [
//                 home02ScreenTopBarWidget(
//                   context: context,
//                   city: city,
//                   cityMetaDataList: cityMetaDataList,
//                   propertyMetaDataMap: propertyMetaDataMap,
//                   home02ScreenTopBarWidgetListener:  ({filterDataMap, loadProperties}){
//                     homeElegantSliverAppBarListener(filterDataMap: filterDataMap);
//                   },
//                 ),
//                 // HomeScreenSearchTypeWidget(
//                 //   homeScreenSearchTypeWidgetListener: (String selectedItem, String selectedItemSlug){
//                 //     // Do something here
//                 //   }
//                 // ),
//               ],
//             ),
//           );
//         }),
//     elevation: 5,
//   );
// }




typedef Home02ScreenSearchBarWidgetListener = void Function({
  Map<String, dynamic> filterDataMap,
  List<dynamic> recentSearchesDataMapList,
  bool loadProperties,
});

Widget home02ScreenSearchBarWidget({
  @required BuildContext context,
  @required Map<String, dynamic> propertyMetaDataMap,
  final Home02ScreenSearchBarWidgetListener home02ScreenSearchBarWidgetListener,
}){
  return Container(
    padding: const EdgeInsets.only(right: 5, left: 5),
    height: 35,
    child: Row(
      children: [
        Expanded(
          flex: 7,
          child: GestureDetector(
            onTap: () async {
              final Suggestion result = await showSearch(
                context: context,
                delegate: AddressSearch('', forKeyWordSearch: true),
              );
              if (result != null && result.description.isNotEmpty) {
                Map<String, String> keyWordMap = {
                  PROPERTY_KEYWORD: result.description
                };

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SearchResult(
                      dataInitializationMap: keyWordMap,
                      searchPageListener:
                          (Map<String, dynamic> map, String closeOption) {
                        if (closeOption == CLOSE) {
                          Navigator.of(context).pop();
                        }
                      },
                    ),
                  ),
                );
              }
            },
            child: Container(
              padding: EdgeInsets.only(right: GenericMethods.isRTL(context) ? 10 : 0, left: GenericMethods.isRTL(context) ? 0 :10),
              height: 35,
              child: Row(
                children: [
                  AppThemePreferences().appTheme.homeScreenSearchBarIcon,
                  Padding(
                    padding: EdgeInsets.only(right: GenericMethods.isRTL(context) ? 10 : 0, left: GenericMethods.isRTL(context) ? 0 :10),
                    child: genericTextWidget(
                      GenericMethods.getLocalizedString("search"),
                      style: AppThemePreferences().appTheme.searchBarTextStyle,
                    ),
                  )
                ],
              ),
              decoration: BoxDecoration(
                color: AppThemePreferences().appTheme.containerBackgroundColor,
                border: Border.all(
                    color:
                        AppThemePreferences().appTheme.containerBackgroundColor,
                    width: 0),
                borderRadius: BorderRadius.only(
                    topLeft: GenericMethods.isRTL(context) ? const Radius.circular(0) : const Radius.circular(10),
                    bottomLeft: GenericMethods.isRTL(context) ? const Radius.circular(0) : const Radius.circular(10),
                    topRight: GenericMethods.isRTL(context) ? const Radius.circular(10) : const Radius.circular(0),
                    bottomRight: GenericMethods.isRTL(context) ? const Radius.circular(10) : const Radius.circular(0),
                    //
                    ),
              ),
            ),
          ),
        ),
        Expanded(
          child: GestureDetector(
            onTap: () {
              navigateToFilterScreen(
                context: context,
                navigateToFilterScreenListener: (
                    {filterDataMap,
                    recentSearchesDataMapList,
                    loadProperties}) {
                  home02ScreenSearchBarWidgetListener(
                    filterDataMap: filterDataMap,
                    recentSearchesDataMapList: recentSearchesDataMapList,
                    loadProperties: loadProperties,
                  );
                },
              );
            },
            child: Container(
              height: 35,
              padding: EdgeInsets.only(right: GenericMethods.isRTL(context) ? 0 : 10, left: GenericMethods.isRTL(context) ? 10 :0),
              child: GestureDetector(
                  onTap: () {
                    navigateToFilterScreen(
                      context: context,
                      navigateToFilterScreenListener: (
                          {filterDataMap,
                          recentSearchesDataMapList,
                          loadProperties}) {
                        home02ScreenSearchBarWidgetListener(
                          filterDataMap: filterDataMap,
                          recentSearchesDataMapList: recentSearchesDataMapList,
                          loadProperties: loadProperties,
                        );
                      },
                    );
                  },
                  child: AppThemePreferences()
                      .appTheme
                      .homeScreenSearchBarFilterIcon),
              decoration: BoxDecoration(
                color: AppThemePreferences().appTheme.containerBackgroundColor,
                border: Border.all(
                    color:
                        AppThemePreferences().appTheme.containerBackgroundColor,
                    width: 0),
                borderRadius: BorderRadius.only(
                  topLeft: GenericMethods.isRTL(context) ? const Radius.circular(10) : const Radius.circular(0),
                  bottomLeft: GenericMethods.isRTL(context) ? const Radius.circular(10) : const Radius.circular(0),
                  topRight: GenericMethods.isRTL(context) ? const Radius.circular(0) : const Radius.circular(10),
                  bottomRight: GenericMethods.isRTL(context) ? const Radius.circular(0) : const Radius.circular(10),
                ),
              ),
            ),
          ),
        ),
      ],
    ),
  );

  // InkWell(
  //   onTap: () async {
  //     print("click");
  //     final Suggestion result = await showSearch(
  //       context: context,
  //       delegate: AddressSearch('',forKeyWordSearch: true),
  //     );
  //     print("result");
  //     if (result != null&& result.description.isNotEmpty) {
  //       Map<String, String> keyWordMap = {
  //         PROPERTY_KEYWORD:result.description
  //       };
  //
  //       Navigator.push(
  //         context,
  //         MaterialPageRoute(
  //           builder: (context) => SearchResult(
  //             dataInitializationMap: keyWordMap,
  //             searchPageListener: (Map<String, dynamic> map, String closeOption) {
  //               if (closeOption == CLOSE) {
  //                 Navigator.of(context).pop();
  //               }
  //             },
  //           ),
  //         ),
  //       );
  //     }
  //   },
  //   child: SizedBox(
  //     height: 36.0,
  //     width: double.infinity,
  //     child: TextFormField(
  //       readOnly: true,
  //       strutStyle: const StrutStyle(forceStrutHeight: true),
  //       decoration: InputDecoration(
  //         enabledBorder: OutlineInputBorder(
  //           borderRadius: BorderRadius.circular(10.0),
  //           borderSide: BorderSide(
  //             color: AppThemePreferences().appTheme.searchBarBackgroundColor,
  //             width: 0.0,
  //           ),
  //         ),
  //         enabled: false,
  //         border: OutlineInputBorder(
  //           borderRadius: BorderRadius.circular(10.0),
  //           borderSide: BorderSide(
  //             color: AppThemePreferences().appTheme.searchBarBackgroundColor,
  //             width: 0.0,
  //           ),
  //         ),
  //         contentPadding: const EdgeInsets.only(top: 5, left: 0, right: 0),
  //         fillColor: AppThemePreferences().appTheme.searchBar02BackgroundColor,
  //         filled: true,
  //         prefixIcon: Padding(
  //           padding: const EdgeInsets.only(right: 0, left: 0),
  //           child: AppThemePreferences().appTheme.homeScreenSearchBarIcon,
  //         ),
  //         hintText: GenericMethods.getLocalizedString("search"),
  //         hintStyle: AppThemePreferences().appTheme.searchBarTextStyle,
  //         suffixIcon: Padding(
  //           padding: const EdgeInsets.only(right: 10, left: 10),
  //           child: GestureDetector(
  //               onTap: () {
  //                 navigateToFilterScreen(
  //                   context: context,
  //                   navigateToFilterScreenListener: (
  //                       {filterDataMap,
  //                       recentSearchesDataMapList,
  //                       loadProperties}) {
  //                     home02ScreenSearchBarWidgetListener(
  //                       filterDataMap: filterDataMap,
  //                       recentSearchesDataMapList: recentSearchesDataMapList,
  //                       loadProperties: loadProperties,
  //                     );
  //                   },
  //                 );
  //               },
  //               child: AppThemePreferences().appTheme.homeScreenSearchBarFilterIcon),
  //         ),
  //       ),
  //     ),
  //   ),
  // );
}

void navigateToFilterScreen({
  @required BuildContext context,
  final Home02ScreenSearchBarWidgetListener navigateToFilterScreenListener,
}){
  StatefulWidget Function(dynamic context) builder;
  builder = (context) => FilterPage(
    mapInitializeData: HiveStorageManager.readFilterDataInfo(),
    filterPageListener: (Map<String, dynamic> dataMap, String closeOption) {
      if (closeOption == DONE) {
        navigateToFilterScreenListener(
          filterDataMap: HiveStorageManager.readFilterDataInfo(),
          recentSearchesDataMapList: HiveStorageManager.readRecentSearchesInfo(),
          loadProperties: true,
        );
        Navigator.pop(context);

        GenericMethods.navigateToSearchResultScreen(
            context: context,
            dataInitializationMap: HiveStorageManager.readFilterDataInfo(),
            navigateToSearchResultScreenListener: ({filterDataMap, recentSearchesDataMapList, loadProperties}){
              navigateToFilterScreenListener(
                filterDataMap: filterDataMap,
                recentSearchesDataMapList: recentSearchesDataMapList,
                loadProperties: loadProperties,
              );
            }
        );
      } else if(closeOption == CLOSE){
        Navigator.pop(context);
      }else if(closeOption == UPDATE_DATA || closeOption == RESET){
        navigateToFilterScreenListener(
          filterDataMap: dataMap,
          loadProperties: true,
        );
      }else{
        navigateToFilterScreenListener(
          filterDataMap: dataMap,
          loadProperties: false,
        );
      }
    },
  );
  GenericMethods.navigateToRoute(context: context, builder: builder);
}




typedef Home02ScreenTopBarWidgetListener = void Function({
  Map<String, dynamic> filterDataMap,
  bool loadProperties,
});

Widget home02ScreenTopBarWidget({
  @required BuildContext context,
  @required Map<String, dynamic> propertyMetaDataMap,
  @required List<dynamic> cityMetaDataList,
  @required String city,
  Widget searchByIdWidget,
  final Home02ScreenTopBarWidgetListener home02ScreenTopBarWidgetListener,
}){
  return Container(
    padding: const EdgeInsets.only(top: 5.0, left: 20, right: 20),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        home02ScreenLocationWidget(
          context: context,
          city: city,
          propertyMetaDataMap: propertyMetaDataMap,
          cityMetaDataList: cityMetaDataList,
          home02ScreenLocationWidgetListener: ({filterDataMap, loadProperties}){
            home02ScreenTopBarWidgetListener(
              filterDataMap: filterDataMap,
              loadProperties: loadProperties,
            );
          },
        ),
        searchByIdWidget,
        // SearchByIdWidget(),
      ],
    ),
  );
}

Widget home02ScreenLocationWidget({
  @required BuildContext context,
  @required String city,
  @required Map<String, dynamic> propertyMetaDataMap,
  @required List<dynamic> cityMetaDataList,
  final Home02ScreenTopBarWidgetListener home02ScreenLocationWidgetListener,
}){
  return GestureDetector(
    onTap: () {
      if(propertyMetaDataMap == null){
        toastWidget(buildContext: context, text: GenericMethods.getLocalizedString("data_loading"));
      }else{
        if(cityMetaDataList == null) {
          toastWidget(buildContext: context, text: GenericMethods.getLocalizedString("data_loading"));
          return;
        }
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CityPicker(
                citiesMetaDataList: cityMetaDataList,
                cityPickerListener: (String pickedCity, int pickedCityId, String pickedCitySlug) {
                  Map<String, dynamic> filterDataMap = HiveStorageManager.readFilterDataInfo();
                  filterDataMap[CITY] = pickedCity;
                  filterDataMap[CITY_ID] = pickedCityId;
                  filterDataMap[CITY_SLUG] = pickedCitySlug;
                  HiveStorageManager.storeFilterDataInfo(map: filterDataMap);

                  home02ScreenLocationWidgetListener(
                    filterDataMap: filterDataMap,
                    loadProperties: true,
                  );
                }),
          ),
        );
      }
    },
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        const SizedBox(width: 35),
        // Padding(
        //   padding: const EdgeInsets.only(left: 15),
        //   child: AppThemePreferences().appTheme.homeScreenTopBarLocationIcon,
        // ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            genericTextWidget(
              GenericMethods.getLocalizedString("current_location"),
              strutStyle: const StrutStyle(forceStrutHeight: true),
              style: AppThemePreferences().appTheme.subTitleTextStyle
            ),
            Padding(
              padding: const EdgeInsets.only(top: 5.0),
              child: Row(
                children: [
                  AppThemePreferences().appTheme.homeScreenTopBarLocationFilledIcon,
                  Padding(
                    padding: const EdgeInsets.only(left: 4.0,top: 2),
                    child: genericTextWidget(
                      city,
                      strutStyle: const StrutStyle(forceStrutHeight: true),
                      style:  AppThemePreferences().appTheme.titleTextStyle,
                    ),
                  ),
                  AppThemePreferences().appTheme.homeScreenTopBarDownArrowIcon,
                ],
              ),
            ),
          ],
        ),
        // Padding(
        //   padding: const EdgeInsets.only(left: 10),
        //   child: Column(
        //     mainAxisAlignment: MainAxisAlignment.end,
        //     crossAxisAlignment: CrossAxisAlignment.start,
        //     children: [
        //       genericTextWidget(
        //         GenericMethods.getLocalizedString("location"),
        //         strutStyle: const StrutStyle(forceStrutHeight: true),
        //       ),
        //       Padding(
        //         padding: const EdgeInsets.only(top: 2.0),
        //         child: genericTextWidget(
        //           city,
        //           strutStyle: const StrutStyle(forceStrutHeight: true),
        //           style:  AppThemePreferences().appTheme.locationWidgetTextStyle,
        //         ),
        //       ),
        //     ],
        //   ),
        // ),
        // Padding(
        //     padding: const EdgeInsets.only(left: 5, top: 20),
        //     child: CircleAvatar(
        //       radius: 7,
        //       backgroundColor: AppThemePreferences().appTheme.homeScreenTopBarRightArrowBackgroundColor,
        //       // backgroundColor: AppThemePreferences().appTheme.primaryColor,
        //       child: AppThemePreferences().appTheme.homeScreenTopBarRightArrowIcon,
        //     )),
      ],
    ),
  );
}

