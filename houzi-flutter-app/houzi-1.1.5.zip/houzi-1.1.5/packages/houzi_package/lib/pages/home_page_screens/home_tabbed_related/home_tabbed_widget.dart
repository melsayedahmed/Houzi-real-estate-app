import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/general_notifier.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/property_manager_files/property_manager.dart';
import 'package:houzi_package/files/user_log_provider.dart';
import 'package:houzi_package/pages/home_page_screens/home_screen.dart';
import 'package:houzi_package/pages/home_page_screens/home_tabbed_related/related_widgets/home_tabbed_sliver_app_bar.dart';
import 'package:houzi_package/pages/home_page_screens/home_tabbed_related/related_widgets/home_tabbed_widgets_listing.dart';
import 'package:houzi_package/pages/property_details_page.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_drawer_widgets/home_screen_drawer_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:provider/provider.dart';
// import 'package:pull_to_refresh/pull_to_refresh.dart';

class HomeTabbed extends StatefulWidget {

  final GlobalKey<ScaffoldState> scaffoldKey;

  const HomeTabbed({
    Key key,
    this.scaffoldKey
  }) : super(key: key);

  @override
  _HomeTabbedState createState() => _HomeTabbedState();
}

class _HomeTabbedState extends State<HomeTabbed>  with TickerProviderStateMixin {

  final PropertyBloc _propertyBloc = PropertyBloc();

  int _selectedCityId;

  String _selectedCity = "";

  String _userImage = "";
  String _userName = "";

  List<dynamic> _cityMetaDataList = [];
  List<dynamic> _propertyTypeMetaDataList = [];

  Map<String, dynamic> filterDataMap = {};
  Map<String, dynamic> _propertyMetaDataMap = {};

  bool isFree = false;
  int uploadedPropertyId;

  bool _isLoggedIn = false;
  String _userRole;

  VoidCallback  propertyUploadListener;
  VoidCallback  generalNotifierListener;

  bool errorWhileDataLoading = false;

  List<dynamic> propertyStatusListWithData = [];

  List<dynamic> homeConfigList = [];
  List<dynamic> drawerConfigList = [];

  bool needToRefresh = false;

  int _tabBarInitialIndex = 0;

  String selectedSectionType;

  TabController _tabController;

  // final RefreshController _refreshController = RefreshController(initialRefresh: false);

  // final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey = GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    super.initState();
    loadData();
    getHomeConfigFile();
    getDrawerConfigFile();

    _tabController = TabController(
        length: homeConfigList.length,
        initialIndex: _tabBarInitialIndex,
        vsync: this);
  }

  checkInternetAndLoadData(){
    needToRefresh = true;
    errorWhileDataLoading = false;
    loadData();
    if(mounted){
      setState(() {});
    }
  }

  void loadData(){
    /// Load Data From Storage
    filterDataMap = HiveStorageManager.readFilterDataInfo();
    _userRole = HiveStorageManager.getUserRole();
    _userName = HiveStorageManager.getUserName();
    _userImage = HiveStorageManager.getUserAvatar();
    _cityMetaDataList = HiveStorageManager.readCitiesMetaData();
    _propertyTypeMetaDataList = HiveStorageManager.readPropertyTypesMetaData();

    /// General Notifier Listener
    generalNotifierListener = () {
      if (GeneralNotifier().change == GeneralNotifier.USER_PROFILE_UPDATE) {
        if(mounted) {
          setState(() {
            _userName = HiveStorageManager.getUserName();
            _userImage = HiveStorageManager.getUserAvatar();
          });
        }
      }

      if (GeneralNotifier().change == GeneralNotifier.APP_CONFIGURATIONS_UPDATED) {
        if(mounted) {
          setState(() {
            getHomeConfigFile();
            getDrawerConfigFile();
          });
        }
      }
    };

    /// Property Upload Listener
    propertyUploadListener = () {
      if(mounted) {
        setState(() {
          isFree = PropertyManager().isPropertyUploaderFree;
          uploadedPropertyId = PropertyManager().uploadedPropertyId;
        });
      }

      if(uploadedPropertyId != null){
        int propertyId = uploadedPropertyId;
        toastWidget(
            buildContext: context,
            showButton: true,
            buttonText: GenericMethods.getLocalizedString("view_property"),
            text: GenericMethods.getLocalizedString("property_uploaded"),
            toastDuration: 4,
            onButtonPressed: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PropertyDetailsPage(
                    propertyID: propertyId,
                    heroId: '$propertyId$SINGLE',
                  ),
                ),
              );
            }
        );
        PropertyManager().uploadedPropertyId = null;
      }
    };
    PropertyManager().addListener(propertyUploadListener);

    GeneralNotifier().addListener(generalNotifierListener);

    if(Provider.of<UserLoggedProvider>(context,listen: false).isLoggedIn){
      PropertyManager().uploadProperty();
      if(mounted) {
        setState(() {
          _isLoggedIn = true;
        });
      }
    }

    /// Fetch the last selected City Data form Filter Data
    if(filterDataMap != null){
      if(mounted) {
        setState(() {
          if (filterDataMap.containsKey(CITY)) {
            _selectedCity = filterDataMap[CITY];
          }
          if (filterDataMap.containsKey(CITY_ID)) {
            _selectedCityId = filterDataMap[CITY_ID];
          }
        });
      }
    }

    loadRemainingData();

  }

  void loadRemainingData() {
    fetchPropertyMetaData().then((value) {
      if(value['response'].runtimeType == Response){
        errorWhileDataLoading = true;
      }else{
        _propertyMetaDataMap = value;
        _cityMetaDataList = HiveStorageManager.readCitiesMetaData();
        _propertyTypeMetaDataList = HiveStorageManager.readPropertyTypesMetaData();

        GenericMethods.updateTouchBaseDataAndConfigurations(_propertyMetaDataMap);
      }

      needToRefresh = false;
      if(mounted){
        setState(() {});
      }
      return null;
    });
  }

  @override
  void dispose() {
    super.dispose();

    _cityMetaDataList = [];
    filterDataMap = {};
    _propertyMetaDataMap = {};

    if (propertyUploadListener != null) {
      PropertyManager().removeListener(propertyUploadListener);
    }
    if (generalNotifierListener != null) {
      GeneralNotifier().removeListener(generalNotifierListener);
    }
    if(_tabController != null){
      _tabController.dispose();
    }
  }

  clearMetaData(){
    HiveStorageManager.clearData();
  }

  @override
  Widget build(BuildContext context) {
    if(_cityMetaDataList == null || _cityMetaDataList.isEmpty){
      _cityMetaDataList = HiveStorageManager.readCitiesMetaData();
    }

    if(_propertyTypeMetaDataList == null || _propertyTypeMetaDataList.isEmpty){
      _propertyTypeMetaDataList = HiveStorageManager.readPropertyTypesMetaData();
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: HomeScreen().getSystemUiOverlayStyle(design: HOME_SCREEN_DESIGN),
        child: DefaultTabController(
          length: homeConfigList.length,
          child: Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            key: widget.scaffoldKey,
            drawer: HomeScreenDrawerWidget(
              drawerConfigDataList: drawerConfigList,
              drawerInfoData: {
                USER_PROFILE_NAME : _userName,
                USER_PROFILE_IMAGE : _userImage,
                USER_ROLE : _userRole,
                USER_LOGGED_IN : _isLoggedIn,
              },
              homeScreenDrawerWidgetListener: (bool loginInfo){
                setState(() {
                  _isLoggedIn = loginInfo;
                });
              },
            ),
            body: Stack(
              children: [
                NestedScrollView(
                    headerSliverBuilder:
                        (BuildContext context, bool innerBoxIsScrolled) {
                          return <Widget>[
                            /// Home01 Screen Sliver App Bar Widget
                            HomeTabbedSliverAppBar(
                              userName: _userName,
                              propertyMetaDataMap: _propertyMetaDataMap,
                              onLeadingIconPressed: () =>
                                  widget.scaffoldKey.currentState.openDrawer(),
                              homeTabbedSliverAppBarListener: (filterDataMap) {
                                updateData(filterDataMap);
                              },
                            ),
                            SliverPersistentHeader(
                              delegate: _SliverAppBarDelegate(
                                TabBar(
                                  tabs: homeConfigList.map((item) {
                                    return Tab(text: GenericMethods.getLocalizedString(item[titleKey]));
                                  }).toList(),
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  // padding: EdgeInsets.only(bottom: 10),
                                  unselectedLabelColor: Colors.grey[400],
                                  unselectedLabelStyle: TextStyle(
                                    // fontWeight: FontWeight.w300,
                                  ),
                                  indicatorColor: Colors.white,
                                  isScrollable: true,
                                  // indicatorPadding: EdgeInsets.symmetric(horizontal: 75),
                                  labelColor: Colors.white,
                                  onTap: (index){
                                    selectedSectionType = homeConfigList[index][sectionTypeKey];
                                  },
                                  controller: _tabController,
                                ),
                              ),
                              pinned: true,
                              // floating: true,
                            ),
                          ];
                        },
                  body: TabBarView(
                    controller: _tabController,
                    children: homeConfigList.map((item) {
                      return item[sectionTypeKey] == recentSearchKey ? SingleChildScrollView(
                        child: HomeTabbedListingsWidget(
                          homeScreenData: item,
                          selectedItem: selectedSectionType,
                          homeTabbedListingsWidgetListener: (bool errorOccur, bool dataLoadingComplete) {

                          },
                        ),
                      ) :
                      RefreshIndicator(
                        edgeOffset: 0.0,
                        onRefresh: () async {
                          if(selectedSectionType == item[sectionTypeKey]){
                            setState(() {
                              clearMetaData();
                              needToRefresh = true;
                            });
                            loadData();
                          }

                          return null;
                        },
                        child: SingleChildScrollView(
                          child: HomeTabbedListingsWidget(
                            homeScreenData: item,
                            refresh: needToRefresh,
                            selectedItem: selectedSectionType,
                            homeTabbedListingsWidgetListener: (bool errorOccur, bool dataLoadingComplete) {
                              errorWhileDataLoading = errorOccur;
                              if(dataLoadingComplete){
                                setState(() {
                                  needToRefresh = false;
                                });
                              }
                            },
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
                if(errorWhileDataLoading) internetConnectionErrorWidget(),
              ],
            ),

          // ),
      ),
        ),
    );
  }

  Widget internetConnectionErrorWidget(){
    return Positioned(
        bottom: 0,
        child: SafeArea(
            top: false,
            child: noInternetBottomActionBar(context, ()=> checkInternetAndLoadData())));
  }

  Future<Map<String, dynamic>> fetchPropertyMetaData() async {
    Map<String, dynamic> _metaDataMap = {};
    _metaDataMap = await _propertyBloc.fetchPropertyMetaData();
    return _metaDataMap;
  }

  String getSelectedCity(){
    if(filterDataMap[CITY] != null && filterDataMap[CITY].isNotEmpty){
      return filterDataMap[CITY];
    } else if(_selectedCity != null && _selectedCity.isNotEmpty){
      return _selectedCity;
    }

    return GenericMethods.getLocalizedString("please_select");
  }

  int getSelectedStatusIndex(){
    if(filterDataMap != null && filterDataMap.containsKey(PROPERTY_STATUS_SLUG)
        && filterDataMap[PROPERTY_STATUS_SLUG] != null &&
        filterDataMap[PROPERTY_STATUS_SLUG].isNotEmpty){
      int index = propertyStatusListWithData.indexWhere((element) => element.slug == filterDataMap[PROPERTY_STATUS_SLUG]);
      if(index != -1){
        return index;
      }

      return 0;
    }

    return 0;
  }

  updateData(Map<String, dynamic> map) {
    if (mounted) {
      setState(() {
        filterDataMap = map;
        var oldSelectedCityId = _selectedCityId;
        _selectedCity = filterDataMap[CITY] ?? GenericMethods.getLocalizedString("please_select");
        _selectedCityId = filterDataMap[CITY_ID] ?? null;
        if (oldSelectedCityId != _selectedCityId) {
          saveSelectedCityInfo(_selectedCityId, _selectedCity, filterDataMap[CITY_SLUG]);
        }
        GeneralNotifier().publishChange(GeneralNotifier.FILTER_DATA_LOADING_COMPLETE);
      });
    }
  }

  void saveSelectedCityInfo(int cityId, String cityName, String citySlug){
    HiveStorageManager.storeSelectedCityInfo(data:
    {
      CITY : cityName,
      CITY_ID : cityId,
      CITY_SLUG: citySlug,
    }
    );
    GeneralNotifier().publishChange(GeneralNotifier.CITY_DATA_UPDATE);
  }

  getHomeConfigFile() {
    var homeConfigListData = HiveStorageManager.readHomeConfigListData() ?? [];
    if (homeConfigListData != null && homeConfigListData.isNotEmpty) {
      homeConfigList.clear();
      if(mounted) {
        setState(() {
          homeConfigList = jsonDecode(homeConfigListData);
          // homeConfigList.removeWhere((homeItem) {
          //   return (homeItem[sectionTypeKey] == adKey ||
          //       homeItem[sectionTypeKey] == termWithIconsTermKey);
          // });

          homeConfigList.removeWhere((homeItem) {
            return (homeItem[sectionTypeKey] == adKey);
          });

          // Set the initial index of TabBar
          for(var item in homeConfigList){
            if(item[sectionTypeKey] != termWithIconsTermKey && item[sectionTypeKey] != recentSearchKey){
              _tabBarInitialIndex = homeConfigList.indexOf(item);
              selectedSectionType = homeConfigList[_tabBarInitialIndex][sectionTypeKey];
              // print("selected sectionTypeKey: ${item[sectionTypeKey]}");
              break;
            }
          }
        });
      }
    }
  }

  getDrawerConfigFile() {
    var storedDrawerConfig = HiveStorageManager.readDrawerConfigListData() ?? [];
    if (storedDrawerConfig != null && storedDrawerConfig.isNotEmpty) {
      drawerConfigList.clear();
      if(mounted) {
        setState(() {
          drawerConfigList = jsonDecode(storedDrawerConfig);
        });
      }
    }
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {

  _SliverAppBarDelegate(this._tabBar);

  final TabBar _tabBar;

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppThemePreferences().appTheme.primaryColor,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}
