import 'package:flutter/material.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_page.dart';

import '../common/constants.dart';
import '../files/generic_methods/generic_methods.dart';
import '../widgets/data_loading_widget.dart';
import '../widgets/generic_text_widget.dart';

typedef MapViewListener = void Function(Map<String,String> coordinatesMap, bool stickToIndex);
class MapView extends StatefulWidget {

  List<dynamic> _listArticles;
  MapViewListener mapViewListener;
  bool showWaitingWidget;

  MapView(List<dynamic> listArticles, {mapViewListener,bool showWaitingWidget}) {
    this._listArticles = listArticles;
    this.mapViewListener = mapViewListener;
    this.showWaitingWidget = showWaitingWidget;
  }

  int _selectedArticleIndex = -1;
  int _lastSelectedIndex = -1;

  bool _showAllMap = false;
  bool _snapCameraToSelectedIndex = false;


  set snapCameraToSelectedIndex(bool value) {
    _snapCameraToSelectedIndex = value;
  }

  set showAllMap(bool value) {
    _showAllMap = value;
  }

  set selectedArticleIndex(int value) {
    // _lastSelectedIndex = _selectedArticleIndex;
    _selectedArticleIndex = value;
  }

  set lastSelectedIndex(int value) {
    _lastSelectedIndex = value;
  }

  @override
  State<MapView> createState() => _MapViewState();
}

class _MapViewState extends State<MapView> with AutomaticKeepAliveClientMixin<MapView> {

  // GeoCode geoCode = GeoCode();

  bool showSearchInThisArea = false;

  double mapZoom = 11;//11;
  bool showMap = true;

  Set<Marker> googleMapMarkers = {};

  List<String> addressCoordinatesList = [];
  final _initialCameraPosition = CameraPosition(
    target: LatLng(37.4219999, -122.0862462),
    zoom: 11,
  );
  GoogleMapController _googleMapController;

  LatLng _lastMapPosition;
  int counter = 0;
  int latestLatInInt;
  int latestLngInInt;

  bool mapViewAll = true;

  double x0, x1, y0, y1;
  GoogleMap map, tempMap;



  @override
  void initState() {
    super.initState();

  }

  setupMarkersIfPossible() {
    googleMapMarkers.clear();
    widget._listArticles.removeWhere((element) => element is AdWidget);
    widget._listArticles.map((mapItem) {
      Article item = mapItem;
      final heroId = item.id.toString() + "-marker";
      final propId = item.id;
      var address = item.address.coordinates.toString();
      if ((address != null) && (address.isNotEmpty) && (address != ',')) {
        var temp = address.split(",");

        double lat = double.parse(temp[0]);
        double lng = double.parse(temp[1]);
        latestLatInInt = lat.toInt();
        latestLngInInt = lng.toInt();
        if (x0 == null) {
          x0 = x1 = lat;
          y0 = y1 = lng;
        } else {
          if (lat > x1) x1 = lat;
          if (lat < x0) x0 = lat;
          if (lng > y1) y1 = lng;
          if (lng < y0) y0 = lng;
        }

        Marker marker = Marker(
            markerId: MarkerId(heroId),
            position: LatLng(lat, lng),
            infoWindow: InfoWindow(
                title: item.title.toString(),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PropertyDetailsPage(
                          propertyID: propId, heroId: heroId),
                    ),
                  );
                }));
        if(mounted) {
          setState(() {
            googleMapMarkers.add(marker);
          });
        }
      }
    }).toList();

    // if (x1 != null && x0 != null && y1 != null && x0 != null) {
    //   LatLngBounds latLngBounds =
    //   LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
    //   if (_googleMapController != null) {
    //     CameraUpdate cameraUpdate = CameraUpdate.newLatLngBounds(latLngBounds, 190.0);
    //     _googleMapController.animateCamera(cameraUpdate);
    //     // setState(() {
    //     //   // showSearchInThisArea = false;
    //     //   // widget._enableCameraMovement = false;
    //     // });
    //   }
    // }
    // if (widget._snapCameraToSelectedIndex) {
    //   if (x1 != null && x0 != null && y1 != null && x0 != null) {
    //     LatLngBounds latLngBounds =
    //         LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
    //     if (_googleMapController != null) {
    //       CameraUpdate cameraUpdate =
    //           CameraUpdate.newLatLngBounds(latLngBounds, 190.0);
    //       _googleMapController.animateCamera(cameraUpdate);
    //       setState(() {
    //         // showSearchInThisArea = false;
    //         // widget._enableCameraMovement = false;
    //       });
    //
    //     }
    //   }
    // }

  }

  @override
  void dispose() {

    if(_googleMapController != null){
      _googleMapController.dispose();
    }
    super.dispose();
  }

  GoogleMapController getController() {
    return _googleMapController;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    showMap = widget._showAllMap;
    setupMarkersIfPossible();

    map = GoogleMap(
      myLocationButtonEnabled: false,
      zoomGesturesEnabled: true,
      tiltGesturesEnabled: false,
      zoomControlsEnabled: true,

      onMapCreated: (controller) {
        _googleMapController = controller;
        return _googleMapController;
      },
      onCameraMove:(CameraPosition cameraPosition){
        mapZoom = cameraPosition.zoom;
        _lastMapPosition = cameraPosition.target;
        if (cameraPosition.target.latitude.toInt() != latestLatInInt
            && cameraPosition.target.longitude.toInt() != latestLngInInt){
          showSearchInThisArea = true;
        }
        // print("camera pos lat: ${cameraPosition.target.latitude.toInt()}");
        // print("camera pos lng: ${cameraPosition.target.longitude.toInt()}");
        // print("latestLatInInt: ${latestLatInInt}");
        // print("latestLngInInt: ${latestLngInInt}");

        widget._snapCameraToSelectedIndex = false;

      },
      onCameraIdle: (){
        if(mounted){
          setState(() {});
        }
      },
      markers: googleMapMarkers,
      initialCameraPosition: _initialCameraPosition,

    );



    if (_googleMapController != null) {
      if (widget._lastSelectedIndex != -1 && widget._listArticles!=null && widget._listArticles.isNotEmpty
          && widget._listArticles.length > widget._lastSelectedIndex) {

        var item = widget._listArticles[widget._lastSelectedIndex];

        final heroId = item.id.toString() + "-marker";
        var address = item.address.coordinates.toString();
        if ((address != null) && (address.isNotEmpty) && (address != ',')) {
          _googleMapController.hideMarkerInfoWindow(MarkerId(heroId));
        }
      }

      if (widget._snapCameraToSelectedIndex && widget._selectedArticleIndex >= 0 && widget._listArticles!=null && widget._listArticles.isNotEmpty
          && widget._listArticles.length > widget._lastSelectedIndex) {
        var item = widget._listArticles[widget._selectedArticleIndex];
        final heroId = item.id.toString() + "-marker";

        var address = item.address.coordinates.toString();
        if ((address != null) && (address.isNotEmpty) && (address != ',')) {
          _googleMapController.showMarkerInfoWindow(MarkerId(heroId));
          var temp = address.split(",");
          var location = CameraPosition(
              target: LatLng(double.parse(temp[0]), double.parse(temp[1])), zoom: mapZoom);

          latestLatInInt = double.parse(temp[0]).toInt();
          latestLngInInt = double.parse(temp[1]).toInt();

          // print("property: latlng: $latestLatInInt, $latestLngInInt");
          _googleMapController.animateCamera(CameraUpdate.newCameraPosition(location));
          // if(widget._snapCameraToSelectedIndex){
          //   var location = CameraPosition(
          //       target: LatLng(double.parse(temp[0]), double.parse(temp[1])), zoom: mapZoom);
          //   _googleMapController.animateCamera(CameraUpdate.newCameraPosition(location));
          //   // setState(() {
          //   //   widget._enableCameraMovement = false;
          //   //  // showSearchInThisArea = true;
          //   // });
          //
          // }
        }

      }
    }

    if (showMap == true) {
      if(x1 != null && x0 != null && y1 != null && x0 != null){
        LatLngBounds latLngBounds = LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
        if (_googleMapController != null) {
          CameraUpdate cameraUpdate = CameraUpdate.newLatLngBounds(latLngBounds, 190.0);
          // _googleMapController.moveCamera(cameraUpdate);
          _googleMapController.animateCamera(cameraUpdate);
        }
      }
    }


    return Scaffold(
      body: Stack(
        children: [
          map,
          showSearchInThisArea
              ? Container(
                  margin: EdgeInsets.only(top: 120),
                  alignment: Alignment.topCenter,
                  child: FloatingActionButton.extended(
                    backgroundColor: AppThemePreferences().appTheme.searchBarBackgroundColor,
                    onPressed: () {
                      var visibleRegion = _googleMapController.getVisibleRegion();
                      visibleRegion.then((value) {
                        var distance = Geolocator.distanceBetween(
                            value.northeast.latitude,
                            value.northeast.longitude,
                            value.southwest.latitude,
                            value.southwest.longitude);

                        double distanceInKiloMeters = distance / 1000;
                        double roundDistanceInKM = double.parse((distanceInKiloMeters).toStringAsFixed(2));

                        Map<String, String> coordinatesMap = {
                          LATITUDE: _lastMapPosition.latitude.toString(),
                          LONGITUDE: _lastMapPosition.longitude.toString(),
                          RADIUS: roundDistanceInKM.toString(),
                        };
                        widget.mapViewListener(coordinatesMap, false);
                        if(mounted) {
                          setState(() {
                            widget.showWaitingWidget = true;
                            showSearchInThisArea = false;
                            widget._snapCameraToSelectedIndex = false;
                          });
                        }
                      });
                    },
                    label: genericTextWidget(
                        GenericMethods.getLocalizedString("search_in_this_area"),
                        style: AppThemePreferences().appTheme.filterPageChoiceChipTextStyle,
                    ),
                  ),
                )
              : Container(),
          widget.showWaitingWidget == true
              ? Container(
            margin: const EdgeInsets.only(top: 160),
            alignment: Alignment.topCenter,
            child: SizedBox(
              width: 70,
              height: 70,
              child: loadingBallBeatWidget(),
            ),
          )
              : Container()
        ],
      ),
      // floatingActionButton:

      // builder,
    );
  }

  @override
  bool get wantKeepAlive => true;

}




// import 'dart:async';
// import 'dart:typed_data';
// import 'dart:ui';
//
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// // import 'package:flutter_gen/gen_l10n/app_localizations.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_maps_cluster_manager/google_maps_cluster_manager.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:houzi_package/files/app_preferences/app_preferences.dart';
// import 'package:houzi_package/models/article.dart';
//
// import '../common/constants.dart';
// import '../files/generic_methods/general_notifier.dart';
// import '../files/generic_methods/generic_methods.dart';
// import '../widgets/data_loading_widget.dart';
// import '../widgets/generic_text_widget.dart';
//
// class Place with ClusterItem {
//   final String name;
//   final LatLng latLng;
//
//   Place({this.name, this.latLng});
//
//   @override
//   LatLng get location => latLng;
// }
//
// typedef MapViewListener = void Function(Map<String,String> coordinatesMap, bool stickToIndex);
// class MapView extends StatefulWidget {
//
//   final List<dynamic> _listArticles;
//   final MapViewListener mapViewListener;
//   bool showWaitingWidget;
//
//   MapView(this._listArticles, {Key key, this.mapViewListener,this.showWaitingWidget}) : super(key: key);
//
//   int _selectedArticleIndex = -1;
//   int _lastSelectedIndex = -1;
//
//   bool _showAllMap = false;
//   bool _snapCameraToSelectedIndex = false;
//
//
//   set snapCameraToSelectedIndex(bool value) {
//     _snapCameraToSelectedIndex = value;
//   }
//
//   set showAllMap(bool value) {
//     _showAllMap = value;
//   }
//
//   set selectedArticleIndex(int value) {
//     // _lastSelectedIndex = _selectedArticleIndex;
//     _selectedArticleIndex = value;
//   }
//
//   set lastSelectedIndex(int value) {
//     _lastSelectedIndex = value;
//   }
//
//   @override
//   State<MapView> createState() => _MapViewState();
// }
//
// class _MapViewState extends State<MapView> with AutomaticKeepAliveClientMixin<MapView> {
//
//   // GeoCode geoCode = GeoCode();
//
//   bool showSearchInThisArea = false;
//
//   double mapZoom = 11;//11;
//   bool showMap = true;
//
//   Set<Marker> googleMapMarkers = {};
//
//   List<String> addressCoordinatesList = [];
//   final _initialCameraPosition =
//   // CameraPosition(target: LatLng(48.856613, 2.352222), zoom: 12.0);
//   CameraPosition(target: LatLng(37.4219999, -122.0862462), zoom: 14,);
//   GoogleMapController _googleMapController;
//   Completer<GoogleMapController> _controller = Completer();
//   LatLng _lastMapPosition;
//   int counter = 0;
//   int latestLatInInt;
//   int latestLngInInt;
//
//   bool mapViewAll = true;
//
//   double x0, x1, y0, y1;
//   GoogleMap map, tempMap;
//   ClusterManager manager;
//
//   VoidCallback generalNotifierListener;
//
//
//   @override
//   void initState() {
//
//
//
//     setupMarkersIfPossible();
//     manager = _initClusterManager();
//     super.initState();
//
//     // if (GeneralNotifier().change == GeneralNotifier.DATA_FETCH_FROM_API) {
//     //     setupMarkersIfPossible();
//     // }
//     //
//     // GeneralNotifier().addListener(generalNotifierListener);
//
//   }
//
//   List<Place> items = [];
//   int itemsListLength = 0;
//
//   ClusterManager _initClusterManager() {
//     return ClusterManager<Place>(items, _updateMarkers, markerBuilder: _markerBuilder,levels: [1, 3, 5, 7, 9, 11, 13, 15, 17]);
//   }
//
//   void _updateMarkers(Set<Marker> markers) {
//     print('Updated ${markers.length} markers');
//     setState(() {
//       googleMapMarkers = markers;
//     });
//   }
//
//   Future<Marker> Function(Cluster<dynamic>) get _markerBuilder {
//     return (cluster) async {
//       // print("location: ${cluster.location}");
//       return Marker(
//         markerId: MarkerId(cluster.getId()),
//         position: cluster.location,
//         onTap: () {
//           // print('---- $cluster');
//           for (var p in cluster.items) {
//             // print(p);
//           }
//         },
//         icon: cluster.count != 1 ?  await _getMarkerBitmap(cluster.isMultiple ? 125 : 75,
//             text: cluster.isMultiple ? cluster.count.toString() : null) : BitmapDescriptor.defaultMarker
//         // await BitmapDescriptor.fromAssetImage(
//         //     ImageConfiguration(size: Size(96, 96)),
//         //     'assets/location.jpg'),
//       );
//     };
//   }
//
//   Future<BitmapDescriptor> _getMarkerBitmap(int size, {String text}) async {
//     if (kIsWeb) size = (size / 2).floor();
//
//     final PictureRecorder pictureRecorder = PictureRecorder();
//     final Canvas canvas = Canvas(pictureRecorder);
//     final Paint paint1 = Paint()..color = Colors.orange;
//     final Paint paint2 = Paint()..color = Colors.white;
//
//     canvas.drawCircle(Offset(size / 2, size / 2), size / 2.0, paint1);
//     canvas.drawCircle(Offset(size / 2, size / 2), size / 2.2, paint2);
//     canvas.drawCircle(Offset(size / 2, size / 2), size / 2.8, paint1);
//
//     if (text != null) {
//       TextPainter painter = TextPainter(textDirection: TextDirection.ltr);
//       painter.text = TextSpan(
//         text: text,
//         style: TextStyle(
//             fontSize: size / 3,
//             color: Colors.white,
//             fontWeight: FontWeight.normal),
//       );
//       painter.layout();
//       painter.paint(
//         canvas,
//         Offset(size / 2 - painter.width / 2, size / 2 - painter.height / 2),
//       );
//     }
//
//     final img = await pictureRecorder.endRecording().toImage(size, size);
//     final data = await img.toByteData(format: ImageByteFormat.png);
//
//     return BitmapDescriptor.fromBytes(data.buffer.asUint8List());
//   }
//
//   setupMarkersIfPossible() {
//    // googleMapMarkers.clear();
//
//     widget._listArticles.map((mapItem) {
//       Article item = mapItem;
//       final heroId = item.id.toString() + "-marker";
//       final propId = item.id;
//       var address = item.address.coordinates.toString();
//       if ((address != null) && (address.isNotEmpty) && (address != ',')) {
//         var temp = address.split(",");
//
//         double lat = double.parse(temp[0]);
//         double lng = double.parse(temp[1]);
//         latestLatInInt = lat.toInt();
//         latestLngInInt = lng.toInt();
//         if (x0 == null) {
//           x0 = x1 = lat;
//           y0 = y1 = lng;
//         } else {
//           if (lat > x1) x1 = lat;
//           if (lat < x0) x0 = lat;
//           if (lng > y1) y1 = lng;
//           if (lng < y0) y0 = lng;
//         }
//
//         // Marker marker = Marker(
//         //     markerId: MarkerId(heroId),
//         //     position: LatLng(lat, lng),
//         //     infoWindow: InfoWindow(
//         //         title: item.title.toString(),
//         //         onTap: () {
//         //           Navigator.push(
//         //             context,
//         //             MaterialPageRoute(
//         //               builder: (context) => PropertyDetailsPage(
//         //                   propertyID: propId, heroId: heroId),
//         //             ),
//         //           );
//         //         }));
//
//         items.add(Place(
//             name: heroId,
//             latLng: LatLng(lat, lng)));
//         if(mounted) {
//           setState(() {});
//         }
//       }
//     }).toList();
//
//     if (items != null && items.isNotEmpty) {
//       print(items.length);
//       print("calling UPDATE");
//
//       manager.setItems(items);
//       if(items.length != itemsListLength) {
//           itemsListLength = items.length;
//
//       }
//
//     }
//
//     //manager = _initClusterManager();
//
//     // if (x1 != null && x0 != null && y1 != null && x0 != null) {
//     //   LatLngBounds latLngBounds =
//     //   LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
//     //   if (_googleMapController != null) {
//     //     CameraUpdate cameraUpdate = CameraUpdate.newLatLngBounds(latLngBounds, 190.0);
//     //     _googleMapController.animateCamera(cameraUpdate);
//     //     // setState(() {
//     //     //   // showSearchInThisArea = false;
//     //     //   // widget._enableCameraMovement = false;
//     //     // });
//     //   }
//     // }
//     // if (widget._snapCameraToSelectedIndex) {
//     //   if (x1 != null && x0 != null && y1 != null && x0 != null) {
//     //     LatLngBounds latLngBounds =
//     //         LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
//     //     if (_googleMapController != null) {
//     //       CameraUpdate cameraUpdate =
//     //           CameraUpdate.newLatLngBounds(latLngBounds, 190.0);
//     //       _googleMapController.animateCamera(cameraUpdate);
//     //       setState(() {
//     //         // showSearchInThisArea = false;
//     //         // widget._enableCameraMovement = false;
//     //       });
//     //
//     //     }
//     //   }
//     // }
//
//   }
//
//   @override
//   void dispose() {
//
//     if(_googleMapController != null){
//       _googleMapController.dispose();
//     }
//     super.dispose();
//   }
//
//   GoogleMapController getController() {
//     return _googleMapController;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     super.build(context);
//
//     showMap = widget._showAllMap;
//     if(widget._listArticles.length!=null && widget._listArticles.length != itemsListLength) {
//       setupMarkersIfPossible();
//
//     }
//
//
//     map = GoogleMap(
//       myLocationButtonEnabled: false,
//       zoomGesturesEnabled: true,
//       tiltGesturesEnabled: false,
//       zoomControlsEnabled: true,
//
//       onMapCreated: (controller) {
//         _controller.complete(controller);
//         manager.setMapId(controller.mapId);
//         _googleMapController = controller;
//         // return _googleMapController;
//       },
//       onCameraMove:(CameraPosition cameraPosition){
//
//         manager.onCameraMove(cameraPosition,forceUpdate: true);
//         mapZoom = cameraPosition.zoom;
//         _lastMapPosition = cameraPosition.target;
//         if (cameraPosition.target.latitude.toInt() != latestLatInInt
//             && cameraPosition.target.longitude.toInt() != latestLngInInt){
//           showSearchInThisArea = true;
//         }
//         // print("camera pos lat: ${cameraPosition.target.latitude.toInt()}");
//         // print("camera pos lng: ${cameraPosition.target.longitude.toInt()}");
//         // print("latestLatInInt: ${latestLatInInt}");
//         // print("latestLngInInt: ${latestLngInInt}");
//
//         widget._snapCameraToSelectedIndex = false;
//
//       },
//       // onCameraIdle: (){
//       //
//       //   if(mounted){
//       //     setState(() {});
//       //   }
//       //   manager.updateMap;
//       // },
//       onCameraIdle: manager.updateMap,
//
//       markers: googleMapMarkers,
//       initialCameraPosition: _initialCameraPosition,
//
//     );
//
//
//
//     if (_googleMapController != null) {
//       if (widget._lastSelectedIndex != -1 && widget._listArticles!=null && widget._listArticles.isNotEmpty
//           && widget._listArticles.length > widget._lastSelectedIndex) {
//
//         var item = widget._listArticles[widget._lastSelectedIndex];
//
//         final heroId = item.id.toString() + "-marker";
//         var address = item.address.coordinates.toString();
//         if ((address != null) && (address.isNotEmpty) && (address != ',')) {
//           _googleMapController.hideMarkerInfoWindow(MarkerId(heroId));
//         }
//       }
//
//       if (widget._snapCameraToSelectedIndex && widget._selectedArticleIndex >= 0 && widget._listArticles!=null && widget._listArticles.isNotEmpty
//           && widget._listArticles.length > widget._lastSelectedIndex) {
//         var item = widget._listArticles[widget._selectedArticleIndex];
//         final heroId = item.id.toString() + "-marker";
//
//         var address = item.address.coordinates.toString();
//         if ((address != null) && (address.isNotEmpty) && (address != ',')) {
//           _googleMapController.showMarkerInfoWindow(MarkerId(heroId));
//           var temp = address.split(",");
//           var location = CameraPosition(
//               target: LatLng(double.parse(temp[0]), double.parse(temp[1])), zoom: mapZoom);
//
//           latestLatInInt = double.parse(temp[0]).toInt();
//           latestLngInInt = double.parse(temp[1]).toInt();
//
//           // print("property: latlng: $latestLatInInt, $latestLngInInt");
//           _googleMapController.animateCamera(CameraUpdate.newCameraPosition(location));
//           // if(widget._snapCameraToSelectedIndex){
//           //   var location = CameraPosition(
//           //       target: LatLng(double.parse(temp[0]), double.parse(temp[1])), zoom: mapZoom);
//           //   _googleMapController.animateCamera(CameraUpdate.newCameraPosition(location));
//           //   // setState(() {
//           //   //   widget._enableCameraMovement = false;
//           //   //  // showSearchInThisArea = true;
//           //   // });
//           //
//           // }
//         }
//
//       }
//     }
//
//     if (showMap == true) {
//       if(x1 != null && x0 != null && y1 != null && x0 != null){
//         LatLngBounds latLngBounds = LatLngBounds(northeast: LatLng(x1, y1), southwest: LatLng(x0, y0));
//         if (_googleMapController != null) {
//           CameraUpdate cameraUpdate = CameraUpdate.newLatLngBounds(latLngBounds, 190.0);
//           // _googleMapController.moveCamera(cameraUpdate);
//           _googleMapController.animateCamera(cameraUpdate);
//         }
//       }
//     }
//
//
//     return Scaffold(
//       body: Stack(
//         children: [
//           map,
//           showSearchInThisArea
//               ? Container(
//                   margin: const EdgeInsets.only(top: 100),
//                   alignment: Alignment.topCenter,
//                   child: FloatingActionButton.extended(
//                     backgroundColor: AppThemePreferences().appTheme.searchBarBackgroundColor,
//                     onPressed: () {
//                       var visibleRegion = _googleMapController.getVisibleRegion();
//                       visibleRegion.then((value) {
//                         var distance = Geolocator.distanceBetween(
//                             value.northeast.latitude,
//                             value.northeast.longitude,
//                             value.southwest.latitude,
//                             value.southwest.longitude);
//
//                         double distanceInKiloMeters = distance / 1000;
//                         double roundDistanceInKM = double.parse((distanceInKiloMeters).toStringAsFixed(2));
//
//                         Map<String, String> coordinatesMap = {
//                           LATITUDE: _lastMapPosition.latitude.toString(),
//                           LONGITUDE: _lastMapPosition.longitude.toString(),
//                           RADIUS: roundDistanceInKM.toString(),
//                         };
//                         widget.mapViewListener(coordinatesMap, false);
//                         if(mounted) {
//                           setState(() {
//                             widget.showWaitingWidget = true;
//                             showSearchInThisArea = false;
//                             widget._snapCameraToSelectedIndex = false;
//                           });
//                         }
//                       });
//                     },
//                     label: genericTextWidget(
//                         GenericMethods.getLocalizedString("search_in_this_area"),
//                         style: AppThemePreferences().appTheme.filterPageChoiceChipTextStyle,
//                     ),
//                   ),
//                 )
//               : Container(),
//           widget.showWaitingWidget == true
//               ? Container(
//                   margin: const EdgeInsets.only(top: 160),
//                   alignment: Alignment.topCenter,
//                   child: SizedBox(
//                     width: 70,
//                     height: 70,
//                     child: loadingBallBeatWidget(),
//                   ),
//                 )
//               : Container()
//         ],
//       ),
//       // floatingActionButton:
//
//       // builder,
//     );
//   }
//
//   @override
//   bool get wantKeepAlive => true;
//
// }








