import 'package:fancy_shimmer_image/fancy_shimmer_image.dart';
import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_related_pages/full_screen_image_view.dart';
import 'package:houzi_package/pages/property_details_related_pages/property_detail_page_widgets/pd_heading_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/shimmer_effect_error_widget.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class PropertyDetailPageImages extends StatefulWidget {
  final Article article;
  final String title;
  final String heroId;

  final bool refreshWidget;

  const PropertyDetailPageImages({
    this.article,
    this.title,
    this.heroId,
    this.refreshWidget = false,
    Key key,
  }) : super(key: key);

  @override
  State<PropertyDetailPageImages> createState() => _PropertyDetailPageImagesState();
}

class _PropertyDetailPageImagesState extends State<PropertyDetailPageImages> {

  Article _article;
  String firstImage = "";
  List<String> imageUrlsList = [];
  int currentImageIndex = 0;
  PageController pageController = PageController(initialPage: 0);


  @override
  void initState() {
    super.initState();
    _article = widget.article;
    imageUrlsList = _article.imageList;
    firstImage = imageUrlsList[0];
    loadData(_article);
  }

  loadData(Article article) {
    imageUrlsList = article.imageList;
    if (imageUrlsList.first != firstImage) {
      imageUrlsList.insert(0, firstImage);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (_article != widget.article) {
      _article = widget.article;
      loadData(_article);
    }
    return Stack(
      children: <Widget>[
        articleImagesWidget(),
        imageIndicators(),
        imageCountIndicator(),
      ],
    );
  }

  Widget articleImagesWidget() {
    return imageUrlsList != null && imageUrlsList.isNotEmpty
        ? Hero(
      tag: widget.heroId,
      child: SizedBox(
        height: 300,
        child: PageView(
          controller: pageController,
          onPageChanged: (int page) {
            setState(() {
              currentImageIndex = page;
            });
          },
          children: List.generate(
            imageUrlsList.length,
                (index) {
              bool _validURL =
              GenericMethods.validateURL(imageUrlsList[index]);
              return GestureDetector(
                child: !_validURL
                    ? shimmerEffectErrorWidget(iconSize: 100)
                    : FancyShimmerImage(
                  imageUrl: imageUrlsList[index],
                  boxFit: BoxFit.cover,
                  shimmerBaseColor: AppThemePreferences()
                      .appTheme
                      .shimmerEffectBaseColor,
                  shimmerHighlightColor: AppThemePreferences()
                      .appTheme
                      .shimmerEffectHighLightColor,
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  errorWidget:
                  shimmerEffectErrorWidget(iconSize: 100),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          FullScreenImageView(
                            imageUrls: imageUrlsList,
                            tag: widget.heroId,
                          ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    )
        : Container();
  }

  Widget imageIndicators() {
    return Positioned(
      bottom: 10,
      left: 0,
      right: 0,
      child: Align(
        alignment: Alignment.bottomCenter,
        child: imageUrlsList.length > 1
            ? SmoothPageIndicator(
          controller: pageController,
          count: imageUrlsList.length,
          effect: SlideEffect(
            dotHeight: 10.0,
            dotWidth: 10.0,
            spacing: 10,
            dotColor: AppThemePreferences.countIndicatorsColor,
            activeDotColor: AppThemePreferences().appTheme.primaryColor,
          ),
        )
            : Container(),
      ),
    );
  }

  Widget imageCountIndicator() {
    return Positioned(
      bottom: 30,
      left: GenericMethods.isRTL(context) ? 10 : null,
      right: GenericMethods.isRTL(context) ? null : 10,
      child: Align(
        alignment: Alignment.bottomRight,
        child: imageUrlsList.length > 1
            ? Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: AppThemePreferences.imageCountIndicatorBackgroundColor,
            borderRadius: const BorderRadius.all(Radius.circular(4)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              AppThemePreferences()
                  .appTheme
                  .propertyDetailsImageIndicatorCameraIcon,
              genericTextWidget(
                " ${currentImageIndex + 1}/${imageUrlsList.length}",
                style: AppThemePreferences()
                    .appTheme
                    .propertyDetailsPageImageIndicatorTextTextStyle,
              ),
            ],
          ),
        )
            : Container(),
      ),
    );
  }


}