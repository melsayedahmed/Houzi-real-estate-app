import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

class PropertyDetailPageValuedFeatured extends StatefulWidget {
  final Article article;

  const PropertyDetailPageValuedFeatured({this.article, Key key}) : super(key: key);

  @override
  State<PropertyDetailPageValuedFeatured> createState() => _PropertyDetailPageValuedFeaturedState();
}

class _PropertyDetailPageValuedFeaturedState extends State<PropertyDetailPageValuedFeatured> {
  Map<String, String> articleDetailsMap = {};
  final Map<String, String> _mapOfFeaturesWithValues = {};

  final Map<String, dynamic> _iconMap = GenericMethods.getIconsMap();

  @override
  void initState() {
    super.initState();

    articleDetailsMap = widget.article.propertyDetailsMap;

    _iconMap.forEach((key, value) {
      if (articleDetailsMap.containsKey(key)) {
        _mapOfFeaturesWithValues[key] = articleDetailsMap[key];
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return valuedFeaturesWidget();
  }

  Widget valuedFeaturesWidget() {
    return _mapOfFeaturesWithValues != null &&
            _mapOfFeaturesWithValues.isNotEmpty
        ? Container(
            height: 50,
            padding: EdgeInsets.fromLTRB(
                GenericMethods.isRTL(context) ? 0 : 16,
                0, GenericMethods.isRTL(context) ? 16 : 0, 0,
            ),
            child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: _mapOfFeaturesWithValues.length,
              itemBuilder: (context, index) {
                var key = _mapOfFeaturesWithValues.keys.elementAt(index);
                var value = _mapOfFeaturesWithValues[key];
                String label = GenericMethods.getLocalizedString(key);
                return singleValueFeatureWidget(index, key, value, label, _iconMap, widget.article);
              },
            ),
          )
        : Container();
  }

  Widget singleValueFeatureWidget(int index, String key, String value, String label, Map<String, dynamic> _iconMap, Article _article) {
    return Padding(
      padding: EdgeInsets.only(left: index == 0 ? 0 : 5),
      child: Card(
        elevation: AppThemePreferences.zeroElevation,
        shape: AppThemePreferences.roundedCorners(
            AppThemePreferences.propertyDetailPageRoundedCornersRadius),
        color: AppThemePreferences().appTheme.containerBackgroundColor,
        // padding: EdgeInsets.symmetric(horizontal: 10),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            // crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                _iconMap.containsKey(key)
                    ? _iconMap[key]
                    : AppThemePreferences.errorIcon,
                size: AppThemePreferences.propertyDetailsValuedFeaturesIconSize,
              ),
              Container(
                padding: const EdgeInsets.only(top: 0, left: 5),
                child: genericTextWidget(
                  value,
                  textAlign: TextAlign.center,
                  strutStyle:
                      StrutStyle(height: AppThemePreferences.genericTextHeight),
                  style: AppThemePreferences().appTheme.label01TextStyle,
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 0, left: 5),
                child: genericTextWidget(
                  key == PROPERTY_DETAILS_PROPERTY_SIZE
                      ? _article.features.landAreaUnit != null &&
                              _article.features.landAreaUnit.isNotEmpty
                          ? _article.features.landAreaUnit
                          : MEASUREMENT_UNIT_TEXT
                      : label,
                  textAlign: TextAlign.center,
                  strutStyle:
                      StrutStyle(height: AppThemePreferences.genericTextHeight),
                  style: AppThemePreferences().appTheme.label01TextStyle,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
