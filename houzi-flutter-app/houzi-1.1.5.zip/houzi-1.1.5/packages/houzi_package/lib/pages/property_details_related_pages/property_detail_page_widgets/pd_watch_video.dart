import 'package:flutter/material.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_related_pages/property_detail_page_widgets/pd_heading_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class PropertyDetailPageWatchVideo extends StatefulWidget {
  final Article article;
  final String title;

  const PropertyDetailPageWatchVideo({
    this.article,
    this.title,
    Key key,
  }) : super(key: key);

  @override
  State<PropertyDetailPageWatchVideo> createState() =>
      _PropertyDetailPageWatchVideoState();
}

class _PropertyDetailPageWatchVideoState extends State<PropertyDetailPageWatchVideo> {
  Article _article;
  String articleYoutubeVideoLink = "";

  @override
  void initState() {
    super.initState();
    _article = widget.article;
    loadData(_article);
  }

  loadData(Article article) {
    articleYoutubeVideoLink = article.video;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (_article != widget.article) {
      _article = widget.article;
      loadData(_article);
    }
    return watchVideoWidget(widget.title);
  }

  Widget watchVideoWidget(String title) {
    if (title == null || title.isEmpty) {
      title = GenericMethods.getLocalizedString("watch_video");
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
      child:
          articleYoutubeVideoLink != null && articleYoutubeVideoLink.isNotEmpty
              ? getRowWidget(
                  text: GenericMethods.getLocalizedString(title),
                  onTap: navigateToYoutubeVideo,
                )
              : Container(),
    );
  }

  navigateToYoutubeVideo() async {
    var urlIsLaunchAble = await canLaunch(articleYoutubeVideoLink);
    if (urlIsLaunchAble) {
      await launch(articleYoutubeVideoLink);
    } else {
      print("URL can't be launched.");
    }
  }
}
