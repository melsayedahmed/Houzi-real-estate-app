import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_page.dart';
import 'package:houzi_package/pages/property_details_related_pages/full_screen_multi_unit_view.dart';
import 'package:houzi_package/pages/property_details_related_pages/property_detail_page_widgets/pd_heading_widget.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:houzi_package/widgets/article_box_widgets/article_box_design.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_properties_related_widgets/latest_featured_properties_widget/properties_listing_widget.dart';

class PropertyDetailPageRelatedListing extends StatefulWidget {
  final String title;
  final int propertyID;
  final String widgetViewType;
  final bool refreshWidget;

  const PropertyDetailPageRelatedListing({
    this.title,
    this.propertyID,
    this.widgetViewType,
    this.refreshWidget = false,
    Key key,
  }) : super(key: key);

  @override
  State<PropertyDetailPageRelatedListing> createState() =>
      _PropertyDetailPageRelatedListingState();
}

class _PropertyDetailPageRelatedListingState extends State<PropertyDetailPageRelatedListing> {

  Article _article;
  List<dynamic> relatedArticles = [];

  Future<List<dynamic>> _futureRelatedArticles;

  final PropertyBloc _propertyBloc = PropertyBloc();

  @override
  void initState() {
    super.initState();
    _futureRelatedArticles = fetchRelatedArticles(widget.propertyID);
  }

  Future<List<dynamic>> fetchRelatedArticles(int propertyId) async {
    List<dynamic> tempList = [];
    tempList = await _propertyBloc.fetchSimilarArticles(propertyId);
    if (tempList == null || (tempList.isNotEmpty && tempList[0] == null) ||
        (tempList.isNotEmpty && tempList[0].runtimeType == Response)) {

    } else {
      if (tempList.isNotEmpty) {
        relatedArticles.addAll(tempList);
      }
    }
    return relatedArticles;
  }


  @override
  Widget build(BuildContext context) {
    return relatedPosts(_futureRelatedArticles, widget.title, widgetViewType: widget.widgetViewType);
  }

  Widget relatedPosts(Future<List<dynamic>> relatedArticles, String title,
      {String widgetViewType}) {
    if (title == null || title.isEmpty) {
      title = GenericMethods.getLocalizedString("related_properties");
    }

    return FutureBuilder<List<dynamic>>(
      future: relatedArticles,
      builder: (context, articleSnapshot) {
        if (articleSnapshot.hasData) {
          if (articleSnapshot.data.isEmpty) return Container();

          List dataList = articleSnapshot.data;
          return Column(
            children: <Widget>[
              textHeadingWidget(
                  text: GenericMethods.getLocalizedString(title)),
              widgetViewType != null && widgetViewType.isNotEmpty &&
                  widgetViewType == similarPropertiesCarouselView ?
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: relatedPostsCarouselView(dataList),
              ) :
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: relatedPostsListView(dataList),
              ),
              const SizedBox(
                height: 24,
              )
            ],
          );
        } else if (articleSnapshot.hasError) {
          return Container();
        }
        return Container();
        // return loadingWidgetForRelatedProperties();
      },
    );
  }

  Widget relatedPostsListView(List dataList) {
    return Column(
      children: dataList.map((item) {
        final heroId = item.id.toString() + RELATED;
        return ArticleBoxDesign().getArticleBoxDesign(
          design: RELATED_PROPERTIES_DESIGN,
          buildContext: context,
          article: item,
          heroId: heroId,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    PropertyDetailsPage(
                      article: item,
                      propertyID: item.id,
                      heroId: heroId,
                    ),
              ),
            );
          },
        );
      }).toList(),
    );
  }

  Widget relatedPostsCarouselView(List dataList) {
    return PropertiesListingGenericWidget(
      propertiesList: dataList,
      design: RELATED_PROPERTIES_DESIGN,
    );
  }


}
