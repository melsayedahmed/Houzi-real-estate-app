import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_related_pages/property_detail_page_widgets/pd_heading_widget.dart';
import 'package:houzi_package/pages/property_details_related_pages/schedule_a_tour_page.dart';

class PropertyDetailPageSetupTour extends StatefulWidget {
  final Article article;
  final String title;
  final List<dynamic> realtorInfoList;
  final Map<String, dynamic> realtorInfoMap;

  const PropertyDetailPageSetupTour({
    this.article,
    this.title,
    this.realtorInfoList,
    this.realtorInfoMap,
    Key key,
  }) : super(key: key);

  @override
  State<PropertyDetailPageSetupTour> createState() => _PropertyDetailPageSetupTourState();
}

class _PropertyDetailPageSetupTourState extends State<PropertyDetailPageSetupTour> {
  Article _article;
  int tempRealtorId;
  String tempRealtorThumbnail = "";
  String tempRealtorEmail = "";
  String tempRealtorName = "";
  String tempRealtorPhone = "";
  String tempRealtorMobile = "";
  String tempRealtorWhatsApp = "";
  String tempRealtorLink = "";
  String agentDisplayOption = "";
  String articleYoutubeVideoLink = "";
  String articleVirtualTourLink = "";

  Map<String, dynamic> realtorInfoMap = {};

  @override
  void initState() {
    super.initState();
    _article = widget.article;
    loadData(_article);
  }

  loadData(Article article) {
    if (realtorInfoMap.isEmpty &&
        widget.realtorInfoMap != null &&
        widget.realtorInfoMap.isNotEmpty) {
      realtorInfoMap.addAll(widget.realtorInfoMap);
      tempRealtorId = realtorInfoMap[tempRealtorIdKey];
      tempRealtorName = realtorInfoMap[tempRealtorNameKey];
      tempRealtorEmail = realtorInfoMap[tempRealtorEmailKey];
      tempRealtorThumbnail = realtorInfoMap[tempRealtorThumbnailKey];
      tempRealtorPhone = realtorInfoMap[tempRealtorPhoneKey];
      tempRealtorMobile = realtorInfoMap[tempRealtorMobileKey];
      tempRealtorWhatsApp = realtorInfoMap[tempRealtorWhatsAppKey];
      tempRealtorLink = realtorInfoMap[tempRealtorLinkKey];

      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.realtorInfoMap != null && widget.realtorInfoMap.isNotEmpty) {
      _article = widget.article;
      loadData(_article);
    }
    return showButtonGridWidget(widget.title);
  }

  Widget showButtonGridWidget(String title) {
    if (title == null || title.isEmpty) {
      title = GenericMethods.getLocalizedString("setup_tour");
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
      child: getRowWidget(
        text: GenericMethods.getLocalizedString(title),
        onTap: navigateToScheduleATour,
      ),
    );
  }

  navigateToScheduleATour() {
    if (tempRealtorId == null ||
        tempRealtorEmail.isEmpty ||
        _article.id == null) {
      showToastWhileDataLoading(
          context,
          GenericMethods.getLocalizedString("please_wait_data_is_loading"),
          false);
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ScheduleTour(
            agentId: tempRealtorId,
            agentEmail: tempRealtorEmail,
            propertyId: _article.id,
            propertyTitle: GenericMethods.stripHtmlIfNeeded(_article.title),
            propertyPermalink: _article.link,
          ),
        ),
      );
    }
  }
}
