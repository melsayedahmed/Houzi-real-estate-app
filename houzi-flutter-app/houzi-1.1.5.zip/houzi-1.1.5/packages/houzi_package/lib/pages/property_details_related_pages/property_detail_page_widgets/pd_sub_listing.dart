import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_page.dart';
import 'package:houzi_package/pages/property_details_related_pages/full_screen_multi_unit_view.dart';
import 'package:houzi_package/pages/property_details_related_pages/property_detail_page_widgets/pd_heading_widget.dart';
import 'package:houzi_package/pages/search_result.dart';
import 'package:houzi_package/widgets/article_box_widgets/article_box_design.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/home_screen_widgets/home_screen_properties_related_widgets/latest_featured_properties_widget/properties_listing_widget.dart';

class PropertyDetailPageSubListing extends StatefulWidget {
  final Article article;
  final String title;
  final String widgetViewType;
  final bool refreshWidget;

  const PropertyDetailPageSubListing({
    this.article,
    this.title,
    this.widgetViewType,
    this.refreshWidget = false,
    Key key,
  }) : super(key: key);

  @override
  State<PropertyDetailPageSubListing> createState() =>
      _PropertyDetailPageSubListingState();
}

class _PropertyDetailPageSubListingState
    extends State<PropertyDetailPageSubListing> {
  Article _article;

  List<dynamic> multiUnitsList = [];
  List<dynamic> subListingArticles = [];

  Future<List<dynamic>> _futureSubListingArticles;

  final PropertyBloc _propertyBloc = PropertyBloc();

  @override
  void initState() {
    super.initState();
    _article = widget.article;
    loadData(_article);
  }

  loadData(Article article) {
    _futureSubListingArticles =
        fetchSubListingArticles(article.features.multiUnitsListingIDs);
    _futureSubListingArticles.then((value) {
      if (value == null || value.isEmpty) {
        multiUnitsList = article.features.multiUnitsList;
      }
      return null;
    });

    setState(() {});
  }

  Future<List<dynamic>> fetchSubListingArticles(String propertiesId) async {
    List<dynamic> tempList = [];
    if (subListingArticles.isEmpty &&
        propertiesId != null &&
        propertiesId.isNotEmpty) {
      tempList = await _propertyBloc.fetchMultipleArticles(propertiesId);
      if (tempList == null ||
          (tempList.isNotEmpty && tempList[0] == null) ||
          (tempList.isNotEmpty && tempList[0].runtimeType == Response)) {
      } else {
        if (tempList.isNotEmpty) {
          subListingArticles.addAll(tempList);
        }
      }
    }

    return subListingArticles;
  }

  @override
  Widget build(BuildContext context) {
    if (_article != widget.article) {
      _article = widget.article;
      loadData(_article);
    }
    return subListingsPosts(_futureSubListingArticles, widget.title,
        widgetViewType: widget.widgetViewType);
  }

  Widget subListingsPosts(
      Future<List<dynamic>> subListingsArticles, String title,
      {String widgetViewType}) {
    if (title == null || title.isEmpty) {
      title = GenericMethods.getLocalizedString("sub_listings");
    }

    return multiUnitsList != null && multiUnitsList.isNotEmpty
        ? articleMultiUnitsWidget(title)
        : FutureBuilder<List<dynamic>>(
            future: subListingsArticles,
            builder: (context, articleSnapshot) {
              if (articleSnapshot.hasData) {
                if (articleSnapshot.data.isEmpty) return Container();
                List dataList = articleSnapshot.data;
                bool viewAll = false;
                if (dataList.length > 3) {
                  dataList = dataList.sublist(0, 3);
                  viewAll = true;
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    textHeadingWidget(
                        text: GenericMethods.getLocalizedString(title), widget: viewAll ? seeMoreWidget() : Container()),
                    widgetViewType != null &&
                            widgetViewType.isNotEmpty &&
                            widgetViewType == subListingPropertiesCarouselView
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: subListingsPostsCarouselView(dataList),
                          )
                        : Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: subListingsPostsListView(dataList),
                          ),

                    // SizedBox(
                    //   height: 24,
                    // )
                  ],
                );
              } else if (articleSnapshot.hasError) {
                return Container();
              }
              return Container();
              // return loadingWidgetForRelatedProperties();
            },
          );
  }

  Widget subListingsPostsListView(List dataList) {
    return Column(
      children: dataList.map((item) {
        final heroId = item.id.toString() + RELATED;
        return ArticleBoxDesign().getArticleBoxDesign(
          design: RELATED_PROPERTIES_DESIGN,
          buildContext: context,
          article: item,
          heroId: heroId,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PropertyDetailsPage(
                  article: item,
                  propertyID: item.id,
                  heroId: heroId,
                ),
              ),
            );
          },
        );
      }).toList(),
    );
  }

  Widget subListingsPostsCarouselView(List dataList) {
    return PropertiesListingGenericWidget(
      propertiesList: dataList,
      design: RELATED_PROPERTIES_DESIGN,
    );
  }

  Widget seeMoreWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: TextButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SearchResult(
                fetchSubListing: true,
                subListingIds: _article.features.multiUnitsListingIDs,
                searchPageListener:
                    (Map<String, dynamic> map, String closeOption) {
                  if (closeOption == CLOSE) {
                    Navigator.of(context).pop();
                  }
                },
              ),
            ),
          );
        },
        child: genericTextWidget(GenericMethods.getLocalizedString("view_all"),
            style: AppThemePreferences().appTheme.readMoreTextStyle),
      ),
    );
  }

  // Widget articleMultiUnitsWidget(String title) {
  //   if (title == null || title.isEmpty) {
  //     title = GenericMethods.getLocalizedString("sub_listings");
  //   }
  //   return multiUnitsList != null && multiUnitsList.isNotEmpty
  //       ? Column(
  //           children: [
  //             textHeadingWidget(
  //               text: GenericMethods.getLocalizedString(title),
  //             ),
  //             Column(
  //               children: multiUnitsList.map((item) {
  //                 Map<String, dynamic> multiUnitMap = {};
  //                 String faveMuTitle = item.title;
  //                 String faveMuBeds = item.bedrooms;
  //                 String faveMuBaths = item.bathrooms;
  //                 String faveMuSize = "${item.size} ${item.sizePostfix}";
  //
  //                 if (faveMuBeds != null && faveMuBeds.isNotEmpty) {
  //                   multiUnitMap[FLOOR_PLAN_ROOMS] =
  //                       AppThemePreferences.bedIcon;
  //                 }
  //                 if (faveMuBaths != null && faveMuBaths.isNotEmpty) {
  //                   multiUnitMap[FLOOR_PLAN_BATHROOMS] =
  //                       AppThemePreferences.bathtubIcon;
  //                 }
  //                 if (faveMuSize != null && faveMuSize.isNotEmpty) {
  //                   multiUnitMap[FLOOR_PLAN_SIZE] =
  //                       AppThemePreferences.areaSizeIcon;
  //                 }
  //
  //                 return multiUnitMap == null || multiUnitMap.isEmpty
  //                     ? Container()
  //                     : Container(
  //                         padding: const EdgeInsets.symmetric(
  //                             horizontal: 1, vertical: 1),
  //                         color: AppThemePreferences()
  //                             .appTheme
  //                             .containerBackgroundColor,
  //                         child: Card(
  //                           elevation: AppThemePreferences.zeroElevation,
  //                           shape: AppThemePreferences.roundedCorners(
  //                               AppThemePreferences.globalRoundedCornersRadius),
  //                           child: InkWell(
  //                             borderRadius:
  //                                 const BorderRadius.all(Radius.circular(5)),
  //                             onTap: () {
  //                               Navigator.push(
  //                                 context,
  //                                 MaterialPageRoute(
  //                                   builder: (context) =>
  //                                       FullScreenMultiUnits(multiUnitsList),
  //                                 ),
  //                               );
  //                             },
  //                             child: Container(
  //                               padding:
  //                                   const EdgeInsets.fromLTRB(10, 10, 10, 10),
  //                               child: Column(
  //                                 crossAxisAlignment: CrossAxisAlignment.start,
  //                                 children: [
  //                                   Container(
  //                                     padding: const EdgeInsets.fromLTRB(
  //                                         10, 0, 10, 5),
  //                                     child: genericTextWidget(
  //                                       faveMuTitle,
  //                                       strutStyle: StrutStyle(
  //                                           height: AppThemePreferences
  //                                               .genericTextHeight),
  //                                       style: AppThemePreferences()
  //                                           .appTheme
  //                                           .label01TextStyle,
  //                                     ),
  //                                   ),
  //                                   Container(
  //                                     padding: const EdgeInsets.fromLTRB(
  //                                         10, 0, 10, 10),
  //                                     child: ConstrainedBox(
  //                                       constraints: const BoxConstraints(
  //                                         minHeight: 40,
  //                                         maxHeight: 50,
  //                                       ),
  //                                       child: StaggeredGridView.countBuilder(
  //                                         physics:
  //                                             const NeverScrollableScrollPhysics(),
  //                                         crossAxisCount: multiUnitMap.length,
  //                                         padding: const EdgeInsets.symmetric(
  //                                             vertical: 10),
  //                                         itemCount: multiUnitMap.length,
  //                                         itemBuilder: (context, index) {
  //                                           var key = multiUnitMap.keys
  //                                               .elementAt(index);
  //                                           var value = key == FLOOR_PLAN_ROOMS
  //                                               ? faveMuBeds
  //                                               : key == FLOOR_PLAN_BATHROOMS
  //                                                   ? faveMuBaths
  //                                                   : key == FLOOR_PLAN_SIZE
  //                                                       ? faveMuSize
  //                                                       : "";
  //                                           return Column(
  //                                             crossAxisAlignment:
  //                                                 CrossAxisAlignment.center,
  //                                             mainAxisSize: MainAxisSize.min,
  //                                             children: [
  //                                               Align(
  //                                                 alignment: Alignment.center,
  //                                                 child: Icon(
  //                                                   multiUnitMap[key],
  //                                                   size: AppThemePreferences
  //                                                       .propertyDetailsFloorPlansIconSize,
  //                                                 ),
  //                                               ),
  //                                               Container(
  //                                                 alignment: Alignment.center,
  //                                                 padding:
  //                                                     const EdgeInsets.only(
  //                                                         top: 10.0),
  //                                                 child: genericTextWidget(
  //                                                   value,
  //                                                   strutStyle: StrutStyle(
  //                                                       height: AppThemePreferences
  //                                                           .genericTextHeight),
  //                                                   style: AppThemePreferences()
  //                                                       .appTheme
  //                                                       .subTitle02TextStyle,
  //                                                 ),
  //                                               ),
  //                                             ],
  //                                           );
  //                                         },
  //                                         staggeredTileBuilder: (int index) =>
  //                                             const StaggeredTile.fit(1),
  //                                         mainAxisSpacing: 3.0,
  //                                         crossAxisSpacing: 6.0, //16.0,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                 ],
  //                               ),
  //                             ),
  //                           ),
  //                         ),
  //                       );
  //               }).toList(),
  //             ),
  //           ],
  //         )
  //       : Container();
  // }

  Widget articleMultiUnitsWidget(String title) {
    if (title == null || title.isEmpty) {
      title = GenericMethods.getLocalizedString("floor_plans");
    }
    return multiUnitsList != null && multiUnitsList.isNotEmpty
        ? Column(
      children: [
        textHeadingWidget(text: GenericMethods.getLocalizedString(title)),
        Padding(
          padding: const EdgeInsets.fromLTRB(13, 0, 13, 0),
          child: Column(
            children: multiUnitsList.map((item) {
              Map<String, dynamic> multiUnitMap = {};
              String title = item.title;
              String rooms = item.bedrooms;
              String bathrooms = item.bathrooms;
              String size = "${item.size} ${item.sizePostfix}";
              
              String price = item.price;
              String pricePostFix = item.pricePostfix;
              if (pricePostFix != null && pricePostFix.isNotEmpty) {
                price = "$price $pricePostFix";
              }

              if (rooms != null && rooms.isNotEmpty) {
                multiUnitMap[FLOOR_PLAN_ROOMS] =
                    AppThemePreferences.bedIcon;
              }
              if (bathrooms != null && bathrooms.isNotEmpty) {
                multiUnitMap[FLOOR_PLAN_BATHROOMS] =
                    AppThemePreferences.bathtubIcon;
              }
              if (price != null && price.isNotEmpty) {
                multiUnitMap[FLOOR_PLAN_PRICE] =
                    AppThemePreferences.priceTagIcon;
              }
              if (size != null && size.isNotEmpty) {
                multiUnitMap[FLOOR_PLAN_SIZE] =
                    AppThemePreferences.areaSizeIcon;
              }
              return multiUnitMap == null || multiUnitMap.isEmpty
                  ? Container()
                  : Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 1, vertical: 1),
                child: Card(
                  elevation: AppThemePreferences.zeroElevation,
                  color: AppThemePreferences()
                      .appTheme
                      .containerBackgroundColor,
                  shape: AppThemePreferences.roundedCorners(
                      AppThemePreferences
                          .globalRoundedCornersRadius),
                  child: InkWell(
                    borderRadius:
                    const BorderRadius.all(Radius.circular(5)),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FullScreenMultiUnits(multiUnitsList),
                        ),
                      );
                    },
                    child: Container(
                      padding:
                      const EdgeInsets.fromLTRB(10, 10, 10, 10),
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.fromLTRB(
                                10, 0, 10, 5),
                            child: Row(
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                genericTextWidget(
                                  title,
                                  strutStyle: StrutStyle(
                                      height: AppThemePreferences
                                          .genericTextHeight),
                                  style: AppThemePreferences()
                                      .appTheme
                                      .label01TextStyle,
                                ),
                                genericTextWidget(
                                  GenericMethods.getLocalizedString(
                                      "view_sub_listing"),
                                  strutStyle: StrutStyle(
                                      height: AppThemePreferences
                                          .genericTextHeight),
                                  style: AppThemePreferences()
                                      .appTheme
                                      .readMoreTextStyle,
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.fromLTRB(
                                10, 0, 10, 10),
                            child: ConstrainedBox(
                              constraints: const BoxConstraints(
                                minHeight: 50,
                                maxHeight: 60,
                              ),
                              child: StaggeredGridView.countBuilder(
                                physics:
                                const NeverScrollableScrollPhysics(),
                                crossAxisCount: 2,
                                //multiUnitMap.length,
                                padding: const EdgeInsets.symmetric(
                                    vertical: 10),
                                itemCount: multiUnitMap.length,
                                itemBuilder: (context, index) {
                                  var key = multiUnitMap.keys
                                      .elementAt(index);
                                  var value = key ==
                                      FLOOR_PLAN_ROOMS
                                      ? rooms
                                      : key == FLOOR_PLAN_BATHROOMS
                                      ? bathrooms
                                      : key == FLOOR_PLAN_PRICE
                                      ? price
                                      : key ==
                                      FLOOR_PLAN_SIZE
                                      ? size
                                      : "";
                                  return Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    // mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        multiUnitMap[key],
                                        size: AppThemePreferences
                                            .propertyDetailsFloorPlansIconSize,
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.only(
                                            left: 8.0),
                                        child: genericTextWidget(
                                          value,
                                          strutStyle: StrutStyle(
                                              height: AppThemePreferences
                                                  .genericTextHeight),
                                          style:
                                          AppThemePreferences()
                                              .appTheme
                                              .label01TextStyle,
                                        ),
                                      ),
                                    ],
                                  );
                                },
                                staggeredTileBuilder: (int index) =>
                                const StaggeredTile.fit(1),
                                mainAxisSpacing: 10,
                                crossAxisSpacing: 100, //16.0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    )
        : Container();
  }
}
