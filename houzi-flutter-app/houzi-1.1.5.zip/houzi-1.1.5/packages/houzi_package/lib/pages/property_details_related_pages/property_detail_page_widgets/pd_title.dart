import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

class PropertyDetailPageTitle extends StatefulWidget {
  final Article article;
  const PropertyDetailPageTitle({this.article, Key key}) : super(key: key);

  @override
  State<PropertyDetailPageTitle> createState() => _PropertyDetailPageTitleState();
}

class _PropertyDetailPageTitleState extends State<PropertyDetailPageTitle> {

  @override
  Widget build(BuildContext context) {
    return articleTitle();
  }

  Widget articleTitle() {
    return widget.article.title != null && widget.article.title.isNotEmpty
        ? Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 5),
            child: genericTextWidget(
              GenericMethods.stripHtmlIfNeeded(widget.article.title),
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.propertyDetailsPagePropertyTitleTextStyle,
            ),
          )
        : Container();
  }
}
