import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_related_pages/property_detail_page_widgets/pd_heading_widget.dart';
import 'package:houzi_package/pages/send_email_to_realtor.dart';

class PropertyDetailPageEnquireInfo extends StatefulWidget {
  final Article article;
  final String title;
  final Map<String, dynamic> realtorInfoMap;

  const PropertyDetailPageEnquireInfo({
    this.article,
    this.title,
    this.realtorInfoMap,
    Key key,
  }) : super(key: key);

  @override
  State<PropertyDetailPageEnquireInfo> createState() =>
      _PropertyDetailPageEnquireInfoState();
}

class _PropertyDetailPageEnquireInfoState
    extends State<PropertyDetailPageEnquireInfo> {
  Article _article;
  int tempRealtorId;
  String tempRealtorThumbnail = "";
  String tempRealtorEmail = "";
  String tempRealtorName = "";
  String tempRealtorPhone = "";
  String tempRealtorMobile = "";
  String tempRealtorWhatsApp = "";
  String tempRealtorLink = "";
  String agentDisplayOption = "";
  String articleYoutubeVideoLink = "";
  String articleVirtualTourLink = "";

  bool isAgent = false;
  bool isAgency = false;
  bool isAuthor = false;
  Map<String, dynamic> realtorInfoMap = {};

  @override
  void initState() {
    super.initState();
    _article = widget.article;
    loadData();
  }

  loadData() {
    if(realtorInfoMap.isEmpty && widget.realtorInfoMap != null &&
        widget.realtorInfoMap.isNotEmpty) {
      realtorInfoMap.addAll(widget.realtorInfoMap);
      tempRealtorId = realtorInfoMap[tempRealtorIdKey];
      tempRealtorName = realtorInfoMap[tempRealtorNameKey];
      tempRealtorEmail = realtorInfoMap[tempRealtorEmailKey];
      tempRealtorThumbnail = realtorInfoMap[tempRealtorThumbnailKey];
      tempRealtorPhone = realtorInfoMap[tempRealtorPhoneKey];
      tempRealtorMobile = realtorInfoMap[tempRealtorMobileKey];
      tempRealtorWhatsApp = realtorInfoMap[tempRealtorWhatsAppKey];
      tempRealtorLink = realtorInfoMap[tempRealtorLinkKey];
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (widget.realtorInfoMap != null && widget.realtorInfoMap.isNotEmpty) {
      if (widget.realtorInfoMap != realtorInfoMap) {
        _article = widget.article;
        loadData();
      }
    }
    return enquireInfoWidget(widget.title);
  }

  Widget enquireInfoWidget(String title) {
    if (title == null || title.isEmpty) {
      title = GenericMethods.getLocalizedString("enquire_info");
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
      child: getRowWidget(
        text: GenericMethods.getLocalizedString(title),
        onTap: checkConditionsAndNavigate,
      ),
    );
  }

  checkConditionsAndNavigate() {
    if (realtorInfoMap == null || realtorInfoMap.isEmpty) {
      showToastWhileDataLoading(
          context,
          GenericMethods.getLocalizedString("please_wait_data_is_loading"),
          false);
    } else {
      navigateToInquireAboutProperty();
    }
  }

  navigateToInquireAboutProperty(){
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            SendEmailToRealtor(
              informationMap: {
                SEND_EMAIL_APP_BAR_TITLE:
                GenericMethods.getLocalizedString("enquire_information"),
                SEND_EMAIL_REALTOR_ID: tempRealtorId,
                SEND_EMAIL_REALTOR_NAME: tempRealtorName,
                SEND_EMAIL_REALTOR_EMAIL: tempRealtorEmail,
                SEND_EMAIL_REALTOR_TYPE: agentDisplayOption,
                SEND_EMAIL_MESSAGE: GenericMethods.getLocalizedString(
                    "hello_i_am_interested_in",
                    inputWords: [
                      GenericMethods.stripHtmlIfNeeded(_article.title),
                      _article.title,
                      tempRealtorLink
                    ]),
                SEND_EMAIL_THUMBNAIL: tempRealtorThumbnail,
                SEND_EMAIL_SITE_NAME: APP_NAME,
                SEND_EMAIL_LISTING_ID: _article.id,
                SEND_EMAIL_LISTING_NAME: _article.title,
                SEND_EMAIL_LISTING_LINK: _article.link,
              },
            ),
      ),
    );
  }


}
