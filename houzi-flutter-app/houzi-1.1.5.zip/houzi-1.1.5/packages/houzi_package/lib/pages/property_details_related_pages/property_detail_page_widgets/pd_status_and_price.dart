import 'package:flutter/material.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

class PropertyDetailPageStatusAndPrice extends StatefulWidget {
  final Article article;
  const PropertyDetailPageStatusAndPrice({this.article, Key key}) : super(key: key);

  @override
  State<PropertyDetailPageStatusAndPrice> createState() => _PropertyDetailPageStatusAndPriceState();
}

class _PropertyDetailPageStatusAndPriceState extends State<PropertyDetailPageStatusAndPrice> {
  @override
  Widget build(BuildContext context) {
    return statusAndPriceWidget();
  }

  Widget statusAndPriceWidget() {
    String _propertyStatus = GenericMethods.getLocalizedString(widget.article.propertyInfo.propertyStatus);
    String propertyPrice = "";
    String firstPrice = "";
    String _finalPrice = "";

    if (widget.article.propertyDetailsMap.containsKey(PRICE)) {
      propertyPrice = widget.article.propertyDetailsMap[PRICE];
    }
    if (widget.article.propertyDetailsMap.containsKey(FIRST_PRICE)) {
      firstPrice = widget.article.propertyDetailsMap[FIRST_PRICE];
    }

    _finalPrice = GenericMethods.priceFormatter(propertyPrice, firstPrice);

    return _finalPrice.isNotEmpty
        ? Container(
            padding: const EdgeInsets.fromLTRB(20, 5, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: genericTextWidget(
                    _propertyStatus,
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.propertyDetailsPagePropertyStatusTextStyle,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: genericTextWidget(
                    _finalPrice,
                    strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
                    style: AppThemePreferences().appTheme.propertyDetailsPagePropertyPriceTextStyle,
                  ),
                ),
              ],
            ),
          )
        : _propertyStatus.isEmpty
            ? articlePrice(_finalPrice)
            : articleStatus();
  }

  Widget articleStatus() {
    String _propertyStatus = widget.article.propertyInfo.propertyStatus;
    return _propertyStatus != null && _propertyStatus.isNotEmpty
        ? Container(
            padding: const EdgeInsets.fromLTRB(20, 5, 20, 20),
            child: genericTextWidget(
              _propertyStatus,
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.propertyDetailsPagePropertyStatusTextStyle,
            ),
          )
        : Container();
  }

  Widget articlePrice(String _finalPrice) {
    return _finalPrice == null || _finalPrice.isEmpty
        ? Container()
        : Container(
            padding: const EdgeInsets.fromLTRB(20, 5, 20, 20),
            child: genericTextWidget(
              _finalPrice,
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.propertyDetailsPagePropertyPriceTextStyle,
            ),
          );
  }
}
