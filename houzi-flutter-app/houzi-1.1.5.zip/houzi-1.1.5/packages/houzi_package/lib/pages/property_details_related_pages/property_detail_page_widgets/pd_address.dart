import 'package:flutter/material.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';

class PropertyDetailPageAddress extends StatefulWidget {
  final Article article;
  const PropertyDetailPageAddress({this.article, Key key}) : super(key: key);

  @override
  State<PropertyDetailPageAddress> createState() => _PropertyDetailPageAddressState();
}

class _PropertyDetailPageAddressState extends State<PropertyDetailPageAddress> {
  @override
  Widget build(BuildContext context) {
    return addressWidget();
  }

  Widget addressWidget() {
    return widget.article.address.address != null &&
            widget.article.address.address.isNotEmpty
        ? Container(
            padding: const EdgeInsets.fromLTRB(20, 5, 20, 5),
            child: genericTextWidget(
              widget.article.address.address,
              strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
              style: AppThemePreferences().appTheme.bodyTextStyle,
              textAlign: TextAlign.left,
            ),
          )
        : Container();
  }
}
