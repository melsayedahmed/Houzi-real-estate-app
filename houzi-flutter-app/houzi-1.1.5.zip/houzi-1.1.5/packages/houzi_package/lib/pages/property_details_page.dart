import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:houzi_package/blocs/property_bloc.dart';
import 'package:houzi_package/common/constants.dart';
import 'package:houzi_package/files/app_preferences/app_preferences.dart';
import 'package:houzi_package/files/generic_methods/generic_methods.dart';
import 'package:houzi_package/files/hive_storage_files/hive_storage_manager.dart';
import 'package:houzi_package/files/user_log_provider.dart';
import 'package:houzi_package/models/article.dart';
import 'package:houzi_package/pages/property_details_related_pages/pd_widgets_listing.dart';
import 'package:houzi_package/pages/send_email_to_realtor.dart';
import 'package:houzi_package/widgets/button_widget.dart';
import 'package:houzi_package/widgets/generic_text_widget.dart';
import 'package:houzi_package/widgets/no_internet_botton_widget.dart';
import 'package:houzi_package/widgets/no_internet_error_widget.dart';
import 'package:houzi_package/widgets/no_result_error_widget.dart';
import 'package:houzi_package/widgets/toast_widget.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../files/generic_methods/general_notifier.dart';
import '../models/property_detail_page_config.dart';
import '../widgets/review_related_widgets/add_review_page.dart';
import 'home_screen_drawer_menu_pages/user_related/user_signin.dart';

class PropertyDetailsPage extends StatefulWidget {
  final int propertyID;
  final String heroId;
  final Article article;
  final String permaLink;

  PropertyDetailsPage({
    this.article,
    this.propertyID,
    this.heroId,
    this.permaLink
  });

  @override
  _PropertyDetailsPageState createState() => _PropertyDetailsPageState();
}

class _PropertyDetailsPageState extends State<PropertyDetailsPage> {
  // var width;

  bool showInquiresRealtorButton = false;

  int currentImageIndex = 0;
  //int length = 0;

  int tempRealtorId;
  String tempRealtorThumbnail = '';
  String tempRealtorEmail = '';
  String tempRealtorName = '';
  String tempRealtorPhone = "";
  String tempRealtorMobile = "";
  String tempRealtorWhatsApp = "";
  String tempRealtorLink = "";
  String articleLocationLink = "";
  String articleCoordinates = "";

  String totalRating = "";
  String reviewPostType = "";

  String _articleLink = "";

  var realtorInfo;

  bool isAgent = false;
  bool isAgency = false;
  bool isAuthor = false;

  bool showWriteReview = false;

  List<dynamic> relatedArticles = [];
  List<dynamic> singleArticle = [];
  List<dynamic> singleRentalArticle = [];
  // List<dynamic> singleAgentInfoList = [];
  // List<dynamic> singleAgencyInfoList = [];
  List<dynamic> _realtorInfoList = [];
  List<dynamic> propertiesByAgentList = [];

  Future<dynamic> favArticle;
  Future<List<dynamic>> _futureSingleArticle;


  final PropertyBloc _propertyBloc = PropertyBloc();

  PageController pageController = PageController(initialPage: 0);

  int postId = 0;
  int catId = 0;
  int articleId;

  String page = "1";
  String perPage = "10";

  String heroId;
  String articleYoutubeVideoLink;
  String articleVirtualTourLink;
  String agentDisplayOption = "";
  bool isRefreshing = false;

  Article _article;

  Map<String, String> articleDetailsMap = <String, String>{};
  Map<String, String>  customFieldsMap = {};
  Map<String, String> articleAdditionalDetailsMap = {};
  Map<String, dynamic> articleAgentInfoMap = {};
  Map<String, dynamic> _realtorInfoMap = {};

  List<dynamic> floorPlansList = [];
  List<dynamic> additionalDetailsList = [];
  List<dynamic> multiUnitsList = [];
  List<String> internalFeaturesList = [];
  List<String> externalFeaturesList = [];
  List<String> heatingAndCoolingFeaturesList = [];
  List<String> featuresWithoutValuesList = [];
  List<String> featuresList = [];
  List<String> imageUrlsList = [];
  List<String> agentList = [];
  List<String> agencyList = [];

  Future<List<dynamic>> _futureAgentOrAgencyInfo;


  bool emailDeliveryCheck = false;
  bool scheduleTourCheck = false;
  bool isReadMore = false;
  bool isMoreDetails = false;
  bool showMoreFeatures = false;
  bool isLiked = false;
  bool isLoggedIn = false;
  bool isInternetConnected = true;


  double _opacity = 0.0;
  ScrollController _scrollController = ScrollController();

  bool isFav = false;

  String type = "";
  String title = "";
  String postModifiedGmt = "";


  List<dynamic> propertyDetailPageConfigList = [];

  bool sendDetailedArticleData = false;
  bool latestArticleDataIsReady = false;

  String _defaultCurrency = "";

  getPropertyDetailPageConfigFile() async {
    var storedPropertyDetailPageConfig = HiveStorageManager.readPropertyDetailConfigListData();
    if (storedPropertyDetailPageConfig != null && storedPropertyDetailPageConfig.isNotEmpty) {
      setState(() {
        propertyDetailPageConfigList = jsonDecode(storedPropertyDetailPageConfig);
      });
    } else {
      String jsonString = await rootBundle.loadString("assets/configurations/configurations.json");
      final propertyDetailPageConfig = propertyDetailPageLayoutFromJson(jsonString);
      setState(() {
        propertyDetailPageConfigList = propertyDetailPageConfig.propertyDetailPageLayout;
      });
    }

  }

  @override
  void initState() {
    super.initState();

    getPropertyDetailPageConfigFile();

    if (Provider.of<UserLoggedProvider>(context,listen: false).isLoggedIn) {
      setState(() {
        isLoggedIn = true;
      });
    }

    _scrollController = ScrollController()..addListener(_scrollListener);

    if (widget.article != null) {
      _initializeArticleData(widget.article, widget.heroId);
      checkInternetAndLoadData();
      // loadData();
    }
    if(widget.article == null){
      checkInternetAndLoadData();
    }
  }

  checkInternetAndLoadData(){
    // isInternetConnected = true;
    onRefresh();
  }

  @override
  dispose() {
    super.dispose();

  }

  loadData(){
    _defaultCurrency = HiveStorageManager.readDefaultCurrencyInfoData() ?? '\$';
    if (widget.propertyID != null) {
      _futureSingleArticle = fetchSingleArticle(id: widget.propertyID);
      _futureSingleArticle.then((value) {
        if(value.isNotEmpty){
          if(mounted) {
            setState(() {
              _article = value[0];
              latestArticleDataIsReady = true;

              articleAgentInfoMap = _article.propertyInfo.agentInfo;
              agentList = _article.propertyInfo.agentList;
              agencyList = _article.propertyInfo.agencyList;
              agentDisplayOption = _article.propertyInfo.agentDisplayOption;
              loadRealtorInfoData(_article);
            });
          }
          if(isLoggedIn) {
            final response = _propertyBloc.fetchIsFavProperty(widget.propertyID.toString());
            response.then((value) {
              if (value.statusCode == 200 && value.data["success"] == true && value.data["is_fav"] == true) {
                if(mounted){
                  setState(() {
                    isLiked = true;
                    isInternetConnected = true;
                  });
                }
              }else if(value.statusCode == null){
                if(mounted){
                  setState(() {
                    isInternetConnected = false;
                  });
                }
              }
              return null;
            });
          }
        }
        return null;
      });

    } else {
      _futureSingleArticle = fetchSingleArticle(permaLink: widget.permaLink);
      _futureSingleArticle.then((value) {
        if(value.isNotEmpty){
          if(mounted) {
            setState(() {
              _article = value[0];

              articleAgentInfoMap = _article.propertyInfo.agentInfo;
              agentList = _article.propertyInfo.agentList;
              agencyList = _article.propertyInfo.agencyList;
              agentDisplayOption = _article.propertyInfo.agentDisplayOption;
              loadRealtorInfoData(_article);
            });
          }
          if(isLoggedIn) {
            final response = _propertyBloc.fetchIsFavProperty(_article.id.toString());
            response.then((value) {
              if (value.statusCode == 200 && value.data["success"] == true && value.data["is_fav"] == true) {
                if(mounted){
                  setState(() {
                    isLiked = true;
                    isInternetConnected = true;
                  });
                }
              }else if(value.statusCode == null){
                if(mounted){
                  setState(() {
                    isInternetConnected = false;
                  });
                }
              }
              return null;
            });
          }
        }

        return null;
      });
    }
  }

  loadRealtorInfoData(Article article){
    if (agentDisplayOption == AGENCY_INFO) {
      _futureAgentOrAgencyInfo = fetchAgencyInfo(agencyList);
      _futureAgentOrAgencyInfo.then((dataList) {
        if(dataList.isNotEmpty){
          var item = dataList[0];
          tempRealtorId = item.id;
          tempRealtorName = item.title;
          tempRealtorEmail = item.email;
          tempRealtorThumbnail = item.thumbnail;
          tempRealtorPhone = isAgent
              ? item.agentOfficeNumber ?? ""
              : item.agencyPhoneNumber ?? "";
          tempRealtorMobile = isAgent
              ? item.agentMobileNumber ?? ""
              : item.agencyMobileNumber ?? "";
          tempRealtorWhatsApp = isAgent
              ? item.agentWhatsappNumber ?? ""
              : item.agencyWhatsappNumber ?? "";
          tempRealtorLink = isAgent
              ? item.agentLink ?? ""
              : item.agencyLink ?? "";

          _realtorInfoMap = {
            tempRealtorIdKey : tempRealtorId,
            tempRealtorEmailKey : tempRealtorEmail,
            tempRealtorThumbnailKey : tempRealtorThumbnail,
            tempRealtorNameKey : tempRealtorName,
            tempRealtorLinkKey : tempRealtorLink,
            tempRealtorMobileKey : tempRealtorMobile,
            tempRealtorWhatsAppKey : tempRealtorWhatsApp,
            tempRealtorPhoneKey : tempRealtorPhone,
          };
          if(mounted){
            setState(() {});
          }
        }
        return null;
      });
      isAgency = true;
    } else if (agentDisplayOption == AGENT_INFO) {
      _futureAgentOrAgencyInfo = fetchAgentInfo(agentList);
      _futureAgentOrAgencyInfo.then((dataList) {
        if(dataList.isNotEmpty){
          var item = dataList[0];
          tempRealtorId = item.id;
          tempRealtorName = item.title ?? "";
          tempRealtorEmail = item.email;
          tempRealtorThumbnail = item.thumbnail;
          tempRealtorPhone = isAgent
              ? item.agentOfficeNumber ?? ""
              : item.agencyPhoneNumber ?? "";
          tempRealtorMobile = isAgent
              ? item.agentMobileNumber ?? ""
              : item.agencyMobileNumber ?? "";
          tempRealtorWhatsApp = isAgent
              ? item.agentWhatsappNumber ?? ""
              : item.agencyWhatsappNumber ?? "";
          tempRealtorLink = isAgent
              ? item.agentLink ?? ""
              : item.agencyLink ?? "";

          _realtorInfoMap = {
            tempRealtorIdKey : tempRealtorId,
            tempRealtorEmailKey : tempRealtorEmail,
            tempRealtorThumbnailKey : tempRealtorThumbnail,
            tempRealtorNameKey : tempRealtorName,
            tempRealtorLinkKey : tempRealtorLink,
            tempRealtorMobileKey : tempRealtorMobile,
            tempRealtorWhatsAppKey : tempRealtorWhatsApp,
            tempRealtorPhoneKey : tempRealtorPhone,
          };
          if(mounted){
            setState(() {});
          }
        }
        return null;
      });
      isAgent = true;
    } else if (agentDisplayOption == AUTHOR_INFO) {
      // print(agentDisplayOption);
      realtorInfo = article.authorInfo;
      isAuthor = true;
      tempRealtorId = realtorInfo.id;
      tempRealtorEmail = realtorInfo.email;
      tempRealtorThumbnail = realtorInfo.picture;
      tempRealtorName = realtorInfo.name ?? "";
      tempRealtorPhone = realtorInfo.phone ?? "";
      tempRealtorMobile = realtorInfo.mobile ?? "";
      tempRealtorWhatsApp = realtorInfo.whatsApp ?? "";
      tempRealtorLink = "";

      _realtorInfoMap = {
        tempRealtorIdKey : tempRealtorId,
        tempRealtorEmailKey : tempRealtorEmail,
        tempRealtorThumbnailKey : tempRealtorThumbnail,
        tempRealtorNameKey : tempRealtorName,
        tempRealtorLinkKey : tempRealtorLink,
        tempRealtorMobileKey : tempRealtorMobile,
        tempRealtorWhatsAppKey : tempRealtorWhatsApp,
        tempRealtorPhoneKey : tempRealtorPhone,
      };
      if(mounted){
        setState(() {});
      }
    }
  }

  bool isDataLoaded(){
    if(singleArticle != null && singleArticle.isNotEmpty){
      return true;
    }
    return false;
  }

  // @override
  // dispose() {
  //   // if(_nativeAd != null){
  //   //   _nativeAd.dispose();
  //   // }
  //   //
  //   // relatedArticles = []; // you need this
  //   // singleArticle = [];
  //   // singleAgencyInfoList = [];
  //   // singleAgentInfoList = [];
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: AppThemePreferences().appTheme.backgroundColor.withOpacity(_opacity),
        statusBarIconBrightness: AppThemePreferences().appTheme.statusBarIconBrightness,
      ),
      child: Scaffold(
        body: widget.article != null ? lazyLoadingWidget() : isInternetConnected == false ? Align(
          alignment: Alignment.topCenter,
          child: noInternetConnectionErrorWidget(context, (){
            checkInternetAndLoadData();
          }),
        ):eagerLoadingWidget(),
      ),
    );
  }

  _scrollListener() {
    if (_scrollController.offset < 50.0) {
      setState(() {
        _opacity = 0.0;
      });
    }
    if (_scrollController.offset > 50.0 && _scrollController.offset < 100.0) {
      setState(() {
        _opacity = 0.4;
      });
    }
    if (_scrollController.offset > 100.0 && _scrollController.offset < 150.0) {
      setState(() {
        _opacity = 0.8;
      });
    }
    if (_scrollController.offset > 190.0) {
      setState(() {
        _opacity = 1.0;
      });
    }
    // print('Scroll Offset: ${_scrollController.offset}');
    // var isEnd = _scrollController.offset >= _scrollController.position.maxScrollExtent &&
    //     !_scrollController.position.outOfRange;
  }


  Future<List<dynamic>> fetchSingleArticle({int id, permaLink}) async {
    List<dynamic> tempList = [];
    if(id != null){
      tempList = await _propertyBloc.fetchSingleArticle(id);
    }else{
      tempList = await _propertyBloc.fetchSingleArticleViaPermaLink(permaLink);
    }

    if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
      if(mounted){
        setState(() {
          isInternetConnected = false;
        });
      }
    }else {
      if (mounted) {
        setState(() {
          isInternetConnected = true;
        });
      }
      if(tempList.isNotEmpty){
        singleArticle.addAll(tempList);

        // if(widget.article == null) {
        //   _article = singleArticle[0];
        //   imageUrlsList = _article.imageList;
        //   loadArticleData(_article);
        //   _initializeArticleData(_article, widget.heroId);
        // } else {
        //   _article = singleArticle[0];
        //   if (imageUrlsList.isNotEmpty) {
        //     String image = imageUrlsList[0];
        //     if (_article.imageList.contains(image)) {
        //       _article.imageList.remove(image);
        //     }
        //   }
        //
        //   if(mounted){
        //     setState(() {
        //       if (imageUrlsList.length < 2) {
        //         imageUrlsList.addAll(_article.imageList);
        //       }
        //       loadArticleData(_article);
        //     });
        //   }
        // }
      }
    }

    return singleArticle;
  }

  Future<List<dynamic>> fetchAgencyInfo(List<String> list) async {
    _realtorInfoList.clear();
    List<int> tempList01 = list.map(int.parse).toList();
    for(var element in tempList01){
      List<dynamic> tempList = await _propertyBloc.fetchSingleAgencyInfoList(element);
      if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
        if(mounted){
          setState(() {
            isInternetConnected = false;
          });
        }
        break;
      }else {
        if (mounted) {
          setState(() {
            isInternetConnected = true;
          });
        }

        if(tempList.isNotEmpty){
          _realtorInfoList.add(tempList[0]);
        }
      }
    }

    return _realtorInfoList;
  }

  Future<List<dynamic>> fetchAgentInfo(List<String> list) async {
    // singleAgentInfoList.clear();
    List<int> tempList01 = list.map(int.parse).toList();
    for (var element in tempList01) {
      List<dynamic> tempList = [];
      tempList = await _propertyBloc.fetchSingleAgentInfoList(element);
      if (tempList == null || (tempList.isNotEmpty && tempList[0] == null) ||
          (tempList.isNotEmpty && tempList[0].runtimeType == Response)) {
        if (mounted) {
          setState(() {
            isInternetConnected = false;
          });
        }
        break;
      } else {
        if (mounted) {
          setState(() {
            isInternetConnected = true;
          });
        }

        if (tempList.isNotEmpty) {
          _realtorInfoList.add(tempList[0]);
        }
      }
    }
    return _realtorInfoList;
  }

  // Future<List<dynamic>> fetchRelatedArticles(int propertyId) async {
  //   List<dynamic> tempList = [];
  //   tempList = await _propertyBloc.fetchSimilarArticles(propertyId);
  //   if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
  //     if(mounted){
  //       setState(() {
  //         isInternetConnected = false;
  //       });
  //     }
  //   }else {
  //     if (mounted) {
  //       setState(() {
  //         isInternetConnected = true;
  //       });
  //     }
  //     if(tempList.isNotEmpty){
  //       relatedArticles.addAll(tempList);
  //     }
  //   }
  //
  //   return relatedArticles;
  // }
  //
  // Future<List<dynamic>> fetchAgencyInfo(List<String> list) async {
  //   singleAgencyInfoList.clear();
  //   List<int> tempList01 = list.map(int.parse).toList();
  //   for(var element in tempList01){
  //     List<dynamic> tempList = await _propertyBloc.fetchSingleAgencyInfoList(element);
  //     if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
  //       if(mounted){
  //         setState(() {
  //           isInternetConnected = false;
  //         });
  //       }
  //       break;
  //     }else {
  //       if (mounted) {
  //         setState(() {
  //           isInternetConnected = true;
  //         });
  //       }
  //
  //       if(tempList.isNotEmpty){
  //         singleAgencyInfoList.add(tempList[0]);
  //       }
  //     }
  //   }
  //
  //   return singleAgencyInfoList;
  // }
  //
  // Future<List<dynamic>> fetchAgentInfo(List<String> list) async {
  //   singleAgentInfoList.clear();
  //   List<int> tempList01 = list.map(int.parse).toList();
  //   for(var element in tempList01) {
  //     List<dynamic> tempList = [];
  //     tempList = await _propertyBloc.fetchSingleAgentInfoList(element);
  //     if(tempList == null || (tempList.isNotEmpty && tempList[0] == null) || (tempList.isNotEmpty && tempList[0].runtimeType == Response)){
  //       if(mounted){
  //         setState(() {
  //           isInternetConnected = false;
  //         });
  //       }
  //       break;
  //     }else {
  //       if (mounted) {
  //         setState(() {
  //           isInternetConnected = true;
  //         });
  //       }
  //
  //       if(tempList.isNotEmpty){
  //         singleAgentInfoList.add(tempList[0]);
  //       }
  //     }
  //   }
  //
  //   return singleAgentInfoList;
  // }

  _initializeArticleData(Article article, String hId) {
    //setState(() {
    _article = article;
    //});

    heroId = hId;
    postId = _article.id;
    catId = _article.catId;
    _articleLink =  _article.link;
    imageUrlsList = _article.imageList;
    postModifiedGmt = _article.modifiedGmt;

    // articleYoutubeVideoLink = _article.video;
    // articleVirtualTourLink = _article.virtualTourLink;
    //
    // articleDetailsMap = _article.propertyDetailsMap;
    // customFieldsMap = _article.propertyInfo.customFieldsMap;
    // if(customFieldsMap!=null && customFieldsMap.isNotEmpty){
    //   articleDetailsMap.addAll(customFieldsMap);
    // }
    //
    // _iconMap.forEach((key, value) {
    //   if (articleDetailsMap.containsKey(key)) {
    //     _mapOfFeaturesWithValues[key] = articleDetailsMap[key];
    //   }
    // });
  }

  // loadArticleData(Article article) {
  //   if(_articleLink.isEmpty){
  //     _articleLink = article.link;
  //   }
  //   type = article.type;
  //   title = article.title;
  //   if(postModifiedGmt.isEmpty){
  //     postModifiedGmt = article.modifiedGmt;
  //   }
  //
  //   String lat = _article.address.lat;
  //   String long = _article.address.long;
  //   articleLocationLink = 'https://maps.googleapis.com/maps/api/staticmap'
  //       '?center=$lat,$long&zoom=16&size=400x100&markers=color:red%7C$lat,$long&key=$GOOGLE_MAP_API_KEY';
  //
  //
  //   if (_article.propertyInfo.propertyStatus != null &&
  //       _article.propertyInfo.propertyStatus.isNotEmpty) {
  //     articleDetailsMap[ARTICLE_STATUS] = _article.propertyInfo.propertyStatus;
  //   }
  //
  //   floorPlansList = article.features.floorPlansList;
  //   additionalDetailsList = article.features.additionalDetailsList;
  //   multiUnitsList = article.features.multiUnitsList;
  //   articleAgentInfoMap = article.propertyInfo.agentInfo;
  //   agentList = article.propertyInfo.agentList;
  //   agencyList = article.propertyInfo.agencyList;
  //   agentDisplayOption = article.propertyInfo.agentDisplayOption;
  //   String tempRating = article.propertyInfo.houzezTotalRating;
  //   if(tempRating != null && tempRating.isNotEmpty){
  //     double tempTotalRating = double.parse(tempRating);
  //     totalRating = tempTotalRating.toStringAsFixed(0);
  //   }
  //
  //   internalFeaturesList = article.internalFeaturesList;
  //   externalFeaturesList = article.externalFeaturesList;
  //   heatingAndCoolingFeaturesList = article.heatingAndCoolingFeaturesList;
  //
  //   if (internalFeaturesList != null && internalFeaturesList.isNotEmpty) {
  //     featuresList.addAll(internalFeaturesList);
  //   }
  //   if (externalFeaturesList != null && externalFeaturesList.isNotEmpty) {
  //     featuresList.addAll(externalFeaturesList);
  //   }
  //   if (heatingAndCoolingFeaturesList != null &&
  //       heatingAndCoolingFeaturesList.isNotEmpty) {
  //     featuresList.addAll(heatingAndCoolingFeaturesList);
  //   }
  //
  //   featuresList.sort();
  //
  //   for (var element in _withoutValuesFeaturesCheckList) {
  //     if (internalFeaturesList.contains(element)) {
  //       featuresWithoutValuesList.add(element);
  //     }
  //   }
  //   if (agentDisplayOption == AGENCY_INFO) {
  //     _futureAgentOrAgencyInfo = fetchAgencyInfo(agencyList);
  //     _futureAgentOrAgencyInfo.then((dataList) {
  //       if(dataList.isNotEmpty){
  //         var item = dataList[0];
  //         tempRealtorId = item.id;
  //         tempRealtorName = item.title;
  //         tempRealtorEmail = item.email;
  //         tempRealtorThumbnail = item.thumbnail;
  //         bool _validURL = GenericMethods.validateURL(tempRealtorThumbnail);
  //         tempRealtorPhone = isAgent
  //             ? item.agentOfficeNumber ?? ""
  //             : item.agencyPhoneNumber ?? "";
  //         tempRealtorMobile = isAgent
  //             ? item.agentMobileNumber ?? ""
  //             : item.agencyMobileNumber ?? "";
  //         tempRealtorWhatsApp = isAgent
  //             ? item.agentWhatsappNumber ?? ""
  //             : item.agencyWhatsappNumber ?? "";
  //         tempRealtorLink = isAgent
  //             ? item.agentLink ?? ""
  //             : item.agencyLink ?? "";
  //         if(mounted){
  //           setState(() {});
  //         }
  //       }
  //       return null;
  //     });
  //     isAgency = true;
  //   } else if (agentDisplayOption == AGENT_INFO) {
  //     _futureAgentOrAgencyInfo = fetchAgentInfo(agentList);
  //     _futureAgentOrAgencyInfo.then((dataList) {
  //       if(dataList.isNotEmpty){
  //         var item = dataList[0];
  //         tempRealtorId = item.id;
  //         tempRealtorName = item.title;
  //         tempRealtorEmail = item.email;
  //         tempRealtorThumbnail = item.thumbnail;
  //         bool _validURL = GenericMethods.validateURL(tempRealtorThumbnail);
  //         tempRealtorPhone = isAgent
  //             ? item.agentOfficeNumber ?? ""
  //             : item.agencyPhoneNumber ?? "";
  //         tempRealtorMobile = isAgent
  //             ? item.agentMobileNumber ?? ""
  //             : item.agencyMobileNumber ?? "";
  //         tempRealtorWhatsApp = isAgent
  //             ? item.agentWhatsappNumber ?? ""
  //             : item.agencyWhatsappNumber ?? "";
  //         tempRealtorLink = isAgent
  //             ? item.agentLink ?? ""
  //             : item.agencyLink ?? "";
  //         if(mounted){
  //           setState(() {});
  //         }
  //       }
  //       return null;
  //     });
  //     isAgent = true;
  //   } else if (agentDisplayOption == AUTHOR_INFO) {
  //     realtorInfo = article.authorInfo;
  //     isAuthor = true;
  //     tempRealtorId = realtorInfo.id;
  //     tempRealtorEmail = realtorInfo.email;
  //     tempRealtorThumbnail = realtorInfo.picture;
  //     tempRealtorName = realtorInfo.name;
  //     tempRealtorPhone = realtorInfo.phone ?? "";
  //     tempRealtorMobile = realtorInfo.mobile ?? "";
  //     tempRealtorWhatsApp = realtorInfo.whatsApp ?? "";
  //     //tempRealtorLink = realtorInfo.agencyLink ?? "";
  //     if(mounted){
  //       setState(() {});
  //     }
  //   }
  //   if(mounted){
  //     setState(() {});
  //   }
  // }
  //
  // setUpNativeAd(){
  //   _nativeAd = NativeAd(
  //     adUnitId: Platform.isAndroid ? ANDROID_NATIVE_AD_ID : IOS_NATIVE_AD_ID,
  //     factoryId: 'homeNativeAd',
  //     request: const AdRequest(),
  //     listener: NativeAdListener(
  //       onAdLoaded: (_) {
  //         setState(() {
  //           _isNativeAdLoaded = true;
  //         });
  //       },
  //       onAdFailedToLoad: (ad, error) {
  //         ad.dispose();
  //         if (kDebugMode) {
  //           print('Ad load failed (code=${error.code} message=${error.message})');
  //         }
  //       },
  //     ),
  //   );
  //
  //   _nativeAd.load();
  // }

  Widget lazyLoadingWidget() {
    return Stack(
      children: [
        RefreshIndicator(
          onRefresh: () async {
            // setState(() {
            //   clearData();
            // });
            // loadData();
            return null;
          },
          child: SingleChildScrollView(
            controller: _scrollController,
            scrollDirection: Axis.vertical,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: propertyDetailPageConfigList.map((map) {
                    return PropertyDetailsPageWidgets(
                      propertyDetailsPageData: map,
                      article: widget.article,
                      propertyID: widget.propertyID,
                      heroId: widget.heroId,
                      latestArticleData: _article,
                      widgetsHook: GenericMethods.widgetItem,
                      latestArticleDataIsReady: latestArticleDataIsReady,
                      realtorInfoMap: _realtorInfoMap,
                      realtorInfoList: _realtorInfoList,
                      propertyDetailsPageWidgetsListener: (Map<String, dynamic> propertyDetailsPageDataMap, bool isDataLoaded){
                        if(isDataLoaded){
                          latestArticleDataIsReady = false;
                        }
                      },
                    );
                  }).toList(),
                ),
                SizedBox(
                  height: 45,
                  child: Container(),
                ),
              ],
            ),
          ),
        ),
        topBarWidget(),
        bottomActionBarWidget(),
      ],
    );
  }

  Widget eagerLoadingWidget() {
    return FutureBuilder(
      future: _futureSingleArticle,
      builder: (context, articleSnapshot) {
        Article article;
        if (articleSnapshot.hasData) {
          if(articleSnapshot.data.length != 0){
            List<dynamic> list = articleSnapshot.data;
            article = list[0];
          }

          if (articleSnapshot.data.length == 0) return noResultFoundPage();
          return Stack(
            children: [
              RefreshIndicator(
                onRefresh: () async {
                  // setState(() {
                  //   clearData();
                  // });
                  // loadData();
                  // return null;
                },
                child: SingleChildScrollView(
                  controller: _scrollController,
                  scrollDirection: Axis.vertical,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: propertyDetailPageConfigList.map((map) {
                      return PropertyDetailsPageWidgets(
                        propertyDetailsPageData: map,
                        article: article,
                        propertyID: article.id,
                        heroId: widget.heroId,
                        fromEagerLoading: true,
                        latestArticleData: null,
                        widgetsHook: GenericMethods.widgetItem,
                        latestArticleDataIsReady: false,
                        realtorInfoMap: _realtorInfoMap,
                        realtorInfoList: _realtorInfoList,
                        propertyDetailsPageWidgetsListener: (Map<String, dynamic> propertyDetailsPageDataMap, bool dataLoaded){

                          },
                      );
                    }).toList(),
                  ),
                ),
              ),
              topBarWidget(),
              bottomActionBarWidget(),
            ],
          );
        } else if (articleSnapshot.hasError) {
          return noResultFoundPage();
        }
        return loadingIndicatorWidget();
      },
    );
  }

  void onRefresh(){
    if(mounted){
      setState(() {
        clearData();
      });
    }
    loadData();
  }

  Widget topBarWidget() {
    return Positioned(
      top: 0,
      child: Container(
        //height: 90,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: AppThemePreferences().appTheme.backgroundColor.withOpacity(_opacity),
          border: Border(
            bottom: BorderSide(
              width: AppThemePreferences.propertyDetailsPageTopBarDividerBorderWidth,
              color: AppThemePreferences().appTheme.propertyDetailsPageTopBarDividerColor.withOpacity(_opacity),
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: AppThemePreferences().appTheme.propertyDetailsPageTopBarShadowColor.withOpacity(_opacity),
              offset: const Offset(0.0, 4.0), //(x,y)
              blurRadius: 3.0,
            ),
          ],
        ),
        child: SafeArea(
          bottom: false,
          /// Background Container() Widget
          child: Container(
            height: 70,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                /// Back Page Navigation Widget
                // widget.propertyID == null
                //     ? Container()
                //     :
                Expanded(
                  flex: 1,
                  child: CircleAvatar(
                    radius: AppThemePreferences.propertyDetailsPageTopBarCircularAvatarRadius,
                    backgroundColor: AppThemePreferences().appTheme.propertyDetailsPageTopBarIconsBackgroundColor,
                    child: IconButton(
                      iconSize: AppThemePreferences.propertyDetailsPageTopBarIconsIconSize,
                      icon: Icon(AppThemePreferences.arrowBackIcon),
                      color: AppThemePreferences().appTheme.propertyDetailsPageTopBarIconsColor,
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ),
                ),

                /// Property Title Widget
                Expanded(
                  flex: 6,
                  child: Opacity(
                    opacity: _opacity,
                    child: Container(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: genericTextWidget(
                        GenericMethods.stripHtmlIfNeeded(_article.title),
                        overflow: TextOverflow.ellipsis,
                        style: AppThemePreferences().appTheme.propertyDetailsPageTopBarTitleTextStyle,
                      ),
                    ),
                  ),
                ),

                /// Favourite Property Widget
                Expanded(
                  flex: 2,
                  child: CircleAvatar(
                    radius: AppThemePreferences.propertyDetailsPageTopBarCircularAvatarRadius,
                    backgroundColor: AppThemePreferences().appTheme.propertyDetailsPageTopBarIconsBackgroundColor,
                    child: IconButton(
                      iconSize: AppThemePreferences.propertyDetailsPageTopBarIconsIconSize,
                      icon: isLiked
                          ? Icon(
                        AppThemePreferences.favouriteIconFilled,
                        color: AppThemePreferences.favouriteIconColor,
                      )
                          : Icon(
                        AppThemePreferences.favouriteBorderIcon,
                        color: AppThemePreferences().appTheme.propertyDetailsPageTopBarIconsColor,
                      ),
                      onPressed: () async {
                        if(isInternetConnected){
                          if (isLoggedIn) {
                            setState(() {
                              isLiked = !isLiked;
                            });
                            Map<String, dynamic> addOrRemoveFromFavInfo = {
                              "listing_id": widget.propertyID,
                            };
                            final response = await _propertyBloc.fetchAddOrRemoveFromFavResponse(addOrRemoveFromFavInfo);

                            String tempResponseString = response.toString().split("{")[1];
                            Map map = jsonDecode("{${tempResponseString.split("}")[0]}}");
                            if (map['added'] == true && map['response'] == "Added") {
                              setState(() {
                                isLiked = true;
                              });
                              _showToastWhileDataLoading(context, GenericMethods.getLocalizedString("add_to_fav"), false);
                              GeneralNotifier().publishChange(GeneralNotifier.NEW_FAV_ADDED_REMOVED);
                            }
                            else if (map['added'] == false && map['response'] == "Removed") {
                              setState(() {
                                isLiked = false;
                              });
                              _showToastWhileDataLoading(context, GenericMethods.getLocalizedString("remove_from_fav"), false);
                              GeneralNotifier().publishChange(GeneralNotifier.NEW_FAV_ADDED_REMOVED);
                            }


                          }
                          else {
                            _showToastWhileDataLoading(context, GenericMethods.getLocalizedString("you_must_login") + GenericMethods.getLocalizedString("before_adding_to_favorites"), true);
                          }
                        }
                      },
                    ),
                  ),
                ),

                /// Share Widget
                Expanded(
                  flex: 1,
                  child: CircleAvatar(
                    backgroundColor: AppThemePreferences().appTheme.propertyDetailsPageTopBarIconsBackgroundColor,
                    radius: AppThemePreferences.propertyDetailsPageTopBarCircularAvatarRadius,
                    child: IconButton(
                      icon: Icon(
                        AppThemePreferences.shareIcon,
                        color: AppThemePreferences().appTheme.propertyDetailsPageTopBarIconsColor,
                        size: AppThemePreferences.propertyDetailsPageTopBarIconsIconSize,
                      ),
                      onPressed: () {
                        Share.share(GenericMethods.getLocalizedString("property_share_msg",inputWords: ["${GenericMethods.stripHtmlIfNeeded(_article.title)}.",_article.link.isEmpty?_articleLink:_article.link]));
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget bottomActionBarWidget() {
    return Positioned(
      bottom: 0.0,
      child: Container(
        decoration: BoxDecoration(
          color: AppThemePreferences().appTheme.backgroundColor.withOpacity(0.8),
          border: Border(
            top: AppThemePreferences().appTheme.propertyDetailsPageBottomMenuBorderSide,
          ),
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 70,
            child:
            !isInternetConnected ? noInternetBottomActionBar(context, ()=> checkInternetAndLoadData()) :
            Container(
              padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
              width: MediaQuery.of(context).size.width,
              child: Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: buttonWidget(
                      text: GenericMethods.getLocalizedString("email_capital"),
                      fontSize: 12,
                      icon: Icon(
                        AppThemePreferences.emailIcon,
                        color: AppThemePreferences.filledButtonIconColor,
                      ),
                      onPressed: () {
                        if (tempRealtorId == null ||
                            tempRealtorName.isEmpty ||
                            tempRealtorEmail.isEmpty ||
                            agentDisplayOption.isEmpty ||
                            tempRealtorThumbnail.isEmpty ||
                            _article.id == null) {
                          _showToastWhileDataLoading(context, GenericMethods.getLocalizedString("please_wait_data_is_loading"), false);
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  SendEmailToRealtor(
                                    informationMap: {
                                      SEND_EMAIL_APP_BAR_TITLE:
                                      GenericMethods.getLocalizedString("enquire_information"),
                                      SEND_EMAIL_REALTOR_ID: tempRealtorId,
                                      SEND_EMAIL_REALTOR_NAME: tempRealtorName,
                                      SEND_EMAIL_REALTOR_EMAIL: tempRealtorEmail,
                                      SEND_EMAIL_REALTOR_TYPE: agentDisplayOption,
                                      SEND_EMAIL_MESSAGE: GenericMethods.getLocalizedString(
                                          "hello_i_am_interested_in",
                                          inputWords: [
                                            GenericMethods.stripHtmlIfNeeded(_article.title),
                                            _articleLink,
                                            tempRealtorLink
                                          ]),
                                      SEND_EMAIL_THUMBNAIL: tempRealtorThumbnail,
                                      SEND_EMAIL_SITE_NAME: APP_NAME,
                                      SEND_EMAIL_LISTING_ID: _article.id,
                                      SEND_EMAIL_LISTING_NAME: _article.title,
                                      SEND_EMAIL_LISTING_LINK: _articleLink!=null && _articleLink.isNotEmpty ? _articleLink:_article.link,
                                    },
                                  ),
                            ),
                          );
                        }
                      },
                      // centeredContent: true,
                    ),
                  ),
                  (tempRealtorPhone != null && tempRealtorPhone.isNotEmpty )||  (tempRealtorMobile != null && tempRealtorMobile.isNotEmpty) ? const SizedBox(width: 5) : Container(),
                  (tempRealtorPhone != null && tempRealtorPhone.isNotEmpty )||  (tempRealtorMobile != null && tempRealtorMobile.isNotEmpty) ? Expanded(
                    flex: 1,
                    child: buttonWidget(
                      text: GenericMethods.getLocalizedString("call_capital"),
                      fontSize: 12,
                      icon: Icon(
                        AppThemePreferences.phoneIcon,
                        color: AppThemePreferences.filledButtonIconColor,
                      ),
                      onPressed: () {
                        String num = "";
                        if(tempRealtorPhone != null && tempRealtorPhone.isNotEmpty ){
                          num = tempRealtorPhone;
                        } else {
                          num = tempRealtorMobile;
                        }
                        launch("tel://$num");
                      },
                      color: AppThemePreferences.callButtonBackgroundColor,
                      // centeredContent: true,
                    ),
                  ) : Container(),
                  tempRealtorWhatsApp != null && tempRealtorWhatsApp.isNotEmpty ? const SizedBox(width: 5) : Container(),
                  tempRealtorWhatsApp != null && tempRealtorWhatsApp.isNotEmpty ?
                  Expanded(
                    flex: 1,
                    child: whatsappElevatedButtonWidget(),
                  ) : Container(),
                ],
              ),
            ),

          ),
        ),
      ),
    );

  }

  Widget whatsappElevatedButtonWidget() {
    return buttonWidget(
      text: GenericMethods.getLocalizedString("whatsapp"),
      fontSize: 12,
      // centeredContent: true,

      color: AppThemePreferences.whatsAppBackgroundColor,
      onPressed: () async {
        String msg = GenericMethods.getLocalizedString("whatsapp_hello_i_am_interested_in",inputWords: [GenericMethods.stripHtmlIfNeeded(_article.title),_articleLink]);
        var whatsappUrl = "whatsapp://send?phone=$tempRealtorWhatsApp&text=$msg";
        await canLaunch(whatsappUrl)
            ? launch(whatsappUrl)
            : launch("https://wa.me/$tempRealtorWhatsApp");
        launch(whatsappUrl);
      },
    );
  }

  // Widget articleImagesWidget() {
  //   return imageUrlsList != null && imageUrlsList.isNotEmpty
  //       ? Hero(
  //     tag: heroId,
  //     child: SizedBox(
  //       height: 300,
  //       child: PageView(
  //         controller: pageController,
  //         onPageChanged: (int page) {
  //           setState(() {
  //             currentImageIndex = page;
  //           });
  //         },
  //         children: List.generate(
  //           imageUrlsList.length, (index) {
  //           bool _validURL = GenericMethods.validateURL(imageUrlsList[index]);
  //           return GestureDetector(
  //             child: !_validURL ? shimmerEffectErrorWidget(iconSize: 100) : FancyShimmerImage(
  //               imageUrl: imageUrlsList[index],
  //               boxFit: BoxFit.cover,
  //               shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
  //               shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
  //               width: MediaQuery.of(context).size.width,
  //               errorWidget: shimmerEffectErrorWidget(iconSize: 100),
  //             ),
  //             onTap: () {
  //               Navigator.push(
  //                 context,
  //                 MaterialPageRoute(
  //                   builder: (context) => FullScreenImageView(
  //                     imageUrls: imageUrlsList,
  //                     tag: heroId,
  //                   ),
  //                 ),
  //               );
  //             },
  //           );
  //         },
  //         ),
  //       )
  //       ,
  //     ),
  //   )
  //       : Container();
  // }
  //
  // Widget imageIndicators() {
  //   return Positioned(
  //     bottom: 10,
  //     left: 0,
  //     right: 0,
  //     child: Align(
  //       alignment: Alignment.bottomCenter,
  //       child: imageUrlsList.length > 1
  //           ? SmoothPageIndicator(
  //         controller: pageController,
  //         count: imageUrlsList.length,
  //         effect: SlideEffect(
  //           dotHeight: 10.0,
  //           dotWidth: 10.0,
  //           spacing: 10,
  //           dotColor: AppThemePreferences.countIndicatorsColor,
  //           activeDotColor: AppThemePreferences().appTheme.primaryColor,
  //         ),
  //       )
  //           : Container(),
  //     ),
  //   );
  // }
  //
  // Widget imageCountIndicator() {
  //   return Positioned(
  //     bottom: 30,
  //     left: GenericMethods.isRTL(context) ? 10 : null,
  //     right: GenericMethods.isRTL(context) ? null : 10,
  //     child: Align(
  //       alignment: Alignment.bottomRight,
  //       child: imageUrlsList.length > 1
  //           ? Container(
  //         padding: const EdgeInsets.all(5),
  //         decoration: BoxDecoration(
  //           color: AppThemePreferences.imageCountIndicatorBackgroundColor,
  //           borderRadius: const BorderRadius.all(Radius.circular(4)),
  //         ),
  //         child: Row(
  //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //           children: [
  //             AppThemePreferences()
  //                 .appTheme
  //                 .propertyDetailsImageIndicatorCameraIcon,
  //             genericTextWidget(
  //               " ${currentImageIndex + 1}/${imageUrlsList.length}",
  //               style: AppThemePreferences().appTheme.propertyDetailsPageImageIndicatorTextTextStyle,
  //             ),
  //           ],
  //         ),
  //       )
  //           : Container(),
  //     ),
  //   );
  // }
  //
  // Widget articleTitle() {
  //   return _article.title != null && _article.title.isNotEmpty ?
  //   Container(
  //     padding: const EdgeInsets.fromLTRB(20, 20, 20, 5),
  //     child: genericTextWidget(
  //       GenericMethods.stripHtmlIfNeeded(_article.title),
  //       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //       style: AppThemePreferences().appTheme.propertyDetailsPagePropertyTitleTextStyle,
  //     ),
  //   ) : Container();
  // }
  //
  // Widget articleAddress() {
  //   return _article.address.address != null &&
  //       _article.address.address.isNotEmpty
  //       ? Container(
  //     padding: const EdgeInsets.fromLTRB(20, 5, 20, 5),
  //     child: genericTextWidget(
  //       _article.address.address,
  //       strutStyle: StrutStyle(height:AppThemePreferences.genericTextHeight),
  //       style: AppThemePreferences().appTheme.bodyTextStyle,
  //       textAlign: TextAlign.left,
  //     ),
  //   )
  //       : Container();
  // }
  //
  // Widget articleStatusAndPriceWidget() {
  //   String _propertyStatus = GenericMethods.getLocalizedString(_article.propertyInfo.propertyStatus);
  //   String propertyPrice = "";
  //   String firstPrice = "";
  //   String _finalPrice = "";
  //
  //   if(_article.propertyDetailsMap.containsKey(PRICE)){
  //     propertyPrice = _article.propertyDetailsMap[PRICE];
  //   }
  //   if(_article.propertyDetailsMap.containsKey(FIRST_PRICE)){
  //     firstPrice = _article.propertyDetailsMap[FIRST_PRICE];
  //   }
  //
  //   _finalPrice = GenericMethods.priceFormatter(propertyPrice,firstPrice);
  //
  //   return _finalPrice.isNotEmpty
  //       ? Container(
  //     padding: const EdgeInsets.fromLTRB(20, 5, 20, 20),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         Padding(
  //           padding: const EdgeInsets.only(bottom: 5),
  //           child: genericTextWidget(
  //             _propertyStatus,
  //             strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //             style: AppThemePreferences()
  //                 .appTheme
  //                 .propertyDetailsPagePropertyStatusTextStyle,
  //           ),
  //         ),
  //         Padding(
  //           padding: const EdgeInsets.only(top: 5),
  //           child: genericTextWidget( _finalPrice,
  //             strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //             style: AppThemePreferences()
  //                 .appTheme
  //                 .propertyDetailsPagePropertyPriceTextStyle,
  //           ),
  //         ),
  //       ],
  //     ),
  //   ) : _propertyStatus.isEmpty ? articlePrice(_finalPrice) : articleStatus();
  // }
  //
  // Widget articleStatus() {
  //   String _propertyStatus = _article.propertyInfo.propertyStatus;
  //   return _propertyStatus != null && _propertyStatus.isNotEmpty
  //       ? Container(
  //     padding: const EdgeInsets.fromLTRB(20, 5, 20, 20),
  //     child: genericTextWidget(
  //       _propertyStatus,
  //       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //       style: AppThemePreferences()
  //           .appTheme
  //           .propertyDetailsPagePropertyStatusTextStyle,
  //     ),
  //   )
  //       : Container();
  // }
  //
  // Widget articlePrice(String _finalPrice) {
  //   return _finalPrice == null || _finalPrice.isEmpty
  //       ? Container()
  //       : Container(
  //     padding: const EdgeInsets.fromLTRB(20, 5, 20, 20),
  //     child: genericTextWidget(_finalPrice,
  //       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //       style: AppThemePreferences()
  //           .appTheme
  //           .propertyDetailsPagePropertyPriceTextStyle,
  //     ),
  //   );
  // }
  //
  // Widget valuedFeaturesWidget() {
  //   return _mapOfFeaturesWithValues != null && _mapOfFeaturesWithValues.isNotEmpty
  //       ? Container(
  //     color: AppThemePreferences().appTheme.containerBackgroundColor,
  //     padding: const EdgeInsets.fromLTRB(1, 1, 1, 1),
  //     child: Card(
  //       color: AppThemePreferences().appTheme.backgroundColor,
  //       child: ConstrainedBox(
  //         constraints: const BoxConstraints(
  //           minHeight: 60,
  //           maxHeight: 90,
  //         ),
  //         child: StaggeredGridView.countBuilder(
  //           physics: const NeverScrollableScrollPhysics(),
  //           crossAxisCount: _mapOfFeaturesWithValues.length,
  //           padding: const EdgeInsets.only(top: 10, bottom: 10),
  //           itemCount: _mapOfFeaturesWithValues.length,
  //           itemBuilder: (context, index) {
  //             var key = _mapOfFeaturesWithValues.keys.elementAt(index);
  //             var value = _mapOfFeaturesWithValues[key];
  //             String label = GenericMethods.getLocalizedString(key);
  //             return Column(
  //               crossAxisAlignment: CrossAxisAlignment.center,
  //               mainAxisSize: MainAxisSize.min,
  //               children: [
  //                 Icon(
  //                   _iconMap.containsKey(key)
  //                       ? _iconMap[key]
  //                       : AppThemePreferences.errorIcon,
  //                   size: AppThemePreferences
  //                       .propertyDetailsValuedFeaturesIconSize,
  //                 ),
  //                 Flexible(
  //                   child: Padding(
  //                     padding: const EdgeInsets.only(top: 3.0),
  //                     child: genericTextWidget(
  //                       value,
  //                       textAlign: TextAlign.center,
  //                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                       style: AppThemePreferences()
  //                           .appTheme
  //                           .subTitle01TextStyle,
  //                     ),
  //                   ),
  //                 ),
  //                 Flexible(
  //                   child: Padding(
  //                     padding: const EdgeInsets.only(top: 3.0),
  //                     child: genericTextWidget(
  //                       key == PROPERTY_DETAILS_PROPERTY_SIZE
  //                           ? _article.features.landAreaUnit != null && _article.features.landAreaUnit.isNotEmpty
  //                           ? _article.features.landAreaUnit : MEASUREMENT_UNIT_TEXT
  //                           : label,
  //                       textAlign: TextAlign.center,
  //                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                       style: AppThemePreferences().appTheme.subTitle02TextStyle,
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             );
  //           },
  //           staggeredTileBuilder: (int index) => StaggeredTile.fit(1),
  //           mainAxisSpacing: 3.0,
  //           crossAxisSpacing: 6.0,
  //         ),
  //       ),
  //     ),
  //   )
  //       : Container();
  // }
  //
  // Widget textHeadingWidget({String text}) {
  //   return headerWidget(
  //     text: text,
  //     padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
  //   );
  // }
  //
  // Widget articleFeaturesDetailsWidget() {
  //   return articleDetailsMap != null && articleDetailsMap.isNotEmpty
  //       ? Column(
  //     children: [
  //       textHeadingWidget(text: AppLocalizations.of(context).details),
  //       Container(
  //         padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
  //         decoration: BoxDecoration(
  //           color: AppThemePreferences().appTheme.containerBackgroundColor,
  //           border: Border.all(
  //             color: AppThemePreferences().appTheme.containerBackgroundColor,
  //             width: 1.0,
  //           ),
  //         ),
  //         child: MediaQuery.removePadding(
  //           context: context,
  //           removeTop: true,
  //           child: ListView.builder(
  //             physics: const NeverScrollableScrollPhysics(),
  //             shrinkWrap: true,
  //             itemCount: articleDetailsMap.length > 3
  //                 ? isMoreDetails
  //                 ? articleDetailsMap.length
  //                 : 3
  //                 : articleDetailsMap.length,
  //             itemBuilder: (context, int index) {
  //               String key = articleDetailsMap.keys.elementAt(index);
  //
  //               String value = articleDetailsMap[key];
  //               if(key == FIRST_PRICE || key == SECOND_PRICE){
  //                 value = _defaultCurrency + value;
  //               }
  //               key = GenericMethods.getLocalizedString(key);
  //               return Container(
  //                 padding: EdgeInsets.symmetric(horizontal: 20),
  //                 height: 40,
  //                 child: Row(
  //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                   children: [
  //                     genericTextWidget(
  //                       key + ": ",
  //                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                       style: AppThemePreferences().appTheme.label01TextStyle,
  //                     ),
  //                     genericTextWidget(
  //                       value,
  //                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                       style: AppThemePreferences().appTheme.subBody01TextStyle,
  //                     ),
  //                   ],
  //                 ),
  //               );
  //             },
  //           ),
  //         ),
  //       ),
  //     ],
  //   ) : Container();
  // }
  //
  // Widget articleAdditionalFeaturesDetailsWidget() {
  //   return isMoreDetails && additionalDetailsList != null && additionalDetailsList.isNotEmpty
  //       ? Column(
  //     children: [
  //       textHeadingWidget(
  //           text: AppLocalizations.of(context).additional_details
  //       ),
  //       Container(
  //         padding: const EdgeInsets.symmetric(vertical: 5),
  //         child: MediaQuery.removePadding(
  //           context: context,
  //           removeTop: true,
  //           child: ListView.builder(
  //             physics: const NeverScrollableScrollPhysics(),
  //             shrinkWrap: true,
  //             itemCount: additionalDetailsList.length,
  //             itemBuilder: (context, int index) {
  //
  //               String title = additionalDetailsList[index].title;
  //               String value = additionalDetailsList[index].value;
  //
  //               return Column(
  //                 children: [
  //                   Container(
  //                     height: 40,
  //                     padding: const EdgeInsets.symmetric(horizontal: 20),
  //                     color: index % 2 == 0
  //                         ? AppThemePreferences().appTheme.containerBackgroundColor
  //                         : null,
  //                     child: Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         genericTextWidget(
  //                           GenericMethods.getLocalizedString(title) + " : ",
  //                           strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                           style: AppThemePreferences().appTheme.label01TextStyle,
  //                         ),
  //                         genericTextWidget(
  //                           value,
  //                           strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                           style: AppThemePreferences().appTheme.subBody01TextStyle,
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                   // SizedBox(height: 15),
  //                 ],
  //               );
  //             },
  //           ),
  //         ),
  //       ),
  //     ],
  //   ) : Container();
  // }
  //
  // Widget showMoreDetails() {
  //   return articleDetailsMap.length > 3 || (additionalDetailsList != null && additionalDetailsList.isNotEmpty)
  //       ? Row(
  //     mainAxisAlignment: MainAxisAlignment.end,
  //     children: [
  //       Container(
  //         padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
  //         child: InkWell(
  //           onTap: () {
  //             setState(() {
  //               isMoreDetails = !isMoreDetails;
  //             });
  //           },
  //           child: genericTextWidget(
  //             isMoreDetails
  //                 ? AppLocalizations.of(context).less_details
  //                 : AppLocalizations.of(context).more_details,
  //             strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //             style: AppThemePreferences().appTheme.readMoreTextStyle,
  //             // textAlign: TextAlign.right,
  //           ),
  //         ),
  //       ),
  //     ],
  //   )
  //       : Container();
  // }
  //
  // Widget showMoreFeaturesWidget() {
  //   return featuresList.length > 4
  //       ? Row(
  //     mainAxisAlignment: MainAxisAlignment.end,
  //     children: [
  //       Container(
  //         //alignment: Alignment.topRight,
  //         padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
  //         child: InkWell(
  //           onTap: () {
  //             setState(() {
  //               showMoreFeatures = !showMoreFeatures;
  //             });
  //           },
  //           child: genericTextWidget(
  //             showMoreFeatures
  //                 ? AppLocalizations.of(context).show_less
  //                 : AppLocalizations.of(context).show_more,
  //             strutStyle: StrutStyle(
  //                 height: AppThemePreferences.genericTextHeight),
  //             style: AppThemePreferences().appTheme.readMoreTextStyle,
  //             //textAlign: TextAlign.right,
  //           ),
  //         ),
  //       ),
  //     ],
  //   )
  //       : Container();
  // }
  //
  // Widget articleFeaturesWidget() {
  //   return featuresList == null || featuresList.isEmpty ? Container() : Column(
  //     children: [
  //       textHeadingWidget(text: AppLocalizations.of(context).features),
  //       featuresWithoutValuesList != null && featuresWithoutValuesList.isNotEmpty ? Container(
  //         child: StaggeredGridView.countBuilder(
  //           physics: const NeverScrollableScrollPhysics(),
  //           shrinkWrap: true,
  //           crossAxisCount: 3,
  //           padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
  //           itemCount: featuresWithoutValuesList.length,
  //           itemBuilder: (context, index) {
  //             var item = featuresWithoutValuesList[index];
  //             String label = GenericMethods.getLocalizedString(item);
  //
  //             return Column(
  //               crossAxisAlignment: CrossAxisAlignment.center,
  //               children: [
  //                 Icon(
  //                   _iconMap.containsKey(item) ? _iconMap[item] : Icons.error_outlined,
  //                   size: AppThemePreferences.propertyDetailsFeaturesIconSize,
  //                 ),
  //                 Padding(
  //                   padding: const EdgeInsets.only(top: 10.0),
  //                   child: genericTextWidget(
  //                     label,
  //                     strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                     style: AppThemePreferences().appTheme.subBody01TextStyle,
  //                   ),
  //                 ),
  //               ],
  //             );
  //           },
  //
  //           staggeredTileBuilder: (int index) => const StaggeredTile.fit(1),
  //           mainAxisSpacing: 20.0,
  //           crossAxisSpacing: 3.0,
  //         ),
  //       ) : Container(padding: const EdgeInsets.only(bottom: 10),),
  //       Container(
  //         padding: EdgeInsets.fromLTRB(20, 0, 20, 05),
  //         child: Column(
  //           children: [
  //             Wrap(
  //               spacing: 8.0,
  //               runSpacing: 5.0,
  //               children: List<Widget>.generate(
  //                 showMoreFeatures ? featuresList.length : min(3,featuresList.length),
  //                     (int index) {
  //                   var item = featuresList[index];
  //                   String label = GenericMethods.getLocalizedString(item);
  //                   return Chip(
  //                     padding: EdgeInsets.all(10.0),
  //                     backgroundColor: AppThemePreferences().appTheme.propertyDetailsPageChipsBackgroundColor,
  //                     avatar: CircleAvatar(backgroundColor: Colors.transparent, child: AppThemePreferences().appTheme.propertyDetailsChipsIcon),
  //                     label: genericTextWidget(label, strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight), style: AppThemePreferences().appTheme.subBody01TextStyle),
  //                   );
  //                 },
  //               ),
  //             ),
  //           ],
  //         ),
  //       ),
  //     ],
  //   );
  // }
  //
  // Widget articleDescriptionWidget() {
  //   String content = GenericMethods.stripHtmlIfNeeded(_article.content);
  //   final maxLines = isReadMore ? null : 6;
  //   final overFlow = isReadMore ? TextOverflow.visible : TextOverflow.ellipsis;
  //   return content != null && content.isNotEmpty
  //       ? Column(
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: [
  //       textHeadingWidget(text: AppLocalizations.of(context).description),
  //       Container(
  //         padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
  //         child: Align(
  //           alignment: Alignment.centerLeft,
  //           child: genericTextWidget(
  //             content,
  //             maxLines: maxLines,
  //             overflow: overFlow,
  //             strutStyle: StrutStyle(height: AppThemePreferences.bodyTextHeight),
  //             style: AppThemePreferences().appTheme.bodyTextStyle,
  //             textAlign: TextAlign.justify,
  //           ),
  //         ),
  //       ),
  //       content.length > 300
  //           ? Row(
  //         mainAxisAlignment:  MainAxisAlignment.end,
  //         children: [
  //           Container(
  //             padding: EdgeInsets.fromLTRB(20, 0, 20, 5),
  //             child: Align(
  //               // alignment: Alignment.centerRight,
  //               child: InkWell(
  //                 onTap: () {
  //                   setState(() {
  //                     isReadMore = !isReadMore;
  //                   });
  //                 },
  //                 child: genericTextWidget(
  //                   isReadMore
  //                       ? AppLocalizations.of(context).read_less
  //                       : AppLocalizations.of(context).read_more,
  //                   strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                   style:
  //                   AppThemePreferences().appTheme.readMoreTextStyle,
  //                   // textAlign: TextAlign.justify,
  //                 ),
  //               ),
  //             ),
  //           ),
  //         ],
  //       )
  //           : Container(),
  //     ],
  //   )
  //       : Container();
  // }
  //
  // Widget articleAddressWidget() {
  //   return Padding(
  //     padding: const EdgeInsets.only(top:10.0),
  //     child: Column(
  //       children: [
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //           children: [
  //             Padding(
  //               padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
  //               child: genericTextWidget(
  //                 AppLocalizations.of(context).address,
  //                 strutStyle: StrutStyle(height: 1.5),
  //                 style: AppThemePreferences().appTheme.headingTextStyle,
  //               ),
  //             ),
  //             Padding(
  //               padding: const EdgeInsets.symmetric(horizontal: 20),
  //               child: lightButtonWidget(
  //                   buttonWidth: 160,
  //                   buttonHeight: 35,
  //                   text: AppLocalizations.of(context).open_in_map,
  //                   color: AppThemePreferences.selectedItemBackgroundColorLight,
  //                   icon: Icon(
  //                     AppThemePreferences.mapIcon,
  //                     color: AppThemePreferences().appTheme.selectedItemTextColor,
  //                   ),
  //                   onPressed: navigateToFullScreenMapViewArticle),
  //             ),
  //           ],
  //         ),
  //         Container(
  //           padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
  //           decoration: BoxDecoration(
  //             color: AppThemePreferences().appTheme.containerBackgroundColor,
  //             border: Border.all(
  //               color: AppThemePreferences().appTheme.containerBackgroundColor,
  //               width: 1.0,
  //             ),
  //           ),
  //           child: Container(
  //             padding: EdgeInsets.symmetric(horizontal: 20),
  //             // height: 40,
  //             child: Column(
  //               children: [
  //                 // addressRowWidget(AppLocalizations.of(context).address, _article.address.address),
  //                 _article.address.address != null && _article.address.address.isNotEmpty
  //                     ? Row(
  //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                   children: [
  //                     genericTextWidget(
  //                       AppLocalizations.of(context).address + ": ",
  //                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                       style: AppThemePreferences().appTheme.label01TextStyle,
  //                     ),
  //                     SizedBox(
  //                       width: 150,
  //                       child: genericTextWidget(
  //                         _article.address.address,
  //                         overflow: TextOverflow.ellipsis,
  //                         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                         style: AppThemePreferences().appTheme.subBody01TextStyle,
  //                       ),
  //                     ),
  //                   ],
  //                 )
  //                     : Container(),
  //                 addressRowWidget(AppLocalizations.of(context).country, _article.address.country),
  //                 addressRowWidget(AppLocalizations.of(context).city, _article.address.city),
  //                 addressRowWidget(AppLocalizations.of(context).area, _article.address.area),
  //               ],
  //             ),
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }
  //
  // Widget addressRowWidget(String label, String value){
  //   return value!=null && value.isNotEmpty ? Row(
  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //     children: [
  //       genericTextWidget(
  //         label + ": ",
  //         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //         style: AppThemePreferences().appTheme.label01TextStyle,
  //       ),
  //       genericTextWidget(
  //         value,
  //         overflow: TextOverflow.ellipsis,
  //         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //         style: AppThemePreferences().appTheme.subBody01TextStyle,
  //       ),
  //     ],
  //   ):Container();
  // }
  //
  // Widget showPropertyLocationOnMap(){
  //   return Column(
  //     children: [
  //       // textHeadingWidget(
  //       //     text: AppLocalizations.of(context).map_view
  //       // ),
  //       Padding(
  //         padding: const EdgeInsets.fromLTRB(20, 10, 20, 5),
  //         child: GestureDetector(
  //           child: articleLocationLink.isEmpty ? Container() : FancyShimmerImage(
  //             imageUrl: articleLocationLink,
  //             boxFit: BoxFit.cover,
  //             shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
  //             shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
  //             width: MediaQuery.of(context).size.width,
  //             height: 100,
  //             errorWidget: Container(),
  //           ),
  //           onTap: navigateToFullScreenMapViewArticle,
  //         ),
  //       ),
  //     ],
  //   );
  // }
  //
  // navigateToFullScreenMapViewArticle(){
  //   _article.image = imageUrlsList[0];
  //   Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //       builder: (context) => FullScreenMapViewArticle(_article),
  //     ),
  //   );
  // }
  //
  // Widget articleFloorPlanWidget() {
  //   return floorPlansList != null && floorPlansList.isNotEmpty
  //       ? Column(
  //     children: [
  //       textHeadingWidget(
  //           text: AppLocalizations.of(context).floor_plans
  //       ),
  //       Column(
  //         children: floorPlansList.map((item) {
  //           Map<String, dynamic> floorPlanMap = {};
  //           String title = item.title;
  //           String rooms = item.rooms;
  //           String bathrooms = item.bathrooms;
  //           String price = item.price;
  //           String pricePostFix = item.pricePostFix;
  //           if(pricePostFix != null && pricePostFix.isNotEmpty){
  //             price = price + pricePostFix;
  //           }
  //           String size = item.size;
  //           String image = item.image;
  //           // String description = item.description;
  //
  //           if (rooms != null && rooms.isNotEmpty) {
  //             floorPlanMap[FLOOR_PLAN_ROOMS] = AppThemePreferences.bedIcon;
  //           }
  //           if (bathrooms != null && bathrooms.isNotEmpty) {
  //             floorPlanMap[FLOOR_PLAN_BATHROOMS] = AppThemePreferences.bathtubIcon;
  //           }
  //           if (price != null && price.isNotEmpty) {
  //             floorPlanMap[FLOOR_PLAN_PRICE] = AppThemePreferences.priceTagIcon;
  //           }
  //           if (size != null && size.isNotEmpty) {
  //             floorPlanMap[FLOOR_PLAN_SIZE] = AppThemePreferences.areaSizeIcon;
  //           }
  //           return floorPlanMap == null || floorPlanMap.isEmpty || floorPlanMap.length < 1 ?
  //           Container(
  //             width: double.infinity,
  //             height: 80,
  //             padding: const EdgeInsets.symmetric(horizontal: 1, vertical: 1),
  //             color: AppThemePreferences().appTheme.containerBackgroundColor,
  //             child: Card(
  //               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
  //               child: InkWell(
  //                 borderRadius: BorderRadius.all(Radius.circular(5)),
  //                 onTap: () {
  //                   if(image != null && image.isNotEmpty){
  //                     Navigator.push(
  //                       context,
  //                       MaterialPageRoute(
  //                         builder: (context) => FullScreenImageView(
  //                           imageUrls: [image],
  //                           tag: heroId,
  //                           floorPlan: true,
  //                         ),
  //                       ),
  //                     );
  //                   }
  //                 },
  //                 child: Container(
  //                   padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
  //                   child: Row(
  //                     mainAxisAlignment: MainAxisAlignment.spaceAround,
  //                     children: [
  //                       Container(
  //                         padding: EdgeInsets.fromLTRB(10, 0, 10, 5),
  //                         child: genericTextWidget(
  //                           AppLocalizations.of(context).first_floor,
  //                           strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                           style: AppThemePreferences().appTheme.label01TextStyle,
  //                         ),
  //                       ),
  //                       Container(
  //                         padding: EdgeInsets.fromLTRB(10, 0, 10, 5),
  //                         child: CircleAvatar(
  //                           radius: 13,
  //                           backgroundColor: AppThemePreferences().appTheme.homeScreenTopBarRightArrowBackgroundColor,
  //                           // backgroundColor: AppThemePreferences().appTheme.primaryColor,
  //                           child: AppThemePreferences().appTheme.propertyDetailPageRightArrowIcon,
  //                         ),
  //                       ),
  //
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           ) : Container(
  //             padding: const EdgeInsets.symmetric(horizontal: 1, vertical: 1),
  //             color: AppThemePreferences().appTheme.containerBackgroundColor,
  //             child: Card(
  //               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
  //               child: InkWell(
  //                 borderRadius: BorderRadius.all(Radius.circular(5)),
  //                 onTap: () {
  //                   Navigator.push(
  //                     context,
  //                     MaterialPageRoute(
  //                       builder: (context) => FullScreenImageView(
  //                         imageUrls: [image],
  //                         tag: heroId,
  //                         floorPlan: true,
  //                       ),
  //                     ),
  //                   );
  //                 },
  //                 child: Container(
  //                   padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
  //                   child: Column(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: [
  //                       Container(
  //                         padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
  //                         child: genericTextWidget(
  //                           title,
  //                           strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                           style: AppThemePreferences().appTheme.label01TextStyle,
  //                         ),
  //                       ),
  //                       Container(
  //                         padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
  //                         child: ConstrainedBox(
  //                           constraints: const BoxConstraints(
  //                             minHeight: 40,
  //                             maxHeight: 50,
  //                           ),
  //                           child: StaggeredGridView.countBuilder(
  //                             physics: const NeverScrollableScrollPhysics(),
  //                             crossAxisCount: floorPlanMap.length,
  //                             padding: const EdgeInsets.symmetric(vertical: 10),
  //                             itemCount: floorPlanMap.length,
  //                             itemBuilder: (context, index) {
  //                               var key = floorPlanMap.keys.elementAt(index);
  //                               var value = key == FLOOR_PLAN_ROOMS
  //                                   ? rooms
  //                                   : key == FLOOR_PLAN_BATHROOMS
  //                                   ? bathrooms
  //                                   : key == FLOOR_PLAN_PRICE
  //                                   ? price
  //                                   : key == FLOOR_PLAN_SIZE
  //                                   ? size
  //                                   : "";
  //                               return Column(
  //                                 crossAxisAlignment: CrossAxisAlignment.center,
  //                                 mainAxisSize: MainAxisSize.min,
  //                                 children: [
  //                                   Align(
  //                                     alignment: Alignment.center,
  //                                     child: Icon(
  //                                       floorPlanMap[key],
  //                                       size: AppThemePreferences.propertyDetailsFloorPlansIconSize,
  //                                     ),
  //                                   ),
  //                                   Container(
  //                                     alignment: Alignment.center,
  //                                     padding: const EdgeInsets.only(top: 10.0),
  //                                     child: genericTextWidget(
  //                                       key == FLOOR_PLAN_PRICE
  //                                           ? "\$$value"
  //                                           : value,
  //                                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                       style: AppThemePreferences().appTheme.subTitle02TextStyle,
  //                                     ),
  //                                   ),
  //                                 ],
  //                               );
  //                             },
  //                             staggeredTileBuilder: (int index) => new StaggeredTile.fit(1),
  //                             mainAxisSpacing: 3.0,
  //                             crossAxisSpacing: 6.0, //16.0,
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           );
  //         }).toList(),
  //       ),
  //     ],
  //   )
  //       : Container();
  // }
  //
  // Widget articleMultiUnitsWidget() {
  //   return multiUnitsList != null && multiUnitsList.isNotEmpty
  //       ? Column(
  //     children: [
  //       textHeadingWidget(
  //         text: AppLocalizations.of(context).multi_units,
  //       ),
  //       Column(
  //         children: multiUnitsList.map((item) {
  //           Map<String, dynamic> multiUnitMap = {};
  //           String faveMuTitle = item.title;
  //           String faveMuBeds= item.bedrooms;
  //           String faveMuBaths= item.bathrooms;
  //           String faveMuSize= "${item.size} ${item.sizePostfix}";
  //
  //           if (faveMuBeds != null && faveMuBeds.isNotEmpty) {
  //             multiUnitMap[FLOOR_PLAN_ROOMS] = AppThemePreferences.bedIcon;
  //           }
  //           if (faveMuBaths != null && faveMuBaths.isNotEmpty) {
  //             multiUnitMap[FLOOR_PLAN_BATHROOMS] = AppThemePreferences.bathtubIcon;
  //           }
  //           if (faveMuSize != null && faveMuSize.isNotEmpty) {
  //             multiUnitMap[FLOOR_PLAN_SIZE] = AppThemePreferences.areaSizeIcon;
  //           }
  //
  //           return multiUnitMap == null || multiUnitMap.isEmpty || multiUnitMap.length < 1 ? Container() : Container(
  //             padding: const EdgeInsets.symmetric(horizontal: 1, vertical: 1),
  //             color: AppThemePreferences().appTheme.containerBackgroundColor,
  //             child: Card(
  //               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
  //               child: InkWell(
  //                 borderRadius: const BorderRadius.all(Radius.circular(5)),
  //                 onTap: () {
  //                   Navigator.push(
  //                     context,
  //                     MaterialPageRoute(
  //                       builder: (context) => FullScreenMultiUnits(multiUnitsList),
  //                     ),
  //                   );
  //                 },
  //                 child: Container(
  //                   padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
  //                   child: Column(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: [
  //                       Container(
  //                         padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
  //                         child: genericTextWidget(
  //                           faveMuTitle,
  //                           strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                           style: AppThemePreferences().appTheme.label01TextStyle,
  //                         ),
  //                       ),
  //                       Container(
  //                         padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
  //                         child: ConstrainedBox(
  //                           constraints: const BoxConstraints(
  //                             minHeight: 40,
  //                             maxHeight: 50,
  //                           ),
  //                           child: StaggeredGridView.countBuilder(
  //                             physics: const NeverScrollableScrollPhysics(),
  //                             crossAxisCount: multiUnitMap.length,
  //                             padding: const EdgeInsets.symmetric(vertical: 10),
  //                             itemCount: multiUnitMap.length,
  //                             itemBuilder: (context, index) {
  //                               var key = multiUnitMap.keys.elementAt(index);
  //                               var value = key == FLOOR_PLAN_ROOMS
  //                                   ? faveMuBeds
  //                                   : key == FLOOR_PLAN_BATHROOMS
  //                                   ? faveMuBaths
  //                                   : key == FLOOR_PLAN_SIZE
  //                                   ? faveMuSize
  //                                   : "";
  //                               return Column(
  //                                 crossAxisAlignment: CrossAxisAlignment.center,
  //                                 mainAxisSize: MainAxisSize.min,
  //                                 children: [
  //                                   Align(
  //                                     alignment: Alignment.center,
  //                                     child: Icon(
  //                                       multiUnitMap[key],
  //                                       size: AppThemePreferences.propertyDetailsFloorPlansIconSize,
  //                                     ),
  //                                   ),
  //                                   Container(
  //                                     alignment: Alignment.center,
  //                                     padding: const EdgeInsets.only(top: 10.0),
  //                                     child: genericTextWidget(
  //                                       value,
  //                                       strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                       style: AppThemePreferences().appTheme.subTitle02TextStyle,
  //                                     ),
  //                                   ),
  //                                 ],
  //                               );
  //                             },
  //                             staggeredTileBuilder: (int index) => const StaggeredTile.fit(1),
  //                             mainAxisSpacing: 3.0,
  //                             crossAxisSpacing: 6.0, //16.0,
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           );
  //         }).toList(),
  //       ),
  //     ],
  //   )
  //       : Container();
  // }
  //
  // Widget authorContactInformationWidget() {
  //   bool _validURL = GenericMethods.validateURL(tempRealtorThumbnail);
  //   return Container(
  //     child: !isAuthor ? Container() : Column(
  //       children: [
  //         textHeadingWidget(text: AppLocalizations.of(context).contact_information),
  //         Container(
  //           padding: EdgeInsets.symmetric(vertical: 10),
  //           child: Container(
  //             padding: EdgeInsets.symmetric(vertical: 1, horizontal: 1),
  //             color: AppThemePreferences().appTheme.containerBackgroundColor,
  //             height: 150, //180,
  //             child: Card(
  //               elevation: AppThemePreferences.authorContactInformationElevation,
  //               child: Row(
  //                 children: [
  //                   Container(
  //                     padding: EdgeInsets.only(left: 10),
  //                     height: 120, //150,
  //                     width: 110, //120,
  //                     child: Hero(
  //                       tag: 'hero$tempRealtorId',
  //                       child: Stack(
  //                         children: [
  //                           ClipRRect(
  //                             borderRadius: BorderRadius.all(Radius.circular(10)),
  //                             child: !_validURL ? shimmerEffectErrorWidget(iconSize: 50) : FancyShimmerImage(
  //                               imageUrl: tempRealtorThumbnail,
  //                               boxFit: BoxFit.cover,
  //                               shimmerBaseColor: AppThemePreferences()
  //                                   .appTheme
  //                                   .shimmerEffectBaseColor,
  //                               shimmerHighlightColor:
  //                               AppThemePreferences()
  //                                   .appTheme
  //                                   .shimmerEffectHighLightColor,
  //                               errorWidget: shimmerEffectErrorWidget(iconSize: 50),
  //                             ),
  //                           ),
  //                           Positioned.fill(
  //                             child: Material(
  //                               color: Colors.transparent,
  //                               child: InkWell(
  //                                 borderRadius: BorderRadius.all(
  //                                     Radius.circular(10)),
  //                                 onTap: () {
  //                                   navigateToRealtorInfoPage(
  //                                     buildContext: context,
  //                                     agentType: agentDisplayOption,
  //                                     heroId: 'hero$tempRealtorId',
  //                                     realtorInfo: {
  //                                       AUTHOR_DATA: realtorInfo,
  //                                     },
  //                                   );
  //                                 },
  //                               ),
  //                             ),
  //                           ),
  //                         ],
  //                       ),
  //                     ),
  //                   ),
  //                   Expanded(
  //                     child: Container(
  //                       padding: EdgeInsets.fromLTRB(10, 8, 0, 8),
  //                       child: Column(
  //                         crossAxisAlignment: CrossAxisAlignment.start,
  //                         mainAxisAlignment:
  //                         MainAxisAlignment.spaceBetween,
  //                         children: [
  //                           Container(
  //                             padding: EdgeInsets.only(top: 0),
  //                             child: InkWell(
  //                               borderRadius:
  //                               BorderRadius.all(Radius.circular(10)),
  //                               onTap: () {
  //                                 navigateToRealtorInfoPage(
  //                                   buildContext: context,
  //                                   agentType: agentDisplayOption,
  //                                   heroId: 'hero$tempRealtorId',
  //                                   realtorInfo: {
  //                                     AUTHOR_DATA: realtorInfo,
  //                                   },
  //                                 );
  //                               },
  //                               child: Row(
  //                                 children: [
  //                                   Icon(AppThemePreferences.personIcon),
  //                                   Expanded(
  //                                     child: Padding(
  //                                       padding: const EdgeInsets.only(
  //                                           left: 10),
  //                                       child: genericTextWidget(
  //                                         tempRealtorName,
  //                                         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                         style: AppThemePreferences().appTheme.subBody01TextStyle,
  //                                         // style: AppThemePreferences().appTheme.body01TextStyle,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                 ],
  //                               ),
  //                             ),
  //                           ),
  //                           tempRealtorEmail.isNotEmpty
  //                               ? Padding(
  //                             padding:
  //                             const EdgeInsets.only(top: 0),
  //                             child: InkWell(
  //                               borderRadius: BorderRadius.all(
  //                                   Radius.circular(10)),
  //                               onTap: () {
  //                                 Navigator.push(
  //                                   context,
  //                                   MaterialPageRoute(
  //                                     builder: (context) =>
  //                                         SendEmailToRealtor(
  //                                           informationMap: {
  //                                             SEND_EMAIL_REALTOR_NAME:
  //                                             tempRealtorName,
  //                                             SEND_EMAIL_THUMBNAIL:
  //                                             tempRealtorThumbnail,
  //                                             SEND_EMAIL_SITE_NAME:
  //                                             APP_NAME,
  //                                           },
  //                                         ),
  //                                   ),
  //                                 );
  //                               },
  //                               child: Row(
  //                                 children: [
  //                                   Icon(AppThemePreferences
  //                                       .emailIcon),
  //                                   Expanded(
  //                                     child: Padding(
  //                                       padding:
  //                                       const EdgeInsets.only(
  //                                           left: 10),
  //                                       child: genericTextWidget(
  //                                         tempRealtorEmail,
  //                                         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                         style:
  //                                         AppThemePreferences()
  //                                             .appTheme
  //                                             .subBody01TextStyle,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                 ],
  //                               ),
  //                             ),
  //                           )
  //                               : Container(),
  //                           tempRealtorPhone.isNotEmpty
  //                               ? Padding(
  //                             padding:
  //                             const EdgeInsets.only(top: 0),
  //                             child: InkWell(
  //                               borderRadius: BorderRadius.all(
  //                                   Radius.circular(10)),
  //                               onTap: () {
  //                                 launch("tel://$tempRealtorPhone");
  //                               },
  //                               child: Row(
  //                                 children: [
  //                                   Icon(AppThemePreferences
  //                                       .callIcon),
  //                                   Expanded(
  //                                     child: Padding(
  //                                       padding:
  //                                       const EdgeInsets.only(
  //                                           left: 10),
  //                                       child: genericTextWidget(
  //                                         tempRealtorPhone,
  //                                         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                         style:
  //                                         AppThemePreferences()
  //                                             .appTheme
  //                                             .subBody01TextStyle,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                 ],
  //                               ),
  //                             ),
  //                           )
  //                               : Container(),
  //                           tempRealtorMobile.isNotEmpty
  //                               ? Padding(
  //                             padding:
  //                             const EdgeInsets.only(top: 0),
  //                             child: InkWell(
  //                               borderRadius: BorderRadius.all(
  //                                   Radius.circular(10)),
  //                               onTap: () {
  //                                 launch(
  //                                     "tel://$tempRealtorMobile");
  //                               },
  //                               child: Row(
  //                                 children: [
  //                                   Icon(AppThemePreferences
  //                                       .phoneAndroidIcon),
  //                                   Expanded(
  //                                     child: Padding(
  //                                       padding:
  //                                       const EdgeInsets.only(
  //                                           left: 10),
  //                                       child: genericTextWidget(
  //                                         tempRealtorMobile,
  //                                         strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                         style:
  //                                         AppThemePreferences()
  //                                             .appTheme
  //                                             .subBody01TextStyle,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                 ],
  //                               ),
  //                             ),
  //                           )
  //                               : Container(),
  //                         ],
  //                       ),
  //                     ),
  //                   ),
  //                 ],
  //               ),
  //             ),
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }
  //
  // void navigateToRealtorInfoPage(
  //     {BuildContext buildContext,
  //       String agentType,
  //       String heroId,
  //       Map<String, dynamic> realtorInfo}) {
  //   Navigator.push(
  //     buildContext,
  //     MaterialPageRoute(
  //       builder: (context) => RealtorInformationDisplayPage(
  //         agentType: agentType,
  //         heroId: heroId,
  //         realtorInformation: realtorInfo,
  //       ),
  //     ),
  //   );
  // }
  //
  // Widget agentOrAgencyDisplayInformationWidget(Future<List<dynamic>> articlesList) {
  //   return FutureBuilder<List<dynamic>>(
  //     future: articlesList,
  //     builder: (context, articleSnapshot) {
  //       if (articleSnapshot.hasData) {
  //         if (articleSnapshot.data.length == 0) return Container();
  //         return Column(
  //           children: <Widget>[
  //             textHeadingWidget(
  //                 text: AppLocalizations.of(context).contact_information),
  //             Column(
  //               children: articleSnapshot.data.map((item) {
  //                 String heroId = "hero" + item.id.toString();
  //                 tempRealtorId = item.id;
  //                 tempRealtorName = item.title;
  //                 tempRealtorEmail = item.email;
  //                 tempRealtorThumbnail = item.thumbnail;
  //                 bool _validURL = GenericMethods.validateURL(tempRealtorThumbnail);
  //                 tempRealtorPhone = isAgent
  //                     ? item.agentOfficeNumber ?? ""
  //                     : item.agencyPhoneNumber ?? "";
  //                 tempRealtorMobile = isAgent
  //                     ? item.agentMobileNumber ?? ""
  //                     : item.agencyMobileNumber ?? "";
  //                 tempRealtorWhatsApp = isAgent
  //                     ? item.agentWhatsappNumber ?? ""
  //                     : item.agencyWhatsappNumber ?? "";
  //                 tempRealtorLink = isAgent
  //                     ? item.agentLink ?? ""
  //                     : item.agencyLink ?? "";
  //                 return Container(
  //                   padding: EdgeInsets.symmetric(vertical: 10),
  //                   child: Container(
  //                     padding: EdgeInsets.symmetric(vertical: 1, horizontal: 1),
  //                     color: AppThemePreferences().appTheme.containerBackgroundColor,
  //                     height: 150, //150
  //                     child: Card(
  //                       child: Row(
  //                         mainAxisAlignment: MainAxisAlignment.start,
  //                         crossAxisAlignment: CrossAxisAlignment.start,
  //                         children: [
  //                           Container(
  //                             padding: EdgeInsets.only(left: 10, top: 10),
  //                             child: Container(
  //                               height: 120, //150
  //                               width: 110, //120
  //                               child: Hero(
  //                                 tag: heroId,
  //                                 child: Stack(
  //                                   children: [
  //                                     ClipRRect(
  //                                       borderRadius: BorderRadius.all(
  //                                           Radius.circular(10)),
  //                                       child: !_validURL ? shimmerEffectErrorWidget(iconSize: 50) : FancyShimmerImage(
  //                                         imageUrl: item.thumbnail,
  //                                         boxFit: BoxFit.cover,
  //                                         shimmerBaseColor: AppThemePreferences().appTheme.shimmerEffectBaseColor,
  //                                         shimmerHighlightColor: AppThemePreferences().appTheme.shimmerEffectHighLightColor,
  //                                         errorWidget: shimmerEffectErrorWidget(iconSize: 50),),
  //                                     ),
  //                                     Positioned.fill(
  //                                       child: Material(
  //                                         color: Colors.transparent,
  //                                         child: InkWell(
  //                                           borderRadius: BorderRadius.all(
  //                                               Radius.circular(10)),
  //                                           onTap: () {
  //                                             navigateToRealtorInfoPage(
  //                                               buildContext: context,
  //                                               agentType: agentDisplayOption,
  //                                               heroId: heroId,
  //                                               realtorInfo: isAgent
  //                                                   ? {
  //                                                 AGENT_DATA: item,
  //                                               }
  //                                                   : {
  //                                                 AGENCY_DATA: item,
  //                                               },
  //                                             );
  //                                           },
  //                                         ),
  //                                       ),
  //                                     ),
  //                                   ],
  //                                 ),
  //                               ),
  //                             ),
  //                           ),
  //                           Expanded(
  //                             child: Container(
  //                               padding: EdgeInsets.fromLTRB(10, 10, 0, 10),
  //                               child: Column(
  //                                 mainAxisAlignment:
  //                                 MainAxisAlignment.spaceEvenly,
  //                                 crossAxisAlignment: CrossAxisAlignment.start,
  //                                 children: [
  //                                   InkWell(
  //                                     borderRadius:
  //                                     BorderRadius.all(Radius.circular(10)),
  //                                     onTap: () {
  //                                       navigateToRealtorInfoPage(
  //                                         buildContext: context,
  //                                         agentType: agentDisplayOption,
  //                                         heroId: heroId,
  //                                         realtorInfo: isAgent
  //                                             ? {
  //                                           AGENT_DATA: item,
  //                                         }
  //                                             : {
  //                                           AGENCY_DATA: item,
  //                                         },
  //                                       );
  //                                     },
  //                                     child: Row(
  //                                       children: [
  //                                         Icon(AppThemePreferences.personIcon),
  //                                         Expanded(
  //                                           child: Padding(
  //                                             padding: const EdgeInsets.only(
  //                                                 left: 10),
  //                                             child: genericTextWidget(
  //                                               item.title,
  //                                               maxLines: 1,
  //                                               overflow: TextOverflow.ellipsis,
  //                                               strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                               style: AppThemePreferences().appTheme.subBody01TextStyle,
  //                                               // style: AppThemePreferences().appTheme.body01TextStyle,
  //                                             ),
  //                                           ),
  //                                         ),
  //                                       ],
  //                                     ),
  //                                   ),
  //                                   tempRealtorPhone == null ||
  //                                       tempRealtorPhone.isEmpty
  //                                       ? Container()
  //                                       : InkWell(
  //                                     borderRadius: BorderRadius.all(
  //                                         Radius.circular(10)),
  //                                     onTap: () {
  //                                       launch("tel://$tempRealtorPhone");
  //                                     },
  //                                     child: Row(
  //                                       children: [
  //                                         Icon(AppThemePreferences
  //                                             .callIcon),
  //                                         Expanded(
  //                                           child: Padding(
  //                                             padding:
  //                                             const EdgeInsets.only(
  //                                                 left: 10),
  //                                             child: genericTextWidget(
  //                                               tempRealtorPhone,
  //                                               strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                               style:
  //                                               AppThemePreferences()
  //                                                   .appTheme
  //                                                   .subBody01TextStyle,
  //                                             ),
  //                                           ),
  //                                         ),
  //                                       ],
  //                                     ),
  //                                   ),
  //                                   tempRealtorMobile == null ||
  //                                       tempRealtorMobile.isEmpty
  //                                       ? Container()
  //                                       : InkWell(
  //                                     borderRadius: BorderRadius.all(
  //                                         Radius.circular(10)),
  //                                     onTap: () {
  //                                       launch(
  //                                           "tel://$tempRealtorMobile");
  //                                     },
  //                                     child: Row(
  //                                       children: [
  //                                         Icon(AppThemePreferences
  //                                             .phoneAndroidIcon),
  //                                         Expanded(
  //                                           child: Padding(
  //                                             padding:
  //                                             const EdgeInsets.only(
  //                                                 left: 10),
  //                                             child: genericTextWidget(
  //                                               tempRealtorMobile,
  //                                               strutStyle: StrutStyle(height: AppThemePreferences.genericTextHeight),
  //                                               style:
  //                                               AppThemePreferences()
  //                                                   .appTheme
  //                                                   .subBody01TextStyle,
  //                                             ),
  //                                           ),
  //                                         ),
  //                                       ],
  //                                     ),
  //                                   ),
  //                                 ],
  //                               ),
  //                             ),
  //                           ),
  //                         ],
  //                       ),
  //                     ),
  //                   ),
  //                 );
  //               }).toList(),
  //             ),
  //           ],
  //         );
  //       } else if (articleSnapshot.hasError) {
  //         return Container();
  //       }
  //       return Container();
  //       // return loadingWidgetForRealtorInfo();
  //     },
  //   );
  // }
  //
  // Widget showButtonGridWidget() {
  //   return Container(
  //     padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
  //     child: Column(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: [
  //         Row(
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             Expanded(
  //               flex: 8,
  //               child: inquireAboutPropertyElevatedButtonWidget(),
  //             ),
  //             Expanded(
  //               flex: 1,
  //               child: Container(),
  //             ),
  //             Expanded(
  //               flex: 8,
  //               child: scheduleATourElevatedButtonWidget(),
  //             ),
  //           ],
  //         ),
  //         Padding(
  //           padding: const EdgeInsets.only(top: 0),
  //           child: Row(
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             children: [
  //               Expanded(
  //                 flex: 8,
  //                 child: showYoutubeVideoButtonWidget(),
  //               ),
  //               Expanded(
  //                 flex: 1,
  //                 child: Container(),
  //               ),
  //               Expanded(
  //                 flex: 8,
  //                 child: virtualTourElevatedButtonWidget(),
  //               ),
  //             ],
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }
  //
  // Widget inquireAboutPropertyElevatedButtonWidget() {
  //   return Container(
  //     padding: EdgeInsets.symmetric(vertical: 5),
  //     alignment: Alignment.center,
  //     child: lightButtonWidget(
  //
  //       text: AppLocalizations.of(context).enquire_info,
  //       icon: Icon(
  //         AppThemePreferences.emailIcon,
  //         color: AppThemePreferences().appTheme.selectedItemTextColor,
  //       ),
  //       onPressed: () {
  //         if(agentDisplayOption == null || agentDisplayOption.isEmpty){
  //           // if (tempRealtorId == null ||
  //           //     tempRealtorName.isEmpty ||
  //           //     tempRealtorEmail.isEmpty ||
  //           //     agentDisplayOption.isEmpty ||
  //           //     tempRealtorThumbnail.isEmpty ||
  //           //     _article.id == null) {
  //           _showToastWhileDataLoading(
  //               context,
  //               AppLocalizations.of(context).please_wait_data_is_loading,
  //               false);
  //         } else {
  //           Navigator.push(
  //             context,
  //             MaterialPageRoute(
  //               builder: (context) => SendEmailToRealtor(
  //                 informationMap: {
  //                   SEND_EMAIL_APP_BAR_TITLE:
  //                   AppLocalizations.of(context).enquire_information,
  //                   SEND_EMAIL_REALTOR_ID: tempRealtorId,
  //                   SEND_EMAIL_REALTOR_NAME: tempRealtorName,
  //                   SEND_EMAIL_REALTOR_EMAIL: tempRealtorEmail,
  //                   SEND_EMAIL_REALTOR_TYPE: agentDisplayOption,
  //                   SEND_EMAIL_MESSAGE:AppLocalizations.of(context).hello_i_am_interested_in(GenericMethods.stripHtmlIfNeeded(_article.title),_articleLink,tempRealtorLink),
  //                   SEND_EMAIL_THUMBNAIL: tempRealtorThumbnail,
  //                   SEND_EMAIL_SITE_NAME: APP_NAME,
  //                   SEND_EMAIL_LISTING_ID: _article.id,
  //                 },
  //               ),
  //             ),
  //           );
  //         }
  //       },
  //     ),
  //   );
  // }
  //
  // Widget scheduleATourElevatedButtonWidget() {
  //   return Container(
  //     padding: EdgeInsets.symmetric(vertical: 5),
  //     alignment: Alignment.center,
  //     child: lightButtonWidget(
  //       text: AppLocalizations.of(context).setup_tour,
  //       icon: Icon(
  //         AppThemePreferences.dateRangeIcon,
  //         color: AppThemePreferences().appTheme.selectedItemTextColor,
  //         // color: AppThemePreferences.filledButtonIconColor,
  //       ),
  //       onPressed: () {
  //         if (tempRealtorId == null ||
  //             tempRealtorEmail.isEmpty ||
  //             _article.id == null) {
  //           _showToastWhileDataLoading(
  //               context,
  //               AppLocalizations.of(context).please_wait_data_is_loading,
  //               false);
  //         } else {
  //           Navigator.push(
  //             context,
  //             MaterialPageRoute(
  //               builder: (context) => ScheduleTour(
  //                 agentId: tempRealtorId,
  //                 agentEmail: tempRealtorEmail,
  //                 propertyId: _article.id,
  //                 propertyTitle: GenericMethods.stripHtmlIfNeeded(_article.title),
  //                 propertyPermalink: _article.link,
  //               ),
  //             ),
  //           );
  //         }
  //       },
  //     ),
  //   );
  // }
  //
  // Widget showYoutubeVideoButtonWidget() {
  //   return articleYoutubeVideoLink != null && articleYoutubeVideoLink.isNotEmpty
  //       ? Container(
  //     alignment: Alignment.center,
  //     padding: EdgeInsets.symmetric(vertical: 5),
  //     child: lightButtonWidget(
  //       text: AppLocalizations.of(context).watch_video,
  //       icon: Icon(
  //         AppThemePreferences.movieIcon,
  //         color: AppThemePreferences().appTheme.selectedItemTextColor,
  //       ),
  //       onPressed: () async {
  //         if(isInternetConnected){
  //           var urlIsLaunchAble = await canLaunch(articleYoutubeVideoLink);
  //           if (urlIsLaunchAble) {
  //             await launch(articleYoutubeVideoLink);
  //           } else {
  //             print("URL can't be launched.");
  //           }
  //         }
  //       },
  //     ),
  //   )
  //       : Container();
  // }
  //
  // Widget virtualTourElevatedButtonWidget() {
  //   return articleVirtualTourLink != null && articleVirtualTourLink.isNotEmpty
  //       ? Container(
  //     alignment: Alignment.center,
  //     padding: EdgeInsets.symmetric(vertical: 5),
  //     child: lightButtonWidget(
  //       text: AppLocalizations.of(context).virtual_tour_capital,
  //       icon: Icon(
  //         AppThemePreferences.smartDisplayIcon,
  //         color: AppThemePreferences().appTheme.selectedItemTextColor,
  //       ),
  //       onPressed: () async {
  //         Navigator.push(
  //           context,
  //           MaterialPageRoute(
  //             builder: (context) => VirtualTour(articleVirtualTourLink),
  //           ),
  //         );
  //       },
  //     ),
  //   )
  //       : Container();
  // }
  //
  // Widget relatedPosts(Future<List<dynamic>> relatedArticles) {
  //   return FutureBuilder<List<dynamic>>(
  //     future: relatedArticles,
  //     builder: (context, articleSnapshot) {
  //       if (articleSnapshot.hasData) {
  //         if (articleSnapshot.data.length == 0) return Container();
  //         ArticleBoxDesign _articleBoxDesign = ArticleBoxDesign();
  //         return Column(
  //           children: <Widget>[
  //             textHeadingWidget(text: AppLocalizations.of(context).related_properties),
  //             Column(
  //               children: articleSnapshot.data.map((item) {
  //                 final heroId = item.id.toString() + RELATED;
  //                 return _articleBoxDesign.getArticleBoxDesign(
  //                   design: RELATED_PROPERTIES_DESIGN,
  //                   buildContext: context,
  //                   article: item,
  //                   heroId: heroId,
  //                   onTap: () {
  //                     Navigator.push(
  //                       context,
  //                       MaterialPageRoute(
  //                         builder: (context) => PropertyDetailsPage(
  //                           article: item,
  //                           propertyID: item.id,
  //                           heroId: heroId,
  //                         ),
  //                       ),
  //                     );
  //                   },
  //                 );
  //               }).toList(),
  //             ),
  //             SizedBox(
  //               height: 24,
  //             )
  //           ],
  //         );
  //       } else if (articleSnapshot.hasError) {
  //         return Container();
  //       }
  //       return Container();
  //       // return loadingWidgetForRelatedProperties();
  //     },
  //   );
  // }

  Widget loadingIndicatorWidget() {
    return Container(
      alignment: Alignment.center,
      child: SizedBox(
        width: 80,
        height: 20,
        child: LoadingIndicator(
          indicatorType: Indicator.ballBeat,
          colors: [AppThemePreferences().appTheme.primaryColor],
        ),
      ),
    );
  }

  Widget noResultFoundPage() {
    return noResultErrorWidget(
      context,
      headerErrorText: GenericMethods.getLocalizedString("no_result_found"),
      bodyErrorText:
      GenericMethods.getLocalizedString("no_properties_error_message_search_by_id"),
      showBackNavigationIcon: true,
    );
  }

  _showToastWhileDataLoading(BuildContext context, String msg, bool forLogin) {
    !forLogin
        ? toastWidget(
      buildContext: context,
      text: msg,
    )
        : toastWidget(
      buildContext: context,
      showButton: true,
      buttonText: GenericMethods.getLocalizedString("login"),
      text: msg,
      toastDuration: 4,
      onButtonPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => UserSignIn(
                  (String closeOption) {
                if (closeOption == CLOSE) {
                  Navigator.pop(context);
                }
              },
            ),
          ),
        );
      },
    );
  }

  void navigateToAddReviewPage() {
    isLoggedIn
        ? Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddReview(
          listingId: widget.propertyID,
          listingTitle: _article.title,
          reviewPostType: _article.type,
          permaLink: _article.link,
        ),
      ),
    )
        : _showToastWhileDataLoading(
      context,
      GenericMethods.getLocalizedString("you_must_login") + GenericMethods.getLocalizedString("before_leaving_a_review"),
      true,
    );
  }

  void clearData(){
    // relatedArticles.clear();
    // singleArticle.clear();
    // singleRentalArticle.clear();
    // singleAgentInfoList.clear();
    // singleAgencyInfoList.clear();
    // propertiesByAgentList.clear();
    // floorPlansList.clear();
    // internalFeaturesList.clear();
    // externalFeaturesList.clear();
    // heatingAndCoolingFeaturesList.clear();
    // featuresWithoutValuesList.clear();
    // featuresList.clear();
    // //imageUrlsList.clear();
    // agentList.clear();
    // agencyList.clear();
  }
}
